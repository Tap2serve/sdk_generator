/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RoleDTO = {
    id?: number;
    uuid?: string;
    name: string;
    type: RoleDTO.type;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

export namespace RoleDTO {

    export enum type {
        PATIENT = 'PATIENT',
        PROVIDER = 'PROVIDER',
        STAFF = 'STAFF',
    }


}

