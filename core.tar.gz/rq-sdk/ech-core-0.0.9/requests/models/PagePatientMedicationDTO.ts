/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PageableObject } from './PageableObject';
import type { PatientMedicationDTO } from './PatientMedicationDTO';
import type { SortObject } from './SortObject';

export type PagePatientMedicationDTO = {
    totalPages?: number;
    totalElements?: number;
    size?: number;
    content?: Array<PatientMedicationDTO>;
    number?: number;
    sort?: SortObject;
    numberOfElements?: number;
    pageable?: PageableObject;
    first?: boolean;
    last?: boolean;
    empty?: boolean;
};

