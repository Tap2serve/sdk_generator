/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserDTO } from './UserDTO';

export type UserProfileDTO = {
    id?: number;
    uuid?: string;
    phone: string;
    emailVerified?: boolean;
    phoneVerified?: boolean;
    isArchive?: boolean;
    iamId?: string;
    tenantKey?: string;
    lastLogin?: string;
    role?: string;
    roleType?: UserProfileDTO.roleType;
    internalUser?: UserDTO;
};

export namespace UserProfileDTO {

    export enum roleType {
        PATIENT = 'PATIENT',
        PROVIDER = 'PROVIDER',
        STAFF = 'STAFF',
    }


}

