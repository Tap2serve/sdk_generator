/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CountryDTO = {
    id?: number;
    uuid?: string;
    state: string;
    country: string;
    stateIso: string;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
};

