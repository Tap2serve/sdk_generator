/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { SpecialityDTO } from './SpecialityDTO';

export type PhysicalExamTemplateDTO = {
    id?: number;
    uuid?: string;
    name: string;
    templateValue: string;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    specialities?: Array<SpecialityDTO>;
};

