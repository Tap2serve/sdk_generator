/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type LanguageDTO = {
    id?: number;
    uuid?: string;
    name: string;
    createdAt?: string;
    modifiedAt?: string;
};

