/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ProviderDTO } from './ProviderDTO';

export type FeeScheduleDTO = {
    id?: number;
    uuid?: string;
    codeType?: FeeScheduleDTO.codeType;
    procedureCode?: string;
    modifier?: string;
    ndcCode?: string;
    amount?: number;
    ndcQuantity?: number;
    note?: string;
    isActive?: boolean;
    isArchive?: boolean;
    providerId?: ProviderDTO;
};

export namespace FeeScheduleDTO {

    export enum codeType {
        CPT = 'CPT',
        HCPCS = 'HCPCS',
    }


}

