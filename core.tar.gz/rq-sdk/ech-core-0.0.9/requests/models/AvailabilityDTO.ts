/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { LocationDTO } from './LocationDTO';
import type { ProviderDTO } from './ProviderDTO';

export type AvailabilityDTO = {
    id?: number;
    uuid?: string;
    bookingWindow: number;
    timezone: string;
    lastSetting: number;
    inpersonInitialConsultTime?: number;
    inpersonFollowupConsultTime?: number;
    inpersonThresholdBookingtime?: number;
    inpersonBookingIntervalTime?: number;
    virtualInitialConsultTime?: number;
    virtualFollowupConsultTime?: number;
    virtualThresholdBookingTime?: number;
    virtualBookingIntervalTime?: number;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    providerId?: ProviderDTO;
    locationId?: LocationDTO;
};

