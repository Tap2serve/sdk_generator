/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';
import type { PracticeHoursDTO } from './PracticeHoursDTO';
import type { SpecialityDTO } from './SpecialityDTO';

export type ProviderGroupDTO = {
    id?: number;
    uuid?: string;
    name: string;
    description?: string;
    npi: string;
    avatar?: string;
    email: string;
    phone: string;
    website?: string;
    fax?: string;
    schema?: string;
    iamGroup?: string;
    subdomain?: string;
    isActive?: boolean;
    isArchive?: boolean;
    providerCount?: number;
    patientCount?: number;
    appointmentCount?: number;
    encounterCount?: number;
    addressCheckBox?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    physicalAddressId: AddressDTO;
    billingAddressId: AddressDTO;
    specialities?: Array<SpecialityDTO>;
    practiceHours?: Array<PracticeHoursDTO>;
};

