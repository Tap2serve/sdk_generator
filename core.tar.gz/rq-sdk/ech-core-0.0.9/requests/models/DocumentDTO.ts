/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type DocumentDTO = {
    id?: number;
    uuid?: string;
    type: string;
    recordedDate?: string;
    description: string;
    url: string;
    isActive?: boolean;
    approved: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    patientId?: PatientDTO;
};

