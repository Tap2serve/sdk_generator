/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';
import type { InsuranceDTO } from './InsuranceDTO';

export type InsurancePolicyHolderDTO = {
    id?: number;
    firstName?: string;
    lastName?: string;
    dob?: string;
    gender?: string;
    ssn: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    addressId?: AddressDTO;
    insuranceId?: InsuranceDTO;
};

