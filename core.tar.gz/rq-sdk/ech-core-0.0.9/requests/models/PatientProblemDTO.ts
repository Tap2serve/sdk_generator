/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientProblemDTO = {
    id?: number;
    uuid?: string;
    name: string;
    isActive?: boolean;
    type: string;
    dignosedDate: string;
    note?: string;
    approved: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

