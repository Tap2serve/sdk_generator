/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AvailabilityDTO } from './AvailabilityDTO';

export type ProviderAvailabilityDTO = {
    id?: number;
    uuid?: string;
    weekDay: string;
    openingTime?: string;
    closingTime?: string;
    availabilityId?: AvailabilityDTO;
};

