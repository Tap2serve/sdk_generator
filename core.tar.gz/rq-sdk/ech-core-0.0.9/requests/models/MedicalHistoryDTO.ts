/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type MedicalHistoryDTO = {
    id?: number;
    uuid?: string;
    conditionName: string;
    date: string;
    note?: string;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    patientId?: PatientDTO;
};

