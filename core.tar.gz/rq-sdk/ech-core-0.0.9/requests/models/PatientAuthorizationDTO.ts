/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientAuthorizationDTO = {
    id?: number;
    uuid?: string;
    authorizationNumber: string;
    effectiveStartDate?: string;
    effectiveEndDate?: string;
    numberOfVisit: number;
    procedureCode: string;
    speciality?: number;
    visitRemaining?: string;
    note?: string;
    patientId?: PatientDTO;
};

