/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { SpecialityDTO } from './SpecialityDTO';

export type DrugDTO = {
    id?: number;
    uuid?: string;
    type?: DrugDTO.type;
    medicine: string;
    dose: string;
    when: string;
    where: string;
    frequency: string;
    duration: string;
    quantity: number;
    instruction: number;
    source?: number;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    specialityId?: SpecialityDTO;
};

export namespace DrugDTO {

    export enum type {
        TAB = 'TAB',
        SOL = 'SOL',
    }


}

