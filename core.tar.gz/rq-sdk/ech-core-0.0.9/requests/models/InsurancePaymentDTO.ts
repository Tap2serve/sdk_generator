/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { InsurancePayerDTO } from './InsurancePayerDTO';
import type { PatientDTO } from './PatientDTO';
import type { PatientPaymentDTO } from './PatientPaymentDTO';

export type InsurancePaymentDTO = {
    id?: number;
    uuid?: string;
    paymentMode: string;
    paymentMethod: string;
    transactionId: string;
    transactionAmount: number;
    transactionDate: string;
    appliedAmount: number;
    unappliedAmount: number;
    note?: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    payerId?: InsurancePayerDTO;
    patientId?: PatientDTO;
    paymentId?: PatientPaymentDTO;
};

