/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type IamUserDTO = {
    id?: number;
    iamId?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    role: string;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    active?: boolean;
};

