/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { InsurancePayerDTO } from './InsurancePayerDTO';
import type { InsurancePolicyHolderDTO } from './InsurancePolicyHolderDTO';
import type { PatientDTO } from './PatientDTO';

export type InsuranceDTO = {
    id?: number;
    type: InsuranceDTO.type;
    memberId: string;
    planId: string;
    groupId: string;
    groupName: string;
    copay: number;
    relationshipWithHolder: InsuranceDTO.relationshipWithHolder;
    cardFrontSide: string;
    cardBackSide: string;
    payerPhoneNumber: string;
    payerFaxNumber: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    payerId?: InsurancePayerDTO;
    patient?: PatientDTO;
    insurancePolicyHolder?: InsurancePolicyHolderDTO;
};

export namespace InsuranceDTO {

    export enum type {
        PRIMARY = 'PRIMARY',
        SECONDARY = 'SECONDARY',
        OTHER = 'OTHER',
    }

    export enum relationshipWithHolder {
        SELF = 'SELF',
        CHILD = 'CHILD',
        GRANDCHILD = 'GRANDCHILD',
        SPOUSE = 'SPOUSE',
    }


}

