/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientAllergyDTO } from './PatientAllergyDTO';

export type IntakeAllergyDTO = {
    id?: number;
    uuid?: string;
    name: string;
    criticality: string;
    reaction: string;
    severity: string;
    onSetDate: string;
    isActive?: boolean;
    note?: string;
    allergyIds?: Array<PatientAllergyDTO>;
    intakeFormIds?: Array<IntakeFormDTO>;
};

