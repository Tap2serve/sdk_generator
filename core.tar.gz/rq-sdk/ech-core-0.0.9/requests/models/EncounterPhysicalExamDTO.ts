/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EncounterDTO } from './EncounterDTO';

export type EncounterPhysicalExamDTO = {
    id?: number;
    uuid?: string;
    name: string;
    encounterValue: string;
    isarchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    encounterId?: EncounterDTO;
};

