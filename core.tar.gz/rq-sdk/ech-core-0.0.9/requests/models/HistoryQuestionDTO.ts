/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type HistoryQuestionDTO = {
    id?: number;
    uuid?: string;
    question: string;
    type: string;
};

