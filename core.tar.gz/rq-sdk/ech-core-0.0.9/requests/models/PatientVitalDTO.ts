/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientVitalDTO = {
    id?: number;
    uuid?: string;
    name: string;
    vitalValue: string;
    unit: string;
    type: string;
    notes?: string;
    recordedDate?: string;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

