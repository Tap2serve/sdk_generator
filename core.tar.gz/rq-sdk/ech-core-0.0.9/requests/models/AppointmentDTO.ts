/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { InsuranceDTO } from './InsuranceDTO';
import type { IntakeFormDTO } from './IntakeFormDTO';
import type { LocationDTO } from './LocationDTO';
import type { PatientDTO } from './PatientDTO';
import type { ProviderDTO } from './ProviderDTO';
import type { SpecialityDTO } from './SpecialityDTO';

export type AppointmentDTO = {
    id?: number;
    uuid?: string;
    type?: AppointmentDTO.type;
    startTime?: string;
    endTime?: string;
    mode?: AppointmentDTO.mode;
    room?: string;
    paymentType?: AppointmentDTO.paymentType;
    reason?: string;
    note?: string;
    status?: AppointmentDTO.status;
    duration?: number;
    timezone?: string;
    cancelReason?: string;
    patientId?: PatientDTO;
    specialityId?: SpecialityDTO;
    locationId?: LocationDTO;
    providerId?: ProviderDTO;
    primaryInsurance?: InsuranceDTO;
    secondaryInsurance?: InsuranceDTO;
    intakeForm?: IntakeFormDTO;
    rescheduledId?: AppointmentDTO;
};

export namespace AppointmentDTO {

    export enum type {
        NEW = 'NEW',
        FOLLOWUP = 'FOLLOWUP',
    }

    export enum mode {
        INPERSON = 'INPERSON',
        VIRTUAL = 'VIRTUAL',
    }

    export enum paymentType {
        CASH = 'CASH',
        CARD = 'CARD',
        BANK = 'BANK',
    }

    export enum status {
        SCHEDULED = 'SCHEDULED',
        CHECK_IN = 'CHECK_IN',
        EXAM_ROOM = 'EXAM_ROOM',
        IN_ROOM_INTAKE = 'IN_ROOM_INTAKE',
        COMPLETED = 'COMPLETED',
        CANCELLED = 'CANCELLED',
        WAITING_ROOM = 'WAITING_ROOM',
    }


}

