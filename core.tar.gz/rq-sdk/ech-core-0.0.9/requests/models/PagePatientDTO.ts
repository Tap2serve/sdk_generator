/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PageableObject } from './PageableObject';
import type { PatientDTO } from './PatientDTO';
import type { SortObject } from './SortObject';

export type PagePatientDTO = {
    totalPages?: number;
    totalElements?: number;
    size?: number;
    content?: Array<PatientDTO>;
    number?: number;
    sort?: SortObject;
    numberOfElements?: number;
    pageable?: PageableObject;
    first?: boolean;
    last?: boolean;
    empty?: boolean;
};

