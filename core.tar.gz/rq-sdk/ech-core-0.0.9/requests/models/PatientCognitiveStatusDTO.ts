/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { HistoryQuestionDTO } from './HistoryQuestionDTO';
import type { PatientDTO } from './PatientDTO';

export type PatientCognitiveStatusDTO = {
    id?: number;
    uuid?: string;
    answer: string;
    title?: string;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    question?: HistoryQuestionDTO;
    patientId?: PatientDTO;
};

