/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserProfileDTO } from './UserProfileDTO';

export type NotificationDTO = {
    id?: number;
    uuid?: string;
    date: string;
    title: string;
    message: string;
    consumed: boolean;
    type: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    receipient?: UserProfileDTO;
};

