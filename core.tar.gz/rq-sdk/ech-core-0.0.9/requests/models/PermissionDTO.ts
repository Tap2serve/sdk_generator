/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type PermissionDTO = {
    id?: number;
    uuid?: string;
    name: string;
    description?: string;
    module: string;
    permissionKey: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

