/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientPermissionDTO = {
    id?: number;
    uuid?: string;
    patientPermissionKey: string;
    status: string;
    patientIds?: Array<PatientDTO>;
};

