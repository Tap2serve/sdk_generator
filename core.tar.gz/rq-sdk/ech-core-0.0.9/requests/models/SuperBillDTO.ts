/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EncounterDTO } from './EncounterDTO';
import type { InsuranceClaimDTO } from './InsuranceClaimDTO';

export type SuperBillDTO = {
    id?: number;
    uuid?: string;
    billId: string;
    servicePlace: string;
    serviceDate?: string;
    quantity: number;
    totalCharges: number;
    advancePay: number;
    patientBalance: number;
    insuranceBalance: number;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    encounterId?: EncounterDTO;
    insuranceClaim?: InsuranceClaimDTO;
};

