/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';
import type { DiagnosticCentreDTO } from './DiagnosticCentreDTO';
import type { InsuranceDTO } from './InsuranceDTO';
import type { LocationDTO } from './LocationDTO';
import type { PharmacyStoreDTO } from './PharmacyStoreDTO';
import type { ProviderDTO } from './ProviderDTO';
import type { UserProfileDTO } from './UserProfileDTO';

export type PatientDTO = {
    id?: number;
    uuid?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    imageUrl?: string;
    mrn: string;
    firstNameUsed?: string;
    middleName: string;
    motherName?: string;
    birthDate: string;
    gender: PatientDTO.gender;
    maritalStatus?: PatientDTO.maritalStatus;
    ethnicity?: PatientDTO.ethnicity;
    race?: PatientDTO.race;
    ssn?: string;
    language?: string;
    fax?: string;
    emergContactFirstName?: string;
    emergContactLastName?: string;
    emergContactRelation?: PatientDTO.emergContactRelation;
    emergContactNumber?: string;
    emergContactEmail?: string;
    messageConsent?: boolean;
    callConsent?: boolean;
    emailConsent?: boolean;
    note?: string;
    source?: string;
    lastVisit?: string;
    balance?: number;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    addressId?: AddressDTO;
    defaultLocationId?: LocationDTO;
    primaryProviderId?: ProviderDTO;
    preferredPharmacy?: PharmacyStoreDTO;
    preferredLabs?: DiagnosticCentreDTO;
    preferredRadiology?: DiagnosticCentreDTO;
    userId?: UserProfileDTO;
    insurances?: Array<InsuranceDTO>;
    providerGroupId?: string;
    archive?: boolean;
    active?: boolean;
};

export namespace PatientDTO {

    export enum gender {
        MALE = 'MALE',
        FEMALE = 'FEMALE',
        OTHER = 'OTHER',
    }

    export enum maritalStatus {
        MARRIED = 'MARRIED',
        SINGLE = 'SINGLE',
        DIVORCED = 'DIVORCED',
        WIDOWED = 'WIDOWED',
    }

    export enum ethnicity {
        AFRICAN_AMERICAN = 'AFRICAN_AMERICAN',
        ASIAN = 'ASIAN',
    }

    export enum race {
        AFRICAN_AMERICAN = 'AFRICAN_AMERICAN',
        ASIAN = 'ASIAN',
    }

    export enum emergContactRelation {
        SELF = 'SELF',
        CHILD = 'CHILD',
        SPOUSE = 'SPOUSE',
    }


}

