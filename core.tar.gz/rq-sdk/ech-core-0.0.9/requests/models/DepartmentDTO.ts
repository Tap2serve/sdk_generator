/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserProfileDTO } from './UserProfileDTO';

export type DepartmentDTO = {
    id?: number;
    uuid?: string;
    deptId: string;
    name: string;
    contact?: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    adminId?: UserProfileDTO;
};

