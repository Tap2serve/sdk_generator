/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';

export type DiagnosticCentreDTO = {
    id?: number;
    uuid?: string;
    type: DiagnosticCentreDTO.type;
    name: string;
    contactNumber: string;
    faxNumber: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    address?: AddressDTO;
};

export namespace DiagnosticCentreDTO {

    export enum type {
        LAB = 'LAB',
        RADIOLOGY = 'RADIOLOGY',
    }


}

