/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientMedicationDTO } from './PatientMedicationDTO';
import type { ProviderDTO } from './ProviderDTO';

export type IntakeMedicationDTO = {
    id?: number;
    uuid?: string;
    name: string;
    quantity: string;
    unit: string;
    when: string;
    dose: string;
    startDate: string;
    endDate: string;
    note?: string;
    isActive?: boolean;
    prescribedBy?: ProviderDTO;
    intakeFormIds?: Array<IntakeFormDTO>;
    medicationIds?: Array<PatientMedicationDTO>;
};

