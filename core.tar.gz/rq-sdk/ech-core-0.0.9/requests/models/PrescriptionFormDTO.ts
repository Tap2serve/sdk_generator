/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { MedicationDTO } from './MedicationDTO';
import type { PatientDTO } from './PatientDTO';

export type PrescriptionFormDTO = {
    id?: number;
    uuid?: string;
    type: string;
    sig: string;
    quantity: string;
    unit: string;
    refill: string;
    notesForPharmacy: string;
    startDate: string;
    endDate: string;
    dispenseAsWritten: boolean;
    isPermanent: boolean;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    medicationId?: MedicationDTO;
    patientId?: PatientDTO;
};

