/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientDTO } from './PatientDTO';
import type { PatientFamilyHistoryDTO } from './PatientFamilyHistoryDTO';

export type IntakePatientFamilyHistoryDTO = {
    id?: number;
    uuid?: string;
    name: string;
    relation: string;
    onsetAge: number;
    alive: boolean;
    note: string;
    patientId?: PatientDTO;
    intakeFormIds?: Array<IntakeFormDTO>;
    familyHistoryIds?: Array<PatientFamilyHistoryDTO>;
};

