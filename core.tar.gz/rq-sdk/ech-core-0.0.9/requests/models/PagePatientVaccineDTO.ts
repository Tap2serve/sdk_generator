/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PageableObject } from './PageableObject';
import type { PatientVaccineDTO } from './PatientVaccineDTO';
import type { SortObject } from './SortObject';

export type PagePatientVaccineDTO = {
    totalPages?: number;
    totalElements?: number;
    size?: number;
    content?: Array<PatientVaccineDTO>;
    number?: number;
    sort?: SortObject;
    numberOfElements?: number;
    pageable?: PageableObject;
    first?: boolean;
    last?: boolean;
    empty?: boolean;
};

