/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';

export type PharmacyStoreDTO = {
    id?: number;
    uuid?: string;
    name: string;
    contactNumber: string;
    faxNumber: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    addressId?: AddressDTO;
};

