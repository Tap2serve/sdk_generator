/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientAllergyDTO = {
    id?: number;
    uuid?: string;
    name: string;
    criticality: string;
    reaction: string;
    severity: string;
    onSetDate?: string;
    isActive?: boolean;
    note?: string;
    approved: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

