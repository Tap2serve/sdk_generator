/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SortObject = {
    empty?: boolean;
    unsorted?: boolean;
    sorted?: boolean;
};

