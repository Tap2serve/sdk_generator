/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PermissionDTO } from './PermissionDTO';
import type { RoleDTO } from './RoleDTO';

export type RolePermissionDTO = {
    id?: number;
    uuid?: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    roleIds?: Array<RoleDTO>;
    permissionIds?: Array<PermissionDTO>;
};

