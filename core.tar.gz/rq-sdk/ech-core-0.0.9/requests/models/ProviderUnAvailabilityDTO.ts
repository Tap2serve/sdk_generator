/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AvailabilityDTO } from './AvailabilityDTO';

export type ProviderUnAvailabilityDTO = {
    id?: number;
    uuid?: string;
    startTime?: string;
    endTime?: string;
    availabilityId?: AvailabilityDTO;
};

