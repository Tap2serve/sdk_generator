/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PageableObject } from './PageableObject';
import type { SortObject } from './SortObject';
import type { UserProfileDTO } from './UserProfileDTO';

export type PageUserProfileDTO = {
    totalPages?: number;
    totalElements?: number;
    size?: number;
    content?: Array<UserProfileDTO>;
    number?: number;
    sort?: SortObject;
    numberOfElements?: number;
    pageable?: PageableObject;
    first?: boolean;
    last?: boolean;
    empty?: boolean;
};

