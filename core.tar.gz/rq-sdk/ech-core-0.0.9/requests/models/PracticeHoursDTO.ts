/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ProviderGroupDTO } from './ProviderGroupDTO';

export type PracticeHoursDTO = {
    id?: number;
    uuid?: string;
    weekDay: string;
    openingTime: string;
    closingTime: string;
    providerGroup?: ProviderGroupDTO;
};

