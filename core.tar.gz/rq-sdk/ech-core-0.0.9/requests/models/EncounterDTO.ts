/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AppointmentDTO } from './AppointmentDTO';
import type { LocationDTO } from './LocationDTO';
import type { PatientDTO } from './PatientDTO';
import type { ProviderDTO } from './ProviderDTO';

export type EncounterDTO = {
    id?: number;
    uuid?: string;
    status: string;
    visitType: string;
    chiefComplaint: string;
    serviceDate: string;
    note: string;
    isSigned: boolean;
    readyForBilling: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    appointmentId?: AppointmentDTO;
    patientId?: PatientDTO;
    providerId?: ProviderDTO;
    locationId?: LocationDTO;
};

