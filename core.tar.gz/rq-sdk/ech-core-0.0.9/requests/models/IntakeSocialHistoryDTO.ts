/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { HistoryQuestionDTO } from './HistoryQuestionDTO';
import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientDTO } from './PatientDTO';
import type { SocialHistoryDTO } from './SocialHistoryDTO';

export type IntakeSocialHistoryDTO = {
    id?: number;
    uuid?: string;
    answer: string;
    question?: HistoryQuestionDTO;
    patientId?: PatientDTO;
    intakeFormIds?: Array<IntakeFormDTO>;
    socialHistoryIds?: Array<SocialHistoryDTO>;
};

