/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { SuperBillDTO } from './SuperBillDTO';

export type SuperBillChargeDTO = {
    id?: number;
    uuid?: string;
    chargeType: string;
    lineItem: number;
    charges: number;
    discount: number;
    tax: number;
    net: number;
    superBillId?: SuperBillDTO;
};

