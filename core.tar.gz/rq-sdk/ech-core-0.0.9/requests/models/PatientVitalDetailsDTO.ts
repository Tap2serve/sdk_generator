/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { DetailDTO } from './DetailDTO';

export type PatientVitalDetailsDTO = {
    name?: string;
    details?: Array<DetailDTO>;
};

