/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientVaccineDTO } from './PatientVaccineDTO';

export type IntakeVaccineDTO = {
    id?: number;
    uuid?: string;
    name: string;
    administerDay: string;
    administeredBy: number;
    expiryDate: string;
    amount: number;
    unit: string;
    route: string;
    site: string;
    manufacturer: string;
    lot: string;
    intakeFormIds?: Array<IntakeFormDTO>;
    vaccineIds?: Array<PatientVaccineDTO>;
};

