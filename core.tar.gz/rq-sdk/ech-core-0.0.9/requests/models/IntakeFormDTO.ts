/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type IntakeFormDTO = {
    id?: number;
    uuid?: string;
    intakeFormName: string;
    sendDate?: string;
    dueDate?: string;
    submittedDate?: string;
    status: IntakeFormDTO.status;
    filledBy: IntakeFormDTO.filledBy;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

export namespace IntakeFormDTO {

    export enum status {
        SEND = 'SEND',
        FILLED = 'FILLED',
        COMPLETED = 'COMPLETED',
    }

    export enum filledBy {
        PATIENT = 'PATIENT',
        PROVIDER = 'PROVIDER',
    }


}

