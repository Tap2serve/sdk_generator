/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ProviderDTO } from './ProviderDTO';

export type LicensedStatesDTO = {
    id?: number;
    uuid?: string;
    state: string;
    country: string;
    provider?: ProviderDTO;
};

