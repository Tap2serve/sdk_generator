/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EncounterDTO } from './EncounterDTO';

export type EncounterDiagnosisDTO = {
    id?: number;
    uuid?: string;
    code: string;
    description: string;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    encounterId?: EncounterDTO;
};

