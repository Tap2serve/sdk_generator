/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type MedicationDTO = {
    id?: number;
    uuid?: string;
    name: string;
    strength?: string;
    type?: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

