/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EncounterDTO } from './EncounterDTO';

export type EncounterProcedureDTO = {
    id?: number;
    uuid?: string;
    code: string;
    description: string;
    type: string;
    modifier: string;
    diagnosisPointer: string;
    quantity: number;
    charges: number;
    discount: number;
    tax: number;
    net: number;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    encounterId?: EncounterDTO;
};

