/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ConsentFormTemplateDTO = {
    id?: number;
    uuid?: string;
    title: string;
    patientConsent: boolean;
    sendOnAppointment: boolean;
    formUrl: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

