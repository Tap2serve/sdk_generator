/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type NotificationSettingsDTO = {
    id?: number;
    uuid?: string;
    title?: string;
    push?: boolean;
    text?: boolean;
    email?: boolean;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

