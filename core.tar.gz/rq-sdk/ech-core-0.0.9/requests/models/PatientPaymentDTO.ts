/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientPaymentDTO = {
    id?: number;
    uuid?: string;
    paymentMode: string;
    paymentMethod: string;
    paymentId: string;
    payerName: string;
    transactionId: string;
    transactionAmount: number;
    transactionDate: string;
    source?: string;
    referenceNumber?: number;
    cardNumber?: number;
    note?: string;
    appliedAmount: number;
    unappliedAmount: number;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    patientId?: PatientDTO;
};

