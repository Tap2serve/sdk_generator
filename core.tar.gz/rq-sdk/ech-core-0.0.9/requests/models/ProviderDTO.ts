/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { InsurancePayerDTO } from './InsurancePayerDTO';
import type { SpecialityDTO } from './SpecialityDTO';
import type { UserProfileDTO } from './UserProfileDTO';

export type ProviderDTO = {
    id?: number;
    uuid?: string;
    type?: ProviderDTO.type;
    medicalCreds?: string;
    gender?: ProviderDTO.gender;
    fax?: string;
    npi: string;
    groupNpi: string;
    email: string;
    licenseNumber: string;
    experinceYears: string;
    taxonomyNumber: string;
    focusedArea: string;
    hospitalAffilation: string;
    ageGroupSeen: string;
    languagesSpoken: ProviderDTO.languagesSpoken;
    priorAuthorisation: string;
    secondOpinion: string;
    acuteSpeciality: string;
    bio?: string;
    expertise: string;
    experience: string;
    employmentRefNumber?: string;
    acceptNewPatient: boolean;
    acceptCashPay: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    userId?: UserProfileDTO;
    specialities?: Array<SpecialityDTO>;
    acceptedInsurances?: Array<InsurancePayerDTO>;
};

export namespace ProviderDTO {

    export enum type {
        MD = 'MD',
        PSYD = 'PSYD',
        LCSW = 'LCSW',
    }

    export enum gender {
        MALE = 'MALE',
        FEMALE = 'FEMALE',
        OTHER = 'OTHER',
    }

    export enum languagesSpoken {
        ENGLISH = 'ENGLISH',
        SPANISH = 'SPANISH',
        OTHER = 'OTHER',
    }


}

