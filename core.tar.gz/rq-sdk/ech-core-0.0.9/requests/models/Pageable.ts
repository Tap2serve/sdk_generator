/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type Pageable = {
    page?: number;
    size?: number;
    sort?: Array<string>;
};

