/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AssessmentTemplateDTO = {
    id?: number;
    uuid?: string;
    type?: string;
    name?: string;
    templateValue?: string;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

