/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type StaffDTO = {
    uuid?: string;
    email: string;
    firstName: string;
    lastName: string;
    contactNumber: string;
    role?: string;
    active?: boolean;
    avatar?: string;
    newAvatar?: string;
    id?: number;
};

