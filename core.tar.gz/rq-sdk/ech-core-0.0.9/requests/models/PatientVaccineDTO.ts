/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientVaccineDTO = {
    id?: number;
    uuid?: string;
    name: string;
    administerDate?: string;
    administeredby: string;
    expiryDate: string;
    amount: string;
    unit: string;
    route: string;
    site: string;
    manufacturer: string;
    lot: string;
    isActive?: boolean;
    approved: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

