/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SpecialityDTO = {
    id?: number;
    uuid?: string;
    name: string;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
};

