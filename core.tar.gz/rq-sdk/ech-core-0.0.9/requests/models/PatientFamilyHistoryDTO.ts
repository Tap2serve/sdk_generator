/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientFamilyHistoryDTO = {
    id?: number;
    uuid?: string;
    name: string;
    relation: string;
    onSetAge: number;
    alive: boolean;
    note?: string;
    isActive?: boolean;
    approved?: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

