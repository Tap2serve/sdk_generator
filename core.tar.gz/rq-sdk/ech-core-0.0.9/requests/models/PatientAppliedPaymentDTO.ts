/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientPaymentDTO } from './PatientPaymentDTO';
import type { SuperBillDTO } from './SuperBillDTO';

export type PatientAppliedPaymentDTO = {
    id?: number;
    uuid?: string;
    appliedAmount: number;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    paymentIds?: Array<PatientPaymentDTO>;
    superBillIds?: Array<SuperBillDTO>;
};

