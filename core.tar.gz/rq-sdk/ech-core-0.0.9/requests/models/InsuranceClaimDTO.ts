/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { InsurancePayerDTO } from './InsurancePayerDTO';
import type { PatientDTO } from './PatientDTO';
import type { ProviderDTO } from './ProviderDTO';

export type InsuranceClaimDTO = {
    id?: number;
    uuid?: string;
    claimAmount: number;
    claimDate?: string;
    note?: string;
    claimStatus: string;
    settledAmount: number;
    settledDate?: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    billingProviderId?: ProviderDTO;
    patientId?: PatientDTO;
    payerId?: InsurancePayerDTO;
};

