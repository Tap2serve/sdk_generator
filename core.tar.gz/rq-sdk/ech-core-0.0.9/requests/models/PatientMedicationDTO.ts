/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { MedicationDTO } from './MedicationDTO';
import type { PatientDTO } from './PatientDTO';
import type { ProviderDTO } from './ProviderDTO';

export type PatientMedicationDTO = {
    id?: number;
    uuid?: string;
    name: string;
    quantity: string;
    unit: string;
    dose: string;
    startDate: string;
    endDate: string;
    note?: string;
    isActive?: boolean;
    approved: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    prescribedBy?: ProviderDTO;
    medicationId?: MedicationDTO;
    patientId?: PatientDTO;
};

