/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PageableObject } from './PageableObject';
import type { PatientAllergyDTO } from './PatientAllergyDTO';
import type { SortObject } from './SortObject';

export type PagePatientAllergyDTO = {
    totalPages?: number;
    totalElements?: number;
    size?: number;
    content?: Array<PatientAllergyDTO>;
    number?: number;
    sort?: SortObject;
    numberOfElements?: number;
    pageable?: PageableObject;
    first?: boolean;
    last?: boolean;
    empty?: boolean;
};

