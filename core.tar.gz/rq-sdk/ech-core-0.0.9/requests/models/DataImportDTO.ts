/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ProviderGroupDTO } from './ProviderGroupDTO';

export type DataImportDTO = {
    id?: number;
    uuid?: string;
    type: DataImportDTO.type;
    records: number;
    title?: string;
    status?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    providerGroup?: ProviderGroupDTO;
};

export namespace DataImportDTO {

    export enum type {
        PATIENT = 'PATIENT',
        PROVIDER = 'PROVIDER',
        LOINC = 'LOINC',
        CPT = 'CPT',
        DRUG = 'DRUG',
        ICD = 'ICD',
        HCPCS = 'HCPCS',
    }


}

