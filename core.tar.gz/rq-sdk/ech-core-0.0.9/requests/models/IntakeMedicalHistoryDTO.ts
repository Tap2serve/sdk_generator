/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { MedicalHistoryDTO } from './MedicalHistoryDTO';

export type IntakeMedicalHistoryDTO = {
    id?: number;
    uuid?: string;
    answer: string;
    medicalHistoryIds?: Array<MedicalHistoryDTO>;
    intakeFormIds?: Array<IntakeFormDTO>;
};

