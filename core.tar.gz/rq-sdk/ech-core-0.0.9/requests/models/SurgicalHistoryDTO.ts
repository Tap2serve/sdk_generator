/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type SurgicalHistoryDTO = {
    id?: number;
    uuid?: string;
    name: string;
    date: string;
    note: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    patientId?: PatientDTO;
};

