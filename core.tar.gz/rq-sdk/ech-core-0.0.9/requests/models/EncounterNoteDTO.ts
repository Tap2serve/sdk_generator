/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { EncounterDTO } from './EncounterDTO';

export type EncounterNoteDTO = {
    id?: number;
    uuid?: string;
    subjective: string;
    objective: string;
    assessment: string;
    plan: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    encounterId?: EncounterDTO;
};

