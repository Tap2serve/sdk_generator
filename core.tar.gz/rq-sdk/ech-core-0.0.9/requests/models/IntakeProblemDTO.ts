/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IntakeFormDTO } from './IntakeFormDTO';
import type { PatientProblemDTO } from './PatientProblemDTO';

export type IntakeProblemDTO = {
    id?: number;
    uuid?: string;
    name: string;
    isActive?: boolean;
    type: string;
    diagnosedDate: string;
    note: string;
    problemIds?: Array<PatientProblemDTO>;
    intakeFormIds?: Array<IntakeFormDTO>;
};

