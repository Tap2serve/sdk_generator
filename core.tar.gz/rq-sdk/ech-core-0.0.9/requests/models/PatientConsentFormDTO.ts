/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ConsentFormTemplateDTO } from './ConsentFormTemplateDTO';
import type { PatientDTO } from './PatientDTO';

export type PatientConsentFormDTO = {
    id?: number;
    uuid?: string;
    formUrl: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    patientId?: PatientDTO;
    consentFormId?: ConsentFormTemplateDTO;
};

