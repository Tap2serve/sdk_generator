/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { SpecialityDTO } from './SpecialityDTO';

export type VisitNoteTemplateDTO = {
    id?: number;
    uuid?: string;
    type: string;
    specialties?: string;
    name: string;
    templateValue: string;
    isArchive?: boolean;
    isActive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    specialities?: Array<SpecialityDTO>;
};

