/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserDTO = {
    uuid?: string;
    id?: string;
    login?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    isActivated?: boolean;
    imageUrl?: string;
    langKey?: string;
};

