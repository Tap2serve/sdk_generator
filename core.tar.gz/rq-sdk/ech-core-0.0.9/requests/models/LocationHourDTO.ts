/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { LocationDTO } from './LocationDTO';

export type LocationHourDTO = {
    id?: number;
    uuid?: string;
    weekDay: string;
    openingTime: string;
    closingTime: string;
    locationId?: LocationDTO;
};

