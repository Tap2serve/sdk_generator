/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PatientDTO } from './PatientDTO';

export type PatientLabResultDTO = {
    id?: number;
    uuid?: string;
    description?: string;
    resultValue: string;
    recordedDate: string;
    abnoramlFlag: string;
    note: string;
    isActive?: boolean;
    approved: boolean;
    filesUrl: string;
    createdBy?: string;
    modifiedby?: string;
    createdAt?: string;
    modifiedAt?: string;
    patientId?: PatientDTO;
};

