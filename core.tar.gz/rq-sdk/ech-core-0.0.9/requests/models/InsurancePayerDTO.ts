/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type InsurancePayerDTO = {
    id?: number;
    uuid?: string;
    name: string;
    contact: string;
    fax?: string;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
};

