/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { HistoryQuestionDTO } from './HistoryQuestionDTO';
import type { PatientDTO } from './PatientDTO';

export type SocialHistoryDTO = {
    id?: number;
    uuid?: string;
    recordedDate: string;
    title: string;
    answer: string;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    question?: HistoryQuestionDTO;
    patientId?: PatientDTO;
};

