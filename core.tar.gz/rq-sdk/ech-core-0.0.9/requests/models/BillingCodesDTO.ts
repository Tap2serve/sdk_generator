/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PrescriptionFormDTO } from './PrescriptionFormDTO';

export type BillingCodesDTO = {
    id?: number;
    uuid?: string;
    type: BillingCodesDTO.type;
    description: string;
    source: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdBy?: string;
    modifiedBy?: string;
    createdAt?: string;
    modifiedAt?: string;
    prescriptionForm?: PrescriptionFormDTO;
};

export namespace BillingCodesDTO {

    export enum type {
        LOINC = 'LOINC',
        CPT = 'CPT',
        ICD = 'ICD',
        HCPCS = 'HCPCS',
    }


}

