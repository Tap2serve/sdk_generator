/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AddressDTO } from './AddressDTO';
import type { LocationHourDTO } from './LocationHourDTO';
import type { ProviderDTO } from './ProviderDTO';
import type { SpecialityDTO } from './SpecialityDTO';

export type LocationDTO = {
    id?: number;
    uuid?: string;
    name?: string;
    locationId: string;
    contact: string;
    email: string;
    fax?: string;
    note?: string;
    avatar?: string;
    npi: string;
    timeZone: string;
    isActive?: boolean;
    isArchive?: boolean;
    createdAt?: string;
    modifiedAt?: string;
    createdBy?: string;
    modifiedBy?: string;
    physicalAddressId?: AddressDTO;
    billingAddressId?: AddressDTO;
    specialities?: Array<SpecialityDTO>;
    provider?: ProviderDTO;
    locationHours?: Array<LocationHourDTO>;
};

