/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientLabResultDTO } from '../models/PatientLabResultDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientLabResultResourceService {

    /**
     * @param id
     * @returns PatientLabResultDTO OK
     * @throws ApiError
     */
    public static getPatientLabResult(
        id: number,
    ): CancelablePromise<PatientLabResultDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-lab-results/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientLabResultDTO OK
     * @throws ApiError
     */
    public static updatePatientLabResult(
        id: number,
        requestBody: PatientLabResultDTO,
    ): CancelablePromise<PatientLabResultDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-lab-results/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientLabResult(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-lab-results/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientLabResultDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientLabResult(
        id: number,
        requestBody: PatientLabResultDTO,
    ): CancelablePromise<PatientLabResultDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-lab-results/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param resultValueContains
     * @param resultValueDoesNotContain
     * @param resultValueEquals
     * @param resultValueNotEquals
     * @param resultValueSpecified
     * @param resultValueIn
     * @param resultValueNotIn
     * @param recordedDateGreaterThan
     * @param recordedDateLessThan
     * @param recordedDateGreaterThanOrEqual
     * @param recordedDateLessThanOrEqual
     * @param recordedDateEquals
     * @param recordedDateNotEquals
     * @param recordedDateSpecified
     * @param recordedDateIn
     * @param recordedDateNotIn
     * @param abnoramlFlagContains
     * @param abnoramlFlagDoesNotContain
     * @param abnoramlFlagEquals
     * @param abnoramlFlagNotEquals
     * @param abnoramlFlagSpecified
     * @param abnoramlFlagIn
     * @param abnoramlFlagNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param filesUrlContains
     * @param filesUrlDoesNotContain
     * @param filesUrlEquals
     * @param filesUrlNotEquals
     * @param filesUrlSpecified
     * @param filesUrlIn
     * @param filesUrlNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedbyContains
     * @param modifiedbyDoesNotContain
     * @param modifiedbyEquals
     * @param modifiedbyNotEquals
     * @param modifiedbySpecified
     * @param modifiedbyIn
     * @param modifiedbyNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientLabResultDTO OK
     * @throws ApiError
     */
    public static getAllPatientLabResults(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        resultValueContains?: string,
        resultValueDoesNotContain?: string,
        resultValueEquals?: string,
        resultValueNotEquals?: string,
        resultValueSpecified?: boolean,
        resultValueIn?: Array<string>,
        resultValueNotIn?: Array<string>,
        recordedDateGreaterThan?: string,
        recordedDateLessThan?: string,
        recordedDateGreaterThanOrEqual?: string,
        recordedDateLessThanOrEqual?: string,
        recordedDateEquals?: string,
        recordedDateNotEquals?: string,
        recordedDateSpecified?: boolean,
        recordedDateIn?: Array<string>,
        recordedDateNotIn?: Array<string>,
        abnoramlFlagContains?: string,
        abnoramlFlagDoesNotContain?: string,
        abnoramlFlagEquals?: string,
        abnoramlFlagNotEquals?: string,
        abnoramlFlagSpecified?: boolean,
        abnoramlFlagIn?: Array<string>,
        abnoramlFlagNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        filesUrlContains?: string,
        filesUrlDoesNotContain?: string,
        filesUrlEquals?: string,
        filesUrlNotEquals?: string,
        filesUrlSpecified?: boolean,
        filesUrlIn?: Array<string>,
        filesUrlNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedbyContains?: string,
        modifiedbyDoesNotContain?: string,
        modifiedbyEquals?: string,
        modifiedbyNotEquals?: string,
        modifiedbySpecified?: boolean,
        modifiedbyIn?: Array<string>,
        modifiedbyNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientLabResultDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-lab-results',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'resultValue.contains': resultValueContains,
                'resultValue.doesNotContain': resultValueDoesNotContain,
                'resultValue.equals': resultValueEquals,
                'resultValue.notEquals': resultValueNotEquals,
                'resultValue.specified': resultValueSpecified,
                'resultValue.in': resultValueIn,
                'resultValue.notIn': resultValueNotIn,
                'recordedDate.greaterThan': recordedDateGreaterThan,
                'recordedDate.lessThan': recordedDateLessThan,
                'recordedDate.greaterThanOrEqual': recordedDateGreaterThanOrEqual,
                'recordedDate.lessThanOrEqual': recordedDateLessThanOrEqual,
                'recordedDate.equals': recordedDateEquals,
                'recordedDate.notEquals': recordedDateNotEquals,
                'recordedDate.specified': recordedDateSpecified,
                'recordedDate.in': recordedDateIn,
                'recordedDate.notIn': recordedDateNotIn,
                'abnoramlFlag.contains': abnoramlFlagContains,
                'abnoramlFlag.doesNotContain': abnoramlFlagDoesNotContain,
                'abnoramlFlag.equals': abnoramlFlagEquals,
                'abnoramlFlag.notEquals': abnoramlFlagNotEquals,
                'abnoramlFlag.specified': abnoramlFlagSpecified,
                'abnoramlFlag.in': abnoramlFlagIn,
                'abnoramlFlag.notIn': abnoramlFlagNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'filesUrl.contains': filesUrlContains,
                'filesUrl.doesNotContain': filesUrlDoesNotContain,
                'filesUrl.equals': filesUrlEquals,
                'filesUrl.notEquals': filesUrlNotEquals,
                'filesUrl.specified': filesUrlSpecified,
                'filesUrl.in': filesUrlIn,
                'filesUrl.notIn': filesUrlNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedby.contains': modifiedbyContains,
                'modifiedby.doesNotContain': modifiedbyDoesNotContain,
                'modifiedby.equals': modifiedbyEquals,
                'modifiedby.notEquals': modifiedbyNotEquals,
                'modifiedby.specified': modifiedbySpecified,
                'modifiedby.in': modifiedbyIn,
                'modifiedby.notIn': modifiedbyNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientLabResultDTO OK
     * @throws ApiError
     */
    public static createPatientLabResult(
        requestBody: PatientLabResultDTO,
    ): CancelablePromise<PatientLabResultDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-lab-results',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param resultValueContains
     * @param resultValueDoesNotContain
     * @param resultValueEquals
     * @param resultValueNotEquals
     * @param resultValueSpecified
     * @param resultValueIn
     * @param resultValueNotIn
     * @param recordedDateGreaterThan
     * @param recordedDateLessThan
     * @param recordedDateGreaterThanOrEqual
     * @param recordedDateLessThanOrEqual
     * @param recordedDateEquals
     * @param recordedDateNotEquals
     * @param recordedDateSpecified
     * @param recordedDateIn
     * @param recordedDateNotIn
     * @param abnoramlFlagContains
     * @param abnoramlFlagDoesNotContain
     * @param abnoramlFlagEquals
     * @param abnoramlFlagNotEquals
     * @param abnoramlFlagSpecified
     * @param abnoramlFlagIn
     * @param abnoramlFlagNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param filesUrlContains
     * @param filesUrlDoesNotContain
     * @param filesUrlEquals
     * @param filesUrlNotEquals
     * @param filesUrlSpecified
     * @param filesUrlIn
     * @param filesUrlNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedbyContains
     * @param modifiedbyDoesNotContain
     * @param modifiedbyEquals
     * @param modifiedbyNotEquals
     * @param modifiedbySpecified
     * @param modifiedbyIn
     * @param modifiedbyNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientLabResults(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        resultValueContains?: string,
        resultValueDoesNotContain?: string,
        resultValueEquals?: string,
        resultValueNotEquals?: string,
        resultValueSpecified?: boolean,
        resultValueIn?: Array<string>,
        resultValueNotIn?: Array<string>,
        recordedDateGreaterThan?: string,
        recordedDateLessThan?: string,
        recordedDateGreaterThanOrEqual?: string,
        recordedDateLessThanOrEqual?: string,
        recordedDateEquals?: string,
        recordedDateNotEquals?: string,
        recordedDateSpecified?: boolean,
        recordedDateIn?: Array<string>,
        recordedDateNotIn?: Array<string>,
        abnoramlFlagContains?: string,
        abnoramlFlagDoesNotContain?: string,
        abnoramlFlagEquals?: string,
        abnoramlFlagNotEquals?: string,
        abnoramlFlagSpecified?: boolean,
        abnoramlFlagIn?: Array<string>,
        abnoramlFlagNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        filesUrlContains?: string,
        filesUrlDoesNotContain?: string,
        filesUrlEquals?: string,
        filesUrlNotEquals?: string,
        filesUrlSpecified?: boolean,
        filesUrlIn?: Array<string>,
        filesUrlNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedbyContains?: string,
        modifiedbyDoesNotContain?: string,
        modifiedbyEquals?: string,
        modifiedbyNotEquals?: string,
        modifiedbySpecified?: boolean,
        modifiedbyIn?: Array<string>,
        modifiedbyNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-lab-results/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'resultValue.contains': resultValueContains,
                'resultValue.doesNotContain': resultValueDoesNotContain,
                'resultValue.equals': resultValueEquals,
                'resultValue.notEquals': resultValueNotEquals,
                'resultValue.specified': resultValueSpecified,
                'resultValue.in': resultValueIn,
                'resultValue.notIn': resultValueNotIn,
                'recordedDate.greaterThan': recordedDateGreaterThan,
                'recordedDate.lessThan': recordedDateLessThan,
                'recordedDate.greaterThanOrEqual': recordedDateGreaterThanOrEqual,
                'recordedDate.lessThanOrEqual': recordedDateLessThanOrEqual,
                'recordedDate.equals': recordedDateEquals,
                'recordedDate.notEquals': recordedDateNotEquals,
                'recordedDate.specified': recordedDateSpecified,
                'recordedDate.in': recordedDateIn,
                'recordedDate.notIn': recordedDateNotIn,
                'abnoramlFlag.contains': abnoramlFlagContains,
                'abnoramlFlag.doesNotContain': abnoramlFlagDoesNotContain,
                'abnoramlFlag.equals': abnoramlFlagEquals,
                'abnoramlFlag.notEquals': abnoramlFlagNotEquals,
                'abnoramlFlag.specified': abnoramlFlagSpecified,
                'abnoramlFlag.in': abnoramlFlagIn,
                'abnoramlFlag.notIn': abnoramlFlagNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'filesUrl.contains': filesUrlContains,
                'filesUrl.doesNotContain': filesUrlDoesNotContain,
                'filesUrl.equals': filesUrlEquals,
                'filesUrl.notEquals': filesUrlNotEquals,
                'filesUrl.specified': filesUrlSpecified,
                'filesUrl.in': filesUrlIn,
                'filesUrl.notIn': filesUrlNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedby.contains': modifiedbyContains,
                'modifiedby.doesNotContain': modifiedbyDoesNotContain,
                'modifiedby.equals': modifiedbyEquals,
                'modifiedby.notEquals': modifiedbyNotEquals,
                'modifiedby.specified': modifiedbySpecified,
                'modifiedby.in': modifiedbyIn,
                'modifiedby.notIn': modifiedbyNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
