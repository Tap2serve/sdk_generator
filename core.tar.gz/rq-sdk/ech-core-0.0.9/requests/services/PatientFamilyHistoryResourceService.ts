/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientFamilyHistoryDTO } from '../models/PatientFamilyHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientFamilyHistoryResourceService {

    /**
     * @param id
     * @returns PatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static getPatientFamilyHistory(
        id: number,
    ): CancelablePromise<PatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-family-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static updatePatientFamilyHistory(
        id: number,
        requestBody: PatientFamilyHistoryDTO,
    ): CancelablePromise<PatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-family-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientFamilyHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-family-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientFamilyHistory(
        id: number,
        requestBody: PatientFamilyHistoryDTO,
    ): CancelablePromise<PatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-family-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param relationContains
     * @param relationDoesNotContain
     * @param relationEquals
     * @param relationNotEquals
     * @param relationSpecified
     * @param relationIn
     * @param relationNotIn
     * @param onSetAgeGreaterThan
     * @param onSetAgeLessThan
     * @param onSetAgeGreaterThanOrEqual
     * @param onSetAgeLessThanOrEqual
     * @param onSetAgeEquals
     * @param onSetAgeNotEquals
     * @param onSetAgeSpecified
     * @param onSetAgeIn
     * @param onSetAgeNotIn
     * @param aliveEquals
     * @param aliveNotEquals
     * @param aliveSpecified
     * @param aliveIn
     * @param aliveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakePatientFamilyHistoryIdGreaterThan
     * @param intakePatientFamilyHistoryIdLessThan
     * @param intakePatientFamilyHistoryIdGreaterThanOrEqual
     * @param intakePatientFamilyHistoryIdLessThanOrEqual
     * @param intakePatientFamilyHistoryIdEquals
     * @param intakePatientFamilyHistoryIdNotEquals
     * @param intakePatientFamilyHistoryIdSpecified
     * @param intakePatientFamilyHistoryIdIn
     * @param intakePatientFamilyHistoryIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static getAllPatientFamilyHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        relationContains?: string,
        relationDoesNotContain?: string,
        relationEquals?: string,
        relationNotEquals?: string,
        relationSpecified?: boolean,
        relationIn?: Array<string>,
        relationNotIn?: Array<string>,
        onSetAgeGreaterThan?: number,
        onSetAgeLessThan?: number,
        onSetAgeGreaterThanOrEqual?: number,
        onSetAgeLessThanOrEqual?: number,
        onSetAgeEquals?: number,
        onSetAgeNotEquals?: number,
        onSetAgeSpecified?: boolean,
        onSetAgeIn?: Array<number>,
        onSetAgeNotIn?: Array<number>,
        aliveEquals?: boolean,
        aliveNotEquals?: boolean,
        aliveSpecified?: boolean,
        aliveIn?: Array<boolean>,
        aliveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakePatientFamilyHistoryIdGreaterThan?: number,
        intakePatientFamilyHistoryIdLessThan?: number,
        intakePatientFamilyHistoryIdGreaterThanOrEqual?: number,
        intakePatientFamilyHistoryIdLessThanOrEqual?: number,
        intakePatientFamilyHistoryIdEquals?: number,
        intakePatientFamilyHistoryIdNotEquals?: number,
        intakePatientFamilyHistoryIdSpecified?: boolean,
        intakePatientFamilyHistoryIdIn?: Array<number>,
        intakePatientFamilyHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientFamilyHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-family-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'relation.contains': relationContains,
                'relation.doesNotContain': relationDoesNotContain,
                'relation.equals': relationEquals,
                'relation.notEquals': relationNotEquals,
                'relation.specified': relationSpecified,
                'relation.in': relationIn,
                'relation.notIn': relationNotIn,
                'onSetAge.greaterThan': onSetAgeGreaterThan,
                'onSetAge.lessThan': onSetAgeLessThan,
                'onSetAge.greaterThanOrEqual': onSetAgeGreaterThanOrEqual,
                'onSetAge.lessThanOrEqual': onSetAgeLessThanOrEqual,
                'onSetAge.equals': onSetAgeEquals,
                'onSetAge.notEquals': onSetAgeNotEquals,
                'onSetAge.specified': onSetAgeSpecified,
                'onSetAge.in': onSetAgeIn,
                'onSetAge.notIn': onSetAgeNotIn,
                'alive.equals': aliveEquals,
                'alive.notEquals': aliveNotEquals,
                'alive.specified': aliveSpecified,
                'alive.in': aliveIn,
                'alive.notIn': aliveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakePatientFamilyHistoryId.greaterThan': intakePatientFamilyHistoryIdGreaterThan,
                'intakePatientFamilyHistoryId.lessThan': intakePatientFamilyHistoryIdLessThan,
                'intakePatientFamilyHistoryId.greaterThanOrEqual': intakePatientFamilyHistoryIdGreaterThanOrEqual,
                'intakePatientFamilyHistoryId.lessThanOrEqual': intakePatientFamilyHistoryIdLessThanOrEqual,
                'intakePatientFamilyHistoryId.equals': intakePatientFamilyHistoryIdEquals,
                'intakePatientFamilyHistoryId.notEquals': intakePatientFamilyHistoryIdNotEquals,
                'intakePatientFamilyHistoryId.specified': intakePatientFamilyHistoryIdSpecified,
                'intakePatientFamilyHistoryId.in': intakePatientFamilyHistoryIdIn,
                'intakePatientFamilyHistoryId.notIn': intakePatientFamilyHistoryIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static createPatientFamilyHistory(
        requestBody: PatientFamilyHistoryDTO,
    ): CancelablePromise<PatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-family-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param relationContains
     * @param relationDoesNotContain
     * @param relationEquals
     * @param relationNotEquals
     * @param relationSpecified
     * @param relationIn
     * @param relationNotIn
     * @param onSetAgeGreaterThan
     * @param onSetAgeLessThan
     * @param onSetAgeGreaterThanOrEqual
     * @param onSetAgeLessThanOrEqual
     * @param onSetAgeEquals
     * @param onSetAgeNotEquals
     * @param onSetAgeSpecified
     * @param onSetAgeIn
     * @param onSetAgeNotIn
     * @param aliveEquals
     * @param aliveNotEquals
     * @param aliveSpecified
     * @param aliveIn
     * @param aliveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakePatientFamilyHistoryIdGreaterThan
     * @param intakePatientFamilyHistoryIdLessThan
     * @param intakePatientFamilyHistoryIdGreaterThanOrEqual
     * @param intakePatientFamilyHistoryIdLessThanOrEqual
     * @param intakePatientFamilyHistoryIdEquals
     * @param intakePatientFamilyHistoryIdNotEquals
     * @param intakePatientFamilyHistoryIdSpecified
     * @param intakePatientFamilyHistoryIdIn
     * @param intakePatientFamilyHistoryIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientFamilyHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        relationContains?: string,
        relationDoesNotContain?: string,
        relationEquals?: string,
        relationNotEquals?: string,
        relationSpecified?: boolean,
        relationIn?: Array<string>,
        relationNotIn?: Array<string>,
        onSetAgeGreaterThan?: number,
        onSetAgeLessThan?: number,
        onSetAgeGreaterThanOrEqual?: number,
        onSetAgeLessThanOrEqual?: number,
        onSetAgeEquals?: number,
        onSetAgeNotEquals?: number,
        onSetAgeSpecified?: boolean,
        onSetAgeIn?: Array<number>,
        onSetAgeNotIn?: Array<number>,
        aliveEquals?: boolean,
        aliveNotEquals?: boolean,
        aliveSpecified?: boolean,
        aliveIn?: Array<boolean>,
        aliveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakePatientFamilyHistoryIdGreaterThan?: number,
        intakePatientFamilyHistoryIdLessThan?: number,
        intakePatientFamilyHistoryIdGreaterThanOrEqual?: number,
        intakePatientFamilyHistoryIdLessThanOrEqual?: number,
        intakePatientFamilyHistoryIdEquals?: number,
        intakePatientFamilyHistoryIdNotEquals?: number,
        intakePatientFamilyHistoryIdSpecified?: boolean,
        intakePatientFamilyHistoryIdIn?: Array<number>,
        intakePatientFamilyHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-family-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'relation.contains': relationContains,
                'relation.doesNotContain': relationDoesNotContain,
                'relation.equals': relationEquals,
                'relation.notEquals': relationNotEquals,
                'relation.specified': relationSpecified,
                'relation.in': relationIn,
                'relation.notIn': relationNotIn,
                'onSetAge.greaterThan': onSetAgeGreaterThan,
                'onSetAge.lessThan': onSetAgeLessThan,
                'onSetAge.greaterThanOrEqual': onSetAgeGreaterThanOrEqual,
                'onSetAge.lessThanOrEqual': onSetAgeLessThanOrEqual,
                'onSetAge.equals': onSetAgeEquals,
                'onSetAge.notEquals': onSetAgeNotEquals,
                'onSetAge.specified': onSetAgeSpecified,
                'onSetAge.in': onSetAgeIn,
                'onSetAge.notIn': onSetAgeNotIn,
                'alive.equals': aliveEquals,
                'alive.notEquals': aliveNotEquals,
                'alive.specified': aliveSpecified,
                'alive.in': aliveIn,
                'alive.notIn': aliveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakePatientFamilyHistoryId.greaterThan': intakePatientFamilyHistoryIdGreaterThan,
                'intakePatientFamilyHistoryId.lessThan': intakePatientFamilyHistoryIdLessThan,
                'intakePatientFamilyHistoryId.greaterThanOrEqual': intakePatientFamilyHistoryIdGreaterThanOrEqual,
                'intakePatientFamilyHistoryId.lessThanOrEqual': intakePatientFamilyHistoryIdLessThanOrEqual,
                'intakePatientFamilyHistoryId.equals': intakePatientFamilyHistoryIdEquals,
                'intakePatientFamilyHistoryId.notEquals': intakePatientFamilyHistoryIdNotEquals,
                'intakePatientFamilyHistoryId.specified': intakePatientFamilyHistoryIdSpecified,
                'intakePatientFamilyHistoryId.in': intakePatientFamilyHistoryIdIn,
                'intakePatientFamilyHistoryId.notIn': intakePatientFamilyHistoryIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
