/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SpecialityDTO } from '../models/SpecialityDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class SpecialityResourceService {

    /**
     * @param id
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static getSpeciality(
        id: number,
    ): CancelablePromise<SpecialityDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/specialities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static updateSpeciality(
        id: number,
        requestBody: SpecialityDTO,
    ): CancelablePromise<SpecialityDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/specialities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteSpeciality(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/specialities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static partialUpdateSpeciality(
        id: number,
        requestBody: SpecialityDTO,
    ): CancelablePromise<SpecialityDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/specialities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param locationIdGreaterThan
     * @param locationIdLessThan
     * @param locationIdGreaterThanOrEqual
     * @param locationIdLessThanOrEqual
     * @param locationIdEquals
     * @param locationIdNotEquals
     * @param locationIdSpecified
     * @param locationIdIn
     * @param locationIdNotIn
     * @param physicalExamTemplateIdGreaterThan
     * @param physicalExamTemplateIdLessThan
     * @param physicalExamTemplateIdGreaterThanOrEqual
     * @param physicalExamTemplateIdLessThanOrEqual
     * @param physicalExamTemplateIdEquals
     * @param physicalExamTemplateIdNotEquals
     * @param physicalExamTemplateIdSpecified
     * @param physicalExamTemplateIdIn
     * @param physicalExamTemplateIdNotIn
     * @param drugIdGreaterThan
     * @param drugIdLessThan
     * @param drugIdGreaterThanOrEqual
     * @param drugIdLessThanOrEqual
     * @param drugIdEquals
     * @param drugIdNotEquals
     * @param drugIdSpecified
     * @param drugIdIn
     * @param drugIdNotIn
     * @param visitNoteTemplateIdGreaterThan
     * @param visitNoteTemplateIdLessThan
     * @param visitNoteTemplateIdGreaterThanOrEqual
     * @param visitNoteTemplateIdLessThanOrEqual
     * @param visitNoteTemplateIdEquals
     * @param visitNoteTemplateIdNotEquals
     * @param visitNoteTemplateIdSpecified
     * @param visitNoteTemplateIdIn
     * @param visitNoteTemplateIdNotIn
     * @param providerGroupIdGreaterThan
     * @param providerGroupIdLessThan
     * @param providerGroupIdGreaterThanOrEqual
     * @param providerGroupIdLessThanOrEqual
     * @param providerGroupIdEquals
     * @param providerGroupIdNotEquals
     * @param providerGroupIdSpecified
     * @param providerGroupIdIn
     * @param providerGroupIdNotIn
     * @param customTemplateIdGreaterThan
     * @param customTemplateIdLessThan
     * @param customTemplateIdGreaterThanOrEqual
     * @param customTemplateIdLessThanOrEqual
     * @param customTemplateIdEquals
     * @param customTemplateIdNotEquals
     * @param customTemplateIdSpecified
     * @param customTemplateIdIn
     * @param customTemplateIdNotIn
     * @param reviewOfSystemTemplateIdGreaterThan
     * @param reviewOfSystemTemplateIdLessThan
     * @param reviewOfSystemTemplateIdGreaterThanOrEqual
     * @param reviewOfSystemTemplateIdLessThanOrEqual
     * @param reviewOfSystemTemplateIdEquals
     * @param reviewOfSystemTemplateIdNotEquals
     * @param reviewOfSystemTemplateIdSpecified
     * @param reviewOfSystemTemplateIdIn
     * @param reviewOfSystemTemplateIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static getAllSpecialities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        locationIdGreaterThan?: number,
        locationIdLessThan?: number,
        locationIdGreaterThanOrEqual?: number,
        locationIdLessThanOrEqual?: number,
        locationIdEquals?: number,
        locationIdNotEquals?: number,
        locationIdSpecified?: boolean,
        locationIdIn?: Array<number>,
        locationIdNotIn?: Array<number>,
        physicalExamTemplateIdGreaterThan?: number,
        physicalExamTemplateIdLessThan?: number,
        physicalExamTemplateIdGreaterThanOrEqual?: number,
        physicalExamTemplateIdLessThanOrEqual?: number,
        physicalExamTemplateIdEquals?: number,
        physicalExamTemplateIdNotEquals?: number,
        physicalExamTemplateIdSpecified?: boolean,
        physicalExamTemplateIdIn?: Array<number>,
        physicalExamTemplateIdNotIn?: Array<number>,
        drugIdGreaterThan?: number,
        drugIdLessThan?: number,
        drugIdGreaterThanOrEqual?: number,
        drugIdLessThanOrEqual?: number,
        drugIdEquals?: number,
        drugIdNotEquals?: number,
        drugIdSpecified?: boolean,
        drugIdIn?: Array<number>,
        drugIdNotIn?: Array<number>,
        visitNoteTemplateIdGreaterThan?: number,
        visitNoteTemplateIdLessThan?: number,
        visitNoteTemplateIdGreaterThanOrEqual?: number,
        visitNoteTemplateIdLessThanOrEqual?: number,
        visitNoteTemplateIdEquals?: number,
        visitNoteTemplateIdNotEquals?: number,
        visitNoteTemplateIdSpecified?: boolean,
        visitNoteTemplateIdIn?: Array<number>,
        visitNoteTemplateIdNotIn?: Array<number>,
        providerGroupIdGreaterThan?: number,
        providerGroupIdLessThan?: number,
        providerGroupIdGreaterThanOrEqual?: number,
        providerGroupIdLessThanOrEqual?: number,
        providerGroupIdEquals?: number,
        providerGroupIdNotEquals?: number,
        providerGroupIdSpecified?: boolean,
        providerGroupIdIn?: Array<number>,
        providerGroupIdNotIn?: Array<number>,
        customTemplateIdGreaterThan?: number,
        customTemplateIdLessThan?: number,
        customTemplateIdGreaterThanOrEqual?: number,
        customTemplateIdLessThanOrEqual?: number,
        customTemplateIdEquals?: number,
        customTemplateIdNotEquals?: number,
        customTemplateIdSpecified?: boolean,
        customTemplateIdIn?: Array<number>,
        customTemplateIdNotIn?: Array<number>,
        reviewOfSystemTemplateIdGreaterThan?: number,
        reviewOfSystemTemplateIdLessThan?: number,
        reviewOfSystemTemplateIdGreaterThanOrEqual?: number,
        reviewOfSystemTemplateIdLessThanOrEqual?: number,
        reviewOfSystemTemplateIdEquals?: number,
        reviewOfSystemTemplateIdNotEquals?: number,
        reviewOfSystemTemplateIdSpecified?: boolean,
        reviewOfSystemTemplateIdIn?: Array<number>,
        reviewOfSystemTemplateIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<SpecialityDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/specialities',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'locationId.greaterThan': locationIdGreaterThan,
                'locationId.lessThan': locationIdLessThan,
                'locationId.greaterThanOrEqual': locationIdGreaterThanOrEqual,
                'locationId.lessThanOrEqual': locationIdLessThanOrEqual,
                'locationId.equals': locationIdEquals,
                'locationId.notEquals': locationIdNotEquals,
                'locationId.specified': locationIdSpecified,
                'locationId.in': locationIdIn,
                'locationId.notIn': locationIdNotIn,
                'physicalExamTemplateId.greaterThan': physicalExamTemplateIdGreaterThan,
                'physicalExamTemplateId.lessThan': physicalExamTemplateIdLessThan,
                'physicalExamTemplateId.greaterThanOrEqual': physicalExamTemplateIdGreaterThanOrEqual,
                'physicalExamTemplateId.lessThanOrEqual': physicalExamTemplateIdLessThanOrEqual,
                'physicalExamTemplateId.equals': physicalExamTemplateIdEquals,
                'physicalExamTemplateId.notEquals': physicalExamTemplateIdNotEquals,
                'physicalExamTemplateId.specified': physicalExamTemplateIdSpecified,
                'physicalExamTemplateId.in': physicalExamTemplateIdIn,
                'physicalExamTemplateId.notIn': physicalExamTemplateIdNotIn,
                'drugId.greaterThan': drugIdGreaterThan,
                'drugId.lessThan': drugIdLessThan,
                'drugId.greaterThanOrEqual': drugIdGreaterThanOrEqual,
                'drugId.lessThanOrEqual': drugIdLessThanOrEqual,
                'drugId.equals': drugIdEquals,
                'drugId.notEquals': drugIdNotEquals,
                'drugId.specified': drugIdSpecified,
                'drugId.in': drugIdIn,
                'drugId.notIn': drugIdNotIn,
                'visitNoteTemplateId.greaterThan': visitNoteTemplateIdGreaterThan,
                'visitNoteTemplateId.lessThan': visitNoteTemplateIdLessThan,
                'visitNoteTemplateId.greaterThanOrEqual': visitNoteTemplateIdGreaterThanOrEqual,
                'visitNoteTemplateId.lessThanOrEqual': visitNoteTemplateIdLessThanOrEqual,
                'visitNoteTemplateId.equals': visitNoteTemplateIdEquals,
                'visitNoteTemplateId.notEquals': visitNoteTemplateIdNotEquals,
                'visitNoteTemplateId.specified': visitNoteTemplateIdSpecified,
                'visitNoteTemplateId.in': visitNoteTemplateIdIn,
                'visitNoteTemplateId.notIn': visitNoteTemplateIdNotIn,
                'providerGroupId.greaterThan': providerGroupIdGreaterThan,
                'providerGroupId.lessThan': providerGroupIdLessThan,
                'providerGroupId.greaterThanOrEqual': providerGroupIdGreaterThanOrEqual,
                'providerGroupId.lessThanOrEqual': providerGroupIdLessThanOrEqual,
                'providerGroupId.equals': providerGroupIdEquals,
                'providerGroupId.notEquals': providerGroupIdNotEquals,
                'providerGroupId.specified': providerGroupIdSpecified,
                'providerGroupId.in': providerGroupIdIn,
                'providerGroupId.notIn': providerGroupIdNotIn,
                'customTemplateId.greaterThan': customTemplateIdGreaterThan,
                'customTemplateId.lessThan': customTemplateIdLessThan,
                'customTemplateId.greaterThanOrEqual': customTemplateIdGreaterThanOrEqual,
                'customTemplateId.lessThanOrEqual': customTemplateIdLessThanOrEqual,
                'customTemplateId.equals': customTemplateIdEquals,
                'customTemplateId.notEquals': customTemplateIdNotEquals,
                'customTemplateId.specified': customTemplateIdSpecified,
                'customTemplateId.in': customTemplateIdIn,
                'customTemplateId.notIn': customTemplateIdNotIn,
                'reviewOfSystemTemplateId.greaterThan': reviewOfSystemTemplateIdGreaterThan,
                'reviewOfSystemTemplateId.lessThan': reviewOfSystemTemplateIdLessThan,
                'reviewOfSystemTemplateId.greaterThanOrEqual': reviewOfSystemTemplateIdGreaterThanOrEqual,
                'reviewOfSystemTemplateId.lessThanOrEqual': reviewOfSystemTemplateIdLessThanOrEqual,
                'reviewOfSystemTemplateId.equals': reviewOfSystemTemplateIdEquals,
                'reviewOfSystemTemplateId.notEquals': reviewOfSystemTemplateIdNotEquals,
                'reviewOfSystemTemplateId.specified': reviewOfSystemTemplateIdSpecified,
                'reviewOfSystemTemplateId.in': reviewOfSystemTemplateIdIn,
                'reviewOfSystemTemplateId.notIn': reviewOfSystemTemplateIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static createSpeciality(
        requestBody: SpecialityDTO,
    ): CancelablePromise<SpecialityDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/specialities',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param locationIdGreaterThan
     * @param locationIdLessThan
     * @param locationIdGreaterThanOrEqual
     * @param locationIdLessThanOrEqual
     * @param locationIdEquals
     * @param locationIdNotEquals
     * @param locationIdSpecified
     * @param locationIdIn
     * @param locationIdNotIn
     * @param physicalExamTemplateIdGreaterThan
     * @param physicalExamTemplateIdLessThan
     * @param physicalExamTemplateIdGreaterThanOrEqual
     * @param physicalExamTemplateIdLessThanOrEqual
     * @param physicalExamTemplateIdEquals
     * @param physicalExamTemplateIdNotEquals
     * @param physicalExamTemplateIdSpecified
     * @param physicalExamTemplateIdIn
     * @param physicalExamTemplateIdNotIn
     * @param drugIdGreaterThan
     * @param drugIdLessThan
     * @param drugIdGreaterThanOrEqual
     * @param drugIdLessThanOrEqual
     * @param drugIdEquals
     * @param drugIdNotEquals
     * @param drugIdSpecified
     * @param drugIdIn
     * @param drugIdNotIn
     * @param visitNoteTemplateIdGreaterThan
     * @param visitNoteTemplateIdLessThan
     * @param visitNoteTemplateIdGreaterThanOrEqual
     * @param visitNoteTemplateIdLessThanOrEqual
     * @param visitNoteTemplateIdEquals
     * @param visitNoteTemplateIdNotEquals
     * @param visitNoteTemplateIdSpecified
     * @param visitNoteTemplateIdIn
     * @param visitNoteTemplateIdNotIn
     * @param providerGroupIdGreaterThan
     * @param providerGroupIdLessThan
     * @param providerGroupIdGreaterThanOrEqual
     * @param providerGroupIdLessThanOrEqual
     * @param providerGroupIdEquals
     * @param providerGroupIdNotEquals
     * @param providerGroupIdSpecified
     * @param providerGroupIdIn
     * @param providerGroupIdNotIn
     * @param customTemplateIdGreaterThan
     * @param customTemplateIdLessThan
     * @param customTemplateIdGreaterThanOrEqual
     * @param customTemplateIdLessThanOrEqual
     * @param customTemplateIdEquals
     * @param customTemplateIdNotEquals
     * @param customTemplateIdSpecified
     * @param customTemplateIdIn
     * @param customTemplateIdNotIn
     * @param reviewOfSystemTemplateIdGreaterThan
     * @param reviewOfSystemTemplateIdLessThan
     * @param reviewOfSystemTemplateIdGreaterThanOrEqual
     * @param reviewOfSystemTemplateIdLessThanOrEqual
     * @param reviewOfSystemTemplateIdEquals
     * @param reviewOfSystemTemplateIdNotEquals
     * @param reviewOfSystemTemplateIdSpecified
     * @param reviewOfSystemTemplateIdIn
     * @param reviewOfSystemTemplateIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countSpecialities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        locationIdGreaterThan?: number,
        locationIdLessThan?: number,
        locationIdGreaterThanOrEqual?: number,
        locationIdLessThanOrEqual?: number,
        locationIdEquals?: number,
        locationIdNotEquals?: number,
        locationIdSpecified?: boolean,
        locationIdIn?: Array<number>,
        locationIdNotIn?: Array<number>,
        physicalExamTemplateIdGreaterThan?: number,
        physicalExamTemplateIdLessThan?: number,
        physicalExamTemplateIdGreaterThanOrEqual?: number,
        physicalExamTemplateIdLessThanOrEqual?: number,
        physicalExamTemplateIdEquals?: number,
        physicalExamTemplateIdNotEquals?: number,
        physicalExamTemplateIdSpecified?: boolean,
        physicalExamTemplateIdIn?: Array<number>,
        physicalExamTemplateIdNotIn?: Array<number>,
        drugIdGreaterThan?: number,
        drugIdLessThan?: number,
        drugIdGreaterThanOrEqual?: number,
        drugIdLessThanOrEqual?: number,
        drugIdEquals?: number,
        drugIdNotEquals?: number,
        drugIdSpecified?: boolean,
        drugIdIn?: Array<number>,
        drugIdNotIn?: Array<number>,
        visitNoteTemplateIdGreaterThan?: number,
        visitNoteTemplateIdLessThan?: number,
        visitNoteTemplateIdGreaterThanOrEqual?: number,
        visitNoteTemplateIdLessThanOrEqual?: number,
        visitNoteTemplateIdEquals?: number,
        visitNoteTemplateIdNotEquals?: number,
        visitNoteTemplateIdSpecified?: boolean,
        visitNoteTemplateIdIn?: Array<number>,
        visitNoteTemplateIdNotIn?: Array<number>,
        providerGroupIdGreaterThan?: number,
        providerGroupIdLessThan?: number,
        providerGroupIdGreaterThanOrEqual?: number,
        providerGroupIdLessThanOrEqual?: number,
        providerGroupIdEquals?: number,
        providerGroupIdNotEquals?: number,
        providerGroupIdSpecified?: boolean,
        providerGroupIdIn?: Array<number>,
        providerGroupIdNotIn?: Array<number>,
        customTemplateIdGreaterThan?: number,
        customTemplateIdLessThan?: number,
        customTemplateIdGreaterThanOrEqual?: number,
        customTemplateIdLessThanOrEqual?: number,
        customTemplateIdEquals?: number,
        customTemplateIdNotEquals?: number,
        customTemplateIdSpecified?: boolean,
        customTemplateIdIn?: Array<number>,
        customTemplateIdNotIn?: Array<number>,
        reviewOfSystemTemplateIdGreaterThan?: number,
        reviewOfSystemTemplateIdLessThan?: number,
        reviewOfSystemTemplateIdGreaterThanOrEqual?: number,
        reviewOfSystemTemplateIdLessThanOrEqual?: number,
        reviewOfSystemTemplateIdEquals?: number,
        reviewOfSystemTemplateIdNotEquals?: number,
        reviewOfSystemTemplateIdSpecified?: boolean,
        reviewOfSystemTemplateIdIn?: Array<number>,
        reviewOfSystemTemplateIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/specialities/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'locationId.greaterThan': locationIdGreaterThan,
                'locationId.lessThan': locationIdLessThan,
                'locationId.greaterThanOrEqual': locationIdGreaterThanOrEqual,
                'locationId.lessThanOrEqual': locationIdLessThanOrEqual,
                'locationId.equals': locationIdEquals,
                'locationId.notEquals': locationIdNotEquals,
                'locationId.specified': locationIdSpecified,
                'locationId.in': locationIdIn,
                'locationId.notIn': locationIdNotIn,
                'physicalExamTemplateId.greaterThan': physicalExamTemplateIdGreaterThan,
                'physicalExamTemplateId.lessThan': physicalExamTemplateIdLessThan,
                'physicalExamTemplateId.greaterThanOrEqual': physicalExamTemplateIdGreaterThanOrEqual,
                'physicalExamTemplateId.lessThanOrEqual': physicalExamTemplateIdLessThanOrEqual,
                'physicalExamTemplateId.equals': physicalExamTemplateIdEquals,
                'physicalExamTemplateId.notEquals': physicalExamTemplateIdNotEquals,
                'physicalExamTemplateId.specified': physicalExamTemplateIdSpecified,
                'physicalExamTemplateId.in': physicalExamTemplateIdIn,
                'physicalExamTemplateId.notIn': physicalExamTemplateIdNotIn,
                'drugId.greaterThan': drugIdGreaterThan,
                'drugId.lessThan': drugIdLessThan,
                'drugId.greaterThanOrEqual': drugIdGreaterThanOrEqual,
                'drugId.lessThanOrEqual': drugIdLessThanOrEqual,
                'drugId.equals': drugIdEquals,
                'drugId.notEquals': drugIdNotEquals,
                'drugId.specified': drugIdSpecified,
                'drugId.in': drugIdIn,
                'drugId.notIn': drugIdNotIn,
                'visitNoteTemplateId.greaterThan': visitNoteTemplateIdGreaterThan,
                'visitNoteTemplateId.lessThan': visitNoteTemplateIdLessThan,
                'visitNoteTemplateId.greaterThanOrEqual': visitNoteTemplateIdGreaterThanOrEqual,
                'visitNoteTemplateId.lessThanOrEqual': visitNoteTemplateIdLessThanOrEqual,
                'visitNoteTemplateId.equals': visitNoteTemplateIdEquals,
                'visitNoteTemplateId.notEquals': visitNoteTemplateIdNotEquals,
                'visitNoteTemplateId.specified': visitNoteTemplateIdSpecified,
                'visitNoteTemplateId.in': visitNoteTemplateIdIn,
                'visitNoteTemplateId.notIn': visitNoteTemplateIdNotIn,
                'providerGroupId.greaterThan': providerGroupIdGreaterThan,
                'providerGroupId.lessThan': providerGroupIdLessThan,
                'providerGroupId.greaterThanOrEqual': providerGroupIdGreaterThanOrEqual,
                'providerGroupId.lessThanOrEqual': providerGroupIdLessThanOrEqual,
                'providerGroupId.equals': providerGroupIdEquals,
                'providerGroupId.notEquals': providerGroupIdNotEquals,
                'providerGroupId.specified': providerGroupIdSpecified,
                'providerGroupId.in': providerGroupIdIn,
                'providerGroupId.notIn': providerGroupIdNotIn,
                'customTemplateId.greaterThan': customTemplateIdGreaterThan,
                'customTemplateId.lessThan': customTemplateIdLessThan,
                'customTemplateId.greaterThanOrEqual': customTemplateIdGreaterThanOrEqual,
                'customTemplateId.lessThanOrEqual': customTemplateIdLessThanOrEqual,
                'customTemplateId.equals': customTemplateIdEquals,
                'customTemplateId.notEquals': customTemplateIdNotEquals,
                'customTemplateId.specified': customTemplateIdSpecified,
                'customTemplateId.in': customTemplateIdIn,
                'customTemplateId.notIn': customTemplateIdNotIn,
                'reviewOfSystemTemplateId.greaterThan': reviewOfSystemTemplateIdGreaterThan,
                'reviewOfSystemTemplateId.lessThan': reviewOfSystemTemplateIdLessThan,
                'reviewOfSystemTemplateId.greaterThanOrEqual': reviewOfSystemTemplateIdGreaterThanOrEqual,
                'reviewOfSystemTemplateId.lessThanOrEqual': reviewOfSystemTemplateIdLessThanOrEqual,
                'reviewOfSystemTemplateId.equals': reviewOfSystemTemplateIdEquals,
                'reviewOfSystemTemplateId.notEquals': reviewOfSystemTemplateIdNotEquals,
                'reviewOfSystemTemplateId.specified': reviewOfSystemTemplateIdSpecified,
                'reviewOfSystemTemplateId.in': reviewOfSystemTemplateIdIn,
                'reviewOfSystemTemplateId.notIn': reviewOfSystemTemplateIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
