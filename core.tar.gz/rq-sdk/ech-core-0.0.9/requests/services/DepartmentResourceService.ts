/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DepartmentDTO } from '../models/DepartmentDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class DepartmentResourceService {

    /**
     * @param id
     * @param active
     * @returns any OK
     * @throws ApiError
     */
    public static updateStatus(
        id: number,
        active: boolean,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/{id}/active/{active}',
            path: {
                'id': id,
                'active': active,
            },
        });
    }

    /**
     * @param id
     * @returns DepartmentDTO OK
     * @throws ApiError
     */
    public static getDepartment(
        id: number,
    ): CancelablePromise<DepartmentDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/departments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns DepartmentDTO OK
     * @throws ApiError
     */
    public static updateDepartment(
        id: number,
        requestBody: DepartmentDTO,
    ): CancelablePromise<DepartmentDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/departments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteDepartment(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/departments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns DepartmentDTO OK
     * @throws ApiError
     */
    public static partialUpdateDepartment(
        id: number,
        requestBody: DepartmentDTO,
    ): CancelablePromise<DepartmentDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/departments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param deptIdContains
     * @param deptIdDoesNotContain
     * @param deptIdEquals
     * @param deptIdNotEquals
     * @param deptIdSpecified
     * @param deptIdIn
     * @param deptIdNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param contactContains
     * @param contactDoesNotContain
     * @param contactEquals
     * @param contactNotEquals
     * @param contactSpecified
     * @param contactIn
     * @param contactNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param adminIdIdGreaterThan
     * @param adminIdIdLessThan
     * @param adminIdIdGreaterThanOrEqual
     * @param adminIdIdLessThanOrEqual
     * @param adminIdIdEquals
     * @param adminIdIdNotEquals
     * @param adminIdIdSpecified
     * @param adminIdIdIn
     * @param adminIdIdNotIn
     * @param providerGroupIdIdGreaterThan
     * @param providerGroupIdIdLessThan
     * @param providerGroupIdIdGreaterThanOrEqual
     * @param providerGroupIdIdLessThanOrEqual
     * @param providerGroupIdIdEquals
     * @param providerGroupIdIdNotEquals
     * @param providerGroupIdIdSpecified
     * @param providerGroupIdIdIn
     * @param providerGroupIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns DepartmentDTO OK
     * @throws ApiError
     */
    public static getAllDepartments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        deptIdContains?: string,
        deptIdDoesNotContain?: string,
        deptIdEquals?: string,
        deptIdNotEquals?: string,
        deptIdSpecified?: boolean,
        deptIdIn?: Array<string>,
        deptIdNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        contactContains?: string,
        contactDoesNotContain?: string,
        contactEquals?: string,
        contactNotEquals?: string,
        contactSpecified?: boolean,
        contactIn?: Array<string>,
        contactNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        adminIdIdGreaterThan?: number,
        adminIdIdLessThan?: number,
        adminIdIdGreaterThanOrEqual?: number,
        adminIdIdLessThanOrEqual?: number,
        adminIdIdEquals?: number,
        adminIdIdNotEquals?: number,
        adminIdIdSpecified?: boolean,
        adminIdIdIn?: Array<number>,
        adminIdIdNotIn?: Array<number>,
        providerGroupIdIdGreaterThan?: number,
        providerGroupIdIdLessThan?: number,
        providerGroupIdIdGreaterThanOrEqual?: number,
        providerGroupIdIdLessThanOrEqual?: number,
        providerGroupIdIdEquals?: number,
        providerGroupIdIdNotEquals?: number,
        providerGroupIdIdSpecified?: boolean,
        providerGroupIdIdIn?: Array<number>,
        providerGroupIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<DepartmentDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/departments',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'deptId.contains': deptIdContains,
                'deptId.doesNotContain': deptIdDoesNotContain,
                'deptId.equals': deptIdEquals,
                'deptId.notEquals': deptIdNotEquals,
                'deptId.specified': deptIdSpecified,
                'deptId.in': deptIdIn,
                'deptId.notIn': deptIdNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'contact.contains': contactContains,
                'contact.doesNotContain': contactDoesNotContain,
                'contact.equals': contactEquals,
                'contact.notEquals': contactNotEquals,
                'contact.specified': contactSpecified,
                'contact.in': contactIn,
                'contact.notIn': contactNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'adminIdId.greaterThan': adminIdIdGreaterThan,
                'adminIdId.lessThan': adminIdIdLessThan,
                'adminIdId.greaterThanOrEqual': adminIdIdGreaterThanOrEqual,
                'adminIdId.lessThanOrEqual': adminIdIdLessThanOrEqual,
                'adminIdId.equals': adminIdIdEquals,
                'adminIdId.notEquals': adminIdIdNotEquals,
                'adminIdId.specified': adminIdIdSpecified,
                'adminIdId.in': adminIdIdIn,
                'adminIdId.notIn': adminIdIdNotIn,
                'providerGroupIdId.greaterThan': providerGroupIdIdGreaterThan,
                'providerGroupIdId.lessThan': providerGroupIdIdLessThan,
                'providerGroupIdId.greaterThanOrEqual': providerGroupIdIdGreaterThanOrEqual,
                'providerGroupIdId.lessThanOrEqual': providerGroupIdIdLessThanOrEqual,
                'providerGroupIdId.equals': providerGroupIdIdEquals,
                'providerGroupIdId.notEquals': providerGroupIdIdNotEquals,
                'providerGroupIdId.specified': providerGroupIdIdSpecified,
                'providerGroupIdId.in': providerGroupIdIdIn,
                'providerGroupIdId.notIn': providerGroupIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns DepartmentDTO OK
     * @throws ApiError
     */
    public static createDepartment(
        requestBody: DepartmentDTO,
    ): CancelablePromise<DepartmentDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/departments',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param deptIdContains
     * @param deptIdDoesNotContain
     * @param deptIdEquals
     * @param deptIdNotEquals
     * @param deptIdSpecified
     * @param deptIdIn
     * @param deptIdNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param contactContains
     * @param contactDoesNotContain
     * @param contactEquals
     * @param contactNotEquals
     * @param contactSpecified
     * @param contactIn
     * @param contactNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param adminIdIdGreaterThan
     * @param adminIdIdLessThan
     * @param adminIdIdGreaterThanOrEqual
     * @param adminIdIdLessThanOrEqual
     * @param adminIdIdEquals
     * @param adminIdIdNotEquals
     * @param adminIdIdSpecified
     * @param adminIdIdIn
     * @param adminIdIdNotIn
     * @param providerGroupIdIdGreaterThan
     * @param providerGroupIdIdLessThan
     * @param providerGroupIdIdGreaterThanOrEqual
     * @param providerGroupIdIdLessThanOrEqual
     * @param providerGroupIdIdEquals
     * @param providerGroupIdIdNotEquals
     * @param providerGroupIdIdSpecified
     * @param providerGroupIdIdIn
     * @param providerGroupIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countDepartments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        deptIdContains?: string,
        deptIdDoesNotContain?: string,
        deptIdEquals?: string,
        deptIdNotEquals?: string,
        deptIdSpecified?: boolean,
        deptIdIn?: Array<string>,
        deptIdNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        contactContains?: string,
        contactDoesNotContain?: string,
        contactEquals?: string,
        contactNotEquals?: string,
        contactSpecified?: boolean,
        contactIn?: Array<string>,
        contactNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        adminIdIdGreaterThan?: number,
        adminIdIdLessThan?: number,
        adminIdIdGreaterThanOrEqual?: number,
        adminIdIdLessThanOrEqual?: number,
        adminIdIdEquals?: number,
        adminIdIdNotEquals?: number,
        adminIdIdSpecified?: boolean,
        adminIdIdIn?: Array<number>,
        adminIdIdNotIn?: Array<number>,
        providerGroupIdIdGreaterThan?: number,
        providerGroupIdIdLessThan?: number,
        providerGroupIdIdGreaterThanOrEqual?: number,
        providerGroupIdIdLessThanOrEqual?: number,
        providerGroupIdIdEquals?: number,
        providerGroupIdIdNotEquals?: number,
        providerGroupIdIdSpecified?: boolean,
        providerGroupIdIdIn?: Array<number>,
        providerGroupIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/departments/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'deptId.contains': deptIdContains,
                'deptId.doesNotContain': deptIdDoesNotContain,
                'deptId.equals': deptIdEquals,
                'deptId.notEquals': deptIdNotEquals,
                'deptId.specified': deptIdSpecified,
                'deptId.in': deptIdIn,
                'deptId.notIn': deptIdNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'contact.contains': contactContains,
                'contact.doesNotContain': contactDoesNotContain,
                'contact.equals': contactEquals,
                'contact.notEquals': contactNotEquals,
                'contact.specified': contactSpecified,
                'contact.in': contactIn,
                'contact.notIn': contactNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'adminIdId.greaterThan': adminIdIdGreaterThan,
                'adminIdId.lessThan': adminIdIdLessThan,
                'adminIdId.greaterThanOrEqual': adminIdIdGreaterThanOrEqual,
                'adminIdId.lessThanOrEqual': adminIdIdLessThanOrEqual,
                'adminIdId.equals': adminIdIdEquals,
                'adminIdId.notEquals': adminIdIdNotEquals,
                'adminIdId.specified': adminIdIdSpecified,
                'adminIdId.in': adminIdIdIn,
                'adminIdId.notIn': adminIdIdNotIn,
                'providerGroupIdId.greaterThan': providerGroupIdIdGreaterThan,
                'providerGroupIdId.lessThan': providerGroupIdIdLessThan,
                'providerGroupIdId.greaterThanOrEqual': providerGroupIdIdGreaterThanOrEqual,
                'providerGroupIdId.lessThanOrEqual': providerGroupIdIdLessThanOrEqual,
                'providerGroupIdId.equals': providerGroupIdIdEquals,
                'providerGroupIdId.notEquals': providerGroupIdIdNotEquals,
                'providerGroupIdId.specified': providerGroupIdIdSpecified,
                'providerGroupIdId.in': providerGroupIdIdIn,
                'providerGroupIdId.notIn': providerGroupIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
