/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeProblemDTO } from '../models/IntakeProblemDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeProblemResourceService {

    /**
     * @param id
     * @returns IntakeProblemDTO OK
     * @throws ApiError
     */
    public static getIntakeProblem(
        id: number,
    ): CancelablePromise<IntakeProblemDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-problems/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeProblemDTO OK
     * @throws ApiError
     */
    public static updateIntakeProblem(
        id: number,
        requestBody: IntakeProblemDTO,
    ): CancelablePromise<IntakeProblemDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-problems/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeProblem(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-problems/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeProblemDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeProblem(
        id: number,
        requestBody: IntakeProblemDTO,
    ): CancelablePromise<IntakeProblemDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-problems/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param diagnosedDateGreaterThan
     * @param diagnosedDateLessThan
     * @param diagnosedDateGreaterThanOrEqual
     * @param diagnosedDateLessThanOrEqual
     * @param diagnosedDateEquals
     * @param diagnosedDateNotEquals
     * @param diagnosedDateSpecified
     * @param diagnosedDateIn
     * @param diagnosedDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param problemIdIdGreaterThan
     * @param problemIdIdLessThan
     * @param problemIdIdGreaterThanOrEqual
     * @param problemIdIdLessThanOrEqual
     * @param problemIdIdEquals
     * @param problemIdIdNotEquals
     * @param problemIdIdSpecified
     * @param problemIdIdIn
     * @param problemIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeProblemDTO OK
     * @throws ApiError
     */
    public static getAllIntakeProblems(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        diagnosedDateGreaterThan?: string,
        diagnosedDateLessThan?: string,
        diagnosedDateGreaterThanOrEqual?: string,
        diagnosedDateLessThanOrEqual?: string,
        diagnosedDateEquals?: string,
        diagnosedDateNotEquals?: string,
        diagnosedDateSpecified?: boolean,
        diagnosedDateIn?: Array<string>,
        diagnosedDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        problemIdIdGreaterThan?: number,
        problemIdIdLessThan?: number,
        problemIdIdGreaterThanOrEqual?: number,
        problemIdIdLessThanOrEqual?: number,
        problemIdIdEquals?: number,
        problemIdIdNotEquals?: number,
        problemIdIdSpecified?: boolean,
        problemIdIdIn?: Array<number>,
        problemIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeProblemDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-problems',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'diagnosedDate.greaterThan': diagnosedDateGreaterThan,
                'diagnosedDate.lessThan': diagnosedDateLessThan,
                'diagnosedDate.greaterThanOrEqual': diagnosedDateGreaterThanOrEqual,
                'diagnosedDate.lessThanOrEqual': diagnosedDateLessThanOrEqual,
                'diagnosedDate.equals': diagnosedDateEquals,
                'diagnosedDate.notEquals': diagnosedDateNotEquals,
                'diagnosedDate.specified': diagnosedDateSpecified,
                'diagnosedDate.in': diagnosedDateIn,
                'diagnosedDate.notIn': diagnosedDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'problemIdId.greaterThan': problemIdIdGreaterThan,
                'problemIdId.lessThan': problemIdIdLessThan,
                'problemIdId.greaterThanOrEqual': problemIdIdGreaterThanOrEqual,
                'problemIdId.lessThanOrEqual': problemIdIdLessThanOrEqual,
                'problemIdId.equals': problemIdIdEquals,
                'problemIdId.notEquals': problemIdIdNotEquals,
                'problemIdId.specified': problemIdIdSpecified,
                'problemIdId.in': problemIdIdIn,
                'problemIdId.notIn': problemIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeProblemDTO OK
     * @throws ApiError
     */
    public static createIntakeProblem(
        requestBody: IntakeProblemDTO,
    ): CancelablePromise<IntakeProblemDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-problems',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param diagnosedDateGreaterThan
     * @param diagnosedDateLessThan
     * @param diagnosedDateGreaterThanOrEqual
     * @param diagnosedDateLessThanOrEqual
     * @param diagnosedDateEquals
     * @param diagnosedDateNotEquals
     * @param diagnosedDateSpecified
     * @param diagnosedDateIn
     * @param diagnosedDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param problemIdIdGreaterThan
     * @param problemIdIdLessThan
     * @param problemIdIdGreaterThanOrEqual
     * @param problemIdIdLessThanOrEqual
     * @param problemIdIdEquals
     * @param problemIdIdNotEquals
     * @param problemIdIdSpecified
     * @param problemIdIdIn
     * @param problemIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeProblems(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        diagnosedDateGreaterThan?: string,
        diagnosedDateLessThan?: string,
        diagnosedDateGreaterThanOrEqual?: string,
        diagnosedDateLessThanOrEqual?: string,
        diagnosedDateEquals?: string,
        diagnosedDateNotEquals?: string,
        diagnosedDateSpecified?: boolean,
        diagnosedDateIn?: Array<string>,
        diagnosedDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        problemIdIdGreaterThan?: number,
        problemIdIdLessThan?: number,
        problemIdIdGreaterThanOrEqual?: number,
        problemIdIdLessThanOrEqual?: number,
        problemIdIdEquals?: number,
        problemIdIdNotEquals?: number,
        problemIdIdSpecified?: boolean,
        problemIdIdIn?: Array<number>,
        problemIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-problems/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'diagnosedDate.greaterThan': diagnosedDateGreaterThan,
                'diagnosedDate.lessThan': diagnosedDateLessThan,
                'diagnosedDate.greaterThanOrEqual': diagnosedDateGreaterThanOrEqual,
                'diagnosedDate.lessThanOrEqual': diagnosedDateLessThanOrEqual,
                'diagnosedDate.equals': diagnosedDateEquals,
                'diagnosedDate.notEquals': diagnosedDateNotEquals,
                'diagnosedDate.specified': diagnosedDateSpecified,
                'diagnosedDate.in': diagnosedDateIn,
                'diagnosedDate.notIn': diagnosedDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'problemIdId.greaterThan': problemIdIdGreaterThan,
                'problemIdId.lessThan': problemIdIdLessThan,
                'problemIdId.greaterThanOrEqual': problemIdIdGreaterThanOrEqual,
                'problemIdId.lessThanOrEqual': problemIdIdLessThanOrEqual,
                'problemIdId.equals': problemIdIdEquals,
                'problemIdId.notEquals': problemIdIdNotEquals,
                'problemIdId.specified': problemIdIdSpecified,
                'problemIdId.in': problemIdIdIn,
                'problemIdId.notIn': problemIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
