/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InsurancePaymentDTO } from '../models/InsurancePaymentDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class InsurancePaymentResourceService {

    /**
     * @param id
     * @returns InsurancePaymentDTO OK
     * @throws ApiError
     */
    public static getInsurancePayment(
        id: number,
    ): CancelablePromise<InsurancePaymentDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsurancePaymentDTO OK
     * @throws ApiError
     */
    public static updateInsurancePayment(
        id: number,
        requestBody: InsurancePaymentDTO,
    ): CancelablePromise<InsurancePaymentDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/insurance-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteInsurancePayment(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/insurance-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsurancePaymentDTO OK
     * @throws ApiError
     */
    public static partialUpdateInsurancePayment(
        id: number,
        requestBody: InsurancePaymentDTO,
    ): CancelablePromise<InsurancePaymentDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/insurance-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param paymentModeContains
     * @param paymentModeDoesNotContain
     * @param paymentModeEquals
     * @param paymentModeNotEquals
     * @param paymentModeSpecified
     * @param paymentModeIn
     * @param paymentModeNotIn
     * @param paymentMethodContains
     * @param paymentMethodDoesNotContain
     * @param paymentMethodEquals
     * @param paymentMethodNotEquals
     * @param paymentMethodSpecified
     * @param paymentMethodIn
     * @param paymentMethodNotIn
     * @param transactionIdContains
     * @param transactionIdDoesNotContain
     * @param transactionIdEquals
     * @param transactionIdNotEquals
     * @param transactionIdSpecified
     * @param transactionIdIn
     * @param transactionIdNotIn
     * @param transactionAmountGreaterThan
     * @param transactionAmountLessThan
     * @param transactionAmountGreaterThanOrEqual
     * @param transactionAmountLessThanOrEqual
     * @param transactionAmountEquals
     * @param transactionAmountNotEquals
     * @param transactionAmountSpecified
     * @param transactionAmountIn
     * @param transactionAmountNotIn
     * @param transactionDateGreaterThan
     * @param transactionDateLessThan
     * @param transactionDateGreaterThanOrEqual
     * @param transactionDateLessThanOrEqual
     * @param transactionDateEquals
     * @param transactionDateNotEquals
     * @param transactionDateSpecified
     * @param transactionDateIn
     * @param transactionDateNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param unappliedAmountGreaterThan
     * @param unappliedAmountLessThan
     * @param unappliedAmountGreaterThanOrEqual
     * @param unappliedAmountLessThanOrEqual
     * @param unappliedAmountEquals
     * @param unappliedAmountNotEquals
     * @param unappliedAmountSpecified
     * @param unappliedAmountIn
     * @param unappliedAmountNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param paymentIdIdGreaterThan
     * @param paymentIdIdLessThan
     * @param paymentIdIdGreaterThanOrEqual
     * @param paymentIdIdLessThanOrEqual
     * @param paymentIdIdEquals
     * @param paymentIdIdNotEquals
     * @param paymentIdIdSpecified
     * @param paymentIdIdIn
     * @param paymentIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns InsurancePaymentDTO OK
     * @throws ApiError
     */
    public static getAllInsurancePayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        paymentModeContains?: string,
        paymentModeDoesNotContain?: string,
        paymentModeEquals?: string,
        paymentModeNotEquals?: string,
        paymentModeSpecified?: boolean,
        paymentModeIn?: Array<string>,
        paymentModeNotIn?: Array<string>,
        paymentMethodContains?: string,
        paymentMethodDoesNotContain?: string,
        paymentMethodEquals?: string,
        paymentMethodNotEquals?: string,
        paymentMethodSpecified?: boolean,
        paymentMethodIn?: Array<string>,
        paymentMethodNotIn?: Array<string>,
        transactionIdContains?: string,
        transactionIdDoesNotContain?: string,
        transactionIdEquals?: string,
        transactionIdNotEquals?: string,
        transactionIdSpecified?: boolean,
        transactionIdIn?: Array<string>,
        transactionIdNotIn?: Array<string>,
        transactionAmountGreaterThan?: number,
        transactionAmountLessThan?: number,
        transactionAmountGreaterThanOrEqual?: number,
        transactionAmountLessThanOrEqual?: number,
        transactionAmountEquals?: number,
        transactionAmountNotEquals?: number,
        transactionAmountSpecified?: boolean,
        transactionAmountIn?: Array<number>,
        transactionAmountNotIn?: Array<number>,
        transactionDateGreaterThan?: string,
        transactionDateLessThan?: string,
        transactionDateGreaterThanOrEqual?: string,
        transactionDateLessThanOrEqual?: string,
        transactionDateEquals?: string,
        transactionDateNotEquals?: string,
        transactionDateSpecified?: boolean,
        transactionDateIn?: Array<string>,
        transactionDateNotIn?: Array<string>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        unappliedAmountGreaterThan?: number,
        unappliedAmountLessThan?: number,
        unappliedAmountGreaterThanOrEqual?: number,
        unappliedAmountLessThanOrEqual?: number,
        unappliedAmountEquals?: number,
        unappliedAmountNotEquals?: number,
        unappliedAmountSpecified?: boolean,
        unappliedAmountIn?: Array<number>,
        unappliedAmountNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        paymentIdIdGreaterThan?: number,
        paymentIdIdLessThan?: number,
        paymentIdIdGreaterThanOrEqual?: number,
        paymentIdIdLessThanOrEqual?: number,
        paymentIdIdEquals?: number,
        paymentIdIdNotEquals?: number,
        paymentIdIdSpecified?: boolean,
        paymentIdIdIn?: Array<number>,
        paymentIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<InsurancePaymentDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-payments',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'paymentMode.contains': paymentModeContains,
                'paymentMode.doesNotContain': paymentModeDoesNotContain,
                'paymentMode.equals': paymentModeEquals,
                'paymentMode.notEquals': paymentModeNotEquals,
                'paymentMode.specified': paymentModeSpecified,
                'paymentMode.in': paymentModeIn,
                'paymentMode.notIn': paymentModeNotIn,
                'paymentMethod.contains': paymentMethodContains,
                'paymentMethod.doesNotContain': paymentMethodDoesNotContain,
                'paymentMethod.equals': paymentMethodEquals,
                'paymentMethod.notEquals': paymentMethodNotEquals,
                'paymentMethod.specified': paymentMethodSpecified,
                'paymentMethod.in': paymentMethodIn,
                'paymentMethod.notIn': paymentMethodNotIn,
                'transactionId.contains': transactionIdContains,
                'transactionId.doesNotContain': transactionIdDoesNotContain,
                'transactionId.equals': transactionIdEquals,
                'transactionId.notEquals': transactionIdNotEquals,
                'transactionId.specified': transactionIdSpecified,
                'transactionId.in': transactionIdIn,
                'transactionId.notIn': transactionIdNotIn,
                'transactionAmount.greaterThan': transactionAmountGreaterThan,
                'transactionAmount.lessThan': transactionAmountLessThan,
                'transactionAmount.greaterThanOrEqual': transactionAmountGreaterThanOrEqual,
                'transactionAmount.lessThanOrEqual': transactionAmountLessThanOrEqual,
                'transactionAmount.equals': transactionAmountEquals,
                'transactionAmount.notEquals': transactionAmountNotEquals,
                'transactionAmount.specified': transactionAmountSpecified,
                'transactionAmount.in': transactionAmountIn,
                'transactionAmount.notIn': transactionAmountNotIn,
                'transactionDate.greaterThan': transactionDateGreaterThan,
                'transactionDate.lessThan': transactionDateLessThan,
                'transactionDate.greaterThanOrEqual': transactionDateGreaterThanOrEqual,
                'transactionDate.lessThanOrEqual': transactionDateLessThanOrEqual,
                'transactionDate.equals': transactionDateEquals,
                'transactionDate.notEquals': transactionDateNotEquals,
                'transactionDate.specified': transactionDateSpecified,
                'transactionDate.in': transactionDateIn,
                'transactionDate.notIn': transactionDateNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'unappliedAmount.greaterThan': unappliedAmountGreaterThan,
                'unappliedAmount.lessThan': unappliedAmountLessThan,
                'unappliedAmount.greaterThanOrEqual': unappliedAmountGreaterThanOrEqual,
                'unappliedAmount.lessThanOrEqual': unappliedAmountLessThanOrEqual,
                'unappliedAmount.equals': unappliedAmountEquals,
                'unappliedAmount.notEquals': unappliedAmountNotEquals,
                'unappliedAmount.specified': unappliedAmountSpecified,
                'unappliedAmount.in': unappliedAmountIn,
                'unappliedAmount.notIn': unappliedAmountNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'paymentIdId.greaterThan': paymentIdIdGreaterThan,
                'paymentIdId.lessThan': paymentIdIdLessThan,
                'paymentIdId.greaterThanOrEqual': paymentIdIdGreaterThanOrEqual,
                'paymentIdId.lessThanOrEqual': paymentIdIdLessThanOrEqual,
                'paymentIdId.equals': paymentIdIdEquals,
                'paymentIdId.notEquals': paymentIdIdNotEquals,
                'paymentIdId.specified': paymentIdIdSpecified,
                'paymentIdId.in': paymentIdIdIn,
                'paymentIdId.notIn': paymentIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns InsurancePaymentDTO OK
     * @throws ApiError
     */
    public static createInsurancePayment(
        requestBody: InsurancePaymentDTO,
    ): CancelablePromise<InsurancePaymentDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/insurance-payments',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param paymentModeContains
     * @param paymentModeDoesNotContain
     * @param paymentModeEquals
     * @param paymentModeNotEquals
     * @param paymentModeSpecified
     * @param paymentModeIn
     * @param paymentModeNotIn
     * @param paymentMethodContains
     * @param paymentMethodDoesNotContain
     * @param paymentMethodEquals
     * @param paymentMethodNotEquals
     * @param paymentMethodSpecified
     * @param paymentMethodIn
     * @param paymentMethodNotIn
     * @param transactionIdContains
     * @param transactionIdDoesNotContain
     * @param transactionIdEquals
     * @param transactionIdNotEquals
     * @param transactionIdSpecified
     * @param transactionIdIn
     * @param transactionIdNotIn
     * @param transactionAmountGreaterThan
     * @param transactionAmountLessThan
     * @param transactionAmountGreaterThanOrEqual
     * @param transactionAmountLessThanOrEqual
     * @param transactionAmountEquals
     * @param transactionAmountNotEquals
     * @param transactionAmountSpecified
     * @param transactionAmountIn
     * @param transactionAmountNotIn
     * @param transactionDateGreaterThan
     * @param transactionDateLessThan
     * @param transactionDateGreaterThanOrEqual
     * @param transactionDateLessThanOrEqual
     * @param transactionDateEquals
     * @param transactionDateNotEquals
     * @param transactionDateSpecified
     * @param transactionDateIn
     * @param transactionDateNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param unappliedAmountGreaterThan
     * @param unappliedAmountLessThan
     * @param unappliedAmountGreaterThanOrEqual
     * @param unappliedAmountLessThanOrEqual
     * @param unappliedAmountEquals
     * @param unappliedAmountNotEquals
     * @param unappliedAmountSpecified
     * @param unappliedAmountIn
     * @param unappliedAmountNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param paymentIdIdGreaterThan
     * @param paymentIdIdLessThan
     * @param paymentIdIdGreaterThanOrEqual
     * @param paymentIdIdLessThanOrEqual
     * @param paymentIdIdEquals
     * @param paymentIdIdNotEquals
     * @param paymentIdIdSpecified
     * @param paymentIdIdIn
     * @param paymentIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countInsurancePayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        paymentModeContains?: string,
        paymentModeDoesNotContain?: string,
        paymentModeEquals?: string,
        paymentModeNotEquals?: string,
        paymentModeSpecified?: boolean,
        paymentModeIn?: Array<string>,
        paymentModeNotIn?: Array<string>,
        paymentMethodContains?: string,
        paymentMethodDoesNotContain?: string,
        paymentMethodEquals?: string,
        paymentMethodNotEquals?: string,
        paymentMethodSpecified?: boolean,
        paymentMethodIn?: Array<string>,
        paymentMethodNotIn?: Array<string>,
        transactionIdContains?: string,
        transactionIdDoesNotContain?: string,
        transactionIdEquals?: string,
        transactionIdNotEquals?: string,
        transactionIdSpecified?: boolean,
        transactionIdIn?: Array<string>,
        transactionIdNotIn?: Array<string>,
        transactionAmountGreaterThan?: number,
        transactionAmountLessThan?: number,
        transactionAmountGreaterThanOrEqual?: number,
        transactionAmountLessThanOrEqual?: number,
        transactionAmountEquals?: number,
        transactionAmountNotEquals?: number,
        transactionAmountSpecified?: boolean,
        transactionAmountIn?: Array<number>,
        transactionAmountNotIn?: Array<number>,
        transactionDateGreaterThan?: string,
        transactionDateLessThan?: string,
        transactionDateGreaterThanOrEqual?: string,
        transactionDateLessThanOrEqual?: string,
        transactionDateEquals?: string,
        transactionDateNotEquals?: string,
        transactionDateSpecified?: boolean,
        transactionDateIn?: Array<string>,
        transactionDateNotIn?: Array<string>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        unappliedAmountGreaterThan?: number,
        unappliedAmountLessThan?: number,
        unappliedAmountGreaterThanOrEqual?: number,
        unappliedAmountLessThanOrEqual?: number,
        unappliedAmountEquals?: number,
        unappliedAmountNotEquals?: number,
        unappliedAmountSpecified?: boolean,
        unappliedAmountIn?: Array<number>,
        unappliedAmountNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        paymentIdIdGreaterThan?: number,
        paymentIdIdLessThan?: number,
        paymentIdIdGreaterThanOrEqual?: number,
        paymentIdIdLessThanOrEqual?: number,
        paymentIdIdEquals?: number,
        paymentIdIdNotEquals?: number,
        paymentIdIdSpecified?: boolean,
        paymentIdIdIn?: Array<number>,
        paymentIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-payments/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'paymentMode.contains': paymentModeContains,
                'paymentMode.doesNotContain': paymentModeDoesNotContain,
                'paymentMode.equals': paymentModeEquals,
                'paymentMode.notEquals': paymentModeNotEquals,
                'paymentMode.specified': paymentModeSpecified,
                'paymentMode.in': paymentModeIn,
                'paymentMode.notIn': paymentModeNotIn,
                'paymentMethod.contains': paymentMethodContains,
                'paymentMethod.doesNotContain': paymentMethodDoesNotContain,
                'paymentMethod.equals': paymentMethodEquals,
                'paymentMethod.notEquals': paymentMethodNotEquals,
                'paymentMethod.specified': paymentMethodSpecified,
                'paymentMethod.in': paymentMethodIn,
                'paymentMethod.notIn': paymentMethodNotIn,
                'transactionId.contains': transactionIdContains,
                'transactionId.doesNotContain': transactionIdDoesNotContain,
                'transactionId.equals': transactionIdEquals,
                'transactionId.notEquals': transactionIdNotEquals,
                'transactionId.specified': transactionIdSpecified,
                'transactionId.in': transactionIdIn,
                'transactionId.notIn': transactionIdNotIn,
                'transactionAmount.greaterThan': transactionAmountGreaterThan,
                'transactionAmount.lessThan': transactionAmountLessThan,
                'transactionAmount.greaterThanOrEqual': transactionAmountGreaterThanOrEqual,
                'transactionAmount.lessThanOrEqual': transactionAmountLessThanOrEqual,
                'transactionAmount.equals': transactionAmountEquals,
                'transactionAmount.notEquals': transactionAmountNotEquals,
                'transactionAmount.specified': transactionAmountSpecified,
                'transactionAmount.in': transactionAmountIn,
                'transactionAmount.notIn': transactionAmountNotIn,
                'transactionDate.greaterThan': transactionDateGreaterThan,
                'transactionDate.lessThan': transactionDateLessThan,
                'transactionDate.greaterThanOrEqual': transactionDateGreaterThanOrEqual,
                'transactionDate.lessThanOrEqual': transactionDateLessThanOrEqual,
                'transactionDate.equals': transactionDateEquals,
                'transactionDate.notEquals': transactionDateNotEquals,
                'transactionDate.specified': transactionDateSpecified,
                'transactionDate.in': transactionDateIn,
                'transactionDate.notIn': transactionDateNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'unappliedAmount.greaterThan': unappliedAmountGreaterThan,
                'unappliedAmount.lessThan': unappliedAmountLessThan,
                'unappliedAmount.greaterThanOrEqual': unappliedAmountGreaterThanOrEqual,
                'unappliedAmount.lessThanOrEqual': unappliedAmountLessThanOrEqual,
                'unappliedAmount.equals': unappliedAmountEquals,
                'unappliedAmount.notEquals': unappliedAmountNotEquals,
                'unappliedAmount.specified': unappliedAmountSpecified,
                'unappliedAmount.in': unappliedAmountIn,
                'unappliedAmount.notIn': unappliedAmountNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'paymentIdId.greaterThan': paymentIdIdGreaterThan,
                'paymentIdId.lessThan': paymentIdIdLessThan,
                'paymentIdId.greaterThanOrEqual': paymentIdIdGreaterThanOrEqual,
                'paymentIdId.lessThanOrEqual': paymentIdIdLessThanOrEqual,
                'paymentIdId.equals': paymentIdIdEquals,
                'paymentIdId.notEquals': paymentIdIdNotEquals,
                'paymentIdId.specified': paymentIdIdSpecified,
                'paymentIdId.in': paymentIdIdIn,
                'paymentIdId.notIn': paymentIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
