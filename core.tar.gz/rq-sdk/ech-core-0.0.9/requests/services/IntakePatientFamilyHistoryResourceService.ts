/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakePatientFamilyHistoryDTO } from '../models/IntakePatientFamilyHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakePatientFamilyHistoryResourceService {

    /**
     * @param id
     * @returns IntakePatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static getIntakePatientFamilyHistory(
        id: number,
    ): CancelablePromise<IntakePatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-patient-family-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakePatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static updateIntakePatientFamilyHistory(
        id: number,
        requestBody: IntakePatientFamilyHistoryDTO,
    ): CancelablePromise<IntakePatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-patient-family-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakePatientFamilyHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-patient-family-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakePatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakePatientFamilyHistory(
        id: number,
        requestBody: IntakePatientFamilyHistoryDTO,
    ): CancelablePromise<IntakePatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-patient-family-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param relationContains
     * @param relationDoesNotContain
     * @param relationEquals
     * @param relationNotEquals
     * @param relationSpecified
     * @param relationIn
     * @param relationNotIn
     * @param onsetAgeGreaterThan
     * @param onsetAgeLessThan
     * @param onsetAgeGreaterThanOrEqual
     * @param onsetAgeLessThanOrEqual
     * @param onsetAgeEquals
     * @param onsetAgeNotEquals
     * @param onsetAgeSpecified
     * @param onsetAgeIn
     * @param onsetAgeNotIn
     * @param aliveEquals
     * @param aliveNotEquals
     * @param aliveSpecified
     * @param aliveIn
     * @param aliveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param familyHistoryIdIdGreaterThan
     * @param familyHistoryIdIdLessThan
     * @param familyHistoryIdIdGreaterThanOrEqual
     * @param familyHistoryIdIdLessThanOrEqual
     * @param familyHistoryIdIdEquals
     * @param familyHistoryIdIdNotEquals
     * @param familyHistoryIdIdSpecified
     * @param familyHistoryIdIdIn
     * @param familyHistoryIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakePatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static getAllIntakePatientFamilyHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        relationContains?: string,
        relationDoesNotContain?: string,
        relationEquals?: string,
        relationNotEquals?: string,
        relationSpecified?: boolean,
        relationIn?: Array<string>,
        relationNotIn?: Array<string>,
        onsetAgeGreaterThan?: number,
        onsetAgeLessThan?: number,
        onsetAgeGreaterThanOrEqual?: number,
        onsetAgeLessThanOrEqual?: number,
        onsetAgeEquals?: number,
        onsetAgeNotEquals?: number,
        onsetAgeSpecified?: boolean,
        onsetAgeIn?: Array<number>,
        onsetAgeNotIn?: Array<number>,
        aliveEquals?: boolean,
        aliveNotEquals?: boolean,
        aliveSpecified?: boolean,
        aliveIn?: Array<boolean>,
        aliveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        familyHistoryIdIdGreaterThan?: number,
        familyHistoryIdIdLessThan?: number,
        familyHistoryIdIdGreaterThanOrEqual?: number,
        familyHistoryIdIdLessThanOrEqual?: number,
        familyHistoryIdIdEquals?: number,
        familyHistoryIdIdNotEquals?: number,
        familyHistoryIdIdSpecified?: boolean,
        familyHistoryIdIdIn?: Array<number>,
        familyHistoryIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakePatientFamilyHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-patient-family-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'relation.contains': relationContains,
                'relation.doesNotContain': relationDoesNotContain,
                'relation.equals': relationEquals,
                'relation.notEquals': relationNotEquals,
                'relation.specified': relationSpecified,
                'relation.in': relationIn,
                'relation.notIn': relationNotIn,
                'onsetAge.greaterThan': onsetAgeGreaterThan,
                'onsetAge.lessThan': onsetAgeLessThan,
                'onsetAge.greaterThanOrEqual': onsetAgeGreaterThanOrEqual,
                'onsetAge.lessThanOrEqual': onsetAgeLessThanOrEqual,
                'onsetAge.equals': onsetAgeEquals,
                'onsetAge.notEquals': onsetAgeNotEquals,
                'onsetAge.specified': onsetAgeSpecified,
                'onsetAge.in': onsetAgeIn,
                'onsetAge.notIn': onsetAgeNotIn,
                'alive.equals': aliveEquals,
                'alive.notEquals': aliveNotEquals,
                'alive.specified': aliveSpecified,
                'alive.in': aliveIn,
                'alive.notIn': aliveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'familyHistoryIdId.greaterThan': familyHistoryIdIdGreaterThan,
                'familyHistoryIdId.lessThan': familyHistoryIdIdLessThan,
                'familyHistoryIdId.greaterThanOrEqual': familyHistoryIdIdGreaterThanOrEqual,
                'familyHistoryIdId.lessThanOrEqual': familyHistoryIdIdLessThanOrEqual,
                'familyHistoryIdId.equals': familyHistoryIdIdEquals,
                'familyHistoryIdId.notEquals': familyHistoryIdIdNotEquals,
                'familyHistoryIdId.specified': familyHistoryIdIdSpecified,
                'familyHistoryIdId.in': familyHistoryIdIdIn,
                'familyHistoryIdId.notIn': familyHistoryIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakePatientFamilyHistoryDTO OK
     * @throws ApiError
     */
    public static createIntakePatientFamilyHistory(
        requestBody: IntakePatientFamilyHistoryDTO,
    ): CancelablePromise<IntakePatientFamilyHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-patient-family-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param relationContains
     * @param relationDoesNotContain
     * @param relationEquals
     * @param relationNotEquals
     * @param relationSpecified
     * @param relationIn
     * @param relationNotIn
     * @param onsetAgeGreaterThan
     * @param onsetAgeLessThan
     * @param onsetAgeGreaterThanOrEqual
     * @param onsetAgeLessThanOrEqual
     * @param onsetAgeEquals
     * @param onsetAgeNotEquals
     * @param onsetAgeSpecified
     * @param onsetAgeIn
     * @param onsetAgeNotIn
     * @param aliveEquals
     * @param aliveNotEquals
     * @param aliveSpecified
     * @param aliveIn
     * @param aliveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param familyHistoryIdIdGreaterThan
     * @param familyHistoryIdIdLessThan
     * @param familyHistoryIdIdGreaterThanOrEqual
     * @param familyHistoryIdIdLessThanOrEqual
     * @param familyHistoryIdIdEquals
     * @param familyHistoryIdIdNotEquals
     * @param familyHistoryIdIdSpecified
     * @param familyHistoryIdIdIn
     * @param familyHistoryIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakePatientFamilyHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        relationContains?: string,
        relationDoesNotContain?: string,
        relationEquals?: string,
        relationNotEquals?: string,
        relationSpecified?: boolean,
        relationIn?: Array<string>,
        relationNotIn?: Array<string>,
        onsetAgeGreaterThan?: number,
        onsetAgeLessThan?: number,
        onsetAgeGreaterThanOrEqual?: number,
        onsetAgeLessThanOrEqual?: number,
        onsetAgeEquals?: number,
        onsetAgeNotEquals?: number,
        onsetAgeSpecified?: boolean,
        onsetAgeIn?: Array<number>,
        onsetAgeNotIn?: Array<number>,
        aliveEquals?: boolean,
        aliveNotEquals?: boolean,
        aliveSpecified?: boolean,
        aliveIn?: Array<boolean>,
        aliveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        familyHistoryIdIdGreaterThan?: number,
        familyHistoryIdIdLessThan?: number,
        familyHistoryIdIdGreaterThanOrEqual?: number,
        familyHistoryIdIdLessThanOrEqual?: number,
        familyHistoryIdIdEquals?: number,
        familyHistoryIdIdNotEquals?: number,
        familyHistoryIdIdSpecified?: boolean,
        familyHistoryIdIdIn?: Array<number>,
        familyHistoryIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-patient-family-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'relation.contains': relationContains,
                'relation.doesNotContain': relationDoesNotContain,
                'relation.equals': relationEquals,
                'relation.notEquals': relationNotEquals,
                'relation.specified': relationSpecified,
                'relation.in': relationIn,
                'relation.notIn': relationNotIn,
                'onsetAge.greaterThan': onsetAgeGreaterThan,
                'onsetAge.lessThan': onsetAgeLessThan,
                'onsetAge.greaterThanOrEqual': onsetAgeGreaterThanOrEqual,
                'onsetAge.lessThanOrEqual': onsetAgeLessThanOrEqual,
                'onsetAge.equals': onsetAgeEquals,
                'onsetAge.notEquals': onsetAgeNotEquals,
                'onsetAge.specified': onsetAgeSpecified,
                'onsetAge.in': onsetAgeIn,
                'onsetAge.notIn': onsetAgeNotIn,
                'alive.equals': aliveEquals,
                'alive.notEquals': aliveNotEquals,
                'alive.specified': aliveSpecified,
                'alive.in': aliveIn,
                'alive.notIn': aliveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'familyHistoryIdId.greaterThan': familyHistoryIdIdGreaterThan,
                'familyHistoryIdId.lessThan': familyHistoryIdIdLessThan,
                'familyHistoryIdId.greaterThanOrEqual': familyHistoryIdIdGreaterThanOrEqual,
                'familyHistoryIdId.lessThanOrEqual': familyHistoryIdIdLessThanOrEqual,
                'familyHistoryIdId.equals': familyHistoryIdIdEquals,
                'familyHistoryIdId.notEquals': familyHistoryIdIdNotEquals,
                'familyHistoryIdId.specified': familyHistoryIdIdSpecified,
                'familyHistoryIdId.in': familyHistoryIdIdIn,
                'familyHistoryIdId.notIn': familyHistoryIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
