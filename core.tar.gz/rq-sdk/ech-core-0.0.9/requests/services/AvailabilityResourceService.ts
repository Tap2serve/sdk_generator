/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AvailabilityDTO } from '../models/AvailabilityDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class AvailabilityResourceService {

    /**
     * @param id
     * @returns AvailabilityDTO OK
     * @throws ApiError
     */
    public static getAvailability(
        id: number,
    ): CancelablePromise<AvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns AvailabilityDTO OK
     * @throws ApiError
     */
    public static updateAvailability(
        id: number,
        requestBody: AvailabilityDTO,
    ): CancelablePromise<AvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteAvailability(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns AvailabilityDTO OK
     * @throws ApiError
     */
    public static partialUpdateAvailability(
        id: number,
        requestBody: AvailabilityDTO,
    ): CancelablePromise<AvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param bookingWindowGreaterThan
     * @param bookingWindowLessThan
     * @param bookingWindowGreaterThanOrEqual
     * @param bookingWindowLessThanOrEqual
     * @param bookingWindowEquals
     * @param bookingWindowNotEquals
     * @param bookingWindowSpecified
     * @param bookingWindowIn
     * @param bookingWindowNotIn
     * @param timezoneContains
     * @param timezoneDoesNotContain
     * @param timezoneEquals
     * @param timezoneNotEquals
     * @param timezoneSpecified
     * @param timezoneIn
     * @param timezoneNotIn
     * @param lastSettingGreaterThan
     * @param lastSettingLessThan
     * @param lastSettingGreaterThanOrEqual
     * @param lastSettingLessThanOrEqual
     * @param lastSettingEquals
     * @param lastSettingNotEquals
     * @param lastSettingSpecified
     * @param lastSettingIn
     * @param lastSettingNotIn
     * @param inpersonInitialConsultTimeGreaterThan
     * @param inpersonInitialConsultTimeLessThan
     * @param inpersonInitialConsultTimeGreaterThanOrEqual
     * @param inpersonInitialConsultTimeLessThanOrEqual
     * @param inpersonInitialConsultTimeEquals
     * @param inpersonInitialConsultTimeNotEquals
     * @param inpersonInitialConsultTimeSpecified
     * @param inpersonInitialConsultTimeIn
     * @param inpersonInitialConsultTimeNotIn
     * @param inpersonFollowupConsultTimeGreaterThan
     * @param inpersonFollowupConsultTimeLessThan
     * @param inpersonFollowupConsultTimeGreaterThanOrEqual
     * @param inpersonFollowupConsultTimeLessThanOrEqual
     * @param inpersonFollowupConsultTimeEquals
     * @param inpersonFollowupConsultTimeNotEquals
     * @param inpersonFollowupConsultTimeSpecified
     * @param inpersonFollowupConsultTimeIn
     * @param inpersonFollowupConsultTimeNotIn
     * @param inpersonThresholdBookingtimeGreaterThan
     * @param inpersonThresholdBookingtimeLessThan
     * @param inpersonThresholdBookingtimeGreaterThanOrEqual
     * @param inpersonThresholdBookingtimeLessThanOrEqual
     * @param inpersonThresholdBookingtimeEquals
     * @param inpersonThresholdBookingtimeNotEquals
     * @param inpersonThresholdBookingtimeSpecified
     * @param inpersonThresholdBookingtimeIn
     * @param inpersonThresholdBookingtimeNotIn
     * @param inpersonBookingIntervalTimeGreaterThan
     * @param inpersonBookingIntervalTimeLessThan
     * @param inpersonBookingIntervalTimeGreaterThanOrEqual
     * @param inpersonBookingIntervalTimeLessThanOrEqual
     * @param inpersonBookingIntervalTimeEquals
     * @param inpersonBookingIntervalTimeNotEquals
     * @param inpersonBookingIntervalTimeSpecified
     * @param inpersonBookingIntervalTimeIn
     * @param inpersonBookingIntervalTimeNotIn
     * @param virtualInitialConsultTimeGreaterThan
     * @param virtualInitialConsultTimeLessThan
     * @param virtualInitialConsultTimeGreaterThanOrEqual
     * @param virtualInitialConsultTimeLessThanOrEqual
     * @param virtualInitialConsultTimeEquals
     * @param virtualInitialConsultTimeNotEquals
     * @param virtualInitialConsultTimeSpecified
     * @param virtualInitialConsultTimeIn
     * @param virtualInitialConsultTimeNotIn
     * @param virtualFollowupConsultTimeGreaterThan
     * @param virtualFollowupConsultTimeLessThan
     * @param virtualFollowupConsultTimeGreaterThanOrEqual
     * @param virtualFollowupConsultTimeLessThanOrEqual
     * @param virtualFollowupConsultTimeEquals
     * @param virtualFollowupConsultTimeNotEquals
     * @param virtualFollowupConsultTimeSpecified
     * @param virtualFollowupConsultTimeIn
     * @param virtualFollowupConsultTimeNotIn
     * @param virtualThresholdBookingTimeGreaterThan
     * @param virtualThresholdBookingTimeLessThan
     * @param virtualThresholdBookingTimeGreaterThanOrEqual
     * @param virtualThresholdBookingTimeLessThanOrEqual
     * @param virtualThresholdBookingTimeEquals
     * @param virtualThresholdBookingTimeNotEquals
     * @param virtualThresholdBookingTimeSpecified
     * @param virtualThresholdBookingTimeIn
     * @param virtualThresholdBookingTimeNotIn
     * @param virtualBookingIntervalTimeGreaterThan
     * @param virtualBookingIntervalTimeLessThan
     * @param virtualBookingIntervalTimeGreaterThanOrEqual
     * @param virtualBookingIntervalTimeLessThanOrEqual
     * @param virtualBookingIntervalTimeEquals
     * @param virtualBookingIntervalTimeNotEquals
     * @param virtualBookingIntervalTimeSpecified
     * @param virtualBookingIntervalTimeIn
     * @param virtualBookingIntervalTimeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param locationIdIdGreaterThan
     * @param locationIdIdLessThan
     * @param locationIdIdGreaterThanOrEqual
     * @param locationIdIdLessThanOrEqual
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param providerAvailabilityIdIdGreaterThan
     * @param providerAvailabilityIdIdLessThan
     * @param providerAvailabilityIdIdGreaterThanOrEqual
     * @param providerAvailabilityIdIdLessThanOrEqual
     * @param providerAvailabilityIdIdEquals
     * @param providerAvailabilityIdIdNotEquals
     * @param providerAvailabilityIdIdSpecified
     * @param providerAvailabilityIdIdIn
     * @param providerAvailabilityIdIdNotIn
     * @param providerUnAvailabilityIdIdGreaterThan
     * @param providerUnAvailabilityIdIdLessThan
     * @param providerUnAvailabilityIdIdGreaterThanOrEqual
     * @param providerUnAvailabilityIdIdLessThanOrEqual
     * @param providerUnAvailabilityIdIdEquals
     * @param providerUnAvailabilityIdIdNotEquals
     * @param providerUnAvailabilityIdIdSpecified
     * @param providerUnAvailabilityIdIdIn
     * @param providerUnAvailabilityIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns AvailabilityDTO OK
     * @throws ApiError
     */
    public static getAllAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        bookingWindowGreaterThan?: number,
        bookingWindowLessThan?: number,
        bookingWindowGreaterThanOrEqual?: number,
        bookingWindowLessThanOrEqual?: number,
        bookingWindowEquals?: number,
        bookingWindowNotEquals?: number,
        bookingWindowSpecified?: boolean,
        bookingWindowIn?: Array<number>,
        bookingWindowNotIn?: Array<number>,
        timezoneContains?: string,
        timezoneDoesNotContain?: string,
        timezoneEquals?: string,
        timezoneNotEquals?: string,
        timezoneSpecified?: boolean,
        timezoneIn?: Array<string>,
        timezoneNotIn?: Array<string>,
        lastSettingGreaterThan?: number,
        lastSettingLessThan?: number,
        lastSettingGreaterThanOrEqual?: number,
        lastSettingLessThanOrEqual?: number,
        lastSettingEquals?: number,
        lastSettingNotEquals?: number,
        lastSettingSpecified?: boolean,
        lastSettingIn?: Array<number>,
        lastSettingNotIn?: Array<number>,
        inpersonInitialConsultTimeGreaterThan?: number,
        inpersonInitialConsultTimeLessThan?: number,
        inpersonInitialConsultTimeGreaterThanOrEqual?: number,
        inpersonInitialConsultTimeLessThanOrEqual?: number,
        inpersonInitialConsultTimeEquals?: number,
        inpersonInitialConsultTimeNotEquals?: number,
        inpersonInitialConsultTimeSpecified?: boolean,
        inpersonInitialConsultTimeIn?: Array<number>,
        inpersonInitialConsultTimeNotIn?: Array<number>,
        inpersonFollowupConsultTimeGreaterThan?: number,
        inpersonFollowupConsultTimeLessThan?: number,
        inpersonFollowupConsultTimeGreaterThanOrEqual?: number,
        inpersonFollowupConsultTimeLessThanOrEqual?: number,
        inpersonFollowupConsultTimeEquals?: number,
        inpersonFollowupConsultTimeNotEquals?: number,
        inpersonFollowupConsultTimeSpecified?: boolean,
        inpersonFollowupConsultTimeIn?: Array<number>,
        inpersonFollowupConsultTimeNotIn?: Array<number>,
        inpersonThresholdBookingtimeGreaterThan?: number,
        inpersonThresholdBookingtimeLessThan?: number,
        inpersonThresholdBookingtimeGreaterThanOrEqual?: number,
        inpersonThresholdBookingtimeLessThanOrEqual?: number,
        inpersonThresholdBookingtimeEquals?: number,
        inpersonThresholdBookingtimeNotEquals?: number,
        inpersonThresholdBookingtimeSpecified?: boolean,
        inpersonThresholdBookingtimeIn?: Array<number>,
        inpersonThresholdBookingtimeNotIn?: Array<number>,
        inpersonBookingIntervalTimeGreaterThan?: number,
        inpersonBookingIntervalTimeLessThan?: number,
        inpersonBookingIntervalTimeGreaterThanOrEqual?: number,
        inpersonBookingIntervalTimeLessThanOrEqual?: number,
        inpersonBookingIntervalTimeEquals?: number,
        inpersonBookingIntervalTimeNotEquals?: number,
        inpersonBookingIntervalTimeSpecified?: boolean,
        inpersonBookingIntervalTimeIn?: Array<number>,
        inpersonBookingIntervalTimeNotIn?: Array<number>,
        virtualInitialConsultTimeGreaterThan?: number,
        virtualInitialConsultTimeLessThan?: number,
        virtualInitialConsultTimeGreaterThanOrEqual?: number,
        virtualInitialConsultTimeLessThanOrEqual?: number,
        virtualInitialConsultTimeEquals?: number,
        virtualInitialConsultTimeNotEquals?: number,
        virtualInitialConsultTimeSpecified?: boolean,
        virtualInitialConsultTimeIn?: Array<number>,
        virtualInitialConsultTimeNotIn?: Array<number>,
        virtualFollowupConsultTimeGreaterThan?: number,
        virtualFollowupConsultTimeLessThan?: number,
        virtualFollowupConsultTimeGreaterThanOrEqual?: number,
        virtualFollowupConsultTimeLessThanOrEqual?: number,
        virtualFollowupConsultTimeEquals?: number,
        virtualFollowupConsultTimeNotEquals?: number,
        virtualFollowupConsultTimeSpecified?: boolean,
        virtualFollowupConsultTimeIn?: Array<number>,
        virtualFollowupConsultTimeNotIn?: Array<number>,
        virtualThresholdBookingTimeGreaterThan?: number,
        virtualThresholdBookingTimeLessThan?: number,
        virtualThresholdBookingTimeGreaterThanOrEqual?: number,
        virtualThresholdBookingTimeLessThanOrEqual?: number,
        virtualThresholdBookingTimeEquals?: number,
        virtualThresholdBookingTimeNotEquals?: number,
        virtualThresholdBookingTimeSpecified?: boolean,
        virtualThresholdBookingTimeIn?: Array<number>,
        virtualThresholdBookingTimeNotIn?: Array<number>,
        virtualBookingIntervalTimeGreaterThan?: number,
        virtualBookingIntervalTimeLessThan?: number,
        virtualBookingIntervalTimeGreaterThanOrEqual?: number,
        virtualBookingIntervalTimeLessThanOrEqual?: number,
        virtualBookingIntervalTimeEquals?: number,
        virtualBookingIntervalTimeNotEquals?: number,
        virtualBookingIntervalTimeSpecified?: boolean,
        virtualBookingIntervalTimeIn?: Array<number>,
        virtualBookingIntervalTimeNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        locationIdIdGreaterThan?: number,
        locationIdIdLessThan?: number,
        locationIdIdGreaterThanOrEqual?: number,
        locationIdIdLessThanOrEqual?: number,
        locationIdIdEquals?: number,
        locationIdIdNotEquals?: number,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<number>,
        locationIdIdNotIn?: Array<number>,
        providerAvailabilityIdIdGreaterThan?: number,
        providerAvailabilityIdIdLessThan?: number,
        providerAvailabilityIdIdGreaterThanOrEqual?: number,
        providerAvailabilityIdIdLessThanOrEqual?: number,
        providerAvailabilityIdIdEquals?: number,
        providerAvailabilityIdIdNotEquals?: number,
        providerAvailabilityIdIdSpecified?: boolean,
        providerAvailabilityIdIdIn?: Array<number>,
        providerAvailabilityIdIdNotIn?: Array<number>,
        providerUnAvailabilityIdIdGreaterThan?: number,
        providerUnAvailabilityIdIdLessThan?: number,
        providerUnAvailabilityIdIdGreaterThanOrEqual?: number,
        providerUnAvailabilityIdIdLessThanOrEqual?: number,
        providerUnAvailabilityIdIdEquals?: number,
        providerUnAvailabilityIdIdNotEquals?: number,
        providerUnAvailabilityIdIdSpecified?: boolean,
        providerUnAvailabilityIdIdIn?: Array<number>,
        providerUnAvailabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<AvailabilityDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/availabilities',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'bookingWindow.greaterThan': bookingWindowGreaterThan,
                'bookingWindow.lessThan': bookingWindowLessThan,
                'bookingWindow.greaterThanOrEqual': bookingWindowGreaterThanOrEqual,
                'bookingWindow.lessThanOrEqual': bookingWindowLessThanOrEqual,
                'bookingWindow.equals': bookingWindowEquals,
                'bookingWindow.notEquals': bookingWindowNotEquals,
                'bookingWindow.specified': bookingWindowSpecified,
                'bookingWindow.in': bookingWindowIn,
                'bookingWindow.notIn': bookingWindowNotIn,
                'timezone.contains': timezoneContains,
                'timezone.doesNotContain': timezoneDoesNotContain,
                'timezone.equals': timezoneEquals,
                'timezone.notEquals': timezoneNotEquals,
                'timezone.specified': timezoneSpecified,
                'timezone.in': timezoneIn,
                'timezone.notIn': timezoneNotIn,
                'lastSetting.greaterThan': lastSettingGreaterThan,
                'lastSetting.lessThan': lastSettingLessThan,
                'lastSetting.greaterThanOrEqual': lastSettingGreaterThanOrEqual,
                'lastSetting.lessThanOrEqual': lastSettingLessThanOrEqual,
                'lastSetting.equals': lastSettingEquals,
                'lastSetting.notEquals': lastSettingNotEquals,
                'lastSetting.specified': lastSettingSpecified,
                'lastSetting.in': lastSettingIn,
                'lastSetting.notIn': lastSettingNotIn,
                'inpersonInitialConsultTime.greaterThan': inpersonInitialConsultTimeGreaterThan,
                'inpersonInitialConsultTime.lessThan': inpersonInitialConsultTimeLessThan,
                'inpersonInitialConsultTime.greaterThanOrEqual': inpersonInitialConsultTimeGreaterThanOrEqual,
                'inpersonInitialConsultTime.lessThanOrEqual': inpersonInitialConsultTimeLessThanOrEqual,
                'inpersonInitialConsultTime.equals': inpersonInitialConsultTimeEquals,
                'inpersonInitialConsultTime.notEquals': inpersonInitialConsultTimeNotEquals,
                'inpersonInitialConsultTime.specified': inpersonInitialConsultTimeSpecified,
                'inpersonInitialConsultTime.in': inpersonInitialConsultTimeIn,
                'inpersonInitialConsultTime.notIn': inpersonInitialConsultTimeNotIn,
                'inpersonFollowupConsultTime.greaterThan': inpersonFollowupConsultTimeGreaterThan,
                'inpersonFollowupConsultTime.lessThan': inpersonFollowupConsultTimeLessThan,
                'inpersonFollowupConsultTime.greaterThanOrEqual': inpersonFollowupConsultTimeGreaterThanOrEqual,
                'inpersonFollowupConsultTime.lessThanOrEqual': inpersonFollowupConsultTimeLessThanOrEqual,
                'inpersonFollowupConsultTime.equals': inpersonFollowupConsultTimeEquals,
                'inpersonFollowupConsultTime.notEquals': inpersonFollowupConsultTimeNotEquals,
                'inpersonFollowupConsultTime.specified': inpersonFollowupConsultTimeSpecified,
                'inpersonFollowupConsultTime.in': inpersonFollowupConsultTimeIn,
                'inpersonFollowupConsultTime.notIn': inpersonFollowupConsultTimeNotIn,
                'inpersonThresholdBookingtime.greaterThan': inpersonThresholdBookingtimeGreaterThan,
                'inpersonThresholdBookingtime.lessThan': inpersonThresholdBookingtimeLessThan,
                'inpersonThresholdBookingtime.greaterThanOrEqual': inpersonThresholdBookingtimeGreaterThanOrEqual,
                'inpersonThresholdBookingtime.lessThanOrEqual': inpersonThresholdBookingtimeLessThanOrEqual,
                'inpersonThresholdBookingtime.equals': inpersonThresholdBookingtimeEquals,
                'inpersonThresholdBookingtime.notEquals': inpersonThresholdBookingtimeNotEquals,
                'inpersonThresholdBookingtime.specified': inpersonThresholdBookingtimeSpecified,
                'inpersonThresholdBookingtime.in': inpersonThresholdBookingtimeIn,
                'inpersonThresholdBookingtime.notIn': inpersonThresholdBookingtimeNotIn,
                'inpersonBookingIntervalTime.greaterThan': inpersonBookingIntervalTimeGreaterThan,
                'inpersonBookingIntervalTime.lessThan': inpersonBookingIntervalTimeLessThan,
                'inpersonBookingIntervalTime.greaterThanOrEqual': inpersonBookingIntervalTimeGreaterThanOrEqual,
                'inpersonBookingIntervalTime.lessThanOrEqual': inpersonBookingIntervalTimeLessThanOrEqual,
                'inpersonBookingIntervalTime.equals': inpersonBookingIntervalTimeEquals,
                'inpersonBookingIntervalTime.notEquals': inpersonBookingIntervalTimeNotEquals,
                'inpersonBookingIntervalTime.specified': inpersonBookingIntervalTimeSpecified,
                'inpersonBookingIntervalTime.in': inpersonBookingIntervalTimeIn,
                'inpersonBookingIntervalTime.notIn': inpersonBookingIntervalTimeNotIn,
                'virtualInitialConsultTime.greaterThan': virtualInitialConsultTimeGreaterThan,
                'virtualInitialConsultTime.lessThan': virtualInitialConsultTimeLessThan,
                'virtualInitialConsultTime.greaterThanOrEqual': virtualInitialConsultTimeGreaterThanOrEqual,
                'virtualInitialConsultTime.lessThanOrEqual': virtualInitialConsultTimeLessThanOrEqual,
                'virtualInitialConsultTime.equals': virtualInitialConsultTimeEquals,
                'virtualInitialConsultTime.notEquals': virtualInitialConsultTimeNotEquals,
                'virtualInitialConsultTime.specified': virtualInitialConsultTimeSpecified,
                'virtualInitialConsultTime.in': virtualInitialConsultTimeIn,
                'virtualInitialConsultTime.notIn': virtualInitialConsultTimeNotIn,
                'virtualFollowupConsultTime.greaterThan': virtualFollowupConsultTimeGreaterThan,
                'virtualFollowupConsultTime.lessThan': virtualFollowupConsultTimeLessThan,
                'virtualFollowupConsultTime.greaterThanOrEqual': virtualFollowupConsultTimeGreaterThanOrEqual,
                'virtualFollowupConsultTime.lessThanOrEqual': virtualFollowupConsultTimeLessThanOrEqual,
                'virtualFollowupConsultTime.equals': virtualFollowupConsultTimeEquals,
                'virtualFollowupConsultTime.notEquals': virtualFollowupConsultTimeNotEquals,
                'virtualFollowupConsultTime.specified': virtualFollowupConsultTimeSpecified,
                'virtualFollowupConsultTime.in': virtualFollowupConsultTimeIn,
                'virtualFollowupConsultTime.notIn': virtualFollowupConsultTimeNotIn,
                'virtualThresholdBookingTime.greaterThan': virtualThresholdBookingTimeGreaterThan,
                'virtualThresholdBookingTime.lessThan': virtualThresholdBookingTimeLessThan,
                'virtualThresholdBookingTime.greaterThanOrEqual': virtualThresholdBookingTimeGreaterThanOrEqual,
                'virtualThresholdBookingTime.lessThanOrEqual': virtualThresholdBookingTimeLessThanOrEqual,
                'virtualThresholdBookingTime.equals': virtualThresholdBookingTimeEquals,
                'virtualThresholdBookingTime.notEquals': virtualThresholdBookingTimeNotEquals,
                'virtualThresholdBookingTime.specified': virtualThresholdBookingTimeSpecified,
                'virtualThresholdBookingTime.in': virtualThresholdBookingTimeIn,
                'virtualThresholdBookingTime.notIn': virtualThresholdBookingTimeNotIn,
                'virtualBookingIntervalTime.greaterThan': virtualBookingIntervalTimeGreaterThan,
                'virtualBookingIntervalTime.lessThan': virtualBookingIntervalTimeLessThan,
                'virtualBookingIntervalTime.greaterThanOrEqual': virtualBookingIntervalTimeGreaterThanOrEqual,
                'virtualBookingIntervalTime.lessThanOrEqual': virtualBookingIntervalTimeLessThanOrEqual,
                'virtualBookingIntervalTime.equals': virtualBookingIntervalTimeEquals,
                'virtualBookingIntervalTime.notEquals': virtualBookingIntervalTimeNotEquals,
                'virtualBookingIntervalTime.specified': virtualBookingIntervalTimeSpecified,
                'virtualBookingIntervalTime.in': virtualBookingIntervalTimeIn,
                'virtualBookingIntervalTime.notIn': virtualBookingIntervalTimeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'locationIdId.greaterThan': locationIdIdGreaterThan,
                'locationIdId.lessThan': locationIdIdLessThan,
                'locationIdId.greaterThanOrEqual': locationIdIdGreaterThanOrEqual,
                'locationIdId.lessThanOrEqual': locationIdIdLessThanOrEqual,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'providerAvailabilityIdId.greaterThan': providerAvailabilityIdIdGreaterThan,
                'providerAvailabilityIdId.lessThan': providerAvailabilityIdIdLessThan,
                'providerAvailabilityIdId.greaterThanOrEqual': providerAvailabilityIdIdGreaterThanOrEqual,
                'providerAvailabilityIdId.lessThanOrEqual': providerAvailabilityIdIdLessThanOrEqual,
                'providerAvailabilityIdId.equals': providerAvailabilityIdIdEquals,
                'providerAvailabilityIdId.notEquals': providerAvailabilityIdIdNotEquals,
                'providerAvailabilityIdId.specified': providerAvailabilityIdIdSpecified,
                'providerAvailabilityIdId.in': providerAvailabilityIdIdIn,
                'providerAvailabilityIdId.notIn': providerAvailabilityIdIdNotIn,
                'providerUnAvailabilityIdId.greaterThan': providerUnAvailabilityIdIdGreaterThan,
                'providerUnAvailabilityIdId.lessThan': providerUnAvailabilityIdIdLessThan,
                'providerUnAvailabilityIdId.greaterThanOrEqual': providerUnAvailabilityIdIdGreaterThanOrEqual,
                'providerUnAvailabilityIdId.lessThanOrEqual': providerUnAvailabilityIdIdLessThanOrEqual,
                'providerUnAvailabilityIdId.equals': providerUnAvailabilityIdIdEquals,
                'providerUnAvailabilityIdId.notEquals': providerUnAvailabilityIdIdNotEquals,
                'providerUnAvailabilityIdId.specified': providerUnAvailabilityIdIdSpecified,
                'providerUnAvailabilityIdId.in': providerUnAvailabilityIdIdIn,
                'providerUnAvailabilityIdId.notIn': providerUnAvailabilityIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns AvailabilityDTO OK
     * @throws ApiError
     */
    public static createAvailability(
        requestBody: AvailabilityDTO,
    ): CancelablePromise<AvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/availabilities',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param bookingWindowGreaterThan
     * @param bookingWindowLessThan
     * @param bookingWindowGreaterThanOrEqual
     * @param bookingWindowLessThanOrEqual
     * @param bookingWindowEquals
     * @param bookingWindowNotEquals
     * @param bookingWindowSpecified
     * @param bookingWindowIn
     * @param bookingWindowNotIn
     * @param timezoneContains
     * @param timezoneDoesNotContain
     * @param timezoneEquals
     * @param timezoneNotEquals
     * @param timezoneSpecified
     * @param timezoneIn
     * @param timezoneNotIn
     * @param lastSettingGreaterThan
     * @param lastSettingLessThan
     * @param lastSettingGreaterThanOrEqual
     * @param lastSettingLessThanOrEqual
     * @param lastSettingEquals
     * @param lastSettingNotEquals
     * @param lastSettingSpecified
     * @param lastSettingIn
     * @param lastSettingNotIn
     * @param inpersonInitialConsultTimeGreaterThan
     * @param inpersonInitialConsultTimeLessThan
     * @param inpersonInitialConsultTimeGreaterThanOrEqual
     * @param inpersonInitialConsultTimeLessThanOrEqual
     * @param inpersonInitialConsultTimeEquals
     * @param inpersonInitialConsultTimeNotEquals
     * @param inpersonInitialConsultTimeSpecified
     * @param inpersonInitialConsultTimeIn
     * @param inpersonInitialConsultTimeNotIn
     * @param inpersonFollowupConsultTimeGreaterThan
     * @param inpersonFollowupConsultTimeLessThan
     * @param inpersonFollowupConsultTimeGreaterThanOrEqual
     * @param inpersonFollowupConsultTimeLessThanOrEqual
     * @param inpersonFollowupConsultTimeEquals
     * @param inpersonFollowupConsultTimeNotEquals
     * @param inpersonFollowupConsultTimeSpecified
     * @param inpersonFollowupConsultTimeIn
     * @param inpersonFollowupConsultTimeNotIn
     * @param inpersonThresholdBookingtimeGreaterThan
     * @param inpersonThresholdBookingtimeLessThan
     * @param inpersonThresholdBookingtimeGreaterThanOrEqual
     * @param inpersonThresholdBookingtimeLessThanOrEqual
     * @param inpersonThresholdBookingtimeEquals
     * @param inpersonThresholdBookingtimeNotEquals
     * @param inpersonThresholdBookingtimeSpecified
     * @param inpersonThresholdBookingtimeIn
     * @param inpersonThresholdBookingtimeNotIn
     * @param inpersonBookingIntervalTimeGreaterThan
     * @param inpersonBookingIntervalTimeLessThan
     * @param inpersonBookingIntervalTimeGreaterThanOrEqual
     * @param inpersonBookingIntervalTimeLessThanOrEqual
     * @param inpersonBookingIntervalTimeEquals
     * @param inpersonBookingIntervalTimeNotEquals
     * @param inpersonBookingIntervalTimeSpecified
     * @param inpersonBookingIntervalTimeIn
     * @param inpersonBookingIntervalTimeNotIn
     * @param virtualInitialConsultTimeGreaterThan
     * @param virtualInitialConsultTimeLessThan
     * @param virtualInitialConsultTimeGreaterThanOrEqual
     * @param virtualInitialConsultTimeLessThanOrEqual
     * @param virtualInitialConsultTimeEquals
     * @param virtualInitialConsultTimeNotEquals
     * @param virtualInitialConsultTimeSpecified
     * @param virtualInitialConsultTimeIn
     * @param virtualInitialConsultTimeNotIn
     * @param virtualFollowupConsultTimeGreaterThan
     * @param virtualFollowupConsultTimeLessThan
     * @param virtualFollowupConsultTimeGreaterThanOrEqual
     * @param virtualFollowupConsultTimeLessThanOrEqual
     * @param virtualFollowupConsultTimeEquals
     * @param virtualFollowupConsultTimeNotEquals
     * @param virtualFollowupConsultTimeSpecified
     * @param virtualFollowupConsultTimeIn
     * @param virtualFollowupConsultTimeNotIn
     * @param virtualThresholdBookingTimeGreaterThan
     * @param virtualThresholdBookingTimeLessThan
     * @param virtualThresholdBookingTimeGreaterThanOrEqual
     * @param virtualThresholdBookingTimeLessThanOrEqual
     * @param virtualThresholdBookingTimeEquals
     * @param virtualThresholdBookingTimeNotEquals
     * @param virtualThresholdBookingTimeSpecified
     * @param virtualThresholdBookingTimeIn
     * @param virtualThresholdBookingTimeNotIn
     * @param virtualBookingIntervalTimeGreaterThan
     * @param virtualBookingIntervalTimeLessThan
     * @param virtualBookingIntervalTimeGreaterThanOrEqual
     * @param virtualBookingIntervalTimeLessThanOrEqual
     * @param virtualBookingIntervalTimeEquals
     * @param virtualBookingIntervalTimeNotEquals
     * @param virtualBookingIntervalTimeSpecified
     * @param virtualBookingIntervalTimeIn
     * @param virtualBookingIntervalTimeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param locationIdIdGreaterThan
     * @param locationIdIdLessThan
     * @param locationIdIdGreaterThanOrEqual
     * @param locationIdIdLessThanOrEqual
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param providerAvailabilityIdIdGreaterThan
     * @param providerAvailabilityIdIdLessThan
     * @param providerAvailabilityIdIdGreaterThanOrEqual
     * @param providerAvailabilityIdIdLessThanOrEqual
     * @param providerAvailabilityIdIdEquals
     * @param providerAvailabilityIdIdNotEquals
     * @param providerAvailabilityIdIdSpecified
     * @param providerAvailabilityIdIdIn
     * @param providerAvailabilityIdIdNotIn
     * @param providerUnAvailabilityIdIdGreaterThan
     * @param providerUnAvailabilityIdIdLessThan
     * @param providerUnAvailabilityIdIdGreaterThanOrEqual
     * @param providerUnAvailabilityIdIdLessThanOrEqual
     * @param providerUnAvailabilityIdIdEquals
     * @param providerUnAvailabilityIdIdNotEquals
     * @param providerUnAvailabilityIdIdSpecified
     * @param providerUnAvailabilityIdIdIn
     * @param providerUnAvailabilityIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        bookingWindowGreaterThan?: number,
        bookingWindowLessThan?: number,
        bookingWindowGreaterThanOrEqual?: number,
        bookingWindowLessThanOrEqual?: number,
        bookingWindowEquals?: number,
        bookingWindowNotEquals?: number,
        bookingWindowSpecified?: boolean,
        bookingWindowIn?: Array<number>,
        bookingWindowNotIn?: Array<number>,
        timezoneContains?: string,
        timezoneDoesNotContain?: string,
        timezoneEquals?: string,
        timezoneNotEquals?: string,
        timezoneSpecified?: boolean,
        timezoneIn?: Array<string>,
        timezoneNotIn?: Array<string>,
        lastSettingGreaterThan?: number,
        lastSettingLessThan?: number,
        lastSettingGreaterThanOrEqual?: number,
        lastSettingLessThanOrEqual?: number,
        lastSettingEquals?: number,
        lastSettingNotEquals?: number,
        lastSettingSpecified?: boolean,
        lastSettingIn?: Array<number>,
        lastSettingNotIn?: Array<number>,
        inpersonInitialConsultTimeGreaterThan?: number,
        inpersonInitialConsultTimeLessThan?: number,
        inpersonInitialConsultTimeGreaterThanOrEqual?: number,
        inpersonInitialConsultTimeLessThanOrEqual?: number,
        inpersonInitialConsultTimeEquals?: number,
        inpersonInitialConsultTimeNotEquals?: number,
        inpersonInitialConsultTimeSpecified?: boolean,
        inpersonInitialConsultTimeIn?: Array<number>,
        inpersonInitialConsultTimeNotIn?: Array<number>,
        inpersonFollowupConsultTimeGreaterThan?: number,
        inpersonFollowupConsultTimeLessThan?: number,
        inpersonFollowupConsultTimeGreaterThanOrEqual?: number,
        inpersonFollowupConsultTimeLessThanOrEqual?: number,
        inpersonFollowupConsultTimeEquals?: number,
        inpersonFollowupConsultTimeNotEquals?: number,
        inpersonFollowupConsultTimeSpecified?: boolean,
        inpersonFollowupConsultTimeIn?: Array<number>,
        inpersonFollowupConsultTimeNotIn?: Array<number>,
        inpersonThresholdBookingtimeGreaterThan?: number,
        inpersonThresholdBookingtimeLessThan?: number,
        inpersonThresholdBookingtimeGreaterThanOrEqual?: number,
        inpersonThresholdBookingtimeLessThanOrEqual?: number,
        inpersonThresholdBookingtimeEquals?: number,
        inpersonThresholdBookingtimeNotEquals?: number,
        inpersonThresholdBookingtimeSpecified?: boolean,
        inpersonThresholdBookingtimeIn?: Array<number>,
        inpersonThresholdBookingtimeNotIn?: Array<number>,
        inpersonBookingIntervalTimeGreaterThan?: number,
        inpersonBookingIntervalTimeLessThan?: number,
        inpersonBookingIntervalTimeGreaterThanOrEqual?: number,
        inpersonBookingIntervalTimeLessThanOrEqual?: number,
        inpersonBookingIntervalTimeEquals?: number,
        inpersonBookingIntervalTimeNotEquals?: number,
        inpersonBookingIntervalTimeSpecified?: boolean,
        inpersonBookingIntervalTimeIn?: Array<number>,
        inpersonBookingIntervalTimeNotIn?: Array<number>,
        virtualInitialConsultTimeGreaterThan?: number,
        virtualInitialConsultTimeLessThan?: number,
        virtualInitialConsultTimeGreaterThanOrEqual?: number,
        virtualInitialConsultTimeLessThanOrEqual?: number,
        virtualInitialConsultTimeEquals?: number,
        virtualInitialConsultTimeNotEquals?: number,
        virtualInitialConsultTimeSpecified?: boolean,
        virtualInitialConsultTimeIn?: Array<number>,
        virtualInitialConsultTimeNotIn?: Array<number>,
        virtualFollowupConsultTimeGreaterThan?: number,
        virtualFollowupConsultTimeLessThan?: number,
        virtualFollowupConsultTimeGreaterThanOrEqual?: number,
        virtualFollowupConsultTimeLessThanOrEqual?: number,
        virtualFollowupConsultTimeEquals?: number,
        virtualFollowupConsultTimeNotEquals?: number,
        virtualFollowupConsultTimeSpecified?: boolean,
        virtualFollowupConsultTimeIn?: Array<number>,
        virtualFollowupConsultTimeNotIn?: Array<number>,
        virtualThresholdBookingTimeGreaterThan?: number,
        virtualThresholdBookingTimeLessThan?: number,
        virtualThresholdBookingTimeGreaterThanOrEqual?: number,
        virtualThresholdBookingTimeLessThanOrEqual?: number,
        virtualThresholdBookingTimeEquals?: number,
        virtualThresholdBookingTimeNotEquals?: number,
        virtualThresholdBookingTimeSpecified?: boolean,
        virtualThresholdBookingTimeIn?: Array<number>,
        virtualThresholdBookingTimeNotIn?: Array<number>,
        virtualBookingIntervalTimeGreaterThan?: number,
        virtualBookingIntervalTimeLessThan?: number,
        virtualBookingIntervalTimeGreaterThanOrEqual?: number,
        virtualBookingIntervalTimeLessThanOrEqual?: number,
        virtualBookingIntervalTimeEquals?: number,
        virtualBookingIntervalTimeNotEquals?: number,
        virtualBookingIntervalTimeSpecified?: boolean,
        virtualBookingIntervalTimeIn?: Array<number>,
        virtualBookingIntervalTimeNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        locationIdIdGreaterThan?: number,
        locationIdIdLessThan?: number,
        locationIdIdGreaterThanOrEqual?: number,
        locationIdIdLessThanOrEqual?: number,
        locationIdIdEquals?: number,
        locationIdIdNotEquals?: number,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<number>,
        locationIdIdNotIn?: Array<number>,
        providerAvailabilityIdIdGreaterThan?: number,
        providerAvailabilityIdIdLessThan?: number,
        providerAvailabilityIdIdGreaterThanOrEqual?: number,
        providerAvailabilityIdIdLessThanOrEqual?: number,
        providerAvailabilityIdIdEquals?: number,
        providerAvailabilityIdIdNotEquals?: number,
        providerAvailabilityIdIdSpecified?: boolean,
        providerAvailabilityIdIdIn?: Array<number>,
        providerAvailabilityIdIdNotIn?: Array<number>,
        providerUnAvailabilityIdIdGreaterThan?: number,
        providerUnAvailabilityIdIdLessThan?: number,
        providerUnAvailabilityIdIdGreaterThanOrEqual?: number,
        providerUnAvailabilityIdIdLessThanOrEqual?: number,
        providerUnAvailabilityIdIdEquals?: number,
        providerUnAvailabilityIdIdNotEquals?: number,
        providerUnAvailabilityIdIdSpecified?: boolean,
        providerUnAvailabilityIdIdIn?: Array<number>,
        providerUnAvailabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/availabilities/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'bookingWindow.greaterThan': bookingWindowGreaterThan,
                'bookingWindow.lessThan': bookingWindowLessThan,
                'bookingWindow.greaterThanOrEqual': bookingWindowGreaterThanOrEqual,
                'bookingWindow.lessThanOrEqual': bookingWindowLessThanOrEqual,
                'bookingWindow.equals': bookingWindowEquals,
                'bookingWindow.notEquals': bookingWindowNotEquals,
                'bookingWindow.specified': bookingWindowSpecified,
                'bookingWindow.in': bookingWindowIn,
                'bookingWindow.notIn': bookingWindowNotIn,
                'timezone.contains': timezoneContains,
                'timezone.doesNotContain': timezoneDoesNotContain,
                'timezone.equals': timezoneEquals,
                'timezone.notEquals': timezoneNotEquals,
                'timezone.specified': timezoneSpecified,
                'timezone.in': timezoneIn,
                'timezone.notIn': timezoneNotIn,
                'lastSetting.greaterThan': lastSettingGreaterThan,
                'lastSetting.lessThan': lastSettingLessThan,
                'lastSetting.greaterThanOrEqual': lastSettingGreaterThanOrEqual,
                'lastSetting.lessThanOrEqual': lastSettingLessThanOrEqual,
                'lastSetting.equals': lastSettingEquals,
                'lastSetting.notEquals': lastSettingNotEquals,
                'lastSetting.specified': lastSettingSpecified,
                'lastSetting.in': lastSettingIn,
                'lastSetting.notIn': lastSettingNotIn,
                'inpersonInitialConsultTime.greaterThan': inpersonInitialConsultTimeGreaterThan,
                'inpersonInitialConsultTime.lessThan': inpersonInitialConsultTimeLessThan,
                'inpersonInitialConsultTime.greaterThanOrEqual': inpersonInitialConsultTimeGreaterThanOrEqual,
                'inpersonInitialConsultTime.lessThanOrEqual': inpersonInitialConsultTimeLessThanOrEqual,
                'inpersonInitialConsultTime.equals': inpersonInitialConsultTimeEquals,
                'inpersonInitialConsultTime.notEquals': inpersonInitialConsultTimeNotEquals,
                'inpersonInitialConsultTime.specified': inpersonInitialConsultTimeSpecified,
                'inpersonInitialConsultTime.in': inpersonInitialConsultTimeIn,
                'inpersonInitialConsultTime.notIn': inpersonInitialConsultTimeNotIn,
                'inpersonFollowupConsultTime.greaterThan': inpersonFollowupConsultTimeGreaterThan,
                'inpersonFollowupConsultTime.lessThan': inpersonFollowupConsultTimeLessThan,
                'inpersonFollowupConsultTime.greaterThanOrEqual': inpersonFollowupConsultTimeGreaterThanOrEqual,
                'inpersonFollowupConsultTime.lessThanOrEqual': inpersonFollowupConsultTimeLessThanOrEqual,
                'inpersonFollowupConsultTime.equals': inpersonFollowupConsultTimeEquals,
                'inpersonFollowupConsultTime.notEquals': inpersonFollowupConsultTimeNotEquals,
                'inpersonFollowupConsultTime.specified': inpersonFollowupConsultTimeSpecified,
                'inpersonFollowupConsultTime.in': inpersonFollowupConsultTimeIn,
                'inpersonFollowupConsultTime.notIn': inpersonFollowupConsultTimeNotIn,
                'inpersonThresholdBookingtime.greaterThan': inpersonThresholdBookingtimeGreaterThan,
                'inpersonThresholdBookingtime.lessThan': inpersonThresholdBookingtimeLessThan,
                'inpersonThresholdBookingtime.greaterThanOrEqual': inpersonThresholdBookingtimeGreaterThanOrEqual,
                'inpersonThresholdBookingtime.lessThanOrEqual': inpersonThresholdBookingtimeLessThanOrEqual,
                'inpersonThresholdBookingtime.equals': inpersonThresholdBookingtimeEquals,
                'inpersonThresholdBookingtime.notEquals': inpersonThresholdBookingtimeNotEquals,
                'inpersonThresholdBookingtime.specified': inpersonThresholdBookingtimeSpecified,
                'inpersonThresholdBookingtime.in': inpersonThresholdBookingtimeIn,
                'inpersonThresholdBookingtime.notIn': inpersonThresholdBookingtimeNotIn,
                'inpersonBookingIntervalTime.greaterThan': inpersonBookingIntervalTimeGreaterThan,
                'inpersonBookingIntervalTime.lessThan': inpersonBookingIntervalTimeLessThan,
                'inpersonBookingIntervalTime.greaterThanOrEqual': inpersonBookingIntervalTimeGreaterThanOrEqual,
                'inpersonBookingIntervalTime.lessThanOrEqual': inpersonBookingIntervalTimeLessThanOrEqual,
                'inpersonBookingIntervalTime.equals': inpersonBookingIntervalTimeEquals,
                'inpersonBookingIntervalTime.notEquals': inpersonBookingIntervalTimeNotEquals,
                'inpersonBookingIntervalTime.specified': inpersonBookingIntervalTimeSpecified,
                'inpersonBookingIntervalTime.in': inpersonBookingIntervalTimeIn,
                'inpersonBookingIntervalTime.notIn': inpersonBookingIntervalTimeNotIn,
                'virtualInitialConsultTime.greaterThan': virtualInitialConsultTimeGreaterThan,
                'virtualInitialConsultTime.lessThan': virtualInitialConsultTimeLessThan,
                'virtualInitialConsultTime.greaterThanOrEqual': virtualInitialConsultTimeGreaterThanOrEqual,
                'virtualInitialConsultTime.lessThanOrEqual': virtualInitialConsultTimeLessThanOrEqual,
                'virtualInitialConsultTime.equals': virtualInitialConsultTimeEquals,
                'virtualInitialConsultTime.notEquals': virtualInitialConsultTimeNotEquals,
                'virtualInitialConsultTime.specified': virtualInitialConsultTimeSpecified,
                'virtualInitialConsultTime.in': virtualInitialConsultTimeIn,
                'virtualInitialConsultTime.notIn': virtualInitialConsultTimeNotIn,
                'virtualFollowupConsultTime.greaterThan': virtualFollowupConsultTimeGreaterThan,
                'virtualFollowupConsultTime.lessThan': virtualFollowupConsultTimeLessThan,
                'virtualFollowupConsultTime.greaterThanOrEqual': virtualFollowupConsultTimeGreaterThanOrEqual,
                'virtualFollowupConsultTime.lessThanOrEqual': virtualFollowupConsultTimeLessThanOrEqual,
                'virtualFollowupConsultTime.equals': virtualFollowupConsultTimeEquals,
                'virtualFollowupConsultTime.notEquals': virtualFollowupConsultTimeNotEquals,
                'virtualFollowupConsultTime.specified': virtualFollowupConsultTimeSpecified,
                'virtualFollowupConsultTime.in': virtualFollowupConsultTimeIn,
                'virtualFollowupConsultTime.notIn': virtualFollowupConsultTimeNotIn,
                'virtualThresholdBookingTime.greaterThan': virtualThresholdBookingTimeGreaterThan,
                'virtualThresholdBookingTime.lessThan': virtualThresholdBookingTimeLessThan,
                'virtualThresholdBookingTime.greaterThanOrEqual': virtualThresholdBookingTimeGreaterThanOrEqual,
                'virtualThresholdBookingTime.lessThanOrEqual': virtualThresholdBookingTimeLessThanOrEqual,
                'virtualThresholdBookingTime.equals': virtualThresholdBookingTimeEquals,
                'virtualThresholdBookingTime.notEquals': virtualThresholdBookingTimeNotEquals,
                'virtualThresholdBookingTime.specified': virtualThresholdBookingTimeSpecified,
                'virtualThresholdBookingTime.in': virtualThresholdBookingTimeIn,
                'virtualThresholdBookingTime.notIn': virtualThresholdBookingTimeNotIn,
                'virtualBookingIntervalTime.greaterThan': virtualBookingIntervalTimeGreaterThan,
                'virtualBookingIntervalTime.lessThan': virtualBookingIntervalTimeLessThan,
                'virtualBookingIntervalTime.greaterThanOrEqual': virtualBookingIntervalTimeGreaterThanOrEqual,
                'virtualBookingIntervalTime.lessThanOrEqual': virtualBookingIntervalTimeLessThanOrEqual,
                'virtualBookingIntervalTime.equals': virtualBookingIntervalTimeEquals,
                'virtualBookingIntervalTime.notEquals': virtualBookingIntervalTimeNotEquals,
                'virtualBookingIntervalTime.specified': virtualBookingIntervalTimeSpecified,
                'virtualBookingIntervalTime.in': virtualBookingIntervalTimeIn,
                'virtualBookingIntervalTime.notIn': virtualBookingIntervalTimeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'locationIdId.greaterThan': locationIdIdGreaterThan,
                'locationIdId.lessThan': locationIdIdLessThan,
                'locationIdId.greaterThanOrEqual': locationIdIdGreaterThanOrEqual,
                'locationIdId.lessThanOrEqual': locationIdIdLessThanOrEqual,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'providerAvailabilityIdId.greaterThan': providerAvailabilityIdIdGreaterThan,
                'providerAvailabilityIdId.lessThan': providerAvailabilityIdIdLessThan,
                'providerAvailabilityIdId.greaterThanOrEqual': providerAvailabilityIdIdGreaterThanOrEqual,
                'providerAvailabilityIdId.lessThanOrEqual': providerAvailabilityIdIdLessThanOrEqual,
                'providerAvailabilityIdId.equals': providerAvailabilityIdIdEquals,
                'providerAvailabilityIdId.notEquals': providerAvailabilityIdIdNotEquals,
                'providerAvailabilityIdId.specified': providerAvailabilityIdIdSpecified,
                'providerAvailabilityIdId.in': providerAvailabilityIdIdIn,
                'providerAvailabilityIdId.notIn': providerAvailabilityIdIdNotIn,
                'providerUnAvailabilityIdId.greaterThan': providerUnAvailabilityIdIdGreaterThan,
                'providerUnAvailabilityIdId.lessThan': providerUnAvailabilityIdIdLessThan,
                'providerUnAvailabilityIdId.greaterThanOrEqual': providerUnAvailabilityIdIdGreaterThanOrEqual,
                'providerUnAvailabilityIdId.lessThanOrEqual': providerUnAvailabilityIdIdLessThanOrEqual,
                'providerUnAvailabilityIdId.equals': providerUnAvailabilityIdIdEquals,
                'providerUnAvailabilityIdId.notEquals': providerUnAvailabilityIdIdNotEquals,
                'providerUnAvailabilityIdId.specified': providerUnAvailabilityIdIdSpecified,
                'providerUnAvailabilityIdId.in': providerUnAvailabilityIdIdIn,
                'providerUnAvailabilityIdId.notIn': providerUnAvailabilityIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
