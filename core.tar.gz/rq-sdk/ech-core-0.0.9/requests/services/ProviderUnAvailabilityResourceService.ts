/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ProviderUnAvailabilityDTO } from '../models/ProviderUnAvailabilityDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ProviderUnAvailabilityResourceService {

    /**
     * @param id
     * @returns ProviderUnAvailabilityDTO OK
     * @throws ApiError
     */
    public static getProviderUnAvailability(
        id: number,
    ): CancelablePromise<ProviderUnAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-un-availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns ProviderUnAvailabilityDTO OK
     * @throws ApiError
     */
    public static updateProviderUnAvailability(
        id: number,
        requestBody: ProviderUnAvailabilityDTO,
    ): CancelablePromise<ProviderUnAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/provider-un-availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteProviderUnAvailability(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/provider-un-availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns ProviderUnAvailabilityDTO OK
     * @throws ApiError
     */
    public static partialUpdateProviderUnAvailability(
        id: number,
        requestBody: ProviderUnAvailabilityDTO,
    ): CancelablePromise<ProviderUnAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/provider-un-availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param startTimeGreaterThan
     * @param startTimeLessThan
     * @param startTimeGreaterThanOrEqual
     * @param startTimeLessThanOrEqual
     * @param startTimeEquals
     * @param startTimeNotEquals
     * @param startTimeSpecified
     * @param startTimeIn
     * @param startTimeNotIn
     * @param endTimeGreaterThan
     * @param endTimeLessThan
     * @param endTimeGreaterThanOrEqual
     * @param endTimeLessThanOrEqual
     * @param endTimeEquals
     * @param endTimeNotEquals
     * @param endTimeSpecified
     * @param endTimeIn
     * @param endTimeNotIn
     * @param availabilityIdIdGreaterThan
     * @param availabilityIdIdLessThan
     * @param availabilityIdIdGreaterThanOrEqual
     * @param availabilityIdIdLessThanOrEqual
     * @param availabilityIdIdEquals
     * @param availabilityIdIdNotEquals
     * @param availabilityIdIdSpecified
     * @param availabilityIdIdIn
     * @param availabilityIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns ProviderUnAvailabilityDTO OK
     * @throws ApiError
     */
    public static getAllProviderUnAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        startTimeGreaterThan?: string,
        startTimeLessThan?: string,
        startTimeGreaterThanOrEqual?: string,
        startTimeLessThanOrEqual?: string,
        startTimeEquals?: string,
        startTimeNotEquals?: string,
        startTimeSpecified?: boolean,
        startTimeIn?: Array<string>,
        startTimeNotIn?: Array<string>,
        endTimeGreaterThan?: string,
        endTimeLessThan?: string,
        endTimeGreaterThanOrEqual?: string,
        endTimeLessThanOrEqual?: string,
        endTimeEquals?: string,
        endTimeNotEquals?: string,
        endTimeSpecified?: boolean,
        endTimeIn?: Array<string>,
        endTimeNotIn?: Array<string>,
        availabilityIdIdGreaterThan?: number,
        availabilityIdIdLessThan?: number,
        availabilityIdIdGreaterThanOrEqual?: number,
        availabilityIdIdLessThanOrEqual?: number,
        availabilityIdIdEquals?: number,
        availabilityIdIdNotEquals?: number,
        availabilityIdIdSpecified?: boolean,
        availabilityIdIdIn?: Array<number>,
        availabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<ProviderUnAvailabilityDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-un-availabilities',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'startTime.greaterThan': startTimeGreaterThan,
                'startTime.lessThan': startTimeLessThan,
                'startTime.greaterThanOrEqual': startTimeGreaterThanOrEqual,
                'startTime.lessThanOrEqual': startTimeLessThanOrEqual,
                'startTime.equals': startTimeEquals,
                'startTime.notEquals': startTimeNotEquals,
                'startTime.specified': startTimeSpecified,
                'startTime.in': startTimeIn,
                'startTime.notIn': startTimeNotIn,
                'endTime.greaterThan': endTimeGreaterThan,
                'endTime.lessThan': endTimeLessThan,
                'endTime.greaterThanOrEqual': endTimeGreaterThanOrEqual,
                'endTime.lessThanOrEqual': endTimeLessThanOrEqual,
                'endTime.equals': endTimeEquals,
                'endTime.notEquals': endTimeNotEquals,
                'endTime.specified': endTimeSpecified,
                'endTime.in': endTimeIn,
                'endTime.notIn': endTimeNotIn,
                'availabilityIdId.greaterThan': availabilityIdIdGreaterThan,
                'availabilityIdId.lessThan': availabilityIdIdLessThan,
                'availabilityIdId.greaterThanOrEqual': availabilityIdIdGreaterThanOrEqual,
                'availabilityIdId.lessThanOrEqual': availabilityIdIdLessThanOrEqual,
                'availabilityIdId.equals': availabilityIdIdEquals,
                'availabilityIdId.notEquals': availabilityIdIdNotEquals,
                'availabilityIdId.specified': availabilityIdIdSpecified,
                'availabilityIdId.in': availabilityIdIdIn,
                'availabilityIdId.notIn': availabilityIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns ProviderUnAvailabilityDTO OK
     * @throws ApiError
     */
    public static createProviderUnAvailability(
        requestBody: ProviderUnAvailabilityDTO,
    ): CancelablePromise<ProviderUnAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/provider-un-availabilities',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param startTimeGreaterThan
     * @param startTimeLessThan
     * @param startTimeGreaterThanOrEqual
     * @param startTimeLessThanOrEqual
     * @param startTimeEquals
     * @param startTimeNotEquals
     * @param startTimeSpecified
     * @param startTimeIn
     * @param startTimeNotIn
     * @param endTimeGreaterThan
     * @param endTimeLessThan
     * @param endTimeGreaterThanOrEqual
     * @param endTimeLessThanOrEqual
     * @param endTimeEquals
     * @param endTimeNotEquals
     * @param endTimeSpecified
     * @param endTimeIn
     * @param endTimeNotIn
     * @param availabilityIdIdGreaterThan
     * @param availabilityIdIdLessThan
     * @param availabilityIdIdGreaterThanOrEqual
     * @param availabilityIdIdLessThanOrEqual
     * @param availabilityIdIdEquals
     * @param availabilityIdIdNotEquals
     * @param availabilityIdIdSpecified
     * @param availabilityIdIdIn
     * @param availabilityIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countProviderUnAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        startTimeGreaterThan?: string,
        startTimeLessThan?: string,
        startTimeGreaterThanOrEqual?: string,
        startTimeLessThanOrEqual?: string,
        startTimeEquals?: string,
        startTimeNotEquals?: string,
        startTimeSpecified?: boolean,
        startTimeIn?: Array<string>,
        startTimeNotIn?: Array<string>,
        endTimeGreaterThan?: string,
        endTimeLessThan?: string,
        endTimeGreaterThanOrEqual?: string,
        endTimeLessThanOrEqual?: string,
        endTimeEquals?: string,
        endTimeNotEquals?: string,
        endTimeSpecified?: boolean,
        endTimeIn?: Array<string>,
        endTimeNotIn?: Array<string>,
        availabilityIdIdGreaterThan?: number,
        availabilityIdIdLessThan?: number,
        availabilityIdIdGreaterThanOrEqual?: number,
        availabilityIdIdLessThanOrEqual?: number,
        availabilityIdIdEquals?: number,
        availabilityIdIdNotEquals?: number,
        availabilityIdIdSpecified?: boolean,
        availabilityIdIdIn?: Array<number>,
        availabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-un-availabilities/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'startTime.greaterThan': startTimeGreaterThan,
                'startTime.lessThan': startTimeLessThan,
                'startTime.greaterThanOrEqual': startTimeGreaterThanOrEqual,
                'startTime.lessThanOrEqual': startTimeLessThanOrEqual,
                'startTime.equals': startTimeEquals,
                'startTime.notEquals': startTimeNotEquals,
                'startTime.specified': startTimeSpecified,
                'startTime.in': startTimeIn,
                'startTime.notIn': startTimeNotIn,
                'endTime.greaterThan': endTimeGreaterThan,
                'endTime.lessThan': endTimeLessThan,
                'endTime.greaterThanOrEqual': endTimeGreaterThanOrEqual,
                'endTime.lessThanOrEqual': endTimeLessThanOrEqual,
                'endTime.equals': endTimeEquals,
                'endTime.notEquals': endTimeNotEquals,
                'endTime.specified': endTimeSpecified,
                'endTime.in': endTimeIn,
                'endTime.notIn': endTimeNotIn,
                'availabilityIdId.greaterThan': availabilityIdIdGreaterThan,
                'availabilityIdId.lessThan': availabilityIdIdLessThan,
                'availabilityIdId.greaterThanOrEqual': availabilityIdIdGreaterThanOrEqual,
                'availabilityIdId.lessThanOrEqual': availabilityIdIdLessThanOrEqual,
                'availabilityIdId.equals': availabilityIdIdEquals,
                'availabilityIdId.notEquals': availabilityIdIdNotEquals,
                'availabilityIdId.specified': availabilityIdIdSpecified,
                'availabilityIdId.in': availabilityIdIdIn,
                'availabilityIdId.notIn': availabilityIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
