/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeMedicationDTO } from '../models/IntakeMedicationDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeMedicationResourceService {

    /**
     * @param id
     * @returns IntakeMedicationDTO OK
     * @throws ApiError
     */
    public static getIntakeMedication(
        id: number,
    ): CancelablePromise<IntakeMedicationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medications/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeMedicationDTO OK
     * @throws ApiError
     */
    public static updateIntakeMedication(
        id: number,
        requestBody: IntakeMedicationDTO,
    ): CancelablePromise<IntakeMedicationDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-medications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeMedication(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-medications/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeMedicationDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeMedication(
        id: number,
        requestBody: IntakeMedicationDTO,
    ): CancelablePromise<IntakeMedicationDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-medications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param whenContains
     * @param whenDoesNotContain
     * @param whenEquals
     * @param whenNotEquals
     * @param whenSpecified
     * @param whenIn
     * @param whenNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param prescribedByIdGreaterThan
     * @param prescribedByIdLessThan
     * @param prescribedByIdGreaterThanOrEqual
     * @param prescribedByIdLessThanOrEqual
     * @param prescribedByIdEquals
     * @param prescribedByIdNotEquals
     * @param prescribedByIdSpecified
     * @param prescribedByIdIn
     * @param prescribedByIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeMedicationDTO OK
     * @throws ApiError
     */
    public static getAllIntakeMedications(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        whenContains?: string,
        whenDoesNotContain?: string,
        whenEquals?: string,
        whenNotEquals?: string,
        whenSpecified?: boolean,
        whenIn?: Array<string>,
        whenNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        prescribedByIdGreaterThan?: number,
        prescribedByIdLessThan?: number,
        prescribedByIdGreaterThanOrEqual?: number,
        prescribedByIdLessThanOrEqual?: number,
        prescribedByIdEquals?: number,
        prescribedByIdNotEquals?: number,
        prescribedByIdSpecified?: boolean,
        prescribedByIdIn?: Array<number>,
        prescribedByIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeMedicationDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medications',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'when.contains': whenContains,
                'when.doesNotContain': whenDoesNotContain,
                'when.equals': whenEquals,
                'when.notEquals': whenNotEquals,
                'when.specified': whenSpecified,
                'when.in': whenIn,
                'when.notIn': whenNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'prescribedById.greaterThan': prescribedByIdGreaterThan,
                'prescribedById.lessThan': prescribedByIdLessThan,
                'prescribedById.greaterThanOrEqual': prescribedByIdGreaterThanOrEqual,
                'prescribedById.lessThanOrEqual': prescribedByIdLessThanOrEqual,
                'prescribedById.equals': prescribedByIdEquals,
                'prescribedById.notEquals': prescribedByIdNotEquals,
                'prescribedById.specified': prescribedByIdSpecified,
                'prescribedById.in': prescribedByIdIn,
                'prescribedById.notIn': prescribedByIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeMedicationDTO OK
     * @throws ApiError
     */
    public static createIntakeMedication(
        requestBody: IntakeMedicationDTO,
    ): CancelablePromise<IntakeMedicationDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-medications',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param whenContains
     * @param whenDoesNotContain
     * @param whenEquals
     * @param whenNotEquals
     * @param whenSpecified
     * @param whenIn
     * @param whenNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param prescribedByIdGreaterThan
     * @param prescribedByIdLessThan
     * @param prescribedByIdGreaterThanOrEqual
     * @param prescribedByIdLessThanOrEqual
     * @param prescribedByIdEquals
     * @param prescribedByIdNotEquals
     * @param prescribedByIdSpecified
     * @param prescribedByIdIn
     * @param prescribedByIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeMedications(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        whenContains?: string,
        whenDoesNotContain?: string,
        whenEquals?: string,
        whenNotEquals?: string,
        whenSpecified?: boolean,
        whenIn?: Array<string>,
        whenNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        prescribedByIdGreaterThan?: number,
        prescribedByIdLessThan?: number,
        prescribedByIdGreaterThanOrEqual?: number,
        prescribedByIdLessThanOrEqual?: number,
        prescribedByIdEquals?: number,
        prescribedByIdNotEquals?: number,
        prescribedByIdSpecified?: boolean,
        prescribedByIdIn?: Array<number>,
        prescribedByIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medications/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'when.contains': whenContains,
                'when.doesNotContain': whenDoesNotContain,
                'when.equals': whenEquals,
                'when.notEquals': whenNotEquals,
                'when.specified': whenSpecified,
                'when.in': whenIn,
                'when.notIn': whenNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'prescribedById.greaterThan': prescribedByIdGreaterThan,
                'prescribedById.lessThan': prescribedByIdLessThan,
                'prescribedById.greaterThanOrEqual': prescribedByIdGreaterThanOrEqual,
                'prescribedById.lessThanOrEqual': prescribedByIdLessThanOrEqual,
                'prescribedById.equals': prescribedByIdEquals,
                'prescribedById.notEquals': prescribedByIdNotEquals,
                'prescribedById.specified': prescribedByIdSpecified,
                'prescribedById.in': prescribedByIdIn,
                'prescribedById.notIn': prescribedByIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
