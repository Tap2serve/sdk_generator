/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EncounterDTO } from '../models/EncounterDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class EncounterResourceService {

    /**
     * @param id
     * @returns EncounterDTO OK
     * @throws ApiError
     */
    public static getEncounter(
        id: number,
    ): CancelablePromise<EncounterDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounters/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterDTO OK
     * @throws ApiError
     */
    public static updateEncounter(
        id: number,
        requestBody: EncounterDTO,
    ): CancelablePromise<EncounterDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/encounters/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteEncounter(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/encounters/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterDTO OK
     * @throws ApiError
     */
    public static partialUpdateEncounter(
        id: number,
        requestBody: EncounterDTO,
    ): CancelablePromise<EncounterDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/encounters/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param statusContains
     * @param statusDoesNotContain
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param visitTypeContains
     * @param visitTypeDoesNotContain
     * @param visitTypeEquals
     * @param visitTypeNotEquals
     * @param visitTypeSpecified
     * @param visitTypeIn
     * @param visitTypeNotIn
     * @param chiefComplaintContains
     * @param chiefComplaintDoesNotContain
     * @param chiefComplaintEquals
     * @param chiefComplaintNotEquals
     * @param chiefComplaintSpecified
     * @param chiefComplaintIn
     * @param chiefComplaintNotIn
     * @param serviceDateGreaterThan
     * @param serviceDateLessThan
     * @param serviceDateGreaterThanOrEqual
     * @param serviceDateLessThanOrEqual
     * @param serviceDateEquals
     * @param serviceDateNotEquals
     * @param serviceDateSpecified
     * @param serviceDateIn
     * @param serviceDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isSignedEquals
     * @param isSignedNotEquals
     * @param isSignedSpecified
     * @param isSignedIn
     * @param isSignedNotIn
     * @param readyForBillingEquals
     * @param readyForBillingNotEquals
     * @param readyForBillingSpecified
     * @param readyForBillingIn
     * @param readyForBillingNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param appointmentIdIdGreaterThan
     * @param appointmentIdIdLessThan
     * @param appointmentIdIdGreaterThanOrEqual
     * @param appointmentIdIdLessThanOrEqual
     * @param appointmentIdIdEquals
     * @param appointmentIdIdNotEquals
     * @param appointmentIdIdSpecified
     * @param appointmentIdIdIn
     * @param appointmentIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param locationIdIdGreaterThan
     * @param locationIdIdLessThan
     * @param locationIdIdGreaterThanOrEqual
     * @param locationIdIdLessThanOrEqual
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param encounterNoteIdGreaterThan
     * @param encounterNoteIdLessThan
     * @param encounterNoteIdGreaterThanOrEqual
     * @param encounterNoteIdLessThanOrEqual
     * @param encounterNoteIdEquals
     * @param encounterNoteIdNotEquals
     * @param encounterNoteIdSpecified
     * @param encounterNoteIdIn
     * @param encounterNoteIdNotIn
     * @param encounterReviewOfSystemIdGreaterThan
     * @param encounterReviewOfSystemIdLessThan
     * @param encounterReviewOfSystemIdGreaterThanOrEqual
     * @param encounterReviewOfSystemIdLessThanOrEqual
     * @param encounterReviewOfSystemIdEquals
     * @param encounterReviewOfSystemIdNotEquals
     * @param encounterReviewOfSystemIdSpecified
     * @param encounterReviewOfSystemIdIn
     * @param encounterReviewOfSystemIdNotIn
     * @param superBillIdGreaterThan
     * @param superBillIdLessThan
     * @param superBillIdGreaterThanOrEqual
     * @param superBillIdLessThanOrEqual
     * @param superBillIdEquals
     * @param superBillIdNotEquals
     * @param superBillIdSpecified
     * @param superBillIdIn
     * @param superBillIdNotIn
     * @param encounterPhysicalExamIdGreaterThan
     * @param encounterPhysicalExamIdLessThan
     * @param encounterPhysicalExamIdGreaterThanOrEqual
     * @param encounterPhysicalExamIdLessThanOrEqual
     * @param encounterPhysicalExamIdEquals
     * @param encounterPhysicalExamIdNotEquals
     * @param encounterPhysicalExamIdSpecified
     * @param encounterPhysicalExamIdIn
     * @param encounterPhysicalExamIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns EncounterDTO OK
     * @throws ApiError
     */
    public static getAllEncounters(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        statusContains?: string,
        statusDoesNotContain?: string,
        statusEquals?: string,
        statusNotEquals?: string,
        statusSpecified?: boolean,
        statusIn?: Array<string>,
        statusNotIn?: Array<string>,
        visitTypeContains?: string,
        visitTypeDoesNotContain?: string,
        visitTypeEquals?: string,
        visitTypeNotEquals?: string,
        visitTypeSpecified?: boolean,
        visitTypeIn?: Array<string>,
        visitTypeNotIn?: Array<string>,
        chiefComplaintContains?: string,
        chiefComplaintDoesNotContain?: string,
        chiefComplaintEquals?: string,
        chiefComplaintNotEquals?: string,
        chiefComplaintSpecified?: boolean,
        chiefComplaintIn?: Array<string>,
        chiefComplaintNotIn?: Array<string>,
        serviceDateGreaterThan?: string,
        serviceDateLessThan?: string,
        serviceDateGreaterThanOrEqual?: string,
        serviceDateLessThanOrEqual?: string,
        serviceDateEquals?: string,
        serviceDateNotEquals?: string,
        serviceDateSpecified?: boolean,
        serviceDateIn?: Array<string>,
        serviceDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isSignedEquals?: boolean,
        isSignedNotEquals?: boolean,
        isSignedSpecified?: boolean,
        isSignedIn?: Array<boolean>,
        isSignedNotIn?: Array<boolean>,
        readyForBillingEquals?: boolean,
        readyForBillingNotEquals?: boolean,
        readyForBillingSpecified?: boolean,
        readyForBillingIn?: Array<boolean>,
        readyForBillingNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        appointmentIdIdGreaterThan?: number,
        appointmentIdIdLessThan?: number,
        appointmentIdIdGreaterThanOrEqual?: number,
        appointmentIdIdLessThanOrEqual?: number,
        appointmentIdIdEquals?: number,
        appointmentIdIdNotEquals?: number,
        appointmentIdIdSpecified?: boolean,
        appointmentIdIdIn?: Array<number>,
        appointmentIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        locationIdIdGreaterThan?: number,
        locationIdIdLessThan?: number,
        locationIdIdGreaterThanOrEqual?: number,
        locationIdIdLessThanOrEqual?: number,
        locationIdIdEquals?: number,
        locationIdIdNotEquals?: number,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<number>,
        locationIdIdNotIn?: Array<number>,
        encounterNoteIdGreaterThan?: number,
        encounterNoteIdLessThan?: number,
        encounterNoteIdGreaterThanOrEqual?: number,
        encounterNoteIdLessThanOrEqual?: number,
        encounterNoteIdEquals?: number,
        encounterNoteIdNotEquals?: number,
        encounterNoteIdSpecified?: boolean,
        encounterNoteIdIn?: Array<number>,
        encounterNoteIdNotIn?: Array<number>,
        encounterReviewOfSystemIdGreaterThan?: number,
        encounterReviewOfSystemIdLessThan?: number,
        encounterReviewOfSystemIdGreaterThanOrEqual?: number,
        encounterReviewOfSystemIdLessThanOrEqual?: number,
        encounterReviewOfSystemIdEquals?: number,
        encounterReviewOfSystemIdNotEquals?: number,
        encounterReviewOfSystemIdSpecified?: boolean,
        encounterReviewOfSystemIdIn?: Array<number>,
        encounterReviewOfSystemIdNotIn?: Array<number>,
        superBillIdGreaterThan?: number,
        superBillIdLessThan?: number,
        superBillIdGreaterThanOrEqual?: number,
        superBillIdLessThanOrEqual?: number,
        superBillIdEquals?: number,
        superBillIdNotEquals?: number,
        superBillIdSpecified?: boolean,
        superBillIdIn?: Array<number>,
        superBillIdNotIn?: Array<number>,
        encounterPhysicalExamIdGreaterThan?: number,
        encounterPhysicalExamIdLessThan?: number,
        encounterPhysicalExamIdGreaterThanOrEqual?: number,
        encounterPhysicalExamIdLessThanOrEqual?: number,
        encounterPhysicalExamIdEquals?: number,
        encounterPhysicalExamIdNotEquals?: number,
        encounterPhysicalExamIdSpecified?: boolean,
        encounterPhysicalExamIdIn?: Array<number>,
        encounterPhysicalExamIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<EncounterDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounters',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'status.contains': statusContains,
                'status.doesNotContain': statusDoesNotContain,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'visitType.contains': visitTypeContains,
                'visitType.doesNotContain': visitTypeDoesNotContain,
                'visitType.equals': visitTypeEquals,
                'visitType.notEquals': visitTypeNotEquals,
                'visitType.specified': visitTypeSpecified,
                'visitType.in': visitTypeIn,
                'visitType.notIn': visitTypeNotIn,
                'chiefComplaint.contains': chiefComplaintContains,
                'chiefComplaint.doesNotContain': chiefComplaintDoesNotContain,
                'chiefComplaint.equals': chiefComplaintEquals,
                'chiefComplaint.notEquals': chiefComplaintNotEquals,
                'chiefComplaint.specified': chiefComplaintSpecified,
                'chiefComplaint.in': chiefComplaintIn,
                'chiefComplaint.notIn': chiefComplaintNotIn,
                'serviceDate.greaterThan': serviceDateGreaterThan,
                'serviceDate.lessThan': serviceDateLessThan,
                'serviceDate.greaterThanOrEqual': serviceDateGreaterThanOrEqual,
                'serviceDate.lessThanOrEqual': serviceDateLessThanOrEqual,
                'serviceDate.equals': serviceDateEquals,
                'serviceDate.notEquals': serviceDateNotEquals,
                'serviceDate.specified': serviceDateSpecified,
                'serviceDate.in': serviceDateIn,
                'serviceDate.notIn': serviceDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isSigned.equals': isSignedEquals,
                'isSigned.notEquals': isSignedNotEquals,
                'isSigned.specified': isSignedSpecified,
                'isSigned.in': isSignedIn,
                'isSigned.notIn': isSignedNotIn,
                'readyForBilling.equals': readyForBillingEquals,
                'readyForBilling.notEquals': readyForBillingNotEquals,
                'readyForBilling.specified': readyForBillingSpecified,
                'readyForBilling.in': readyForBillingIn,
                'readyForBilling.notIn': readyForBillingNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'appointmentIdId.greaterThan': appointmentIdIdGreaterThan,
                'appointmentIdId.lessThan': appointmentIdIdLessThan,
                'appointmentIdId.greaterThanOrEqual': appointmentIdIdGreaterThanOrEqual,
                'appointmentIdId.lessThanOrEqual': appointmentIdIdLessThanOrEqual,
                'appointmentIdId.equals': appointmentIdIdEquals,
                'appointmentIdId.notEquals': appointmentIdIdNotEquals,
                'appointmentIdId.specified': appointmentIdIdSpecified,
                'appointmentIdId.in': appointmentIdIdIn,
                'appointmentIdId.notIn': appointmentIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'locationIdId.greaterThan': locationIdIdGreaterThan,
                'locationIdId.lessThan': locationIdIdLessThan,
                'locationIdId.greaterThanOrEqual': locationIdIdGreaterThanOrEqual,
                'locationIdId.lessThanOrEqual': locationIdIdLessThanOrEqual,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'encounterNoteId.greaterThan': encounterNoteIdGreaterThan,
                'encounterNoteId.lessThan': encounterNoteIdLessThan,
                'encounterNoteId.greaterThanOrEqual': encounterNoteIdGreaterThanOrEqual,
                'encounterNoteId.lessThanOrEqual': encounterNoteIdLessThanOrEqual,
                'encounterNoteId.equals': encounterNoteIdEquals,
                'encounterNoteId.notEquals': encounterNoteIdNotEquals,
                'encounterNoteId.specified': encounterNoteIdSpecified,
                'encounterNoteId.in': encounterNoteIdIn,
                'encounterNoteId.notIn': encounterNoteIdNotIn,
                'encounterReviewOfSystemId.greaterThan': encounterReviewOfSystemIdGreaterThan,
                'encounterReviewOfSystemId.lessThan': encounterReviewOfSystemIdLessThan,
                'encounterReviewOfSystemId.greaterThanOrEqual': encounterReviewOfSystemIdGreaterThanOrEqual,
                'encounterReviewOfSystemId.lessThanOrEqual': encounterReviewOfSystemIdLessThanOrEqual,
                'encounterReviewOfSystemId.equals': encounterReviewOfSystemIdEquals,
                'encounterReviewOfSystemId.notEquals': encounterReviewOfSystemIdNotEquals,
                'encounterReviewOfSystemId.specified': encounterReviewOfSystemIdSpecified,
                'encounterReviewOfSystemId.in': encounterReviewOfSystemIdIn,
                'encounterReviewOfSystemId.notIn': encounterReviewOfSystemIdNotIn,
                'superBillId.greaterThan': superBillIdGreaterThan,
                'superBillId.lessThan': superBillIdLessThan,
                'superBillId.greaterThanOrEqual': superBillIdGreaterThanOrEqual,
                'superBillId.lessThanOrEqual': superBillIdLessThanOrEqual,
                'superBillId.equals': superBillIdEquals,
                'superBillId.notEquals': superBillIdNotEquals,
                'superBillId.specified': superBillIdSpecified,
                'superBillId.in': superBillIdIn,
                'superBillId.notIn': superBillIdNotIn,
                'encounterPhysicalExamId.greaterThan': encounterPhysicalExamIdGreaterThan,
                'encounterPhysicalExamId.lessThan': encounterPhysicalExamIdLessThan,
                'encounterPhysicalExamId.greaterThanOrEqual': encounterPhysicalExamIdGreaterThanOrEqual,
                'encounterPhysicalExamId.lessThanOrEqual': encounterPhysicalExamIdLessThanOrEqual,
                'encounterPhysicalExamId.equals': encounterPhysicalExamIdEquals,
                'encounterPhysicalExamId.notEquals': encounterPhysicalExamIdNotEquals,
                'encounterPhysicalExamId.specified': encounterPhysicalExamIdSpecified,
                'encounterPhysicalExamId.in': encounterPhysicalExamIdIn,
                'encounterPhysicalExamId.notIn': encounterPhysicalExamIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns EncounterDTO OK
     * @throws ApiError
     */
    public static createEncounter(
        requestBody: EncounterDTO,
    ): CancelablePromise<EncounterDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/encounters',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param statusContains
     * @param statusDoesNotContain
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param visitTypeContains
     * @param visitTypeDoesNotContain
     * @param visitTypeEquals
     * @param visitTypeNotEquals
     * @param visitTypeSpecified
     * @param visitTypeIn
     * @param visitTypeNotIn
     * @param chiefComplaintContains
     * @param chiefComplaintDoesNotContain
     * @param chiefComplaintEquals
     * @param chiefComplaintNotEquals
     * @param chiefComplaintSpecified
     * @param chiefComplaintIn
     * @param chiefComplaintNotIn
     * @param serviceDateGreaterThan
     * @param serviceDateLessThan
     * @param serviceDateGreaterThanOrEqual
     * @param serviceDateLessThanOrEqual
     * @param serviceDateEquals
     * @param serviceDateNotEquals
     * @param serviceDateSpecified
     * @param serviceDateIn
     * @param serviceDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isSignedEquals
     * @param isSignedNotEquals
     * @param isSignedSpecified
     * @param isSignedIn
     * @param isSignedNotIn
     * @param readyForBillingEquals
     * @param readyForBillingNotEquals
     * @param readyForBillingSpecified
     * @param readyForBillingIn
     * @param readyForBillingNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param appointmentIdIdGreaterThan
     * @param appointmentIdIdLessThan
     * @param appointmentIdIdGreaterThanOrEqual
     * @param appointmentIdIdLessThanOrEqual
     * @param appointmentIdIdEquals
     * @param appointmentIdIdNotEquals
     * @param appointmentIdIdSpecified
     * @param appointmentIdIdIn
     * @param appointmentIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param locationIdIdGreaterThan
     * @param locationIdIdLessThan
     * @param locationIdIdGreaterThanOrEqual
     * @param locationIdIdLessThanOrEqual
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param encounterNoteIdGreaterThan
     * @param encounterNoteIdLessThan
     * @param encounterNoteIdGreaterThanOrEqual
     * @param encounterNoteIdLessThanOrEqual
     * @param encounterNoteIdEquals
     * @param encounterNoteIdNotEquals
     * @param encounterNoteIdSpecified
     * @param encounterNoteIdIn
     * @param encounterNoteIdNotIn
     * @param encounterReviewOfSystemIdGreaterThan
     * @param encounterReviewOfSystemIdLessThan
     * @param encounterReviewOfSystemIdGreaterThanOrEqual
     * @param encounterReviewOfSystemIdLessThanOrEqual
     * @param encounterReviewOfSystemIdEquals
     * @param encounterReviewOfSystemIdNotEquals
     * @param encounterReviewOfSystemIdSpecified
     * @param encounterReviewOfSystemIdIn
     * @param encounterReviewOfSystemIdNotIn
     * @param superBillIdGreaterThan
     * @param superBillIdLessThan
     * @param superBillIdGreaterThanOrEqual
     * @param superBillIdLessThanOrEqual
     * @param superBillIdEquals
     * @param superBillIdNotEquals
     * @param superBillIdSpecified
     * @param superBillIdIn
     * @param superBillIdNotIn
     * @param encounterPhysicalExamIdGreaterThan
     * @param encounterPhysicalExamIdLessThan
     * @param encounterPhysicalExamIdGreaterThanOrEqual
     * @param encounterPhysicalExamIdLessThanOrEqual
     * @param encounterPhysicalExamIdEquals
     * @param encounterPhysicalExamIdNotEquals
     * @param encounterPhysicalExamIdSpecified
     * @param encounterPhysicalExamIdIn
     * @param encounterPhysicalExamIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countEncounters(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        statusContains?: string,
        statusDoesNotContain?: string,
        statusEquals?: string,
        statusNotEquals?: string,
        statusSpecified?: boolean,
        statusIn?: Array<string>,
        statusNotIn?: Array<string>,
        visitTypeContains?: string,
        visitTypeDoesNotContain?: string,
        visitTypeEquals?: string,
        visitTypeNotEquals?: string,
        visitTypeSpecified?: boolean,
        visitTypeIn?: Array<string>,
        visitTypeNotIn?: Array<string>,
        chiefComplaintContains?: string,
        chiefComplaintDoesNotContain?: string,
        chiefComplaintEquals?: string,
        chiefComplaintNotEquals?: string,
        chiefComplaintSpecified?: boolean,
        chiefComplaintIn?: Array<string>,
        chiefComplaintNotIn?: Array<string>,
        serviceDateGreaterThan?: string,
        serviceDateLessThan?: string,
        serviceDateGreaterThanOrEqual?: string,
        serviceDateLessThanOrEqual?: string,
        serviceDateEquals?: string,
        serviceDateNotEquals?: string,
        serviceDateSpecified?: boolean,
        serviceDateIn?: Array<string>,
        serviceDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isSignedEquals?: boolean,
        isSignedNotEquals?: boolean,
        isSignedSpecified?: boolean,
        isSignedIn?: Array<boolean>,
        isSignedNotIn?: Array<boolean>,
        readyForBillingEquals?: boolean,
        readyForBillingNotEquals?: boolean,
        readyForBillingSpecified?: boolean,
        readyForBillingIn?: Array<boolean>,
        readyForBillingNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        appointmentIdIdGreaterThan?: number,
        appointmentIdIdLessThan?: number,
        appointmentIdIdGreaterThanOrEqual?: number,
        appointmentIdIdLessThanOrEqual?: number,
        appointmentIdIdEquals?: number,
        appointmentIdIdNotEquals?: number,
        appointmentIdIdSpecified?: boolean,
        appointmentIdIdIn?: Array<number>,
        appointmentIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        locationIdIdGreaterThan?: number,
        locationIdIdLessThan?: number,
        locationIdIdGreaterThanOrEqual?: number,
        locationIdIdLessThanOrEqual?: number,
        locationIdIdEquals?: number,
        locationIdIdNotEquals?: number,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<number>,
        locationIdIdNotIn?: Array<number>,
        encounterNoteIdGreaterThan?: number,
        encounterNoteIdLessThan?: number,
        encounterNoteIdGreaterThanOrEqual?: number,
        encounterNoteIdLessThanOrEqual?: number,
        encounterNoteIdEquals?: number,
        encounterNoteIdNotEquals?: number,
        encounterNoteIdSpecified?: boolean,
        encounterNoteIdIn?: Array<number>,
        encounterNoteIdNotIn?: Array<number>,
        encounterReviewOfSystemIdGreaterThan?: number,
        encounterReviewOfSystemIdLessThan?: number,
        encounterReviewOfSystemIdGreaterThanOrEqual?: number,
        encounterReviewOfSystemIdLessThanOrEqual?: number,
        encounterReviewOfSystemIdEquals?: number,
        encounterReviewOfSystemIdNotEquals?: number,
        encounterReviewOfSystemIdSpecified?: boolean,
        encounterReviewOfSystemIdIn?: Array<number>,
        encounterReviewOfSystemIdNotIn?: Array<number>,
        superBillIdGreaterThan?: number,
        superBillIdLessThan?: number,
        superBillIdGreaterThanOrEqual?: number,
        superBillIdLessThanOrEqual?: number,
        superBillIdEquals?: number,
        superBillIdNotEquals?: number,
        superBillIdSpecified?: boolean,
        superBillIdIn?: Array<number>,
        superBillIdNotIn?: Array<number>,
        encounterPhysicalExamIdGreaterThan?: number,
        encounterPhysicalExamIdLessThan?: number,
        encounterPhysicalExamIdGreaterThanOrEqual?: number,
        encounterPhysicalExamIdLessThanOrEqual?: number,
        encounterPhysicalExamIdEquals?: number,
        encounterPhysicalExamIdNotEquals?: number,
        encounterPhysicalExamIdSpecified?: boolean,
        encounterPhysicalExamIdIn?: Array<number>,
        encounterPhysicalExamIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounters/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'status.contains': statusContains,
                'status.doesNotContain': statusDoesNotContain,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'visitType.contains': visitTypeContains,
                'visitType.doesNotContain': visitTypeDoesNotContain,
                'visitType.equals': visitTypeEquals,
                'visitType.notEquals': visitTypeNotEquals,
                'visitType.specified': visitTypeSpecified,
                'visitType.in': visitTypeIn,
                'visitType.notIn': visitTypeNotIn,
                'chiefComplaint.contains': chiefComplaintContains,
                'chiefComplaint.doesNotContain': chiefComplaintDoesNotContain,
                'chiefComplaint.equals': chiefComplaintEquals,
                'chiefComplaint.notEquals': chiefComplaintNotEquals,
                'chiefComplaint.specified': chiefComplaintSpecified,
                'chiefComplaint.in': chiefComplaintIn,
                'chiefComplaint.notIn': chiefComplaintNotIn,
                'serviceDate.greaterThan': serviceDateGreaterThan,
                'serviceDate.lessThan': serviceDateLessThan,
                'serviceDate.greaterThanOrEqual': serviceDateGreaterThanOrEqual,
                'serviceDate.lessThanOrEqual': serviceDateLessThanOrEqual,
                'serviceDate.equals': serviceDateEquals,
                'serviceDate.notEquals': serviceDateNotEquals,
                'serviceDate.specified': serviceDateSpecified,
                'serviceDate.in': serviceDateIn,
                'serviceDate.notIn': serviceDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isSigned.equals': isSignedEquals,
                'isSigned.notEquals': isSignedNotEquals,
                'isSigned.specified': isSignedSpecified,
                'isSigned.in': isSignedIn,
                'isSigned.notIn': isSignedNotIn,
                'readyForBilling.equals': readyForBillingEquals,
                'readyForBilling.notEquals': readyForBillingNotEquals,
                'readyForBilling.specified': readyForBillingSpecified,
                'readyForBilling.in': readyForBillingIn,
                'readyForBilling.notIn': readyForBillingNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'appointmentIdId.greaterThan': appointmentIdIdGreaterThan,
                'appointmentIdId.lessThan': appointmentIdIdLessThan,
                'appointmentIdId.greaterThanOrEqual': appointmentIdIdGreaterThanOrEqual,
                'appointmentIdId.lessThanOrEqual': appointmentIdIdLessThanOrEqual,
                'appointmentIdId.equals': appointmentIdIdEquals,
                'appointmentIdId.notEquals': appointmentIdIdNotEquals,
                'appointmentIdId.specified': appointmentIdIdSpecified,
                'appointmentIdId.in': appointmentIdIdIn,
                'appointmentIdId.notIn': appointmentIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'locationIdId.greaterThan': locationIdIdGreaterThan,
                'locationIdId.lessThan': locationIdIdLessThan,
                'locationIdId.greaterThanOrEqual': locationIdIdGreaterThanOrEqual,
                'locationIdId.lessThanOrEqual': locationIdIdLessThanOrEqual,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'encounterNoteId.greaterThan': encounterNoteIdGreaterThan,
                'encounterNoteId.lessThan': encounterNoteIdLessThan,
                'encounterNoteId.greaterThanOrEqual': encounterNoteIdGreaterThanOrEqual,
                'encounterNoteId.lessThanOrEqual': encounterNoteIdLessThanOrEqual,
                'encounterNoteId.equals': encounterNoteIdEquals,
                'encounterNoteId.notEquals': encounterNoteIdNotEquals,
                'encounterNoteId.specified': encounterNoteIdSpecified,
                'encounterNoteId.in': encounterNoteIdIn,
                'encounterNoteId.notIn': encounterNoteIdNotIn,
                'encounterReviewOfSystemId.greaterThan': encounterReviewOfSystemIdGreaterThan,
                'encounterReviewOfSystemId.lessThan': encounterReviewOfSystemIdLessThan,
                'encounterReviewOfSystemId.greaterThanOrEqual': encounterReviewOfSystemIdGreaterThanOrEqual,
                'encounterReviewOfSystemId.lessThanOrEqual': encounterReviewOfSystemIdLessThanOrEqual,
                'encounterReviewOfSystemId.equals': encounterReviewOfSystemIdEquals,
                'encounterReviewOfSystemId.notEquals': encounterReviewOfSystemIdNotEquals,
                'encounterReviewOfSystemId.specified': encounterReviewOfSystemIdSpecified,
                'encounterReviewOfSystemId.in': encounterReviewOfSystemIdIn,
                'encounterReviewOfSystemId.notIn': encounterReviewOfSystemIdNotIn,
                'superBillId.greaterThan': superBillIdGreaterThan,
                'superBillId.lessThan': superBillIdLessThan,
                'superBillId.greaterThanOrEqual': superBillIdGreaterThanOrEqual,
                'superBillId.lessThanOrEqual': superBillIdLessThanOrEqual,
                'superBillId.equals': superBillIdEquals,
                'superBillId.notEquals': superBillIdNotEquals,
                'superBillId.specified': superBillIdSpecified,
                'superBillId.in': superBillIdIn,
                'superBillId.notIn': superBillIdNotIn,
                'encounterPhysicalExamId.greaterThan': encounterPhysicalExamIdGreaterThan,
                'encounterPhysicalExamId.lessThan': encounterPhysicalExamIdLessThan,
                'encounterPhysicalExamId.greaterThanOrEqual': encounterPhysicalExamIdGreaterThanOrEqual,
                'encounterPhysicalExamId.lessThanOrEqual': encounterPhysicalExamIdLessThanOrEqual,
                'encounterPhysicalExamId.equals': encounterPhysicalExamIdEquals,
                'encounterPhysicalExamId.notEquals': encounterPhysicalExamIdNotEquals,
                'encounterPhysicalExamId.specified': encounterPhysicalExamIdSpecified,
                'encounterPhysicalExamId.in': encounterPhysicalExamIdIn,
                'encounterPhysicalExamId.notIn': encounterPhysicalExamIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
