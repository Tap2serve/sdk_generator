/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChangePasswordDTO } from '../models/ChangePasswordDTO';
import type { IamUserDTO } from '../models/IamUserDTO';
import type { PageUserProfileDTO } from '../models/PageUserProfileDTO';
import type { UserProfileDTO } from '../models/UserProfileDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class UserProfileResourceService {

    /**
     * @param userId
     * @param isActive
     * @returns string OK
     * @throws ApiError
     */
    public static updateUserStatus(
        userId: string,
        isActive: boolean,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/{userId}/status',
            path: {
                'userId': userId,
            },
            query: {
                'isActive': isActive,
            },
        });
    }

    /**
     * @param providerGroupUuid
     * @param userUuid
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static getUserProfileForProviderGroup(
        providerGroupUuid: string,
        userUuid: string,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user/{providerGroupUuid}/profile/{userUuid}',
            path: {
                'providerGroupUuid': providerGroupUuid,
                'userUuid': userUuid,
            },
        });
    }

    /**
     * @param providerGroupUuid
     * @param userUuid
     * @param isActive
     * @returns string OK
     * @throws ApiError
     */
    public static updateUserStatusForProviderGroup(
        providerGroupUuid: string,
        userUuid: string,
        isActive: boolean,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/user/{providerGroupUuid}/profile/{userUuid}',
            path: {
                'providerGroupUuid': providerGroupUuid,
                'userUuid': userUuid,
            },
            query: {
                'isActive': isActive,
            },
        });
    }

    /**
     * @param id
     * @param providerGroupUuid
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static updateUserProfileForProviderGroup(
        id: number,
        providerGroupUuid: string,
        requestBody: UserProfileDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/user/{providerGroupUuid}/profile/{id}',
            path: {
                'id': id,
                'providerGroupUuid': providerGroupUuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static getUserProfile(
        id: number,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user-profiles/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static updateUserProfile(
        id: number,
        requestBody: UserProfileDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/user-profiles/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteUserProfile(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/user-profiles/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static partialUpdateUserProfile(
        id: number,
        requestBody: UserProfileDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/user-profiles/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param providerGroupUuid
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PageUserProfileDTO OK
     * @throws ApiError
     */
    public static getUsersProfileForProviderGroup(
        providerGroupUuid: string,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PageUserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user/{providerGroupUuid}/profile',
            path: {
                'providerGroupUuid': providerGroupUuid,
            },
            query: {
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param providerGroupUuid
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static createUserProfileForProviderGroup(
        providerGroupUuid: string,
        requestBody: UserProfileDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/user/{providerGroupUuid}/profile',
            path: {
                'providerGroupUuid': providerGroupUuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PageUserProfileDTO OK
     * @throws ApiError
     */
    public static getUserProfiles(
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PageUserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user-profiles',
            query: {
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static createUserProfile(
        requestBody: UserProfileDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/user-profiles',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody
     * @returns string OK
     * @throws ApiError
     */
    public static createIamUser(
        requestBody: IamUserDTO,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/iam-user',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody
     * @returns string OK
     * @throws ApiError
     */
    public static changePassword(
        requestBody: ChangePasswordDTO,
    ): CancelablePromise<string> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/change-password',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param uuid
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static getUserProfileByUuid(
        uuid: string,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user/{uuid}/profile',
            path: {
                'uuid': uuid,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param phoneContains
     * @param phoneDoesNotContain
     * @param phoneEquals
     * @param phoneNotEquals
     * @param phoneSpecified
     * @param phoneIn
     * @param phoneNotIn
     * @param emailVerifiedEquals
     * @param emailVerifiedNotEquals
     * @param emailVerifiedSpecified
     * @param emailVerifiedIn
     * @param emailVerifiedNotIn
     * @param phoneVerifiedEquals
     * @param phoneVerifiedNotEquals
     * @param phoneVerifiedSpecified
     * @param phoneVerifiedIn
     * @param phoneVerifiedNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param iamIdContains
     * @param iamIdDoesNotContain
     * @param iamIdEquals
     * @param iamIdNotEquals
     * @param iamIdSpecified
     * @param iamIdIn
     * @param iamIdNotIn
     * @param tenantKeyContains
     * @param tenantKeyDoesNotContain
     * @param tenantKeyEquals
     * @param tenantKeyNotEquals
     * @param tenantKeySpecified
     * @param tenantKeyIn
     * @param tenantKeyNotIn
     * @param lastLoginContains
     * @param lastLoginDoesNotContain
     * @param lastLoginEquals
     * @param lastLoginNotEquals
     * @param lastLoginSpecified
     * @param lastLoginIn
     * @param lastLoginNotIn
     * @param roleContains
     * @param roleDoesNotContain
     * @param roleEquals
     * @param roleNotEquals
     * @param roleSpecified
     * @param roleIn
     * @param roleNotIn
     * @param roleTypeEquals
     * @param roleTypeNotEquals
     * @param roleTypeSpecified
     * @param roleTypeIn
     * @param roleTypeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param internalUserIdContains
     * @param internalUserIdDoesNotContain
     * @param internalUserIdEquals
     * @param internalUserIdNotEquals
     * @param internalUserIdSpecified
     * @param internalUserIdIn
     * @param internalUserIdNotIn
     * @param departmentIdGreaterThan
     * @param departmentIdLessThan
     * @param departmentIdGreaterThanOrEqual
     * @param departmentIdLessThanOrEqual
     * @param departmentIdEquals
     * @param departmentIdNotEquals
     * @param departmentIdSpecified
     * @param departmentIdIn
     * @param departmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countUserProfiles(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        phoneContains?: string,
        phoneDoesNotContain?: string,
        phoneEquals?: string,
        phoneNotEquals?: string,
        phoneSpecified?: boolean,
        phoneIn?: Array<string>,
        phoneNotIn?: Array<string>,
        emailVerifiedEquals?: boolean,
        emailVerifiedNotEquals?: boolean,
        emailVerifiedSpecified?: boolean,
        emailVerifiedIn?: Array<boolean>,
        emailVerifiedNotIn?: Array<boolean>,
        phoneVerifiedEquals?: boolean,
        phoneVerifiedNotEquals?: boolean,
        phoneVerifiedSpecified?: boolean,
        phoneVerifiedIn?: Array<boolean>,
        phoneVerifiedNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        iamIdContains?: string,
        iamIdDoesNotContain?: string,
        iamIdEquals?: string,
        iamIdNotEquals?: string,
        iamIdSpecified?: boolean,
        iamIdIn?: Array<string>,
        iamIdNotIn?: Array<string>,
        tenantKeyContains?: string,
        tenantKeyDoesNotContain?: string,
        tenantKeyEquals?: string,
        tenantKeyNotEquals?: string,
        tenantKeySpecified?: boolean,
        tenantKeyIn?: Array<string>,
        tenantKeyNotIn?: Array<string>,
        lastLoginContains?: string,
        lastLoginDoesNotContain?: string,
        lastLoginEquals?: string,
        lastLoginNotEquals?: string,
        lastLoginSpecified?: boolean,
        lastLoginIn?: Array<string>,
        lastLoginNotIn?: Array<string>,
        roleContains?: string,
        roleDoesNotContain?: string,
        roleEquals?: string,
        roleNotEquals?: string,
        roleSpecified?: boolean,
        roleIn?: Array<string>,
        roleNotIn?: Array<string>,
        roleTypeEquals?: 'PATIENT' | 'PROVIDER' | 'STAFF',
        roleTypeNotEquals?: 'PATIENT' | 'PROVIDER' | 'STAFF',
        roleTypeSpecified?: boolean,
        roleTypeIn?: Array<'PATIENT' | 'PROVIDER' | 'STAFF'>,
        roleTypeNotIn?: Array<'PATIENT' | 'PROVIDER' | 'STAFF'>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        internalUserIdContains?: string,
        internalUserIdDoesNotContain?: string,
        internalUserIdEquals?: string,
        internalUserIdNotEquals?: string,
        internalUserIdSpecified?: boolean,
        internalUserIdIn?: Array<string>,
        internalUserIdNotIn?: Array<string>,
        departmentIdGreaterThan?: number,
        departmentIdLessThan?: number,
        departmentIdGreaterThanOrEqual?: number,
        departmentIdLessThanOrEqual?: number,
        departmentIdEquals?: number,
        departmentIdNotEquals?: number,
        departmentIdSpecified?: boolean,
        departmentIdIn?: Array<number>,
        departmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user-profiles/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'phone.contains': phoneContains,
                'phone.doesNotContain': phoneDoesNotContain,
                'phone.equals': phoneEquals,
                'phone.notEquals': phoneNotEquals,
                'phone.specified': phoneSpecified,
                'phone.in': phoneIn,
                'phone.notIn': phoneNotIn,
                'emailVerified.equals': emailVerifiedEquals,
                'emailVerified.notEquals': emailVerifiedNotEquals,
                'emailVerified.specified': emailVerifiedSpecified,
                'emailVerified.in': emailVerifiedIn,
                'emailVerified.notIn': emailVerifiedNotIn,
                'phoneVerified.equals': phoneVerifiedEquals,
                'phoneVerified.notEquals': phoneVerifiedNotEquals,
                'phoneVerified.specified': phoneVerifiedSpecified,
                'phoneVerified.in': phoneVerifiedIn,
                'phoneVerified.notIn': phoneVerifiedNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'iamId.contains': iamIdContains,
                'iamId.doesNotContain': iamIdDoesNotContain,
                'iamId.equals': iamIdEquals,
                'iamId.notEquals': iamIdNotEquals,
                'iamId.specified': iamIdSpecified,
                'iamId.in': iamIdIn,
                'iamId.notIn': iamIdNotIn,
                'tenantKey.contains': tenantKeyContains,
                'tenantKey.doesNotContain': tenantKeyDoesNotContain,
                'tenantKey.equals': tenantKeyEquals,
                'tenantKey.notEquals': tenantKeyNotEquals,
                'tenantKey.specified': tenantKeySpecified,
                'tenantKey.in': tenantKeyIn,
                'tenantKey.notIn': tenantKeyNotIn,
                'lastLogin.contains': lastLoginContains,
                'lastLogin.doesNotContain': lastLoginDoesNotContain,
                'lastLogin.equals': lastLoginEquals,
                'lastLogin.notEquals': lastLoginNotEquals,
                'lastLogin.specified': lastLoginSpecified,
                'lastLogin.in': lastLoginIn,
                'lastLogin.notIn': lastLoginNotIn,
                'role.contains': roleContains,
                'role.doesNotContain': roleDoesNotContain,
                'role.equals': roleEquals,
                'role.notEquals': roleNotEquals,
                'role.specified': roleSpecified,
                'role.in': roleIn,
                'role.notIn': roleNotIn,
                'roleType.equals': roleTypeEquals,
                'roleType.notEquals': roleTypeNotEquals,
                'roleType.specified': roleTypeSpecified,
                'roleType.in': roleTypeIn,
                'roleType.notIn': roleTypeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'internalUserId.contains': internalUserIdContains,
                'internalUserId.doesNotContain': internalUserIdDoesNotContain,
                'internalUserId.equals': internalUserIdEquals,
                'internalUserId.notEquals': internalUserIdNotEquals,
                'internalUserId.specified': internalUserIdSpecified,
                'internalUserId.in': internalUserIdIn,
                'internalUserId.notIn': internalUserIdNotIn,
                'departmentId.greaterThan': departmentIdGreaterThan,
                'departmentId.lessThan': departmentIdLessThan,
                'departmentId.greaterThanOrEqual': departmentIdGreaterThanOrEqual,
                'departmentId.lessThanOrEqual': departmentIdLessThanOrEqual,
                'departmentId.equals': departmentIdEquals,
                'departmentId.notEquals': departmentIdNotEquals,
                'departmentId.specified': departmentIdSpecified,
                'departmentId.in': departmentIdIn,
                'departmentId.notIn': departmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'distinct': distinct,
            },
        });
    }

    /**
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static getUserProfileByToken(): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/user-profile',
        });
    }

}
