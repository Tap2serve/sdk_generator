/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PagePatientVaccineDTO } from '../models/PagePatientVaccineDTO';
import type { PatientVaccineDTO } from '../models/PatientVaccineDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientVaccineResourceService {

    /**
     * @param id
     * @returns PatientVaccineDTO OK
     * @throws ApiError
     */
    public static getPatientVaccine(
        id: number,
    ): CancelablePromise<PatientVaccineDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-vaccines/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientVaccineDTO OK
     * @throws ApiError
     */
    public static updatePatientVaccine(
        id: number,
        requestBody: PatientVaccineDTO,
    ): CancelablePromise<PatientVaccineDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-vaccines/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientVaccineDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientVaccine(
        id: number,
        requestBody: PatientVaccineDTO,
    ): CancelablePromise<PatientVaccineDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-vaccines/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param administerDateGreaterThan
     * @param administerDateLessThan
     * @param administerDateGreaterThanOrEqual
     * @param administerDateLessThanOrEqual
     * @param administerDateEquals
     * @param administerDateNotEquals
     * @param administerDateSpecified
     * @param administerDateIn
     * @param administerDateNotIn
     * @param administeredbyGreaterThan
     * @param administeredbyLessThan
     * @param administeredbyGreaterThanOrEqual
     * @param administeredbyLessThanOrEqual
     * @param administeredbyEquals
     * @param administeredbyNotEquals
     * @param administeredbySpecified
     * @param administeredbyIn
     * @param administeredbyNotIn
     * @param expiryDateGreaterThan
     * @param expiryDateLessThan
     * @param expiryDateGreaterThanOrEqual
     * @param expiryDateLessThanOrEqual
     * @param expiryDateEquals
     * @param expiryDateNotEquals
     * @param expiryDateSpecified
     * @param expiryDateIn
     * @param expiryDateNotIn
     * @param amountContains
     * @param amountDoesNotContain
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param routeContains
     * @param routeDoesNotContain
     * @param routeEquals
     * @param routeNotEquals
     * @param routeSpecified
     * @param routeIn
     * @param routeNotIn
     * @param siteContains
     * @param siteDoesNotContain
     * @param siteEquals
     * @param siteNotEquals
     * @param siteSpecified
     * @param siteIn
     * @param siteNotIn
     * @param manufacturerContains
     * @param manufacturerDoesNotContain
     * @param manufacturerEquals
     * @param manufacturerNotEquals
     * @param manufacturerSpecified
     * @param manufacturerIn
     * @param manufacturerNotIn
     * @param lotContains
     * @param lotDoesNotContain
     * @param lotEquals
     * @param lotNotEquals
     * @param lotSpecified
     * @param lotIn
     * @param lotNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeVaccineIdGreaterThan
     * @param intakeVaccineIdLessThan
     * @param intakeVaccineIdGreaterThanOrEqual
     * @param intakeVaccineIdLessThanOrEqual
     * @param intakeVaccineIdEquals
     * @param intakeVaccineIdNotEquals
     * @param intakeVaccineIdSpecified
     * @param intakeVaccineIdIn
     * @param intakeVaccineIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientVaccineDTO OK
     * @throws ApiError
     */
    public static getAllPatientVaccines1(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        administerDateGreaterThan?: string,
        administerDateLessThan?: string,
        administerDateGreaterThanOrEqual?: string,
        administerDateLessThanOrEqual?: string,
        administerDateEquals?: string,
        administerDateNotEquals?: string,
        administerDateSpecified?: boolean,
        administerDateIn?: Array<string>,
        administerDateNotIn?: Array<string>,
        administeredbyGreaterThan?: number,
        administeredbyLessThan?: number,
        administeredbyGreaterThanOrEqual?: number,
        administeredbyLessThanOrEqual?: number,
        administeredbyEquals?: number,
        administeredbyNotEquals?: number,
        administeredbySpecified?: boolean,
        administeredbyIn?: Array<number>,
        administeredbyNotIn?: Array<number>,
        expiryDateGreaterThan?: string,
        expiryDateLessThan?: string,
        expiryDateGreaterThanOrEqual?: string,
        expiryDateLessThanOrEqual?: string,
        expiryDateEquals?: string,
        expiryDateNotEquals?: string,
        expiryDateSpecified?: boolean,
        expiryDateIn?: Array<string>,
        expiryDateNotIn?: Array<string>,
        amountContains?: string,
        amountDoesNotContain?: string,
        amountEquals?: string,
        amountNotEquals?: string,
        amountSpecified?: boolean,
        amountIn?: Array<string>,
        amountNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        routeContains?: string,
        routeDoesNotContain?: string,
        routeEquals?: string,
        routeNotEquals?: string,
        routeSpecified?: boolean,
        routeIn?: Array<string>,
        routeNotIn?: Array<string>,
        siteContains?: string,
        siteDoesNotContain?: string,
        siteEquals?: string,
        siteNotEquals?: string,
        siteSpecified?: boolean,
        siteIn?: Array<string>,
        siteNotIn?: Array<string>,
        manufacturerContains?: string,
        manufacturerDoesNotContain?: string,
        manufacturerEquals?: string,
        manufacturerNotEquals?: string,
        manufacturerSpecified?: boolean,
        manufacturerIn?: Array<string>,
        manufacturerNotIn?: Array<string>,
        lotContains?: string,
        lotDoesNotContain?: string,
        lotEquals?: string,
        lotNotEquals?: string,
        lotSpecified?: boolean,
        lotIn?: Array<string>,
        lotNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeVaccineIdGreaterThan?: number,
        intakeVaccineIdLessThan?: number,
        intakeVaccineIdGreaterThanOrEqual?: number,
        intakeVaccineIdLessThanOrEqual?: number,
        intakeVaccineIdEquals?: number,
        intakeVaccineIdNotEquals?: number,
        intakeVaccineIdSpecified?: boolean,
        intakeVaccineIdIn?: Array<number>,
        intakeVaccineIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientVaccineDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-vaccines',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'administerDate.greaterThan': administerDateGreaterThan,
                'administerDate.lessThan': administerDateLessThan,
                'administerDate.greaterThanOrEqual': administerDateGreaterThanOrEqual,
                'administerDate.lessThanOrEqual': administerDateLessThanOrEqual,
                'administerDate.equals': administerDateEquals,
                'administerDate.notEquals': administerDateNotEquals,
                'administerDate.specified': administerDateSpecified,
                'administerDate.in': administerDateIn,
                'administerDate.notIn': administerDateNotIn,
                'administeredby.greaterThan': administeredbyGreaterThan,
                'administeredby.lessThan': administeredbyLessThan,
                'administeredby.greaterThanOrEqual': administeredbyGreaterThanOrEqual,
                'administeredby.lessThanOrEqual': administeredbyLessThanOrEqual,
                'administeredby.equals': administeredbyEquals,
                'administeredby.notEquals': administeredbyNotEquals,
                'administeredby.specified': administeredbySpecified,
                'administeredby.in': administeredbyIn,
                'administeredby.notIn': administeredbyNotIn,
                'expiryDate.greaterThan': expiryDateGreaterThan,
                'expiryDate.lessThan': expiryDateLessThan,
                'expiryDate.greaterThanOrEqual': expiryDateGreaterThanOrEqual,
                'expiryDate.lessThanOrEqual': expiryDateLessThanOrEqual,
                'expiryDate.equals': expiryDateEquals,
                'expiryDate.notEquals': expiryDateNotEquals,
                'expiryDate.specified': expiryDateSpecified,
                'expiryDate.in': expiryDateIn,
                'expiryDate.notIn': expiryDateNotIn,
                'amount.contains': amountContains,
                'amount.doesNotContain': amountDoesNotContain,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'route.contains': routeContains,
                'route.doesNotContain': routeDoesNotContain,
                'route.equals': routeEquals,
                'route.notEquals': routeNotEquals,
                'route.specified': routeSpecified,
                'route.in': routeIn,
                'route.notIn': routeNotIn,
                'site.contains': siteContains,
                'site.doesNotContain': siteDoesNotContain,
                'site.equals': siteEquals,
                'site.notEquals': siteNotEquals,
                'site.specified': siteSpecified,
                'site.in': siteIn,
                'site.notIn': siteNotIn,
                'manufacturer.contains': manufacturerContains,
                'manufacturer.doesNotContain': manufacturerDoesNotContain,
                'manufacturer.equals': manufacturerEquals,
                'manufacturer.notEquals': manufacturerNotEquals,
                'manufacturer.specified': manufacturerSpecified,
                'manufacturer.in': manufacturerIn,
                'manufacturer.notIn': manufacturerNotIn,
                'lot.contains': lotContains,
                'lot.doesNotContain': lotDoesNotContain,
                'lot.equals': lotEquals,
                'lot.notEquals': lotNotEquals,
                'lot.specified': lotSpecified,
                'lot.in': lotIn,
                'lot.notIn': lotNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeVaccineId.greaterThan': intakeVaccineIdGreaterThan,
                'intakeVaccineId.lessThan': intakeVaccineIdLessThan,
                'intakeVaccineId.greaterThanOrEqual': intakeVaccineIdGreaterThanOrEqual,
                'intakeVaccineId.lessThanOrEqual': intakeVaccineIdLessThanOrEqual,
                'intakeVaccineId.equals': intakeVaccineIdEquals,
                'intakeVaccineId.notEquals': intakeVaccineIdNotEquals,
                'intakeVaccineId.specified': intakeVaccineIdSpecified,
                'intakeVaccineId.in': intakeVaccineIdIn,
                'intakeVaccineId.notIn': intakeVaccineIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientVaccineDTO OK
     * @throws ApiError
     */
    public static createPatientVaccine(
        requestBody: PatientVaccineDTO,
    ): CancelablePromise<PatientVaccineDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-vaccines',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param patientUuid
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PagePatientVaccineDTO OK
     * @throws ApiError
     */
    public static getAllPatientVaccines(
        patientUuid: string,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PagePatientVaccineDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient/{patientUuid}/vaccines',
            path: {
                'patientUuid': patientUuid,
            },
            query: {
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param administerDateGreaterThan
     * @param administerDateLessThan
     * @param administerDateGreaterThanOrEqual
     * @param administerDateLessThanOrEqual
     * @param administerDateEquals
     * @param administerDateNotEquals
     * @param administerDateSpecified
     * @param administerDateIn
     * @param administerDateNotIn
     * @param administeredbyGreaterThan
     * @param administeredbyLessThan
     * @param administeredbyGreaterThanOrEqual
     * @param administeredbyLessThanOrEqual
     * @param administeredbyEquals
     * @param administeredbyNotEquals
     * @param administeredbySpecified
     * @param administeredbyIn
     * @param administeredbyNotIn
     * @param expiryDateGreaterThan
     * @param expiryDateLessThan
     * @param expiryDateGreaterThanOrEqual
     * @param expiryDateLessThanOrEqual
     * @param expiryDateEquals
     * @param expiryDateNotEquals
     * @param expiryDateSpecified
     * @param expiryDateIn
     * @param expiryDateNotIn
     * @param amountContains
     * @param amountDoesNotContain
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param routeContains
     * @param routeDoesNotContain
     * @param routeEquals
     * @param routeNotEquals
     * @param routeSpecified
     * @param routeIn
     * @param routeNotIn
     * @param siteContains
     * @param siteDoesNotContain
     * @param siteEquals
     * @param siteNotEquals
     * @param siteSpecified
     * @param siteIn
     * @param siteNotIn
     * @param manufacturerContains
     * @param manufacturerDoesNotContain
     * @param manufacturerEquals
     * @param manufacturerNotEquals
     * @param manufacturerSpecified
     * @param manufacturerIn
     * @param manufacturerNotIn
     * @param lotContains
     * @param lotDoesNotContain
     * @param lotEquals
     * @param lotNotEquals
     * @param lotSpecified
     * @param lotIn
     * @param lotNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeVaccineIdGreaterThan
     * @param intakeVaccineIdLessThan
     * @param intakeVaccineIdGreaterThanOrEqual
     * @param intakeVaccineIdLessThanOrEqual
     * @param intakeVaccineIdEquals
     * @param intakeVaccineIdNotEquals
     * @param intakeVaccineIdSpecified
     * @param intakeVaccineIdIn
     * @param intakeVaccineIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientVaccines(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        administerDateGreaterThan?: string,
        administerDateLessThan?: string,
        administerDateGreaterThanOrEqual?: string,
        administerDateLessThanOrEqual?: string,
        administerDateEquals?: string,
        administerDateNotEquals?: string,
        administerDateSpecified?: boolean,
        administerDateIn?: Array<string>,
        administerDateNotIn?: Array<string>,
        administeredbyGreaterThan?: number,
        administeredbyLessThan?: number,
        administeredbyGreaterThanOrEqual?: number,
        administeredbyLessThanOrEqual?: number,
        administeredbyEquals?: number,
        administeredbyNotEquals?: number,
        administeredbySpecified?: boolean,
        administeredbyIn?: Array<number>,
        administeredbyNotIn?: Array<number>,
        expiryDateGreaterThan?: string,
        expiryDateLessThan?: string,
        expiryDateGreaterThanOrEqual?: string,
        expiryDateLessThanOrEqual?: string,
        expiryDateEquals?: string,
        expiryDateNotEquals?: string,
        expiryDateSpecified?: boolean,
        expiryDateIn?: Array<string>,
        expiryDateNotIn?: Array<string>,
        amountContains?: string,
        amountDoesNotContain?: string,
        amountEquals?: string,
        amountNotEquals?: string,
        amountSpecified?: boolean,
        amountIn?: Array<string>,
        amountNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        routeContains?: string,
        routeDoesNotContain?: string,
        routeEquals?: string,
        routeNotEquals?: string,
        routeSpecified?: boolean,
        routeIn?: Array<string>,
        routeNotIn?: Array<string>,
        siteContains?: string,
        siteDoesNotContain?: string,
        siteEquals?: string,
        siteNotEquals?: string,
        siteSpecified?: boolean,
        siteIn?: Array<string>,
        siteNotIn?: Array<string>,
        manufacturerContains?: string,
        manufacturerDoesNotContain?: string,
        manufacturerEquals?: string,
        manufacturerNotEquals?: string,
        manufacturerSpecified?: boolean,
        manufacturerIn?: Array<string>,
        manufacturerNotIn?: Array<string>,
        lotContains?: string,
        lotDoesNotContain?: string,
        lotEquals?: string,
        lotNotEquals?: string,
        lotSpecified?: boolean,
        lotIn?: Array<string>,
        lotNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeVaccineIdGreaterThan?: number,
        intakeVaccineIdLessThan?: number,
        intakeVaccineIdGreaterThanOrEqual?: number,
        intakeVaccineIdLessThanOrEqual?: number,
        intakeVaccineIdEquals?: number,
        intakeVaccineIdNotEquals?: number,
        intakeVaccineIdSpecified?: boolean,
        intakeVaccineIdIn?: Array<number>,
        intakeVaccineIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-vaccines/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'administerDate.greaterThan': administerDateGreaterThan,
                'administerDate.lessThan': administerDateLessThan,
                'administerDate.greaterThanOrEqual': administerDateGreaterThanOrEqual,
                'administerDate.lessThanOrEqual': administerDateLessThanOrEqual,
                'administerDate.equals': administerDateEquals,
                'administerDate.notEquals': administerDateNotEquals,
                'administerDate.specified': administerDateSpecified,
                'administerDate.in': administerDateIn,
                'administerDate.notIn': administerDateNotIn,
                'administeredby.greaterThan': administeredbyGreaterThan,
                'administeredby.lessThan': administeredbyLessThan,
                'administeredby.greaterThanOrEqual': administeredbyGreaterThanOrEqual,
                'administeredby.lessThanOrEqual': administeredbyLessThanOrEqual,
                'administeredby.equals': administeredbyEquals,
                'administeredby.notEquals': administeredbyNotEquals,
                'administeredby.specified': administeredbySpecified,
                'administeredby.in': administeredbyIn,
                'administeredby.notIn': administeredbyNotIn,
                'expiryDate.greaterThan': expiryDateGreaterThan,
                'expiryDate.lessThan': expiryDateLessThan,
                'expiryDate.greaterThanOrEqual': expiryDateGreaterThanOrEqual,
                'expiryDate.lessThanOrEqual': expiryDateLessThanOrEqual,
                'expiryDate.equals': expiryDateEquals,
                'expiryDate.notEquals': expiryDateNotEquals,
                'expiryDate.specified': expiryDateSpecified,
                'expiryDate.in': expiryDateIn,
                'expiryDate.notIn': expiryDateNotIn,
                'amount.contains': amountContains,
                'amount.doesNotContain': amountDoesNotContain,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'route.contains': routeContains,
                'route.doesNotContain': routeDoesNotContain,
                'route.equals': routeEquals,
                'route.notEquals': routeNotEquals,
                'route.specified': routeSpecified,
                'route.in': routeIn,
                'route.notIn': routeNotIn,
                'site.contains': siteContains,
                'site.doesNotContain': siteDoesNotContain,
                'site.equals': siteEquals,
                'site.notEquals': siteNotEquals,
                'site.specified': siteSpecified,
                'site.in': siteIn,
                'site.notIn': siteNotIn,
                'manufacturer.contains': manufacturerContains,
                'manufacturer.doesNotContain': manufacturerDoesNotContain,
                'manufacturer.equals': manufacturerEquals,
                'manufacturer.notEquals': manufacturerNotEquals,
                'manufacturer.specified': manufacturerSpecified,
                'manufacturer.in': manufacturerIn,
                'manufacturer.notIn': manufacturerNotIn,
                'lot.contains': lotContains,
                'lot.doesNotContain': lotDoesNotContain,
                'lot.equals': lotEquals,
                'lot.notEquals': lotNotEquals,
                'lot.specified': lotSpecified,
                'lot.in': lotIn,
                'lot.notIn': lotNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeVaccineId.greaterThan': intakeVaccineIdGreaterThan,
                'intakeVaccineId.lessThan': intakeVaccineIdLessThan,
                'intakeVaccineId.greaterThanOrEqual': intakeVaccineIdGreaterThanOrEqual,
                'intakeVaccineId.lessThanOrEqual': intakeVaccineIdLessThanOrEqual,
                'intakeVaccineId.equals': intakeVaccineIdEquals,
                'intakeVaccineId.notEquals': intakeVaccineIdNotEquals,
                'intakeVaccineId.specified': intakeVaccineIdSpecified,
                'intakeVaccineId.in': intakeVaccineIdIn,
                'intakeVaccineId.notIn': intakeVaccineIdNotIn,
                'distinct': distinct,
            },
        });
    }

    /**
     * @param patientVaccineUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientVaccine(
        patientVaccineUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-vaccines/{patientVaccineUuid}',
            path: {
                'patientVaccineUuid': patientVaccineUuid,
            },
        });
    }

}
