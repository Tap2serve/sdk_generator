/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PrescriptionFormDTO } from '../models/PrescriptionFormDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PrescriptionFormResourceService {

    /**
     * @param id
     * @returns PrescriptionFormDTO OK
     * @throws ApiError
     */
    public static getPrescriptionForm(
        id: number,
    ): CancelablePromise<PrescriptionFormDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/prescription-forms/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PrescriptionFormDTO OK
     * @throws ApiError
     */
    public static updatePrescriptionForm(
        id: number,
        requestBody: PrescriptionFormDTO,
    ): CancelablePromise<PrescriptionFormDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/prescription-forms/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePrescriptionForm(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/prescription-forms/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PrescriptionFormDTO OK
     * @throws ApiError
     */
    public static partialUpdatePrescriptionForm(
        id: number,
        requestBody: PrescriptionFormDTO,
    ): CancelablePromise<PrescriptionFormDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/prescription-forms/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param sigContains
     * @param sigDoesNotContain
     * @param sigEquals
     * @param sigNotEquals
     * @param sigSpecified
     * @param sigIn
     * @param sigNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param refillContains
     * @param refillDoesNotContain
     * @param refillEquals
     * @param refillNotEquals
     * @param refillSpecified
     * @param refillIn
     * @param refillNotIn
     * @param notesForPharmacyContains
     * @param notesForPharmacyDoesNotContain
     * @param notesForPharmacyEquals
     * @param notesForPharmacyNotEquals
     * @param notesForPharmacySpecified
     * @param notesForPharmacyIn
     * @param notesForPharmacyNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param dispenseAsWrittenEquals
     * @param dispenseAsWrittenNotEquals
     * @param dispenseAsWrittenSpecified
     * @param dispenseAsWrittenIn
     * @param dispenseAsWrittenNotIn
     * @param isPermanentEquals
     * @param isPermanentNotEquals
     * @param isPermanentSpecified
     * @param isPermanentIn
     * @param isPermanentNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param diagnosisIdGreaterThan
     * @param diagnosisIdLessThan
     * @param diagnosisIdGreaterThanOrEqual
     * @param diagnosisIdLessThanOrEqual
     * @param diagnosisIdEquals
     * @param diagnosisIdNotEquals
     * @param diagnosisIdSpecified
     * @param diagnosisIdIn
     * @param diagnosisIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PrescriptionFormDTO OK
     * @throws ApiError
     */
    public static getAllPrescriptionForms(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        sigContains?: string,
        sigDoesNotContain?: string,
        sigEquals?: string,
        sigNotEquals?: string,
        sigSpecified?: boolean,
        sigIn?: Array<string>,
        sigNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        refillContains?: string,
        refillDoesNotContain?: string,
        refillEquals?: string,
        refillNotEquals?: string,
        refillSpecified?: boolean,
        refillIn?: Array<string>,
        refillNotIn?: Array<string>,
        notesForPharmacyContains?: string,
        notesForPharmacyDoesNotContain?: string,
        notesForPharmacyEquals?: string,
        notesForPharmacyNotEquals?: string,
        notesForPharmacySpecified?: boolean,
        notesForPharmacyIn?: Array<string>,
        notesForPharmacyNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        dispenseAsWrittenEquals?: boolean,
        dispenseAsWrittenNotEquals?: boolean,
        dispenseAsWrittenSpecified?: boolean,
        dispenseAsWrittenIn?: Array<boolean>,
        dispenseAsWrittenNotIn?: Array<boolean>,
        isPermanentEquals?: boolean,
        isPermanentNotEquals?: boolean,
        isPermanentSpecified?: boolean,
        isPermanentIn?: Array<boolean>,
        isPermanentNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        diagnosisIdGreaterThan?: number,
        diagnosisIdLessThan?: number,
        diagnosisIdGreaterThanOrEqual?: number,
        diagnosisIdLessThanOrEqual?: number,
        diagnosisIdEquals?: number,
        diagnosisIdNotEquals?: number,
        diagnosisIdSpecified?: boolean,
        diagnosisIdIn?: Array<number>,
        diagnosisIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PrescriptionFormDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/prescription-forms',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'sig.contains': sigContains,
                'sig.doesNotContain': sigDoesNotContain,
                'sig.equals': sigEquals,
                'sig.notEquals': sigNotEquals,
                'sig.specified': sigSpecified,
                'sig.in': sigIn,
                'sig.notIn': sigNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'refill.contains': refillContains,
                'refill.doesNotContain': refillDoesNotContain,
                'refill.equals': refillEquals,
                'refill.notEquals': refillNotEquals,
                'refill.specified': refillSpecified,
                'refill.in': refillIn,
                'refill.notIn': refillNotIn,
                'notesForPharmacy.contains': notesForPharmacyContains,
                'notesForPharmacy.doesNotContain': notesForPharmacyDoesNotContain,
                'notesForPharmacy.equals': notesForPharmacyEquals,
                'notesForPharmacy.notEquals': notesForPharmacyNotEquals,
                'notesForPharmacy.specified': notesForPharmacySpecified,
                'notesForPharmacy.in': notesForPharmacyIn,
                'notesForPharmacy.notIn': notesForPharmacyNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'dispenseAsWritten.equals': dispenseAsWrittenEquals,
                'dispenseAsWritten.notEquals': dispenseAsWrittenNotEquals,
                'dispenseAsWritten.specified': dispenseAsWrittenSpecified,
                'dispenseAsWritten.in': dispenseAsWrittenIn,
                'dispenseAsWritten.notIn': dispenseAsWrittenNotIn,
                'isPermanent.equals': isPermanentEquals,
                'isPermanent.notEquals': isPermanentNotEquals,
                'isPermanent.specified': isPermanentSpecified,
                'isPermanent.in': isPermanentIn,
                'isPermanent.notIn': isPermanentNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'diagnosisId.greaterThan': diagnosisIdGreaterThan,
                'diagnosisId.lessThan': diagnosisIdLessThan,
                'diagnosisId.greaterThanOrEqual': diagnosisIdGreaterThanOrEqual,
                'diagnosisId.lessThanOrEqual': diagnosisIdLessThanOrEqual,
                'diagnosisId.equals': diagnosisIdEquals,
                'diagnosisId.notEquals': diagnosisIdNotEquals,
                'diagnosisId.specified': diagnosisIdSpecified,
                'diagnosisId.in': diagnosisIdIn,
                'diagnosisId.notIn': diagnosisIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PrescriptionFormDTO OK
     * @throws ApiError
     */
    public static createPrescriptionForm(
        requestBody: PrescriptionFormDTO,
    ): CancelablePromise<PrescriptionFormDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/prescription-forms',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param sigContains
     * @param sigDoesNotContain
     * @param sigEquals
     * @param sigNotEquals
     * @param sigSpecified
     * @param sigIn
     * @param sigNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param refillContains
     * @param refillDoesNotContain
     * @param refillEquals
     * @param refillNotEquals
     * @param refillSpecified
     * @param refillIn
     * @param refillNotIn
     * @param notesForPharmacyContains
     * @param notesForPharmacyDoesNotContain
     * @param notesForPharmacyEquals
     * @param notesForPharmacyNotEquals
     * @param notesForPharmacySpecified
     * @param notesForPharmacyIn
     * @param notesForPharmacyNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param dispenseAsWrittenEquals
     * @param dispenseAsWrittenNotEquals
     * @param dispenseAsWrittenSpecified
     * @param dispenseAsWrittenIn
     * @param dispenseAsWrittenNotIn
     * @param isPermanentEquals
     * @param isPermanentNotEquals
     * @param isPermanentSpecified
     * @param isPermanentIn
     * @param isPermanentNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param diagnosisIdGreaterThan
     * @param diagnosisIdLessThan
     * @param diagnosisIdGreaterThanOrEqual
     * @param diagnosisIdLessThanOrEqual
     * @param diagnosisIdEquals
     * @param diagnosisIdNotEquals
     * @param diagnosisIdSpecified
     * @param diagnosisIdIn
     * @param diagnosisIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPrescriptionForms(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        sigContains?: string,
        sigDoesNotContain?: string,
        sigEquals?: string,
        sigNotEquals?: string,
        sigSpecified?: boolean,
        sigIn?: Array<string>,
        sigNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        refillContains?: string,
        refillDoesNotContain?: string,
        refillEquals?: string,
        refillNotEquals?: string,
        refillSpecified?: boolean,
        refillIn?: Array<string>,
        refillNotIn?: Array<string>,
        notesForPharmacyContains?: string,
        notesForPharmacyDoesNotContain?: string,
        notesForPharmacyEquals?: string,
        notesForPharmacyNotEquals?: string,
        notesForPharmacySpecified?: boolean,
        notesForPharmacyIn?: Array<string>,
        notesForPharmacyNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        dispenseAsWrittenEquals?: boolean,
        dispenseAsWrittenNotEquals?: boolean,
        dispenseAsWrittenSpecified?: boolean,
        dispenseAsWrittenIn?: Array<boolean>,
        dispenseAsWrittenNotIn?: Array<boolean>,
        isPermanentEquals?: boolean,
        isPermanentNotEquals?: boolean,
        isPermanentSpecified?: boolean,
        isPermanentIn?: Array<boolean>,
        isPermanentNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        diagnosisIdGreaterThan?: number,
        diagnosisIdLessThan?: number,
        diagnosisIdGreaterThanOrEqual?: number,
        diagnosisIdLessThanOrEqual?: number,
        diagnosisIdEquals?: number,
        diagnosisIdNotEquals?: number,
        diagnosisIdSpecified?: boolean,
        diagnosisIdIn?: Array<number>,
        diagnosisIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/prescription-forms/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'sig.contains': sigContains,
                'sig.doesNotContain': sigDoesNotContain,
                'sig.equals': sigEquals,
                'sig.notEquals': sigNotEquals,
                'sig.specified': sigSpecified,
                'sig.in': sigIn,
                'sig.notIn': sigNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'refill.contains': refillContains,
                'refill.doesNotContain': refillDoesNotContain,
                'refill.equals': refillEquals,
                'refill.notEquals': refillNotEquals,
                'refill.specified': refillSpecified,
                'refill.in': refillIn,
                'refill.notIn': refillNotIn,
                'notesForPharmacy.contains': notesForPharmacyContains,
                'notesForPharmacy.doesNotContain': notesForPharmacyDoesNotContain,
                'notesForPharmacy.equals': notesForPharmacyEquals,
                'notesForPharmacy.notEquals': notesForPharmacyNotEquals,
                'notesForPharmacy.specified': notesForPharmacySpecified,
                'notesForPharmacy.in': notesForPharmacyIn,
                'notesForPharmacy.notIn': notesForPharmacyNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'dispenseAsWritten.equals': dispenseAsWrittenEquals,
                'dispenseAsWritten.notEquals': dispenseAsWrittenNotEquals,
                'dispenseAsWritten.specified': dispenseAsWrittenSpecified,
                'dispenseAsWritten.in': dispenseAsWrittenIn,
                'dispenseAsWritten.notIn': dispenseAsWrittenNotIn,
                'isPermanent.equals': isPermanentEquals,
                'isPermanent.notEquals': isPermanentNotEquals,
                'isPermanent.specified': isPermanentSpecified,
                'isPermanent.in': isPermanentIn,
                'isPermanent.notIn': isPermanentNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'diagnosisId.greaterThan': diagnosisIdGreaterThan,
                'diagnosisId.lessThan': diagnosisIdLessThan,
                'diagnosisId.greaterThanOrEqual': diagnosisIdGreaterThanOrEqual,
                'diagnosisId.lessThanOrEqual': diagnosisIdLessThanOrEqual,
                'diagnosisId.equals': diagnosisIdEquals,
                'diagnosisId.notEquals': diagnosisIdNotEquals,
                'diagnosisId.specified': diagnosisIdSpecified,
                'diagnosisId.in': diagnosisIdIn,
                'diagnosisId.notIn': diagnosisIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
