/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SuperBillDTO } from '../models/SuperBillDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class SuperBillResourceService {

    /**
     * @param id
     * @returns SuperBillDTO OK
     * @throws ApiError
     */
    public static getSuperBill(
        id: number,
    ): CancelablePromise<SuperBillDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bills/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SuperBillDTO OK
     * @throws ApiError
     */
    public static updateSuperBill(
        id: number,
        requestBody: SuperBillDTO,
    ): CancelablePromise<SuperBillDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/super-bills/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteSuperBill(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/super-bills/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SuperBillDTO OK
     * @throws ApiError
     */
    public static partialUpdateSuperBill(
        id: number,
        requestBody: SuperBillDTO,
    ): CancelablePromise<SuperBillDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/super-bills/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param billIdContains
     * @param billIdDoesNotContain
     * @param billIdEquals
     * @param billIdNotEquals
     * @param billIdSpecified
     * @param billIdIn
     * @param billIdNotIn
     * @param servicePlaceContains
     * @param servicePlaceDoesNotContain
     * @param servicePlaceEquals
     * @param servicePlaceNotEquals
     * @param servicePlaceSpecified
     * @param servicePlaceIn
     * @param servicePlaceNotIn
     * @param serviceDateGreaterThan
     * @param serviceDateLessThan
     * @param serviceDateGreaterThanOrEqual
     * @param serviceDateLessThanOrEqual
     * @param serviceDateEquals
     * @param serviceDateNotEquals
     * @param serviceDateSpecified
     * @param serviceDateIn
     * @param serviceDateNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param totalChargesGreaterThan
     * @param totalChargesLessThan
     * @param totalChargesGreaterThanOrEqual
     * @param totalChargesLessThanOrEqual
     * @param totalChargesEquals
     * @param totalChargesNotEquals
     * @param totalChargesSpecified
     * @param totalChargesIn
     * @param totalChargesNotIn
     * @param advancePayGreaterThan
     * @param advancePayLessThan
     * @param advancePayGreaterThanOrEqual
     * @param advancePayLessThanOrEqual
     * @param advancePayEquals
     * @param advancePayNotEquals
     * @param advancePaySpecified
     * @param advancePayIn
     * @param advancePayNotIn
     * @param patientBalanceGreaterThan
     * @param patientBalanceLessThan
     * @param patientBalanceGreaterThanOrEqual
     * @param patientBalanceLessThanOrEqual
     * @param patientBalanceEquals
     * @param patientBalanceNotEquals
     * @param patientBalanceSpecified
     * @param patientBalanceIn
     * @param patientBalanceNotIn
     * @param insuranceBalanceGreaterThan
     * @param insuranceBalanceLessThan
     * @param insuranceBalanceGreaterThanOrEqual
     * @param insuranceBalanceLessThanOrEqual
     * @param insuranceBalanceEquals
     * @param insuranceBalanceNotEquals
     * @param insuranceBalanceSpecified
     * @param insuranceBalanceIn
     * @param insuranceBalanceNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param patientAppliedPaymentIdGreaterThan
     * @param patientAppliedPaymentIdLessThan
     * @param patientAppliedPaymentIdGreaterThanOrEqual
     * @param patientAppliedPaymentIdLessThanOrEqual
     * @param patientAppliedPaymentIdEquals
     * @param patientAppliedPaymentIdNotEquals
     * @param patientAppliedPaymentIdSpecified
     * @param patientAppliedPaymentIdIn
     * @param patientAppliedPaymentIdNotIn
     * @param insuranceClaimIdGreaterThan
     * @param insuranceClaimIdLessThan
     * @param insuranceClaimIdGreaterThanOrEqual
     * @param insuranceClaimIdLessThanOrEqual
     * @param insuranceClaimIdEquals
     * @param insuranceClaimIdNotEquals
     * @param insuranceClaimIdSpecified
     * @param insuranceClaimIdIn
     * @param insuranceClaimIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns SuperBillDTO OK
     * @throws ApiError
     */
    public static getAllSuperBills(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        billIdContains?: string,
        billIdDoesNotContain?: string,
        billIdEquals?: string,
        billIdNotEquals?: string,
        billIdSpecified?: boolean,
        billIdIn?: Array<string>,
        billIdNotIn?: Array<string>,
        servicePlaceContains?: string,
        servicePlaceDoesNotContain?: string,
        servicePlaceEquals?: string,
        servicePlaceNotEquals?: string,
        servicePlaceSpecified?: boolean,
        servicePlaceIn?: Array<string>,
        servicePlaceNotIn?: Array<string>,
        serviceDateGreaterThan?: string,
        serviceDateLessThan?: string,
        serviceDateGreaterThanOrEqual?: string,
        serviceDateLessThanOrEqual?: string,
        serviceDateEquals?: string,
        serviceDateNotEquals?: string,
        serviceDateSpecified?: boolean,
        serviceDateIn?: Array<string>,
        serviceDateNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        totalChargesGreaterThan?: number,
        totalChargesLessThan?: number,
        totalChargesGreaterThanOrEqual?: number,
        totalChargesLessThanOrEqual?: number,
        totalChargesEquals?: number,
        totalChargesNotEquals?: number,
        totalChargesSpecified?: boolean,
        totalChargesIn?: Array<number>,
        totalChargesNotIn?: Array<number>,
        advancePayGreaterThan?: number,
        advancePayLessThan?: number,
        advancePayGreaterThanOrEqual?: number,
        advancePayLessThanOrEqual?: number,
        advancePayEquals?: number,
        advancePayNotEquals?: number,
        advancePaySpecified?: boolean,
        advancePayIn?: Array<number>,
        advancePayNotIn?: Array<number>,
        patientBalanceGreaterThan?: number,
        patientBalanceLessThan?: number,
        patientBalanceGreaterThanOrEqual?: number,
        patientBalanceLessThanOrEqual?: number,
        patientBalanceEquals?: number,
        patientBalanceNotEquals?: number,
        patientBalanceSpecified?: boolean,
        patientBalanceIn?: Array<number>,
        patientBalanceNotIn?: Array<number>,
        insuranceBalanceGreaterThan?: number,
        insuranceBalanceLessThan?: number,
        insuranceBalanceGreaterThanOrEqual?: number,
        insuranceBalanceLessThanOrEqual?: number,
        insuranceBalanceEquals?: number,
        insuranceBalanceNotEquals?: number,
        insuranceBalanceSpecified?: boolean,
        insuranceBalanceIn?: Array<number>,
        insuranceBalanceNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        patientAppliedPaymentIdGreaterThan?: number,
        patientAppliedPaymentIdLessThan?: number,
        patientAppliedPaymentIdGreaterThanOrEqual?: number,
        patientAppliedPaymentIdLessThanOrEqual?: number,
        patientAppliedPaymentIdEquals?: number,
        patientAppliedPaymentIdNotEquals?: number,
        patientAppliedPaymentIdSpecified?: boolean,
        patientAppliedPaymentIdIn?: Array<number>,
        patientAppliedPaymentIdNotIn?: Array<number>,
        insuranceClaimIdGreaterThan?: number,
        insuranceClaimIdLessThan?: number,
        insuranceClaimIdGreaterThanOrEqual?: number,
        insuranceClaimIdLessThanOrEqual?: number,
        insuranceClaimIdEquals?: number,
        insuranceClaimIdNotEquals?: number,
        insuranceClaimIdSpecified?: boolean,
        insuranceClaimIdIn?: Array<number>,
        insuranceClaimIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<SuperBillDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bills',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'billId.contains': billIdContains,
                'billId.doesNotContain': billIdDoesNotContain,
                'billId.equals': billIdEquals,
                'billId.notEquals': billIdNotEquals,
                'billId.specified': billIdSpecified,
                'billId.in': billIdIn,
                'billId.notIn': billIdNotIn,
                'servicePlace.contains': servicePlaceContains,
                'servicePlace.doesNotContain': servicePlaceDoesNotContain,
                'servicePlace.equals': servicePlaceEquals,
                'servicePlace.notEquals': servicePlaceNotEquals,
                'servicePlace.specified': servicePlaceSpecified,
                'servicePlace.in': servicePlaceIn,
                'servicePlace.notIn': servicePlaceNotIn,
                'serviceDate.greaterThan': serviceDateGreaterThan,
                'serviceDate.lessThan': serviceDateLessThan,
                'serviceDate.greaterThanOrEqual': serviceDateGreaterThanOrEqual,
                'serviceDate.lessThanOrEqual': serviceDateLessThanOrEqual,
                'serviceDate.equals': serviceDateEquals,
                'serviceDate.notEquals': serviceDateNotEquals,
                'serviceDate.specified': serviceDateSpecified,
                'serviceDate.in': serviceDateIn,
                'serviceDate.notIn': serviceDateNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'totalCharges.greaterThan': totalChargesGreaterThan,
                'totalCharges.lessThan': totalChargesLessThan,
                'totalCharges.greaterThanOrEqual': totalChargesGreaterThanOrEqual,
                'totalCharges.lessThanOrEqual': totalChargesLessThanOrEqual,
                'totalCharges.equals': totalChargesEquals,
                'totalCharges.notEquals': totalChargesNotEquals,
                'totalCharges.specified': totalChargesSpecified,
                'totalCharges.in': totalChargesIn,
                'totalCharges.notIn': totalChargesNotIn,
                'advancePay.greaterThan': advancePayGreaterThan,
                'advancePay.lessThan': advancePayLessThan,
                'advancePay.greaterThanOrEqual': advancePayGreaterThanOrEqual,
                'advancePay.lessThanOrEqual': advancePayLessThanOrEqual,
                'advancePay.equals': advancePayEquals,
                'advancePay.notEquals': advancePayNotEquals,
                'advancePay.specified': advancePaySpecified,
                'advancePay.in': advancePayIn,
                'advancePay.notIn': advancePayNotIn,
                'patientBalance.greaterThan': patientBalanceGreaterThan,
                'patientBalance.lessThan': patientBalanceLessThan,
                'patientBalance.greaterThanOrEqual': patientBalanceGreaterThanOrEqual,
                'patientBalance.lessThanOrEqual': patientBalanceLessThanOrEqual,
                'patientBalance.equals': patientBalanceEquals,
                'patientBalance.notEquals': patientBalanceNotEquals,
                'patientBalance.specified': patientBalanceSpecified,
                'patientBalance.in': patientBalanceIn,
                'patientBalance.notIn': patientBalanceNotIn,
                'insuranceBalance.greaterThan': insuranceBalanceGreaterThan,
                'insuranceBalance.lessThan': insuranceBalanceLessThan,
                'insuranceBalance.greaterThanOrEqual': insuranceBalanceGreaterThanOrEqual,
                'insuranceBalance.lessThanOrEqual': insuranceBalanceLessThanOrEqual,
                'insuranceBalance.equals': insuranceBalanceEquals,
                'insuranceBalance.notEquals': insuranceBalanceNotEquals,
                'insuranceBalance.specified': insuranceBalanceSpecified,
                'insuranceBalance.in': insuranceBalanceIn,
                'insuranceBalance.notIn': insuranceBalanceNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'patientAppliedPaymentId.greaterThan': patientAppliedPaymentIdGreaterThan,
                'patientAppliedPaymentId.lessThan': patientAppliedPaymentIdLessThan,
                'patientAppliedPaymentId.greaterThanOrEqual': patientAppliedPaymentIdGreaterThanOrEqual,
                'patientAppliedPaymentId.lessThanOrEqual': patientAppliedPaymentIdLessThanOrEqual,
                'patientAppliedPaymentId.equals': patientAppliedPaymentIdEquals,
                'patientAppliedPaymentId.notEquals': patientAppliedPaymentIdNotEquals,
                'patientAppliedPaymentId.specified': patientAppliedPaymentIdSpecified,
                'patientAppliedPaymentId.in': patientAppliedPaymentIdIn,
                'patientAppliedPaymentId.notIn': patientAppliedPaymentIdNotIn,
                'insuranceClaimId.greaterThan': insuranceClaimIdGreaterThan,
                'insuranceClaimId.lessThan': insuranceClaimIdLessThan,
                'insuranceClaimId.greaterThanOrEqual': insuranceClaimIdGreaterThanOrEqual,
                'insuranceClaimId.lessThanOrEqual': insuranceClaimIdLessThanOrEqual,
                'insuranceClaimId.equals': insuranceClaimIdEquals,
                'insuranceClaimId.notEquals': insuranceClaimIdNotEquals,
                'insuranceClaimId.specified': insuranceClaimIdSpecified,
                'insuranceClaimId.in': insuranceClaimIdIn,
                'insuranceClaimId.notIn': insuranceClaimIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns SuperBillDTO OK
     * @throws ApiError
     */
    public static createSuperBill(
        requestBody: SuperBillDTO,
    ): CancelablePromise<SuperBillDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/super-bills',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param billIdContains
     * @param billIdDoesNotContain
     * @param billIdEquals
     * @param billIdNotEquals
     * @param billIdSpecified
     * @param billIdIn
     * @param billIdNotIn
     * @param servicePlaceContains
     * @param servicePlaceDoesNotContain
     * @param servicePlaceEquals
     * @param servicePlaceNotEquals
     * @param servicePlaceSpecified
     * @param servicePlaceIn
     * @param servicePlaceNotIn
     * @param serviceDateGreaterThan
     * @param serviceDateLessThan
     * @param serviceDateGreaterThanOrEqual
     * @param serviceDateLessThanOrEqual
     * @param serviceDateEquals
     * @param serviceDateNotEquals
     * @param serviceDateSpecified
     * @param serviceDateIn
     * @param serviceDateNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param totalChargesGreaterThan
     * @param totalChargesLessThan
     * @param totalChargesGreaterThanOrEqual
     * @param totalChargesLessThanOrEqual
     * @param totalChargesEquals
     * @param totalChargesNotEquals
     * @param totalChargesSpecified
     * @param totalChargesIn
     * @param totalChargesNotIn
     * @param advancePayGreaterThan
     * @param advancePayLessThan
     * @param advancePayGreaterThanOrEqual
     * @param advancePayLessThanOrEqual
     * @param advancePayEquals
     * @param advancePayNotEquals
     * @param advancePaySpecified
     * @param advancePayIn
     * @param advancePayNotIn
     * @param patientBalanceGreaterThan
     * @param patientBalanceLessThan
     * @param patientBalanceGreaterThanOrEqual
     * @param patientBalanceLessThanOrEqual
     * @param patientBalanceEquals
     * @param patientBalanceNotEquals
     * @param patientBalanceSpecified
     * @param patientBalanceIn
     * @param patientBalanceNotIn
     * @param insuranceBalanceGreaterThan
     * @param insuranceBalanceLessThan
     * @param insuranceBalanceGreaterThanOrEqual
     * @param insuranceBalanceLessThanOrEqual
     * @param insuranceBalanceEquals
     * @param insuranceBalanceNotEquals
     * @param insuranceBalanceSpecified
     * @param insuranceBalanceIn
     * @param insuranceBalanceNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param patientAppliedPaymentIdGreaterThan
     * @param patientAppliedPaymentIdLessThan
     * @param patientAppliedPaymentIdGreaterThanOrEqual
     * @param patientAppliedPaymentIdLessThanOrEqual
     * @param patientAppliedPaymentIdEquals
     * @param patientAppliedPaymentIdNotEquals
     * @param patientAppliedPaymentIdSpecified
     * @param patientAppliedPaymentIdIn
     * @param patientAppliedPaymentIdNotIn
     * @param insuranceClaimIdGreaterThan
     * @param insuranceClaimIdLessThan
     * @param insuranceClaimIdGreaterThanOrEqual
     * @param insuranceClaimIdLessThanOrEqual
     * @param insuranceClaimIdEquals
     * @param insuranceClaimIdNotEquals
     * @param insuranceClaimIdSpecified
     * @param insuranceClaimIdIn
     * @param insuranceClaimIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countSuperBills(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        billIdContains?: string,
        billIdDoesNotContain?: string,
        billIdEquals?: string,
        billIdNotEquals?: string,
        billIdSpecified?: boolean,
        billIdIn?: Array<string>,
        billIdNotIn?: Array<string>,
        servicePlaceContains?: string,
        servicePlaceDoesNotContain?: string,
        servicePlaceEquals?: string,
        servicePlaceNotEquals?: string,
        servicePlaceSpecified?: boolean,
        servicePlaceIn?: Array<string>,
        servicePlaceNotIn?: Array<string>,
        serviceDateGreaterThan?: string,
        serviceDateLessThan?: string,
        serviceDateGreaterThanOrEqual?: string,
        serviceDateLessThanOrEqual?: string,
        serviceDateEquals?: string,
        serviceDateNotEquals?: string,
        serviceDateSpecified?: boolean,
        serviceDateIn?: Array<string>,
        serviceDateNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        totalChargesGreaterThan?: number,
        totalChargesLessThan?: number,
        totalChargesGreaterThanOrEqual?: number,
        totalChargesLessThanOrEqual?: number,
        totalChargesEquals?: number,
        totalChargesNotEquals?: number,
        totalChargesSpecified?: boolean,
        totalChargesIn?: Array<number>,
        totalChargesNotIn?: Array<number>,
        advancePayGreaterThan?: number,
        advancePayLessThan?: number,
        advancePayGreaterThanOrEqual?: number,
        advancePayLessThanOrEqual?: number,
        advancePayEquals?: number,
        advancePayNotEquals?: number,
        advancePaySpecified?: boolean,
        advancePayIn?: Array<number>,
        advancePayNotIn?: Array<number>,
        patientBalanceGreaterThan?: number,
        patientBalanceLessThan?: number,
        patientBalanceGreaterThanOrEqual?: number,
        patientBalanceLessThanOrEqual?: number,
        patientBalanceEquals?: number,
        patientBalanceNotEquals?: number,
        patientBalanceSpecified?: boolean,
        patientBalanceIn?: Array<number>,
        patientBalanceNotIn?: Array<number>,
        insuranceBalanceGreaterThan?: number,
        insuranceBalanceLessThan?: number,
        insuranceBalanceGreaterThanOrEqual?: number,
        insuranceBalanceLessThanOrEqual?: number,
        insuranceBalanceEquals?: number,
        insuranceBalanceNotEquals?: number,
        insuranceBalanceSpecified?: boolean,
        insuranceBalanceIn?: Array<number>,
        insuranceBalanceNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        patientAppliedPaymentIdGreaterThan?: number,
        patientAppliedPaymentIdLessThan?: number,
        patientAppliedPaymentIdGreaterThanOrEqual?: number,
        patientAppliedPaymentIdLessThanOrEqual?: number,
        patientAppliedPaymentIdEquals?: number,
        patientAppliedPaymentIdNotEquals?: number,
        patientAppliedPaymentIdSpecified?: boolean,
        patientAppliedPaymentIdIn?: Array<number>,
        patientAppliedPaymentIdNotIn?: Array<number>,
        insuranceClaimIdGreaterThan?: number,
        insuranceClaimIdLessThan?: number,
        insuranceClaimIdGreaterThanOrEqual?: number,
        insuranceClaimIdLessThanOrEqual?: number,
        insuranceClaimIdEquals?: number,
        insuranceClaimIdNotEquals?: number,
        insuranceClaimIdSpecified?: boolean,
        insuranceClaimIdIn?: Array<number>,
        insuranceClaimIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bills/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'billId.contains': billIdContains,
                'billId.doesNotContain': billIdDoesNotContain,
                'billId.equals': billIdEquals,
                'billId.notEquals': billIdNotEquals,
                'billId.specified': billIdSpecified,
                'billId.in': billIdIn,
                'billId.notIn': billIdNotIn,
                'servicePlace.contains': servicePlaceContains,
                'servicePlace.doesNotContain': servicePlaceDoesNotContain,
                'servicePlace.equals': servicePlaceEquals,
                'servicePlace.notEquals': servicePlaceNotEquals,
                'servicePlace.specified': servicePlaceSpecified,
                'servicePlace.in': servicePlaceIn,
                'servicePlace.notIn': servicePlaceNotIn,
                'serviceDate.greaterThan': serviceDateGreaterThan,
                'serviceDate.lessThan': serviceDateLessThan,
                'serviceDate.greaterThanOrEqual': serviceDateGreaterThanOrEqual,
                'serviceDate.lessThanOrEqual': serviceDateLessThanOrEqual,
                'serviceDate.equals': serviceDateEquals,
                'serviceDate.notEquals': serviceDateNotEquals,
                'serviceDate.specified': serviceDateSpecified,
                'serviceDate.in': serviceDateIn,
                'serviceDate.notIn': serviceDateNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'totalCharges.greaterThan': totalChargesGreaterThan,
                'totalCharges.lessThan': totalChargesLessThan,
                'totalCharges.greaterThanOrEqual': totalChargesGreaterThanOrEqual,
                'totalCharges.lessThanOrEqual': totalChargesLessThanOrEqual,
                'totalCharges.equals': totalChargesEquals,
                'totalCharges.notEquals': totalChargesNotEquals,
                'totalCharges.specified': totalChargesSpecified,
                'totalCharges.in': totalChargesIn,
                'totalCharges.notIn': totalChargesNotIn,
                'advancePay.greaterThan': advancePayGreaterThan,
                'advancePay.lessThan': advancePayLessThan,
                'advancePay.greaterThanOrEqual': advancePayGreaterThanOrEqual,
                'advancePay.lessThanOrEqual': advancePayLessThanOrEqual,
                'advancePay.equals': advancePayEquals,
                'advancePay.notEquals': advancePayNotEquals,
                'advancePay.specified': advancePaySpecified,
                'advancePay.in': advancePayIn,
                'advancePay.notIn': advancePayNotIn,
                'patientBalance.greaterThan': patientBalanceGreaterThan,
                'patientBalance.lessThan': patientBalanceLessThan,
                'patientBalance.greaterThanOrEqual': patientBalanceGreaterThanOrEqual,
                'patientBalance.lessThanOrEqual': patientBalanceLessThanOrEqual,
                'patientBalance.equals': patientBalanceEquals,
                'patientBalance.notEquals': patientBalanceNotEquals,
                'patientBalance.specified': patientBalanceSpecified,
                'patientBalance.in': patientBalanceIn,
                'patientBalance.notIn': patientBalanceNotIn,
                'insuranceBalance.greaterThan': insuranceBalanceGreaterThan,
                'insuranceBalance.lessThan': insuranceBalanceLessThan,
                'insuranceBalance.greaterThanOrEqual': insuranceBalanceGreaterThanOrEqual,
                'insuranceBalance.lessThanOrEqual': insuranceBalanceLessThanOrEqual,
                'insuranceBalance.equals': insuranceBalanceEquals,
                'insuranceBalance.notEquals': insuranceBalanceNotEquals,
                'insuranceBalance.specified': insuranceBalanceSpecified,
                'insuranceBalance.in': insuranceBalanceIn,
                'insuranceBalance.notIn': insuranceBalanceNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'patientAppliedPaymentId.greaterThan': patientAppliedPaymentIdGreaterThan,
                'patientAppliedPaymentId.lessThan': patientAppliedPaymentIdLessThan,
                'patientAppliedPaymentId.greaterThanOrEqual': patientAppliedPaymentIdGreaterThanOrEqual,
                'patientAppliedPaymentId.lessThanOrEqual': patientAppliedPaymentIdLessThanOrEqual,
                'patientAppliedPaymentId.equals': patientAppliedPaymentIdEquals,
                'patientAppliedPaymentId.notEquals': patientAppliedPaymentIdNotEquals,
                'patientAppliedPaymentId.specified': patientAppliedPaymentIdSpecified,
                'patientAppliedPaymentId.in': patientAppliedPaymentIdIn,
                'patientAppliedPaymentId.notIn': patientAppliedPaymentIdNotIn,
                'insuranceClaimId.greaterThan': insuranceClaimIdGreaterThan,
                'insuranceClaimId.lessThan': insuranceClaimIdLessThan,
                'insuranceClaimId.greaterThanOrEqual': insuranceClaimIdGreaterThanOrEqual,
                'insuranceClaimId.lessThanOrEqual': insuranceClaimIdLessThanOrEqual,
                'insuranceClaimId.equals': insuranceClaimIdEquals,
                'insuranceClaimId.notEquals': insuranceClaimIdNotEquals,
                'insuranceClaimId.specified': insuranceClaimIdSpecified,
                'insuranceClaimId.in': insuranceClaimIdIn,
                'insuranceClaimId.notIn': insuranceClaimIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
