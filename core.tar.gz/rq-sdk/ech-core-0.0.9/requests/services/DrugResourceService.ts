/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DrugDTO } from '../models/DrugDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class DrugResourceService {

    /**
     * @param id
     * @returns DrugDTO OK
     * @throws ApiError
     */
    public static getDrug(
        id: number,
    ): CancelablePromise<DrugDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/drugs/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns DrugDTO OK
     * @throws ApiError
     */
    public static updateDrug(
        id: number,
        requestBody: DrugDTO,
    ): CancelablePromise<DrugDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/drugs/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteDrug(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/drugs/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns DrugDTO OK
     * @throws ApiError
     */
    public static partialUpdateDrug(
        id: number,
        requestBody: DrugDTO,
    ): CancelablePromise<DrugDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/drugs/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param medicineContains
     * @param medicineDoesNotContain
     * @param medicineEquals
     * @param medicineNotEquals
     * @param medicineSpecified
     * @param medicineIn
     * @param medicineNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param whenContains
     * @param whenDoesNotContain
     * @param whenEquals
     * @param whenNotEquals
     * @param whenSpecified
     * @param whenIn
     * @param whenNotIn
     * @param whereContains
     * @param whereDoesNotContain
     * @param whereEquals
     * @param whereNotEquals
     * @param whereSpecified
     * @param whereIn
     * @param whereNotIn
     * @param frequencyContains
     * @param frequencyDoesNotContain
     * @param frequencyEquals
     * @param frequencyNotEquals
     * @param frequencySpecified
     * @param frequencyIn
     * @param frequencyNotIn
     * @param durationContains
     * @param durationDoesNotContain
     * @param durationEquals
     * @param durationNotEquals
     * @param durationSpecified
     * @param durationIn
     * @param durationNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param instructionGreaterThan
     * @param instructionLessThan
     * @param instructionGreaterThanOrEqual
     * @param instructionLessThanOrEqual
     * @param instructionEquals
     * @param instructionNotEquals
     * @param instructionSpecified
     * @param instructionIn
     * @param instructionNotIn
     * @param sourceGreaterThan
     * @param sourceLessThan
     * @param sourceGreaterThanOrEqual
     * @param sourceLessThanOrEqual
     * @param sourceEquals
     * @param sourceNotEquals
     * @param sourceSpecified
     * @param sourceIn
     * @param sourceNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param specialityIdIdGreaterThan
     * @param specialityIdIdLessThan
     * @param specialityIdIdGreaterThanOrEqual
     * @param specialityIdIdLessThanOrEqual
     * @param specialityIdIdEquals
     * @param specialityIdIdNotEquals
     * @param specialityIdIdSpecified
     * @param specialityIdIdIn
     * @param specialityIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns DrugDTO OK
     * @throws ApiError
     */
    public static getAllDrugs(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeEquals?: 'TAB' | 'SOL',
        typeNotEquals?: 'TAB' | 'SOL',
        typeSpecified?: boolean,
        typeIn?: Array<'TAB' | 'SOL'>,
        typeNotIn?: Array<'TAB' | 'SOL'>,
        medicineContains?: string,
        medicineDoesNotContain?: string,
        medicineEquals?: string,
        medicineNotEquals?: string,
        medicineSpecified?: boolean,
        medicineIn?: Array<string>,
        medicineNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        whenContains?: string,
        whenDoesNotContain?: string,
        whenEquals?: string,
        whenNotEquals?: string,
        whenSpecified?: boolean,
        whenIn?: Array<string>,
        whenNotIn?: Array<string>,
        whereContains?: string,
        whereDoesNotContain?: string,
        whereEquals?: string,
        whereNotEquals?: string,
        whereSpecified?: boolean,
        whereIn?: Array<string>,
        whereNotIn?: Array<string>,
        frequencyContains?: string,
        frequencyDoesNotContain?: string,
        frequencyEquals?: string,
        frequencyNotEquals?: string,
        frequencySpecified?: boolean,
        frequencyIn?: Array<string>,
        frequencyNotIn?: Array<string>,
        durationContains?: string,
        durationDoesNotContain?: string,
        durationEquals?: string,
        durationNotEquals?: string,
        durationSpecified?: boolean,
        durationIn?: Array<string>,
        durationNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        instructionGreaterThan?: number,
        instructionLessThan?: number,
        instructionGreaterThanOrEqual?: number,
        instructionLessThanOrEqual?: number,
        instructionEquals?: number,
        instructionNotEquals?: number,
        instructionSpecified?: boolean,
        instructionIn?: Array<number>,
        instructionNotIn?: Array<number>,
        sourceGreaterThan?: number,
        sourceLessThan?: number,
        sourceGreaterThanOrEqual?: number,
        sourceLessThanOrEqual?: number,
        sourceEquals?: number,
        sourceNotEquals?: number,
        sourceSpecified?: boolean,
        sourceIn?: Array<number>,
        sourceNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        specialityIdIdGreaterThan?: number,
        specialityIdIdLessThan?: number,
        specialityIdIdGreaterThanOrEqual?: number,
        specialityIdIdLessThanOrEqual?: number,
        specialityIdIdEquals?: number,
        specialityIdIdNotEquals?: number,
        specialityIdIdSpecified?: boolean,
        specialityIdIdIn?: Array<number>,
        specialityIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<DrugDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/drugs',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'medicine.contains': medicineContains,
                'medicine.doesNotContain': medicineDoesNotContain,
                'medicine.equals': medicineEquals,
                'medicine.notEquals': medicineNotEquals,
                'medicine.specified': medicineSpecified,
                'medicine.in': medicineIn,
                'medicine.notIn': medicineNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'when.contains': whenContains,
                'when.doesNotContain': whenDoesNotContain,
                'when.equals': whenEquals,
                'when.notEquals': whenNotEquals,
                'when.specified': whenSpecified,
                'when.in': whenIn,
                'when.notIn': whenNotIn,
                'where.contains': whereContains,
                'where.doesNotContain': whereDoesNotContain,
                'where.equals': whereEquals,
                'where.notEquals': whereNotEquals,
                'where.specified': whereSpecified,
                'where.in': whereIn,
                'where.notIn': whereNotIn,
                'frequency.contains': frequencyContains,
                'frequency.doesNotContain': frequencyDoesNotContain,
                'frequency.equals': frequencyEquals,
                'frequency.notEquals': frequencyNotEquals,
                'frequency.specified': frequencySpecified,
                'frequency.in': frequencyIn,
                'frequency.notIn': frequencyNotIn,
                'duration.contains': durationContains,
                'duration.doesNotContain': durationDoesNotContain,
                'duration.equals': durationEquals,
                'duration.notEquals': durationNotEquals,
                'duration.specified': durationSpecified,
                'duration.in': durationIn,
                'duration.notIn': durationNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'instruction.greaterThan': instructionGreaterThan,
                'instruction.lessThan': instructionLessThan,
                'instruction.greaterThanOrEqual': instructionGreaterThanOrEqual,
                'instruction.lessThanOrEqual': instructionLessThanOrEqual,
                'instruction.equals': instructionEquals,
                'instruction.notEquals': instructionNotEquals,
                'instruction.specified': instructionSpecified,
                'instruction.in': instructionIn,
                'instruction.notIn': instructionNotIn,
                'source.greaterThan': sourceGreaterThan,
                'source.lessThan': sourceLessThan,
                'source.greaterThanOrEqual': sourceGreaterThanOrEqual,
                'source.lessThanOrEqual': sourceLessThanOrEqual,
                'source.equals': sourceEquals,
                'source.notEquals': sourceNotEquals,
                'source.specified': sourceSpecified,
                'source.in': sourceIn,
                'source.notIn': sourceNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'specialityIdId.greaterThan': specialityIdIdGreaterThan,
                'specialityIdId.lessThan': specialityIdIdLessThan,
                'specialityIdId.greaterThanOrEqual': specialityIdIdGreaterThanOrEqual,
                'specialityIdId.lessThanOrEqual': specialityIdIdLessThanOrEqual,
                'specialityIdId.equals': specialityIdIdEquals,
                'specialityIdId.notEquals': specialityIdIdNotEquals,
                'specialityIdId.specified': specialityIdIdSpecified,
                'specialityIdId.in': specialityIdIdIn,
                'specialityIdId.notIn': specialityIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns DrugDTO OK
     * @throws ApiError
     */
    public static createDrug(
        requestBody: DrugDTO,
    ): CancelablePromise<DrugDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/drugs',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param medicineContains
     * @param medicineDoesNotContain
     * @param medicineEquals
     * @param medicineNotEquals
     * @param medicineSpecified
     * @param medicineIn
     * @param medicineNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param whenContains
     * @param whenDoesNotContain
     * @param whenEquals
     * @param whenNotEquals
     * @param whenSpecified
     * @param whenIn
     * @param whenNotIn
     * @param whereContains
     * @param whereDoesNotContain
     * @param whereEquals
     * @param whereNotEquals
     * @param whereSpecified
     * @param whereIn
     * @param whereNotIn
     * @param frequencyContains
     * @param frequencyDoesNotContain
     * @param frequencyEquals
     * @param frequencyNotEquals
     * @param frequencySpecified
     * @param frequencyIn
     * @param frequencyNotIn
     * @param durationContains
     * @param durationDoesNotContain
     * @param durationEquals
     * @param durationNotEquals
     * @param durationSpecified
     * @param durationIn
     * @param durationNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param instructionGreaterThan
     * @param instructionLessThan
     * @param instructionGreaterThanOrEqual
     * @param instructionLessThanOrEqual
     * @param instructionEquals
     * @param instructionNotEquals
     * @param instructionSpecified
     * @param instructionIn
     * @param instructionNotIn
     * @param sourceGreaterThan
     * @param sourceLessThan
     * @param sourceGreaterThanOrEqual
     * @param sourceLessThanOrEqual
     * @param sourceEquals
     * @param sourceNotEquals
     * @param sourceSpecified
     * @param sourceIn
     * @param sourceNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param specialityIdIdGreaterThan
     * @param specialityIdIdLessThan
     * @param specialityIdIdGreaterThanOrEqual
     * @param specialityIdIdLessThanOrEqual
     * @param specialityIdIdEquals
     * @param specialityIdIdNotEquals
     * @param specialityIdIdSpecified
     * @param specialityIdIdIn
     * @param specialityIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countDrugs(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeEquals?: 'TAB' | 'SOL',
        typeNotEquals?: 'TAB' | 'SOL',
        typeSpecified?: boolean,
        typeIn?: Array<'TAB' | 'SOL'>,
        typeNotIn?: Array<'TAB' | 'SOL'>,
        medicineContains?: string,
        medicineDoesNotContain?: string,
        medicineEquals?: string,
        medicineNotEquals?: string,
        medicineSpecified?: boolean,
        medicineIn?: Array<string>,
        medicineNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        whenContains?: string,
        whenDoesNotContain?: string,
        whenEquals?: string,
        whenNotEquals?: string,
        whenSpecified?: boolean,
        whenIn?: Array<string>,
        whenNotIn?: Array<string>,
        whereContains?: string,
        whereDoesNotContain?: string,
        whereEquals?: string,
        whereNotEquals?: string,
        whereSpecified?: boolean,
        whereIn?: Array<string>,
        whereNotIn?: Array<string>,
        frequencyContains?: string,
        frequencyDoesNotContain?: string,
        frequencyEquals?: string,
        frequencyNotEquals?: string,
        frequencySpecified?: boolean,
        frequencyIn?: Array<string>,
        frequencyNotIn?: Array<string>,
        durationContains?: string,
        durationDoesNotContain?: string,
        durationEquals?: string,
        durationNotEquals?: string,
        durationSpecified?: boolean,
        durationIn?: Array<string>,
        durationNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        instructionGreaterThan?: number,
        instructionLessThan?: number,
        instructionGreaterThanOrEqual?: number,
        instructionLessThanOrEqual?: number,
        instructionEquals?: number,
        instructionNotEquals?: number,
        instructionSpecified?: boolean,
        instructionIn?: Array<number>,
        instructionNotIn?: Array<number>,
        sourceGreaterThan?: number,
        sourceLessThan?: number,
        sourceGreaterThanOrEqual?: number,
        sourceLessThanOrEqual?: number,
        sourceEquals?: number,
        sourceNotEquals?: number,
        sourceSpecified?: boolean,
        sourceIn?: Array<number>,
        sourceNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        specialityIdIdGreaterThan?: number,
        specialityIdIdLessThan?: number,
        specialityIdIdGreaterThanOrEqual?: number,
        specialityIdIdLessThanOrEqual?: number,
        specialityIdIdEquals?: number,
        specialityIdIdNotEquals?: number,
        specialityIdIdSpecified?: boolean,
        specialityIdIdIn?: Array<number>,
        specialityIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/drugs/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'medicine.contains': medicineContains,
                'medicine.doesNotContain': medicineDoesNotContain,
                'medicine.equals': medicineEquals,
                'medicine.notEquals': medicineNotEquals,
                'medicine.specified': medicineSpecified,
                'medicine.in': medicineIn,
                'medicine.notIn': medicineNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'when.contains': whenContains,
                'when.doesNotContain': whenDoesNotContain,
                'when.equals': whenEquals,
                'when.notEquals': whenNotEquals,
                'when.specified': whenSpecified,
                'when.in': whenIn,
                'when.notIn': whenNotIn,
                'where.contains': whereContains,
                'where.doesNotContain': whereDoesNotContain,
                'where.equals': whereEquals,
                'where.notEquals': whereNotEquals,
                'where.specified': whereSpecified,
                'where.in': whereIn,
                'where.notIn': whereNotIn,
                'frequency.contains': frequencyContains,
                'frequency.doesNotContain': frequencyDoesNotContain,
                'frequency.equals': frequencyEquals,
                'frequency.notEquals': frequencyNotEquals,
                'frequency.specified': frequencySpecified,
                'frequency.in': frequencyIn,
                'frequency.notIn': frequencyNotIn,
                'duration.contains': durationContains,
                'duration.doesNotContain': durationDoesNotContain,
                'duration.equals': durationEquals,
                'duration.notEquals': durationNotEquals,
                'duration.specified': durationSpecified,
                'duration.in': durationIn,
                'duration.notIn': durationNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'instruction.greaterThan': instructionGreaterThan,
                'instruction.lessThan': instructionLessThan,
                'instruction.greaterThanOrEqual': instructionGreaterThanOrEqual,
                'instruction.lessThanOrEqual': instructionLessThanOrEqual,
                'instruction.equals': instructionEquals,
                'instruction.notEquals': instructionNotEquals,
                'instruction.specified': instructionSpecified,
                'instruction.in': instructionIn,
                'instruction.notIn': instructionNotIn,
                'source.greaterThan': sourceGreaterThan,
                'source.lessThan': sourceLessThan,
                'source.greaterThanOrEqual': sourceGreaterThanOrEqual,
                'source.lessThanOrEqual': sourceLessThanOrEqual,
                'source.equals': sourceEquals,
                'source.notEquals': sourceNotEquals,
                'source.specified': sourceSpecified,
                'source.in': sourceIn,
                'source.notIn': sourceNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'specialityIdId.greaterThan': specialityIdIdGreaterThan,
                'specialityIdId.lessThan': specialityIdIdLessThan,
                'specialityIdId.greaterThanOrEqual': specialityIdIdGreaterThanOrEqual,
                'specialityIdId.lessThanOrEqual': specialityIdIdLessThanOrEqual,
                'specialityIdId.equals': specialityIdIdEquals,
                'specialityIdId.notEquals': specialityIdIdNotEquals,
                'specialityIdId.specified': specialityIdIdSpecified,
                'specialityIdId.in': specialityIdIdIn,
                'specialityIdId.notIn': specialityIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
