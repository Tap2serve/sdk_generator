/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeAllergyDTO } from '../models/IntakeAllergyDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeAllergyResourceService {

    /**
     * @param id
     * @returns IntakeAllergyDTO OK
     * @throws ApiError
     */
    public static getIntakeAllergy(
        id: number,
    ): CancelablePromise<IntakeAllergyDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-allergies/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeAllergyDTO OK
     * @throws ApiError
     */
    public static updateIntakeAllergy(
        id: number,
        requestBody: IntakeAllergyDTO,
    ): CancelablePromise<IntakeAllergyDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-allergies/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeAllergy(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-allergies/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeAllergyDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeAllergy(
        id: number,
        requestBody: IntakeAllergyDTO,
    ): CancelablePromise<IntakeAllergyDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-allergies/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param criticalityContains
     * @param criticalityDoesNotContain
     * @param criticalityEquals
     * @param criticalityNotEquals
     * @param criticalitySpecified
     * @param criticalityIn
     * @param criticalityNotIn
     * @param reactionContains
     * @param reactionDoesNotContain
     * @param reactionEquals
     * @param reactionNotEquals
     * @param reactionSpecified
     * @param reactionIn
     * @param reactionNotIn
     * @param severityContains
     * @param severityDoesNotContain
     * @param severityEquals
     * @param severityNotEquals
     * @param severitySpecified
     * @param severityIn
     * @param severityNotIn
     * @param onSetDateGreaterThan
     * @param onSetDateLessThan
     * @param onSetDateGreaterThanOrEqual
     * @param onSetDateLessThanOrEqual
     * @param onSetDateEquals
     * @param onSetDateNotEquals
     * @param onSetDateSpecified
     * @param onSetDateIn
     * @param onSetDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param allergyIdIdGreaterThan
     * @param allergyIdIdLessThan
     * @param allergyIdIdGreaterThanOrEqual
     * @param allergyIdIdLessThanOrEqual
     * @param allergyIdIdEquals
     * @param allergyIdIdNotEquals
     * @param allergyIdIdSpecified
     * @param allergyIdIdIn
     * @param allergyIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeAllergyDTO OK
     * @throws ApiError
     */
    public static getAllIntakeAllergies(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        criticalityContains?: string,
        criticalityDoesNotContain?: string,
        criticalityEquals?: string,
        criticalityNotEquals?: string,
        criticalitySpecified?: boolean,
        criticalityIn?: Array<string>,
        criticalityNotIn?: Array<string>,
        reactionContains?: string,
        reactionDoesNotContain?: string,
        reactionEquals?: string,
        reactionNotEquals?: string,
        reactionSpecified?: boolean,
        reactionIn?: Array<string>,
        reactionNotIn?: Array<string>,
        severityContains?: string,
        severityDoesNotContain?: string,
        severityEquals?: string,
        severityNotEquals?: string,
        severitySpecified?: boolean,
        severityIn?: Array<string>,
        severityNotIn?: Array<string>,
        onSetDateGreaterThan?: string,
        onSetDateLessThan?: string,
        onSetDateGreaterThanOrEqual?: string,
        onSetDateLessThanOrEqual?: string,
        onSetDateEquals?: string,
        onSetDateNotEquals?: string,
        onSetDateSpecified?: boolean,
        onSetDateIn?: Array<string>,
        onSetDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        allergyIdIdGreaterThan?: number,
        allergyIdIdLessThan?: number,
        allergyIdIdGreaterThanOrEqual?: number,
        allergyIdIdLessThanOrEqual?: number,
        allergyIdIdEquals?: number,
        allergyIdIdNotEquals?: number,
        allergyIdIdSpecified?: boolean,
        allergyIdIdIn?: Array<number>,
        allergyIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeAllergyDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-allergies',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'criticality.contains': criticalityContains,
                'criticality.doesNotContain': criticalityDoesNotContain,
                'criticality.equals': criticalityEquals,
                'criticality.notEquals': criticalityNotEquals,
                'criticality.specified': criticalitySpecified,
                'criticality.in': criticalityIn,
                'criticality.notIn': criticalityNotIn,
                'reaction.contains': reactionContains,
                'reaction.doesNotContain': reactionDoesNotContain,
                'reaction.equals': reactionEquals,
                'reaction.notEquals': reactionNotEquals,
                'reaction.specified': reactionSpecified,
                'reaction.in': reactionIn,
                'reaction.notIn': reactionNotIn,
                'severity.contains': severityContains,
                'severity.doesNotContain': severityDoesNotContain,
                'severity.equals': severityEquals,
                'severity.notEquals': severityNotEquals,
                'severity.specified': severitySpecified,
                'severity.in': severityIn,
                'severity.notIn': severityNotIn,
                'onSetDate.greaterThan': onSetDateGreaterThan,
                'onSetDate.lessThan': onSetDateLessThan,
                'onSetDate.greaterThanOrEqual': onSetDateGreaterThanOrEqual,
                'onSetDate.lessThanOrEqual': onSetDateLessThanOrEqual,
                'onSetDate.equals': onSetDateEquals,
                'onSetDate.notEquals': onSetDateNotEquals,
                'onSetDate.specified': onSetDateSpecified,
                'onSetDate.in': onSetDateIn,
                'onSetDate.notIn': onSetDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'allergyIdId.greaterThan': allergyIdIdGreaterThan,
                'allergyIdId.lessThan': allergyIdIdLessThan,
                'allergyIdId.greaterThanOrEqual': allergyIdIdGreaterThanOrEqual,
                'allergyIdId.lessThanOrEqual': allergyIdIdLessThanOrEqual,
                'allergyIdId.equals': allergyIdIdEquals,
                'allergyIdId.notEquals': allergyIdIdNotEquals,
                'allergyIdId.specified': allergyIdIdSpecified,
                'allergyIdId.in': allergyIdIdIn,
                'allergyIdId.notIn': allergyIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeAllergyDTO OK
     * @throws ApiError
     */
    public static createIntakeAllergy(
        requestBody: IntakeAllergyDTO,
    ): CancelablePromise<IntakeAllergyDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-allergies',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param criticalityContains
     * @param criticalityDoesNotContain
     * @param criticalityEquals
     * @param criticalityNotEquals
     * @param criticalitySpecified
     * @param criticalityIn
     * @param criticalityNotIn
     * @param reactionContains
     * @param reactionDoesNotContain
     * @param reactionEquals
     * @param reactionNotEquals
     * @param reactionSpecified
     * @param reactionIn
     * @param reactionNotIn
     * @param severityContains
     * @param severityDoesNotContain
     * @param severityEquals
     * @param severityNotEquals
     * @param severitySpecified
     * @param severityIn
     * @param severityNotIn
     * @param onSetDateGreaterThan
     * @param onSetDateLessThan
     * @param onSetDateGreaterThanOrEqual
     * @param onSetDateLessThanOrEqual
     * @param onSetDateEquals
     * @param onSetDateNotEquals
     * @param onSetDateSpecified
     * @param onSetDateIn
     * @param onSetDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param allergyIdIdGreaterThan
     * @param allergyIdIdLessThan
     * @param allergyIdIdGreaterThanOrEqual
     * @param allergyIdIdLessThanOrEqual
     * @param allergyIdIdEquals
     * @param allergyIdIdNotEquals
     * @param allergyIdIdSpecified
     * @param allergyIdIdIn
     * @param allergyIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeAllergies(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        criticalityContains?: string,
        criticalityDoesNotContain?: string,
        criticalityEquals?: string,
        criticalityNotEquals?: string,
        criticalitySpecified?: boolean,
        criticalityIn?: Array<string>,
        criticalityNotIn?: Array<string>,
        reactionContains?: string,
        reactionDoesNotContain?: string,
        reactionEquals?: string,
        reactionNotEquals?: string,
        reactionSpecified?: boolean,
        reactionIn?: Array<string>,
        reactionNotIn?: Array<string>,
        severityContains?: string,
        severityDoesNotContain?: string,
        severityEquals?: string,
        severityNotEquals?: string,
        severitySpecified?: boolean,
        severityIn?: Array<string>,
        severityNotIn?: Array<string>,
        onSetDateGreaterThan?: string,
        onSetDateLessThan?: string,
        onSetDateGreaterThanOrEqual?: string,
        onSetDateLessThanOrEqual?: string,
        onSetDateEquals?: string,
        onSetDateNotEquals?: string,
        onSetDateSpecified?: boolean,
        onSetDateIn?: Array<string>,
        onSetDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        allergyIdIdGreaterThan?: number,
        allergyIdIdLessThan?: number,
        allergyIdIdGreaterThanOrEqual?: number,
        allergyIdIdLessThanOrEqual?: number,
        allergyIdIdEquals?: number,
        allergyIdIdNotEquals?: number,
        allergyIdIdSpecified?: boolean,
        allergyIdIdIn?: Array<number>,
        allergyIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-allergies/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'criticality.contains': criticalityContains,
                'criticality.doesNotContain': criticalityDoesNotContain,
                'criticality.equals': criticalityEquals,
                'criticality.notEquals': criticalityNotEquals,
                'criticality.specified': criticalitySpecified,
                'criticality.in': criticalityIn,
                'criticality.notIn': criticalityNotIn,
                'reaction.contains': reactionContains,
                'reaction.doesNotContain': reactionDoesNotContain,
                'reaction.equals': reactionEquals,
                'reaction.notEquals': reactionNotEquals,
                'reaction.specified': reactionSpecified,
                'reaction.in': reactionIn,
                'reaction.notIn': reactionNotIn,
                'severity.contains': severityContains,
                'severity.doesNotContain': severityDoesNotContain,
                'severity.equals': severityEquals,
                'severity.notEquals': severityNotEquals,
                'severity.specified': severitySpecified,
                'severity.in': severityIn,
                'severity.notIn': severityNotIn,
                'onSetDate.greaterThan': onSetDateGreaterThan,
                'onSetDate.lessThan': onSetDateLessThan,
                'onSetDate.greaterThanOrEqual': onSetDateGreaterThanOrEqual,
                'onSetDate.lessThanOrEqual': onSetDateLessThanOrEqual,
                'onSetDate.equals': onSetDateEquals,
                'onSetDate.notEquals': onSetDateNotEquals,
                'onSetDate.specified': onSetDateSpecified,
                'onSetDate.in': onSetDateIn,
                'onSetDate.notIn': onSetDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'allergyIdId.greaterThan': allergyIdIdGreaterThan,
                'allergyIdId.lessThan': allergyIdIdLessThan,
                'allergyIdId.greaterThanOrEqual': allergyIdIdGreaterThanOrEqual,
                'allergyIdId.lessThanOrEqual': allergyIdIdLessThanOrEqual,
                'allergyIdId.equals': allergyIdIdEquals,
                'allergyIdId.notEquals': allergyIdIdNotEquals,
                'allergyIdId.specified': allergyIdIdSpecified,
                'allergyIdId.in': allergyIdIdIn,
                'allergyIdId.notIn': allergyIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
