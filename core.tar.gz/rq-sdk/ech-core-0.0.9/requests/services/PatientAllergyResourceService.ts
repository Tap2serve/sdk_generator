/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PagePatientAllergyDTO } from '../models/PagePatientAllergyDTO';
import type { PatientAllergyDTO } from '../models/PatientAllergyDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientAllergyResourceService {

    /**
     * @param id
     * @returns PatientAllergyDTO OK
     * @throws ApiError
     */
    public static getPatientAllergy(
        id: number,
    ): CancelablePromise<PatientAllergyDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-allergies/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAllergyDTO OK
     * @throws ApiError
     */
    public static updatePatientAllergy(
        id: number,
        requestBody: PatientAllergyDTO,
    ): CancelablePromise<PatientAllergyDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-allergies/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAllergyDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientAllergy(
        id: number,
        requestBody: PatientAllergyDTO,
    ): CancelablePromise<PatientAllergyDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-allergies/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param criticalityContains
     * @param criticalityDoesNotContain
     * @param criticalityEquals
     * @param criticalityNotEquals
     * @param criticalitySpecified
     * @param criticalityIn
     * @param criticalityNotIn
     * @param reactionContains
     * @param reactionDoesNotContain
     * @param reactionEquals
     * @param reactionNotEquals
     * @param reactionSpecified
     * @param reactionIn
     * @param reactionNotIn
     * @param severityContains
     * @param severityDoesNotContain
     * @param severityEquals
     * @param severityNotEquals
     * @param severitySpecified
     * @param severityIn
     * @param severityNotIn
     * @param onSetDateGreaterThan
     * @param onSetDateLessThan
     * @param onSetDateGreaterThanOrEqual
     * @param onSetDateLessThanOrEqual
     * @param onSetDateEquals
     * @param onSetDateNotEquals
     * @param onSetDateSpecified
     * @param onSetDateIn
     * @param onSetDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeAllergyIdGreaterThan
     * @param intakeAllergyIdLessThan
     * @param intakeAllergyIdGreaterThanOrEqual
     * @param intakeAllergyIdLessThanOrEqual
     * @param intakeAllergyIdEquals
     * @param intakeAllergyIdNotEquals
     * @param intakeAllergyIdSpecified
     * @param intakeAllergyIdIn
     * @param intakeAllergyIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientAllergyDTO OK
     * @throws ApiError
     */
    public static getAllPatientAllergies1(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        criticalityContains?: string,
        criticalityDoesNotContain?: string,
        criticalityEquals?: string,
        criticalityNotEquals?: string,
        criticalitySpecified?: boolean,
        criticalityIn?: Array<string>,
        criticalityNotIn?: Array<string>,
        reactionContains?: string,
        reactionDoesNotContain?: string,
        reactionEquals?: string,
        reactionNotEquals?: string,
        reactionSpecified?: boolean,
        reactionIn?: Array<string>,
        reactionNotIn?: Array<string>,
        severityContains?: string,
        severityDoesNotContain?: string,
        severityEquals?: string,
        severityNotEquals?: string,
        severitySpecified?: boolean,
        severityIn?: Array<string>,
        severityNotIn?: Array<string>,
        onSetDateGreaterThan?: string,
        onSetDateLessThan?: string,
        onSetDateGreaterThanOrEqual?: string,
        onSetDateLessThanOrEqual?: string,
        onSetDateEquals?: string,
        onSetDateNotEquals?: string,
        onSetDateSpecified?: boolean,
        onSetDateIn?: Array<string>,
        onSetDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeAllergyIdGreaterThan?: number,
        intakeAllergyIdLessThan?: number,
        intakeAllergyIdGreaterThanOrEqual?: number,
        intakeAllergyIdLessThanOrEqual?: number,
        intakeAllergyIdEquals?: number,
        intakeAllergyIdNotEquals?: number,
        intakeAllergyIdSpecified?: boolean,
        intakeAllergyIdIn?: Array<number>,
        intakeAllergyIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientAllergyDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-allergies',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'criticality.contains': criticalityContains,
                'criticality.doesNotContain': criticalityDoesNotContain,
                'criticality.equals': criticalityEquals,
                'criticality.notEquals': criticalityNotEquals,
                'criticality.specified': criticalitySpecified,
                'criticality.in': criticalityIn,
                'criticality.notIn': criticalityNotIn,
                'reaction.contains': reactionContains,
                'reaction.doesNotContain': reactionDoesNotContain,
                'reaction.equals': reactionEquals,
                'reaction.notEquals': reactionNotEquals,
                'reaction.specified': reactionSpecified,
                'reaction.in': reactionIn,
                'reaction.notIn': reactionNotIn,
                'severity.contains': severityContains,
                'severity.doesNotContain': severityDoesNotContain,
                'severity.equals': severityEquals,
                'severity.notEquals': severityNotEquals,
                'severity.specified': severitySpecified,
                'severity.in': severityIn,
                'severity.notIn': severityNotIn,
                'onSetDate.greaterThan': onSetDateGreaterThan,
                'onSetDate.lessThan': onSetDateLessThan,
                'onSetDate.greaterThanOrEqual': onSetDateGreaterThanOrEqual,
                'onSetDate.lessThanOrEqual': onSetDateLessThanOrEqual,
                'onSetDate.equals': onSetDateEquals,
                'onSetDate.notEquals': onSetDateNotEquals,
                'onSetDate.specified': onSetDateSpecified,
                'onSetDate.in': onSetDateIn,
                'onSetDate.notIn': onSetDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeAllergyId.greaterThan': intakeAllergyIdGreaterThan,
                'intakeAllergyId.lessThan': intakeAllergyIdLessThan,
                'intakeAllergyId.greaterThanOrEqual': intakeAllergyIdGreaterThanOrEqual,
                'intakeAllergyId.lessThanOrEqual': intakeAllergyIdLessThanOrEqual,
                'intakeAllergyId.equals': intakeAllergyIdEquals,
                'intakeAllergyId.notEquals': intakeAllergyIdNotEquals,
                'intakeAllergyId.specified': intakeAllergyIdSpecified,
                'intakeAllergyId.in': intakeAllergyIdIn,
                'intakeAllergyId.notIn': intakeAllergyIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientAllergyDTO OK
     * @throws ApiError
     */
    public static createPatientAllergy(
        requestBody: PatientAllergyDTO,
    ): CancelablePromise<PatientAllergyDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-allergies',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param patientUuid
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PagePatientAllergyDTO OK
     * @throws ApiError
     */
    public static getAllPatientAllergies(
        patientUuid: string,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PagePatientAllergyDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient/{patientUuid}/allergies',
            path: {
                'patientUuid': patientUuid,
            },
            query: {
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param criticalityContains
     * @param criticalityDoesNotContain
     * @param criticalityEquals
     * @param criticalityNotEquals
     * @param criticalitySpecified
     * @param criticalityIn
     * @param criticalityNotIn
     * @param reactionContains
     * @param reactionDoesNotContain
     * @param reactionEquals
     * @param reactionNotEquals
     * @param reactionSpecified
     * @param reactionIn
     * @param reactionNotIn
     * @param severityContains
     * @param severityDoesNotContain
     * @param severityEquals
     * @param severityNotEquals
     * @param severitySpecified
     * @param severityIn
     * @param severityNotIn
     * @param onSetDateGreaterThan
     * @param onSetDateLessThan
     * @param onSetDateGreaterThanOrEqual
     * @param onSetDateLessThanOrEqual
     * @param onSetDateEquals
     * @param onSetDateNotEquals
     * @param onSetDateSpecified
     * @param onSetDateIn
     * @param onSetDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeAllergyIdGreaterThan
     * @param intakeAllergyIdLessThan
     * @param intakeAllergyIdGreaterThanOrEqual
     * @param intakeAllergyIdLessThanOrEqual
     * @param intakeAllergyIdEquals
     * @param intakeAllergyIdNotEquals
     * @param intakeAllergyIdSpecified
     * @param intakeAllergyIdIn
     * @param intakeAllergyIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientAllergies(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        criticalityContains?: string,
        criticalityDoesNotContain?: string,
        criticalityEquals?: string,
        criticalityNotEquals?: string,
        criticalitySpecified?: boolean,
        criticalityIn?: Array<string>,
        criticalityNotIn?: Array<string>,
        reactionContains?: string,
        reactionDoesNotContain?: string,
        reactionEquals?: string,
        reactionNotEquals?: string,
        reactionSpecified?: boolean,
        reactionIn?: Array<string>,
        reactionNotIn?: Array<string>,
        severityContains?: string,
        severityDoesNotContain?: string,
        severityEquals?: string,
        severityNotEquals?: string,
        severitySpecified?: boolean,
        severityIn?: Array<string>,
        severityNotIn?: Array<string>,
        onSetDateGreaterThan?: string,
        onSetDateLessThan?: string,
        onSetDateGreaterThanOrEqual?: string,
        onSetDateLessThanOrEqual?: string,
        onSetDateEquals?: string,
        onSetDateNotEquals?: string,
        onSetDateSpecified?: boolean,
        onSetDateIn?: Array<string>,
        onSetDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeAllergyIdGreaterThan?: number,
        intakeAllergyIdLessThan?: number,
        intakeAllergyIdGreaterThanOrEqual?: number,
        intakeAllergyIdLessThanOrEqual?: number,
        intakeAllergyIdEquals?: number,
        intakeAllergyIdNotEquals?: number,
        intakeAllergyIdSpecified?: boolean,
        intakeAllergyIdIn?: Array<number>,
        intakeAllergyIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-allergies/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'criticality.contains': criticalityContains,
                'criticality.doesNotContain': criticalityDoesNotContain,
                'criticality.equals': criticalityEquals,
                'criticality.notEquals': criticalityNotEquals,
                'criticality.specified': criticalitySpecified,
                'criticality.in': criticalityIn,
                'criticality.notIn': criticalityNotIn,
                'reaction.contains': reactionContains,
                'reaction.doesNotContain': reactionDoesNotContain,
                'reaction.equals': reactionEquals,
                'reaction.notEquals': reactionNotEquals,
                'reaction.specified': reactionSpecified,
                'reaction.in': reactionIn,
                'reaction.notIn': reactionNotIn,
                'severity.contains': severityContains,
                'severity.doesNotContain': severityDoesNotContain,
                'severity.equals': severityEquals,
                'severity.notEquals': severityNotEquals,
                'severity.specified': severitySpecified,
                'severity.in': severityIn,
                'severity.notIn': severityNotIn,
                'onSetDate.greaterThan': onSetDateGreaterThan,
                'onSetDate.lessThan': onSetDateLessThan,
                'onSetDate.greaterThanOrEqual': onSetDateGreaterThanOrEqual,
                'onSetDate.lessThanOrEqual': onSetDateLessThanOrEqual,
                'onSetDate.equals': onSetDateEquals,
                'onSetDate.notEquals': onSetDateNotEquals,
                'onSetDate.specified': onSetDateSpecified,
                'onSetDate.in': onSetDateIn,
                'onSetDate.notIn': onSetDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeAllergyId.greaterThan': intakeAllergyIdGreaterThan,
                'intakeAllergyId.lessThan': intakeAllergyIdLessThan,
                'intakeAllergyId.greaterThanOrEqual': intakeAllergyIdGreaterThanOrEqual,
                'intakeAllergyId.lessThanOrEqual': intakeAllergyIdLessThanOrEqual,
                'intakeAllergyId.equals': intakeAllergyIdEquals,
                'intakeAllergyId.notEquals': intakeAllergyIdNotEquals,
                'intakeAllergyId.specified': intakeAllergyIdSpecified,
                'intakeAllergyId.in': intakeAllergyIdIn,
                'intakeAllergyId.notIn': intakeAllergyIdNotIn,
                'distinct': distinct,
            },
        });
    }

    /**
     * @param patientAllergyUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientAllergy(
        patientAllergyUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-allergies/{patientAllergyUuid}',
            path: {
                'patientAllergyUuid': patientAllergyUuid,
            },
        });
    }

}
