/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientPermissionDTO } from '../models/PatientPermissionDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientPermissionResourceService {

    /**
     * @param id
     * @returns PatientPermissionDTO OK
     * @throws ApiError
     */
    public static getPatientPermission(
        id: number,
    ): CancelablePromise<PatientPermissionDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-permissions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientPermissionDTO OK
     * @throws ApiError
     */
    public static updatePatientPermission(
        id: number,
        requestBody: PatientPermissionDTO,
    ): CancelablePromise<PatientPermissionDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-permissions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientPermission(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-permissions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientPermissionDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientPermission(
        id: number,
        requestBody: PatientPermissionDTO,
    ): CancelablePromise<PatientPermissionDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-permissions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param patientPermissionKeyContains
     * @param patientPermissionKeyDoesNotContain
     * @param patientPermissionKeyEquals
     * @param patientPermissionKeyNotEquals
     * @param patientPermissionKeySpecified
     * @param patientPermissionKeyIn
     * @param patientPermissionKeyNotIn
     * @param statusContains
     * @param statusDoesNotContain
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientPermissionDTO OK
     * @throws ApiError
     */
    public static getAllPatientPermissions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        patientPermissionKeyContains?: string,
        patientPermissionKeyDoesNotContain?: string,
        patientPermissionKeyEquals?: string,
        patientPermissionKeyNotEquals?: string,
        patientPermissionKeySpecified?: boolean,
        patientPermissionKeyIn?: Array<string>,
        patientPermissionKeyNotIn?: Array<string>,
        statusContains?: string,
        statusDoesNotContain?: string,
        statusEquals?: string,
        statusNotEquals?: string,
        statusSpecified?: boolean,
        statusIn?: Array<string>,
        statusNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientPermissionDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-permissions',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'patientPermissionKey.contains': patientPermissionKeyContains,
                'patientPermissionKey.doesNotContain': patientPermissionKeyDoesNotContain,
                'patientPermissionKey.equals': patientPermissionKeyEquals,
                'patientPermissionKey.notEquals': patientPermissionKeyNotEquals,
                'patientPermissionKey.specified': patientPermissionKeySpecified,
                'patientPermissionKey.in': patientPermissionKeyIn,
                'patientPermissionKey.notIn': patientPermissionKeyNotIn,
                'status.contains': statusContains,
                'status.doesNotContain': statusDoesNotContain,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientPermissionDTO OK
     * @throws ApiError
     */
    public static createPatientPermission(
        requestBody: PatientPermissionDTO,
    ): CancelablePromise<PatientPermissionDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-permissions',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param patientPermissionKeyContains
     * @param patientPermissionKeyDoesNotContain
     * @param patientPermissionKeyEquals
     * @param patientPermissionKeyNotEquals
     * @param patientPermissionKeySpecified
     * @param patientPermissionKeyIn
     * @param patientPermissionKeyNotIn
     * @param statusContains
     * @param statusDoesNotContain
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientPermissions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        patientPermissionKeyContains?: string,
        patientPermissionKeyDoesNotContain?: string,
        patientPermissionKeyEquals?: string,
        patientPermissionKeyNotEquals?: string,
        patientPermissionKeySpecified?: boolean,
        patientPermissionKeyIn?: Array<string>,
        patientPermissionKeyNotIn?: Array<string>,
        statusContains?: string,
        statusDoesNotContain?: string,
        statusEquals?: string,
        statusNotEquals?: string,
        statusSpecified?: boolean,
        statusIn?: Array<string>,
        statusNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-permissions/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'patientPermissionKey.contains': patientPermissionKeyContains,
                'patientPermissionKey.doesNotContain': patientPermissionKeyDoesNotContain,
                'patientPermissionKey.equals': patientPermissionKeyEquals,
                'patientPermissionKey.notEquals': patientPermissionKeyNotEquals,
                'patientPermissionKey.specified': patientPermissionKeySpecified,
                'patientPermissionKey.in': patientPermissionKeyIn,
                'patientPermissionKey.notIn': patientPermissionKeyNotIn,
                'status.contains': statusContains,
                'status.doesNotContain': statusDoesNotContain,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
