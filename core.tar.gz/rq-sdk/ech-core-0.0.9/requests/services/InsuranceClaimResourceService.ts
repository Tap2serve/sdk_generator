/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InsuranceClaimDTO } from '../models/InsuranceClaimDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class InsuranceClaimResourceService {

    /**
     * @param id
     * @returns InsuranceClaimDTO OK
     * @throws ApiError
     */
    public static getInsuranceClaim(
        id: number,
    ): CancelablePromise<InsuranceClaimDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-claims/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsuranceClaimDTO OK
     * @throws ApiError
     */
    public static updateInsuranceClaim(
        id: number,
        requestBody: InsuranceClaimDTO,
    ): CancelablePromise<InsuranceClaimDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/insurance-claims/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteInsuranceClaim(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/insurance-claims/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsuranceClaimDTO OK
     * @throws ApiError
     */
    public static partialUpdateInsuranceClaim(
        id: number,
        requestBody: InsuranceClaimDTO,
    ): CancelablePromise<InsuranceClaimDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/insurance-claims/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param claimAmountGreaterThan
     * @param claimAmountLessThan
     * @param claimAmountGreaterThanOrEqual
     * @param claimAmountLessThanOrEqual
     * @param claimAmountEquals
     * @param claimAmountNotEquals
     * @param claimAmountSpecified
     * @param claimAmountIn
     * @param claimAmountNotIn
     * @param claimDateGreaterThan
     * @param claimDateLessThan
     * @param claimDateGreaterThanOrEqual
     * @param claimDateLessThanOrEqual
     * @param claimDateEquals
     * @param claimDateNotEquals
     * @param claimDateSpecified
     * @param claimDateIn
     * @param claimDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param claimStatusContains
     * @param claimStatusDoesNotContain
     * @param claimStatusEquals
     * @param claimStatusNotEquals
     * @param claimStatusSpecified
     * @param claimStatusIn
     * @param claimStatusNotIn
     * @param settledAmountGreaterThan
     * @param settledAmountLessThan
     * @param settledAmountGreaterThanOrEqual
     * @param settledAmountLessThanOrEqual
     * @param settledAmountEquals
     * @param settledAmountNotEquals
     * @param settledAmountSpecified
     * @param settledAmountIn
     * @param settledAmountNotIn
     * @param settledDateGreaterThan
     * @param settledDateLessThan
     * @param settledDateGreaterThanOrEqual
     * @param settledDateLessThanOrEqual
     * @param settledDateEquals
     * @param settledDateNotEquals
     * @param settledDateSpecified
     * @param settledDateIn
     * @param settledDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param billingProviderIdIdGreaterThan
     * @param billingProviderIdIdLessThan
     * @param billingProviderIdIdGreaterThanOrEqual
     * @param billingProviderIdIdLessThanOrEqual
     * @param billingProviderIdIdEquals
     * @param billingProviderIdIdNotEquals
     * @param billingProviderIdIdSpecified
     * @param billingProviderIdIdIn
     * @param billingProviderIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param superBillIdGreaterThan
     * @param superBillIdLessThan
     * @param superBillIdGreaterThanOrEqual
     * @param superBillIdLessThanOrEqual
     * @param superBillIdEquals
     * @param superBillIdNotEquals
     * @param superBillIdSpecified
     * @param superBillIdIn
     * @param superBillIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns InsuranceClaimDTO OK
     * @throws ApiError
     */
    public static getAllInsuranceClaims(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        claimAmountGreaterThan?: number,
        claimAmountLessThan?: number,
        claimAmountGreaterThanOrEqual?: number,
        claimAmountLessThanOrEqual?: number,
        claimAmountEquals?: number,
        claimAmountNotEquals?: number,
        claimAmountSpecified?: boolean,
        claimAmountIn?: Array<number>,
        claimAmountNotIn?: Array<number>,
        claimDateGreaterThan?: string,
        claimDateLessThan?: string,
        claimDateGreaterThanOrEqual?: string,
        claimDateLessThanOrEqual?: string,
        claimDateEquals?: string,
        claimDateNotEquals?: string,
        claimDateSpecified?: boolean,
        claimDateIn?: Array<string>,
        claimDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        claimStatusContains?: string,
        claimStatusDoesNotContain?: string,
        claimStatusEquals?: string,
        claimStatusNotEquals?: string,
        claimStatusSpecified?: boolean,
        claimStatusIn?: Array<string>,
        claimStatusNotIn?: Array<string>,
        settledAmountGreaterThan?: number,
        settledAmountLessThan?: number,
        settledAmountGreaterThanOrEqual?: number,
        settledAmountLessThanOrEqual?: number,
        settledAmountEquals?: number,
        settledAmountNotEquals?: number,
        settledAmountSpecified?: boolean,
        settledAmountIn?: Array<number>,
        settledAmountNotIn?: Array<number>,
        settledDateGreaterThan?: string,
        settledDateLessThan?: string,
        settledDateGreaterThanOrEqual?: string,
        settledDateLessThanOrEqual?: string,
        settledDateEquals?: string,
        settledDateNotEquals?: string,
        settledDateSpecified?: boolean,
        settledDateIn?: Array<string>,
        settledDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        billingProviderIdIdGreaterThan?: number,
        billingProviderIdIdLessThan?: number,
        billingProviderIdIdGreaterThanOrEqual?: number,
        billingProviderIdIdLessThanOrEqual?: number,
        billingProviderIdIdEquals?: number,
        billingProviderIdIdNotEquals?: number,
        billingProviderIdIdSpecified?: boolean,
        billingProviderIdIdIn?: Array<number>,
        billingProviderIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        superBillIdGreaterThan?: number,
        superBillIdLessThan?: number,
        superBillIdGreaterThanOrEqual?: number,
        superBillIdLessThanOrEqual?: number,
        superBillIdEquals?: number,
        superBillIdNotEquals?: number,
        superBillIdSpecified?: boolean,
        superBillIdIn?: Array<number>,
        superBillIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<InsuranceClaimDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-claims',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'claimAmount.greaterThan': claimAmountGreaterThan,
                'claimAmount.lessThan': claimAmountLessThan,
                'claimAmount.greaterThanOrEqual': claimAmountGreaterThanOrEqual,
                'claimAmount.lessThanOrEqual': claimAmountLessThanOrEqual,
                'claimAmount.equals': claimAmountEquals,
                'claimAmount.notEquals': claimAmountNotEquals,
                'claimAmount.specified': claimAmountSpecified,
                'claimAmount.in': claimAmountIn,
                'claimAmount.notIn': claimAmountNotIn,
                'claimDate.greaterThan': claimDateGreaterThan,
                'claimDate.lessThan': claimDateLessThan,
                'claimDate.greaterThanOrEqual': claimDateGreaterThanOrEqual,
                'claimDate.lessThanOrEqual': claimDateLessThanOrEqual,
                'claimDate.equals': claimDateEquals,
                'claimDate.notEquals': claimDateNotEquals,
                'claimDate.specified': claimDateSpecified,
                'claimDate.in': claimDateIn,
                'claimDate.notIn': claimDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'claimStatus.contains': claimStatusContains,
                'claimStatus.doesNotContain': claimStatusDoesNotContain,
                'claimStatus.equals': claimStatusEquals,
                'claimStatus.notEquals': claimStatusNotEquals,
                'claimStatus.specified': claimStatusSpecified,
                'claimStatus.in': claimStatusIn,
                'claimStatus.notIn': claimStatusNotIn,
                'settledAmount.greaterThan': settledAmountGreaterThan,
                'settledAmount.lessThan': settledAmountLessThan,
                'settledAmount.greaterThanOrEqual': settledAmountGreaterThanOrEqual,
                'settledAmount.lessThanOrEqual': settledAmountLessThanOrEqual,
                'settledAmount.equals': settledAmountEquals,
                'settledAmount.notEquals': settledAmountNotEquals,
                'settledAmount.specified': settledAmountSpecified,
                'settledAmount.in': settledAmountIn,
                'settledAmount.notIn': settledAmountNotIn,
                'settledDate.greaterThan': settledDateGreaterThan,
                'settledDate.lessThan': settledDateLessThan,
                'settledDate.greaterThanOrEqual': settledDateGreaterThanOrEqual,
                'settledDate.lessThanOrEqual': settledDateLessThanOrEqual,
                'settledDate.equals': settledDateEquals,
                'settledDate.notEquals': settledDateNotEquals,
                'settledDate.specified': settledDateSpecified,
                'settledDate.in': settledDateIn,
                'settledDate.notIn': settledDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'billingProviderIdId.greaterThan': billingProviderIdIdGreaterThan,
                'billingProviderIdId.lessThan': billingProviderIdIdLessThan,
                'billingProviderIdId.greaterThanOrEqual': billingProviderIdIdGreaterThanOrEqual,
                'billingProviderIdId.lessThanOrEqual': billingProviderIdIdLessThanOrEqual,
                'billingProviderIdId.equals': billingProviderIdIdEquals,
                'billingProviderIdId.notEquals': billingProviderIdIdNotEquals,
                'billingProviderIdId.specified': billingProviderIdIdSpecified,
                'billingProviderIdId.in': billingProviderIdIdIn,
                'billingProviderIdId.notIn': billingProviderIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'superBillId.greaterThan': superBillIdGreaterThan,
                'superBillId.lessThan': superBillIdLessThan,
                'superBillId.greaterThanOrEqual': superBillIdGreaterThanOrEqual,
                'superBillId.lessThanOrEqual': superBillIdLessThanOrEqual,
                'superBillId.equals': superBillIdEquals,
                'superBillId.notEquals': superBillIdNotEquals,
                'superBillId.specified': superBillIdSpecified,
                'superBillId.in': superBillIdIn,
                'superBillId.notIn': superBillIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns InsuranceClaimDTO OK
     * @throws ApiError
     */
    public static createInsuranceClaim(
        requestBody: InsuranceClaimDTO,
    ): CancelablePromise<InsuranceClaimDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/insurance-claims',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param claimAmountGreaterThan
     * @param claimAmountLessThan
     * @param claimAmountGreaterThanOrEqual
     * @param claimAmountLessThanOrEqual
     * @param claimAmountEquals
     * @param claimAmountNotEquals
     * @param claimAmountSpecified
     * @param claimAmountIn
     * @param claimAmountNotIn
     * @param claimDateGreaterThan
     * @param claimDateLessThan
     * @param claimDateGreaterThanOrEqual
     * @param claimDateLessThanOrEqual
     * @param claimDateEquals
     * @param claimDateNotEquals
     * @param claimDateSpecified
     * @param claimDateIn
     * @param claimDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param claimStatusContains
     * @param claimStatusDoesNotContain
     * @param claimStatusEquals
     * @param claimStatusNotEquals
     * @param claimStatusSpecified
     * @param claimStatusIn
     * @param claimStatusNotIn
     * @param settledAmountGreaterThan
     * @param settledAmountLessThan
     * @param settledAmountGreaterThanOrEqual
     * @param settledAmountLessThanOrEqual
     * @param settledAmountEquals
     * @param settledAmountNotEquals
     * @param settledAmountSpecified
     * @param settledAmountIn
     * @param settledAmountNotIn
     * @param settledDateGreaterThan
     * @param settledDateLessThan
     * @param settledDateGreaterThanOrEqual
     * @param settledDateLessThanOrEqual
     * @param settledDateEquals
     * @param settledDateNotEquals
     * @param settledDateSpecified
     * @param settledDateIn
     * @param settledDateNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param billingProviderIdIdGreaterThan
     * @param billingProviderIdIdLessThan
     * @param billingProviderIdIdGreaterThanOrEqual
     * @param billingProviderIdIdLessThanOrEqual
     * @param billingProviderIdIdEquals
     * @param billingProviderIdIdNotEquals
     * @param billingProviderIdIdSpecified
     * @param billingProviderIdIdIn
     * @param billingProviderIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param superBillIdGreaterThan
     * @param superBillIdLessThan
     * @param superBillIdGreaterThanOrEqual
     * @param superBillIdLessThanOrEqual
     * @param superBillIdEquals
     * @param superBillIdNotEquals
     * @param superBillIdSpecified
     * @param superBillIdIn
     * @param superBillIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countInsuranceClaims(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        claimAmountGreaterThan?: number,
        claimAmountLessThan?: number,
        claimAmountGreaterThanOrEqual?: number,
        claimAmountLessThanOrEqual?: number,
        claimAmountEquals?: number,
        claimAmountNotEquals?: number,
        claimAmountSpecified?: boolean,
        claimAmountIn?: Array<number>,
        claimAmountNotIn?: Array<number>,
        claimDateGreaterThan?: string,
        claimDateLessThan?: string,
        claimDateGreaterThanOrEqual?: string,
        claimDateLessThanOrEqual?: string,
        claimDateEquals?: string,
        claimDateNotEquals?: string,
        claimDateSpecified?: boolean,
        claimDateIn?: Array<string>,
        claimDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        claimStatusContains?: string,
        claimStatusDoesNotContain?: string,
        claimStatusEquals?: string,
        claimStatusNotEquals?: string,
        claimStatusSpecified?: boolean,
        claimStatusIn?: Array<string>,
        claimStatusNotIn?: Array<string>,
        settledAmountGreaterThan?: number,
        settledAmountLessThan?: number,
        settledAmountGreaterThanOrEqual?: number,
        settledAmountLessThanOrEqual?: number,
        settledAmountEquals?: number,
        settledAmountNotEquals?: number,
        settledAmountSpecified?: boolean,
        settledAmountIn?: Array<number>,
        settledAmountNotIn?: Array<number>,
        settledDateGreaterThan?: string,
        settledDateLessThan?: string,
        settledDateGreaterThanOrEqual?: string,
        settledDateLessThanOrEqual?: string,
        settledDateEquals?: string,
        settledDateNotEquals?: string,
        settledDateSpecified?: boolean,
        settledDateIn?: Array<string>,
        settledDateNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        billingProviderIdIdGreaterThan?: number,
        billingProviderIdIdLessThan?: number,
        billingProviderIdIdGreaterThanOrEqual?: number,
        billingProviderIdIdLessThanOrEqual?: number,
        billingProviderIdIdEquals?: number,
        billingProviderIdIdNotEquals?: number,
        billingProviderIdIdSpecified?: boolean,
        billingProviderIdIdIn?: Array<number>,
        billingProviderIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        superBillIdGreaterThan?: number,
        superBillIdLessThan?: number,
        superBillIdGreaterThanOrEqual?: number,
        superBillIdLessThanOrEqual?: number,
        superBillIdEquals?: number,
        superBillIdNotEquals?: number,
        superBillIdSpecified?: boolean,
        superBillIdIn?: Array<number>,
        superBillIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-claims/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'claimAmount.greaterThan': claimAmountGreaterThan,
                'claimAmount.lessThan': claimAmountLessThan,
                'claimAmount.greaterThanOrEqual': claimAmountGreaterThanOrEqual,
                'claimAmount.lessThanOrEqual': claimAmountLessThanOrEqual,
                'claimAmount.equals': claimAmountEquals,
                'claimAmount.notEquals': claimAmountNotEquals,
                'claimAmount.specified': claimAmountSpecified,
                'claimAmount.in': claimAmountIn,
                'claimAmount.notIn': claimAmountNotIn,
                'claimDate.greaterThan': claimDateGreaterThan,
                'claimDate.lessThan': claimDateLessThan,
                'claimDate.greaterThanOrEqual': claimDateGreaterThanOrEqual,
                'claimDate.lessThanOrEqual': claimDateLessThanOrEqual,
                'claimDate.equals': claimDateEquals,
                'claimDate.notEquals': claimDateNotEquals,
                'claimDate.specified': claimDateSpecified,
                'claimDate.in': claimDateIn,
                'claimDate.notIn': claimDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'claimStatus.contains': claimStatusContains,
                'claimStatus.doesNotContain': claimStatusDoesNotContain,
                'claimStatus.equals': claimStatusEquals,
                'claimStatus.notEquals': claimStatusNotEquals,
                'claimStatus.specified': claimStatusSpecified,
                'claimStatus.in': claimStatusIn,
                'claimStatus.notIn': claimStatusNotIn,
                'settledAmount.greaterThan': settledAmountGreaterThan,
                'settledAmount.lessThan': settledAmountLessThan,
                'settledAmount.greaterThanOrEqual': settledAmountGreaterThanOrEqual,
                'settledAmount.lessThanOrEqual': settledAmountLessThanOrEqual,
                'settledAmount.equals': settledAmountEquals,
                'settledAmount.notEquals': settledAmountNotEquals,
                'settledAmount.specified': settledAmountSpecified,
                'settledAmount.in': settledAmountIn,
                'settledAmount.notIn': settledAmountNotIn,
                'settledDate.greaterThan': settledDateGreaterThan,
                'settledDate.lessThan': settledDateLessThan,
                'settledDate.greaterThanOrEqual': settledDateGreaterThanOrEqual,
                'settledDate.lessThanOrEqual': settledDateLessThanOrEqual,
                'settledDate.equals': settledDateEquals,
                'settledDate.notEquals': settledDateNotEquals,
                'settledDate.specified': settledDateSpecified,
                'settledDate.in': settledDateIn,
                'settledDate.notIn': settledDateNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'billingProviderIdId.greaterThan': billingProviderIdIdGreaterThan,
                'billingProviderIdId.lessThan': billingProviderIdIdLessThan,
                'billingProviderIdId.greaterThanOrEqual': billingProviderIdIdGreaterThanOrEqual,
                'billingProviderIdId.lessThanOrEqual': billingProviderIdIdLessThanOrEqual,
                'billingProviderIdId.equals': billingProviderIdIdEquals,
                'billingProviderIdId.notEquals': billingProviderIdIdNotEquals,
                'billingProviderIdId.specified': billingProviderIdIdSpecified,
                'billingProviderIdId.in': billingProviderIdIdIn,
                'billingProviderIdId.notIn': billingProviderIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'superBillId.greaterThan': superBillIdGreaterThan,
                'superBillId.lessThan': superBillIdLessThan,
                'superBillId.greaterThanOrEqual': superBillIdGreaterThanOrEqual,
                'superBillId.lessThanOrEqual': superBillIdLessThanOrEqual,
                'superBillId.equals': superBillIdEquals,
                'superBillId.notEquals': superBillIdNotEquals,
                'superBillId.specified': superBillIdSpecified,
                'superBillId.in': superBillIdIn,
                'superBillId.notIn': superBillIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
