/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { LocationDTO } from '../models/LocationDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class LocationResourceService {

    /**
     * @param locationUuid
     * @param status
     * @returns any OK
     * @throws ApiError
     */
    public static updateLocationStatus(
        locationUuid: string,
        status: boolean,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/locations/{locationUuid}/{status}',
            path: {
                'locationUuid': locationUuid,
                'status': status,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns LocationDTO OK
     * @throws ApiError
     */
    public static updateLocation(
        id: number,
        requestBody: LocationDTO,
    ): CancelablePromise<LocationDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/locations/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns LocationDTO OK
     * @throws ApiError
     */
    public static partialUpdateLocation(
        id: number,
        requestBody: LocationDTO,
    ): CancelablePromise<LocationDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/locations/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param locationIdContains
     * @param locationIdDoesNotContain
     * @param locationIdEquals
     * @param locationIdNotEquals
     * @param locationIdSpecified
     * @param locationIdIn
     * @param locationIdNotIn
     * @param contactContains
     * @param contactDoesNotContain
     * @param contactEquals
     * @param contactNotEquals
     * @param contactSpecified
     * @param contactIn
     * @param contactNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param avatarContains
     * @param avatarDoesNotContain
     * @param avatarEquals
     * @param avatarNotEquals
     * @param avatarSpecified
     * @param avatarIn
     * @param avatarNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param timeZoneContains
     * @param timeZoneDoesNotContain
     * @param timeZoneEquals
     * @param timeZoneNotEquals
     * @param timeZoneSpecified
     * @param timeZoneIn
     * @param timeZoneNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param physicalAddressIdIdGreaterThan
     * @param physicalAddressIdIdLessThan
     * @param physicalAddressIdIdGreaterThanOrEqual
     * @param physicalAddressIdIdLessThanOrEqual
     * @param physicalAddressIdIdEquals
     * @param physicalAddressIdIdNotEquals
     * @param physicalAddressIdIdSpecified
     * @param physicalAddressIdIdIn
     * @param physicalAddressIdIdNotIn
     * @param billingAddressIdIdGreaterThan
     * @param billingAddressIdIdLessThan
     * @param billingAddressIdIdGreaterThanOrEqual
     * @param billingAddressIdIdLessThanOrEqual
     * @param billingAddressIdIdEquals
     * @param billingAddressIdIdNotEquals
     * @param billingAddressIdIdSpecified
     * @param billingAddressIdIdIn
     * @param billingAddressIdIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param workingHoursIdGreaterThan
     * @param workingHoursIdLessThan
     * @param workingHoursIdGreaterThanOrEqual
     * @param workingHoursIdLessThanOrEqual
     * @param workingHoursIdEquals
     * @param workingHoursIdNotEquals
     * @param workingHoursIdSpecified
     * @param workingHoursIdIn
     * @param workingHoursIdNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param availabilityIdGreaterThan
     * @param availabilityIdLessThan
     * @param availabilityIdGreaterThanOrEqual
     * @param availabilityIdLessThanOrEqual
     * @param availabilityIdEquals
     * @param availabilityIdNotEquals
     * @param availabilityIdSpecified
     * @param availabilityIdIn
     * @param availabilityIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns LocationDTO OK
     * @throws ApiError
     */
    public static getAllLocations(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        locationIdContains?: string,
        locationIdDoesNotContain?: string,
        locationIdEquals?: string,
        locationIdNotEquals?: string,
        locationIdSpecified?: boolean,
        locationIdIn?: Array<string>,
        locationIdNotIn?: Array<string>,
        contactContains?: string,
        contactDoesNotContain?: string,
        contactEquals?: string,
        contactNotEquals?: string,
        contactSpecified?: boolean,
        contactIn?: Array<string>,
        contactNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        avatarContains?: string,
        avatarDoesNotContain?: string,
        avatarEquals?: string,
        avatarNotEquals?: string,
        avatarSpecified?: boolean,
        avatarIn?: Array<string>,
        avatarNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        timeZoneContains?: string,
        timeZoneDoesNotContain?: string,
        timeZoneEquals?: string,
        timeZoneNotEquals?: string,
        timeZoneSpecified?: boolean,
        timeZoneIn?: Array<string>,
        timeZoneNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        physicalAddressIdIdGreaterThan?: number,
        physicalAddressIdIdLessThan?: number,
        physicalAddressIdIdGreaterThanOrEqual?: number,
        physicalAddressIdIdLessThanOrEqual?: number,
        physicalAddressIdIdEquals?: number,
        physicalAddressIdIdNotEquals?: number,
        physicalAddressIdIdSpecified?: boolean,
        physicalAddressIdIdIn?: Array<number>,
        physicalAddressIdIdNotIn?: Array<number>,
        billingAddressIdIdGreaterThan?: number,
        billingAddressIdIdLessThan?: number,
        billingAddressIdIdGreaterThanOrEqual?: number,
        billingAddressIdIdLessThanOrEqual?: number,
        billingAddressIdIdEquals?: number,
        billingAddressIdIdNotEquals?: number,
        billingAddressIdIdSpecified?: boolean,
        billingAddressIdIdIn?: Array<number>,
        billingAddressIdIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        workingHoursIdGreaterThan?: number,
        workingHoursIdLessThan?: number,
        workingHoursIdGreaterThanOrEqual?: number,
        workingHoursIdLessThanOrEqual?: number,
        workingHoursIdEquals?: number,
        workingHoursIdNotEquals?: number,
        workingHoursIdSpecified?: boolean,
        workingHoursIdIn?: Array<number>,
        workingHoursIdNotIn?: Array<number>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        availabilityIdGreaterThan?: number,
        availabilityIdLessThan?: number,
        availabilityIdGreaterThanOrEqual?: number,
        availabilityIdLessThanOrEqual?: number,
        availabilityIdEquals?: number,
        availabilityIdNotEquals?: number,
        availabilityIdSpecified?: boolean,
        availabilityIdIn?: Array<number>,
        availabilityIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<LocationDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/locations',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'locationId.contains': locationIdContains,
                'locationId.doesNotContain': locationIdDoesNotContain,
                'locationId.equals': locationIdEquals,
                'locationId.notEquals': locationIdNotEquals,
                'locationId.specified': locationIdSpecified,
                'locationId.in': locationIdIn,
                'locationId.notIn': locationIdNotIn,
                'contact.contains': contactContains,
                'contact.doesNotContain': contactDoesNotContain,
                'contact.equals': contactEquals,
                'contact.notEquals': contactNotEquals,
                'contact.specified': contactSpecified,
                'contact.in': contactIn,
                'contact.notIn': contactNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'avatar.contains': avatarContains,
                'avatar.doesNotContain': avatarDoesNotContain,
                'avatar.equals': avatarEquals,
                'avatar.notEquals': avatarNotEquals,
                'avatar.specified': avatarSpecified,
                'avatar.in': avatarIn,
                'avatar.notIn': avatarNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'timeZone.contains': timeZoneContains,
                'timeZone.doesNotContain': timeZoneDoesNotContain,
                'timeZone.equals': timeZoneEquals,
                'timeZone.notEquals': timeZoneNotEquals,
                'timeZone.specified': timeZoneSpecified,
                'timeZone.in': timeZoneIn,
                'timeZone.notIn': timeZoneNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'physicalAddressIdId.greaterThan': physicalAddressIdIdGreaterThan,
                'physicalAddressIdId.lessThan': physicalAddressIdIdLessThan,
                'physicalAddressIdId.greaterThanOrEqual': physicalAddressIdIdGreaterThanOrEqual,
                'physicalAddressIdId.lessThanOrEqual': physicalAddressIdIdLessThanOrEqual,
                'physicalAddressIdId.equals': physicalAddressIdIdEquals,
                'physicalAddressIdId.notEquals': physicalAddressIdIdNotEquals,
                'physicalAddressIdId.specified': physicalAddressIdIdSpecified,
                'physicalAddressIdId.in': physicalAddressIdIdIn,
                'physicalAddressIdId.notIn': physicalAddressIdIdNotIn,
                'billingAddressIdId.greaterThan': billingAddressIdIdGreaterThan,
                'billingAddressIdId.lessThan': billingAddressIdIdLessThan,
                'billingAddressIdId.greaterThanOrEqual': billingAddressIdIdGreaterThanOrEqual,
                'billingAddressIdId.lessThanOrEqual': billingAddressIdIdLessThanOrEqual,
                'billingAddressIdId.equals': billingAddressIdIdEquals,
                'billingAddressIdId.notEquals': billingAddressIdIdNotEquals,
                'billingAddressIdId.specified': billingAddressIdIdSpecified,
                'billingAddressIdId.in': billingAddressIdIdIn,
                'billingAddressIdId.notIn': billingAddressIdIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'workingHoursId.greaterThan': workingHoursIdGreaterThan,
                'workingHoursId.lessThan': workingHoursIdLessThan,
                'workingHoursId.greaterThanOrEqual': workingHoursIdGreaterThanOrEqual,
                'workingHoursId.lessThanOrEqual': workingHoursIdLessThanOrEqual,
                'workingHoursId.equals': workingHoursIdEquals,
                'workingHoursId.notEquals': workingHoursIdNotEquals,
                'workingHoursId.specified': workingHoursIdSpecified,
                'workingHoursId.in': workingHoursIdIn,
                'workingHoursId.notIn': workingHoursIdNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'availabilityId.greaterThan': availabilityIdGreaterThan,
                'availabilityId.lessThan': availabilityIdLessThan,
                'availabilityId.greaterThanOrEqual': availabilityIdGreaterThanOrEqual,
                'availabilityId.lessThanOrEqual': availabilityIdLessThanOrEqual,
                'availabilityId.equals': availabilityIdEquals,
                'availabilityId.notEquals': availabilityIdNotEquals,
                'availabilityId.specified': availabilityIdSpecified,
                'availabilityId.in': availabilityIdIn,
                'availabilityId.notIn': availabilityIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns LocationDTO OK
     * @throws ApiError
     */
    public static createLocation(
        requestBody: LocationDTO,
    ): CancelablePromise<LocationDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/locations',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param locationUuid
     * @returns LocationDTO OK
     * @throws ApiError
     */
    public static getLocation(
        locationUuid: string,
    ): CancelablePromise<LocationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/locations/{locationUuid}',
            path: {
                'locationUuid': locationUuid,
            },
        });
    }

    /**
     * @param locationUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deleteLocation(
        locationUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/locations/{locationUuid}',
            path: {
                'locationUuid': locationUuid,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param locationIdContains
     * @param locationIdDoesNotContain
     * @param locationIdEquals
     * @param locationIdNotEquals
     * @param locationIdSpecified
     * @param locationIdIn
     * @param locationIdNotIn
     * @param contactContains
     * @param contactDoesNotContain
     * @param contactEquals
     * @param contactNotEquals
     * @param contactSpecified
     * @param contactIn
     * @param contactNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param avatarContains
     * @param avatarDoesNotContain
     * @param avatarEquals
     * @param avatarNotEquals
     * @param avatarSpecified
     * @param avatarIn
     * @param avatarNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param timeZoneContains
     * @param timeZoneDoesNotContain
     * @param timeZoneEquals
     * @param timeZoneNotEquals
     * @param timeZoneSpecified
     * @param timeZoneIn
     * @param timeZoneNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param physicalAddressIdIdGreaterThan
     * @param physicalAddressIdIdLessThan
     * @param physicalAddressIdIdGreaterThanOrEqual
     * @param physicalAddressIdIdLessThanOrEqual
     * @param physicalAddressIdIdEquals
     * @param physicalAddressIdIdNotEquals
     * @param physicalAddressIdIdSpecified
     * @param physicalAddressIdIdIn
     * @param physicalAddressIdIdNotIn
     * @param billingAddressIdIdGreaterThan
     * @param billingAddressIdIdLessThan
     * @param billingAddressIdIdGreaterThanOrEqual
     * @param billingAddressIdIdLessThanOrEqual
     * @param billingAddressIdIdEquals
     * @param billingAddressIdIdNotEquals
     * @param billingAddressIdIdSpecified
     * @param billingAddressIdIdIn
     * @param billingAddressIdIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param workingHoursIdGreaterThan
     * @param workingHoursIdLessThan
     * @param workingHoursIdGreaterThanOrEqual
     * @param workingHoursIdLessThanOrEqual
     * @param workingHoursIdEquals
     * @param workingHoursIdNotEquals
     * @param workingHoursIdSpecified
     * @param workingHoursIdIn
     * @param workingHoursIdNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param availabilityIdGreaterThan
     * @param availabilityIdLessThan
     * @param availabilityIdGreaterThanOrEqual
     * @param availabilityIdLessThanOrEqual
     * @param availabilityIdEquals
     * @param availabilityIdNotEquals
     * @param availabilityIdSpecified
     * @param availabilityIdIn
     * @param availabilityIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countLocations(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        locationIdContains?: string,
        locationIdDoesNotContain?: string,
        locationIdEquals?: string,
        locationIdNotEquals?: string,
        locationIdSpecified?: boolean,
        locationIdIn?: Array<string>,
        locationIdNotIn?: Array<string>,
        contactContains?: string,
        contactDoesNotContain?: string,
        contactEquals?: string,
        contactNotEquals?: string,
        contactSpecified?: boolean,
        contactIn?: Array<string>,
        contactNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        avatarContains?: string,
        avatarDoesNotContain?: string,
        avatarEquals?: string,
        avatarNotEquals?: string,
        avatarSpecified?: boolean,
        avatarIn?: Array<string>,
        avatarNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        timeZoneContains?: string,
        timeZoneDoesNotContain?: string,
        timeZoneEquals?: string,
        timeZoneNotEquals?: string,
        timeZoneSpecified?: boolean,
        timeZoneIn?: Array<string>,
        timeZoneNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        physicalAddressIdIdGreaterThan?: number,
        physicalAddressIdIdLessThan?: number,
        physicalAddressIdIdGreaterThanOrEqual?: number,
        physicalAddressIdIdLessThanOrEqual?: number,
        physicalAddressIdIdEquals?: number,
        physicalAddressIdIdNotEquals?: number,
        physicalAddressIdIdSpecified?: boolean,
        physicalAddressIdIdIn?: Array<number>,
        physicalAddressIdIdNotIn?: Array<number>,
        billingAddressIdIdGreaterThan?: number,
        billingAddressIdIdLessThan?: number,
        billingAddressIdIdGreaterThanOrEqual?: number,
        billingAddressIdIdLessThanOrEqual?: number,
        billingAddressIdIdEquals?: number,
        billingAddressIdIdNotEquals?: number,
        billingAddressIdIdSpecified?: boolean,
        billingAddressIdIdIn?: Array<number>,
        billingAddressIdIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        workingHoursIdGreaterThan?: number,
        workingHoursIdLessThan?: number,
        workingHoursIdGreaterThanOrEqual?: number,
        workingHoursIdLessThanOrEqual?: number,
        workingHoursIdEquals?: number,
        workingHoursIdNotEquals?: number,
        workingHoursIdSpecified?: boolean,
        workingHoursIdIn?: Array<number>,
        workingHoursIdNotIn?: Array<number>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        availabilityIdGreaterThan?: number,
        availabilityIdLessThan?: number,
        availabilityIdGreaterThanOrEqual?: number,
        availabilityIdLessThanOrEqual?: number,
        availabilityIdEquals?: number,
        availabilityIdNotEquals?: number,
        availabilityIdSpecified?: boolean,
        availabilityIdIn?: Array<number>,
        availabilityIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/locations/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'locationId.contains': locationIdContains,
                'locationId.doesNotContain': locationIdDoesNotContain,
                'locationId.equals': locationIdEquals,
                'locationId.notEquals': locationIdNotEquals,
                'locationId.specified': locationIdSpecified,
                'locationId.in': locationIdIn,
                'locationId.notIn': locationIdNotIn,
                'contact.contains': contactContains,
                'contact.doesNotContain': contactDoesNotContain,
                'contact.equals': contactEquals,
                'contact.notEquals': contactNotEquals,
                'contact.specified': contactSpecified,
                'contact.in': contactIn,
                'contact.notIn': contactNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'avatar.contains': avatarContains,
                'avatar.doesNotContain': avatarDoesNotContain,
                'avatar.equals': avatarEquals,
                'avatar.notEquals': avatarNotEquals,
                'avatar.specified': avatarSpecified,
                'avatar.in': avatarIn,
                'avatar.notIn': avatarNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'timeZone.contains': timeZoneContains,
                'timeZone.doesNotContain': timeZoneDoesNotContain,
                'timeZone.equals': timeZoneEquals,
                'timeZone.notEquals': timeZoneNotEquals,
                'timeZone.specified': timeZoneSpecified,
                'timeZone.in': timeZoneIn,
                'timeZone.notIn': timeZoneNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'physicalAddressIdId.greaterThan': physicalAddressIdIdGreaterThan,
                'physicalAddressIdId.lessThan': physicalAddressIdIdLessThan,
                'physicalAddressIdId.greaterThanOrEqual': physicalAddressIdIdGreaterThanOrEqual,
                'physicalAddressIdId.lessThanOrEqual': physicalAddressIdIdLessThanOrEqual,
                'physicalAddressIdId.equals': physicalAddressIdIdEquals,
                'physicalAddressIdId.notEquals': physicalAddressIdIdNotEquals,
                'physicalAddressIdId.specified': physicalAddressIdIdSpecified,
                'physicalAddressIdId.in': physicalAddressIdIdIn,
                'physicalAddressIdId.notIn': physicalAddressIdIdNotIn,
                'billingAddressIdId.greaterThan': billingAddressIdIdGreaterThan,
                'billingAddressIdId.lessThan': billingAddressIdIdLessThan,
                'billingAddressIdId.greaterThanOrEqual': billingAddressIdIdGreaterThanOrEqual,
                'billingAddressIdId.lessThanOrEqual': billingAddressIdIdLessThanOrEqual,
                'billingAddressIdId.equals': billingAddressIdIdEquals,
                'billingAddressIdId.notEquals': billingAddressIdIdNotEquals,
                'billingAddressIdId.specified': billingAddressIdIdSpecified,
                'billingAddressIdId.in': billingAddressIdIdIn,
                'billingAddressIdId.notIn': billingAddressIdIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'workingHoursId.greaterThan': workingHoursIdGreaterThan,
                'workingHoursId.lessThan': workingHoursIdLessThan,
                'workingHoursId.greaterThanOrEqual': workingHoursIdGreaterThanOrEqual,
                'workingHoursId.lessThanOrEqual': workingHoursIdLessThanOrEqual,
                'workingHoursId.equals': workingHoursIdEquals,
                'workingHoursId.notEquals': workingHoursIdNotEquals,
                'workingHoursId.specified': workingHoursIdSpecified,
                'workingHoursId.in': workingHoursIdIn,
                'workingHoursId.notIn': workingHoursIdNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'availabilityId.greaterThan': availabilityIdGreaterThan,
                'availabilityId.lessThan': availabilityIdLessThan,
                'availabilityId.greaterThanOrEqual': availabilityIdGreaterThanOrEqual,
                'availabilityId.lessThanOrEqual': availabilityIdLessThanOrEqual,
                'availabilityId.equals': availabilityIdEquals,
                'availabilityId.notEquals': availabilityIdNotEquals,
                'availabilityId.specified': availabilityIdSpecified,
                'availabilityId.in': availabilityIdIn,
                'availabilityId.notIn': availabilityIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
