/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AppointmentDTO } from '../models/AppointmentDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class AppointmentResourceService {

    /**
     * @param uuid
     * @returns AppointmentDTO OK
     * @throws ApiError
     */
    public static getAppointment(
        uuid: string,
    ): CancelablePromise<AppointmentDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/appointments/{uuid}',
            path: {
                'uuid': uuid,
            },
        });
    }

    /**
     * @param uuid
     * @param requestBody
     * @returns AppointmentDTO OK
     * @throws ApiError
     */
    public static updateAppointment(
        uuid: string,
        requestBody: AppointmentDTO,
    ): CancelablePromise<AppointmentDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/appointments/{uuid}',
            path: {
                'uuid': uuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param uuid
     * @returns any OK
     * @throws ApiError
     */
    public static deleteAppointment(
        uuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/appointments/{uuid}',
            path: {
                'uuid': uuid,
            },
        });
    }

    /**
     * @param uuid
     * @param requestBody
     * @returns AppointmentDTO OK
     * @throws ApiError
     */
    public static partialUpdateAppointment(
        uuid: string,
        requestBody: AppointmentDTO,
    ): CancelablePromise<AppointmentDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/appointments/{uuid}',
            path: {
                'uuid': uuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param startTimeGreaterThan
     * @param startTimeLessThan
     * @param startTimeGreaterThanOrEqual
     * @param startTimeLessThanOrEqual
     * @param startTimeEquals
     * @param startTimeNotEquals
     * @param startTimeSpecified
     * @param startTimeIn
     * @param startTimeNotIn
     * @param endTimeGreaterThan
     * @param endTimeLessThan
     * @param endTimeGreaterThanOrEqual
     * @param endTimeLessThanOrEqual
     * @param endTimeEquals
     * @param endTimeNotEquals
     * @param endTimeSpecified
     * @param endTimeIn
     * @param endTimeNotIn
     * @param modeEquals
     * @param modeNotEquals
     * @param modeSpecified
     * @param modeIn
     * @param modeNotIn
     * @param roomContains
     * @param roomDoesNotContain
     * @param roomEquals
     * @param roomNotEquals
     * @param roomSpecified
     * @param roomIn
     * @param roomNotIn
     * @param paymentTypeEquals
     * @param paymentTypeNotEquals
     * @param paymentTypeSpecified
     * @param paymentTypeIn
     * @param paymentTypeNotIn
     * @param reasonContains
     * @param reasonDoesNotContain
     * @param reasonEquals
     * @param reasonNotEquals
     * @param reasonSpecified
     * @param reasonIn
     * @param reasonNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param durationGreaterThan
     * @param durationLessThan
     * @param durationGreaterThanOrEqual
     * @param durationLessThanOrEqual
     * @param durationEquals
     * @param durationNotEquals
     * @param durationSpecified
     * @param durationIn
     * @param durationNotIn
     * @param timezoneContains
     * @param timezoneDoesNotContain
     * @param timezoneEquals
     * @param timezoneNotEquals
     * @param timezoneSpecified
     * @param timezoneIn
     * @param timezoneNotIn
     * @param cancelReasonContains
     * @param cancelReasonDoesNotContain
     * @param cancelReasonEquals
     * @param cancelReasonNotEquals
     * @param cancelReasonSpecified
     * @param cancelReasonIn
     * @param cancelReasonNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param primaryInsuranceIdGreaterThan
     * @param primaryInsuranceIdLessThan
     * @param primaryInsuranceIdGreaterThanOrEqual
     * @param primaryInsuranceIdLessThanOrEqual
     * @param primaryInsuranceIdEquals
     * @param primaryInsuranceIdNotEquals
     * @param primaryInsuranceIdSpecified
     * @param primaryInsuranceIdIn
     * @param primaryInsuranceIdNotIn
     * @param secondaryInsuranceIdGreaterThan
     * @param secondaryInsuranceIdLessThan
     * @param secondaryInsuranceIdGreaterThanOrEqual
     * @param secondaryInsuranceIdLessThanOrEqual
     * @param secondaryInsuranceIdEquals
     * @param secondaryInsuranceIdNotEquals
     * @param secondaryInsuranceIdSpecified
     * @param secondaryInsuranceIdIn
     * @param secondaryInsuranceIdNotIn
     * @param intakeFormIdGreaterThan
     * @param intakeFormIdLessThan
     * @param intakeFormIdGreaterThanOrEqual
     * @param intakeFormIdLessThanOrEqual
     * @param intakeFormIdEquals
     * @param intakeFormIdNotEquals
     * @param intakeFormIdSpecified
     * @param intakeFormIdIn
     * @param intakeFormIdNotIn
     * @param rescheduledIdIdGreaterThan
     * @param rescheduledIdIdLessThan
     * @param rescheduledIdIdGreaterThanOrEqual
     * @param rescheduledIdIdLessThanOrEqual
     * @param rescheduledIdIdEquals
     * @param rescheduledIdIdNotEquals
     * @param rescheduledIdIdSpecified
     * @param rescheduledIdIdIn
     * @param rescheduledIdIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns AppointmentDTO OK
     * @throws ApiError
     */
    public static getAllAppointments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        typeEquals?: 'NEW' | 'FOLLOWUP',
        typeNotEquals?: 'NEW' | 'FOLLOWUP',
        typeSpecified?: boolean,
        typeIn?: Array<'NEW' | 'FOLLOWUP'>,
        typeNotIn?: Array<'NEW' | 'FOLLOWUP'>,
        startTimeGreaterThan?: string,
        startTimeLessThan?: string,
        startTimeGreaterThanOrEqual?: string,
        startTimeLessThanOrEqual?: string,
        startTimeEquals?: string,
        startTimeNotEquals?: string,
        startTimeSpecified?: boolean,
        startTimeIn?: Array<string>,
        startTimeNotIn?: Array<string>,
        endTimeGreaterThan?: string,
        endTimeLessThan?: string,
        endTimeGreaterThanOrEqual?: string,
        endTimeLessThanOrEqual?: string,
        endTimeEquals?: string,
        endTimeNotEquals?: string,
        endTimeSpecified?: boolean,
        endTimeIn?: Array<string>,
        endTimeNotIn?: Array<string>,
        modeEquals?: 'INPERSON' | 'VIRTUAL',
        modeNotEquals?: 'INPERSON' | 'VIRTUAL',
        modeSpecified?: boolean,
        modeIn?: Array<'INPERSON' | 'VIRTUAL'>,
        modeNotIn?: Array<'INPERSON' | 'VIRTUAL'>,
        roomContains?: string,
        roomDoesNotContain?: string,
        roomEquals?: string,
        roomNotEquals?: string,
        roomSpecified?: boolean,
        roomIn?: Array<string>,
        roomNotIn?: Array<string>,
        paymentTypeEquals?: 'CASH' | 'CARD' | 'BANK',
        paymentTypeNotEquals?: 'CASH' | 'CARD' | 'BANK',
        paymentTypeSpecified?: boolean,
        paymentTypeIn?: Array<'CASH' | 'CARD' | 'BANK'>,
        paymentTypeNotIn?: Array<'CASH' | 'CARD' | 'BANK'>,
        reasonContains?: string,
        reasonDoesNotContain?: string,
        reasonEquals?: string,
        reasonNotEquals?: string,
        reasonSpecified?: boolean,
        reasonIn?: Array<string>,
        reasonNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        statusEquals?: 'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM',
        statusNotEquals?: 'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM',
        statusSpecified?: boolean,
        statusIn?: Array<'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM'>,
        statusNotIn?: Array<'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM'>,
        durationGreaterThan?: number,
        durationLessThan?: number,
        durationGreaterThanOrEqual?: number,
        durationLessThanOrEqual?: number,
        durationEquals?: number,
        durationNotEquals?: number,
        durationSpecified?: boolean,
        durationIn?: Array<number>,
        durationNotIn?: Array<number>,
        timezoneContains?: string,
        timezoneDoesNotContain?: string,
        timezoneEquals?: string,
        timezoneNotEquals?: string,
        timezoneSpecified?: boolean,
        timezoneIn?: Array<string>,
        timezoneNotIn?: Array<string>,
        cancelReasonContains?: string,
        cancelReasonDoesNotContain?: string,
        cancelReasonEquals?: string,
        cancelReasonNotEquals?: string,
        cancelReasonSpecified?: boolean,
        cancelReasonIn?: Array<string>,
        cancelReasonNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdEquals?: string,
        patientIdIdNotEquals?: string,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<string>,
        patientIdIdNotIn?: Array<string>,
        locationIdIdEquals?: string,
        locationIdIdNotEquals?: string,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<string>,
        locationIdIdNotIn?: Array<string>,
        providerIdIdEquals?: string,
        providerIdIdNotEquals?: string,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<string>,
        providerIdIdNotIn?: Array<string>,
        primaryInsuranceIdGreaterThan?: number,
        primaryInsuranceIdLessThan?: number,
        primaryInsuranceIdGreaterThanOrEqual?: number,
        primaryInsuranceIdLessThanOrEqual?: number,
        primaryInsuranceIdEquals?: number,
        primaryInsuranceIdNotEquals?: number,
        primaryInsuranceIdSpecified?: boolean,
        primaryInsuranceIdIn?: Array<number>,
        primaryInsuranceIdNotIn?: Array<number>,
        secondaryInsuranceIdGreaterThan?: number,
        secondaryInsuranceIdLessThan?: number,
        secondaryInsuranceIdGreaterThanOrEqual?: number,
        secondaryInsuranceIdLessThanOrEqual?: number,
        secondaryInsuranceIdEquals?: number,
        secondaryInsuranceIdNotEquals?: number,
        secondaryInsuranceIdSpecified?: boolean,
        secondaryInsuranceIdIn?: Array<number>,
        secondaryInsuranceIdNotIn?: Array<number>,
        intakeFormIdGreaterThan?: number,
        intakeFormIdLessThan?: number,
        intakeFormIdGreaterThanOrEqual?: number,
        intakeFormIdLessThanOrEqual?: number,
        intakeFormIdEquals?: number,
        intakeFormIdNotEquals?: number,
        intakeFormIdSpecified?: boolean,
        intakeFormIdIn?: Array<number>,
        intakeFormIdNotIn?: Array<number>,
        rescheduledIdIdGreaterThan?: number,
        rescheduledIdIdLessThan?: number,
        rescheduledIdIdGreaterThanOrEqual?: number,
        rescheduledIdIdLessThanOrEqual?: number,
        rescheduledIdIdEquals?: number,
        rescheduledIdIdNotEquals?: number,
        rescheduledIdIdSpecified?: boolean,
        rescheduledIdIdIn?: Array<number>,
        rescheduledIdIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<AppointmentDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/appointments',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'startTime.greaterThan': startTimeGreaterThan,
                'startTime.lessThan': startTimeLessThan,
                'startTime.greaterThanOrEqual': startTimeGreaterThanOrEqual,
                'startTime.lessThanOrEqual': startTimeLessThanOrEqual,
                'startTime.equals': startTimeEquals,
                'startTime.notEquals': startTimeNotEquals,
                'startTime.specified': startTimeSpecified,
                'startTime.in': startTimeIn,
                'startTime.notIn': startTimeNotIn,
                'endTime.greaterThan': endTimeGreaterThan,
                'endTime.lessThan': endTimeLessThan,
                'endTime.greaterThanOrEqual': endTimeGreaterThanOrEqual,
                'endTime.lessThanOrEqual': endTimeLessThanOrEqual,
                'endTime.equals': endTimeEquals,
                'endTime.notEquals': endTimeNotEquals,
                'endTime.specified': endTimeSpecified,
                'endTime.in': endTimeIn,
                'endTime.notIn': endTimeNotIn,
                'mode.equals': modeEquals,
                'mode.notEquals': modeNotEquals,
                'mode.specified': modeSpecified,
                'mode.in': modeIn,
                'mode.notIn': modeNotIn,
                'room.contains': roomContains,
                'room.doesNotContain': roomDoesNotContain,
                'room.equals': roomEquals,
                'room.notEquals': roomNotEquals,
                'room.specified': roomSpecified,
                'room.in': roomIn,
                'room.notIn': roomNotIn,
                'paymentType.equals': paymentTypeEquals,
                'paymentType.notEquals': paymentTypeNotEquals,
                'paymentType.specified': paymentTypeSpecified,
                'paymentType.in': paymentTypeIn,
                'paymentType.notIn': paymentTypeNotIn,
                'reason.contains': reasonContains,
                'reason.doesNotContain': reasonDoesNotContain,
                'reason.equals': reasonEquals,
                'reason.notEquals': reasonNotEquals,
                'reason.specified': reasonSpecified,
                'reason.in': reasonIn,
                'reason.notIn': reasonNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'duration.greaterThan': durationGreaterThan,
                'duration.lessThan': durationLessThan,
                'duration.greaterThanOrEqual': durationGreaterThanOrEqual,
                'duration.lessThanOrEqual': durationLessThanOrEqual,
                'duration.equals': durationEquals,
                'duration.notEquals': durationNotEquals,
                'duration.specified': durationSpecified,
                'duration.in': durationIn,
                'duration.notIn': durationNotIn,
                'timezone.contains': timezoneContains,
                'timezone.doesNotContain': timezoneDoesNotContain,
                'timezone.equals': timezoneEquals,
                'timezone.notEquals': timezoneNotEquals,
                'timezone.specified': timezoneSpecified,
                'timezone.in': timezoneIn,
                'timezone.notIn': timezoneNotIn,
                'cancelReason.contains': cancelReasonContains,
                'cancelReason.doesNotContain': cancelReasonDoesNotContain,
                'cancelReason.equals': cancelReasonEquals,
                'cancelReason.notEquals': cancelReasonNotEquals,
                'cancelReason.specified': cancelReasonSpecified,
                'cancelReason.in': cancelReasonIn,
                'cancelReason.notIn': cancelReasonNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'primaryInsuranceId.greaterThan': primaryInsuranceIdGreaterThan,
                'primaryInsuranceId.lessThan': primaryInsuranceIdLessThan,
                'primaryInsuranceId.greaterThanOrEqual': primaryInsuranceIdGreaterThanOrEqual,
                'primaryInsuranceId.lessThanOrEqual': primaryInsuranceIdLessThanOrEqual,
                'primaryInsuranceId.equals': primaryInsuranceIdEquals,
                'primaryInsuranceId.notEquals': primaryInsuranceIdNotEquals,
                'primaryInsuranceId.specified': primaryInsuranceIdSpecified,
                'primaryInsuranceId.in': primaryInsuranceIdIn,
                'primaryInsuranceId.notIn': primaryInsuranceIdNotIn,
                'secondaryInsuranceId.greaterThan': secondaryInsuranceIdGreaterThan,
                'secondaryInsuranceId.lessThan': secondaryInsuranceIdLessThan,
                'secondaryInsuranceId.greaterThanOrEqual': secondaryInsuranceIdGreaterThanOrEqual,
                'secondaryInsuranceId.lessThanOrEqual': secondaryInsuranceIdLessThanOrEqual,
                'secondaryInsuranceId.equals': secondaryInsuranceIdEquals,
                'secondaryInsuranceId.notEquals': secondaryInsuranceIdNotEquals,
                'secondaryInsuranceId.specified': secondaryInsuranceIdSpecified,
                'secondaryInsuranceId.in': secondaryInsuranceIdIn,
                'secondaryInsuranceId.notIn': secondaryInsuranceIdNotIn,
                'intakeFormId.greaterThan': intakeFormIdGreaterThan,
                'intakeFormId.lessThan': intakeFormIdLessThan,
                'intakeFormId.greaterThanOrEqual': intakeFormIdGreaterThanOrEqual,
                'intakeFormId.lessThanOrEqual': intakeFormIdLessThanOrEqual,
                'intakeFormId.equals': intakeFormIdEquals,
                'intakeFormId.notEquals': intakeFormIdNotEquals,
                'intakeFormId.specified': intakeFormIdSpecified,
                'intakeFormId.in': intakeFormIdIn,
                'intakeFormId.notIn': intakeFormIdNotIn,
                'rescheduledIdId.greaterThan': rescheduledIdIdGreaterThan,
                'rescheduledIdId.lessThan': rescheduledIdIdLessThan,
                'rescheduledIdId.greaterThanOrEqual': rescheduledIdIdGreaterThanOrEqual,
                'rescheduledIdId.lessThanOrEqual': rescheduledIdIdLessThanOrEqual,
                'rescheduledIdId.equals': rescheduledIdIdEquals,
                'rescheduledIdId.notEquals': rescheduledIdIdNotEquals,
                'rescheduledIdId.specified': rescheduledIdIdSpecified,
                'rescheduledIdId.in': rescheduledIdIdIn,
                'rescheduledIdId.notIn': rescheduledIdIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns AppointmentDTO OK
     * @throws ApiError
     */
    public static createAppointment(
        requestBody: AppointmentDTO,
    ): CancelablePromise<AppointmentDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/appointments',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param startTimeGreaterThan
     * @param startTimeLessThan
     * @param startTimeGreaterThanOrEqual
     * @param startTimeLessThanOrEqual
     * @param startTimeEquals
     * @param startTimeNotEquals
     * @param startTimeSpecified
     * @param startTimeIn
     * @param startTimeNotIn
     * @param endTimeGreaterThan
     * @param endTimeLessThan
     * @param endTimeGreaterThanOrEqual
     * @param endTimeLessThanOrEqual
     * @param endTimeEquals
     * @param endTimeNotEquals
     * @param endTimeSpecified
     * @param endTimeIn
     * @param endTimeNotIn
     * @param modeEquals
     * @param modeNotEquals
     * @param modeSpecified
     * @param modeIn
     * @param modeNotIn
     * @param roomContains
     * @param roomDoesNotContain
     * @param roomEquals
     * @param roomNotEquals
     * @param roomSpecified
     * @param roomIn
     * @param roomNotIn
     * @param paymentTypeEquals
     * @param paymentTypeNotEquals
     * @param paymentTypeSpecified
     * @param paymentTypeIn
     * @param paymentTypeNotIn
     * @param reasonContains
     * @param reasonDoesNotContain
     * @param reasonEquals
     * @param reasonNotEquals
     * @param reasonSpecified
     * @param reasonIn
     * @param reasonNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param durationGreaterThan
     * @param durationLessThan
     * @param durationGreaterThanOrEqual
     * @param durationLessThanOrEqual
     * @param durationEquals
     * @param durationNotEquals
     * @param durationSpecified
     * @param durationIn
     * @param durationNotIn
     * @param timezoneContains
     * @param timezoneDoesNotContain
     * @param timezoneEquals
     * @param timezoneNotEquals
     * @param timezoneSpecified
     * @param timezoneIn
     * @param timezoneNotIn
     * @param cancelReasonContains
     * @param cancelReasonDoesNotContain
     * @param cancelReasonEquals
     * @param cancelReasonNotEquals
     * @param cancelReasonSpecified
     * @param cancelReasonIn
     * @param cancelReasonNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param locationIdIdEquals
     * @param locationIdIdNotEquals
     * @param locationIdIdSpecified
     * @param locationIdIdIn
     * @param locationIdIdNotIn
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param primaryInsuranceIdGreaterThan
     * @param primaryInsuranceIdLessThan
     * @param primaryInsuranceIdGreaterThanOrEqual
     * @param primaryInsuranceIdLessThanOrEqual
     * @param primaryInsuranceIdEquals
     * @param primaryInsuranceIdNotEquals
     * @param primaryInsuranceIdSpecified
     * @param primaryInsuranceIdIn
     * @param primaryInsuranceIdNotIn
     * @param secondaryInsuranceIdGreaterThan
     * @param secondaryInsuranceIdLessThan
     * @param secondaryInsuranceIdGreaterThanOrEqual
     * @param secondaryInsuranceIdLessThanOrEqual
     * @param secondaryInsuranceIdEquals
     * @param secondaryInsuranceIdNotEquals
     * @param secondaryInsuranceIdSpecified
     * @param secondaryInsuranceIdIn
     * @param secondaryInsuranceIdNotIn
     * @param intakeFormIdGreaterThan
     * @param intakeFormIdLessThan
     * @param intakeFormIdGreaterThanOrEqual
     * @param intakeFormIdLessThanOrEqual
     * @param intakeFormIdEquals
     * @param intakeFormIdNotEquals
     * @param intakeFormIdSpecified
     * @param intakeFormIdIn
     * @param intakeFormIdNotIn
     * @param rescheduledIdIdGreaterThan
     * @param rescheduledIdIdLessThan
     * @param rescheduledIdIdGreaterThanOrEqual
     * @param rescheduledIdIdLessThanOrEqual
     * @param rescheduledIdIdEquals
     * @param rescheduledIdIdNotEquals
     * @param rescheduledIdIdSpecified
     * @param rescheduledIdIdIn
     * @param rescheduledIdIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countAppointments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        typeEquals?: 'NEW' | 'FOLLOWUP',
        typeNotEquals?: 'NEW' | 'FOLLOWUP',
        typeSpecified?: boolean,
        typeIn?: Array<'NEW' | 'FOLLOWUP'>,
        typeNotIn?: Array<'NEW' | 'FOLLOWUP'>,
        startTimeGreaterThan?: string,
        startTimeLessThan?: string,
        startTimeGreaterThanOrEqual?: string,
        startTimeLessThanOrEqual?: string,
        startTimeEquals?: string,
        startTimeNotEquals?: string,
        startTimeSpecified?: boolean,
        startTimeIn?: Array<string>,
        startTimeNotIn?: Array<string>,
        endTimeGreaterThan?: string,
        endTimeLessThan?: string,
        endTimeGreaterThanOrEqual?: string,
        endTimeLessThanOrEqual?: string,
        endTimeEquals?: string,
        endTimeNotEquals?: string,
        endTimeSpecified?: boolean,
        endTimeIn?: Array<string>,
        endTimeNotIn?: Array<string>,
        modeEquals?: 'INPERSON' | 'VIRTUAL',
        modeNotEquals?: 'INPERSON' | 'VIRTUAL',
        modeSpecified?: boolean,
        modeIn?: Array<'INPERSON' | 'VIRTUAL'>,
        modeNotIn?: Array<'INPERSON' | 'VIRTUAL'>,
        roomContains?: string,
        roomDoesNotContain?: string,
        roomEquals?: string,
        roomNotEquals?: string,
        roomSpecified?: boolean,
        roomIn?: Array<string>,
        roomNotIn?: Array<string>,
        paymentTypeEquals?: 'CASH' | 'CARD' | 'BANK',
        paymentTypeNotEquals?: 'CASH' | 'CARD' | 'BANK',
        paymentTypeSpecified?: boolean,
        paymentTypeIn?: Array<'CASH' | 'CARD' | 'BANK'>,
        paymentTypeNotIn?: Array<'CASH' | 'CARD' | 'BANK'>,
        reasonContains?: string,
        reasonDoesNotContain?: string,
        reasonEquals?: string,
        reasonNotEquals?: string,
        reasonSpecified?: boolean,
        reasonIn?: Array<string>,
        reasonNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        statusEquals?: 'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM',
        statusNotEquals?: 'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM',
        statusSpecified?: boolean,
        statusIn?: Array<'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM'>,
        statusNotIn?: Array<'SCHEDULED' | 'CHECK_IN' | 'EXAM_ROOM' | 'IN_ROOM_INTAKE' | 'COMPLETED' | 'CANCELLED' | 'WAITING_ROOM'>,
        durationGreaterThan?: number,
        durationLessThan?: number,
        durationGreaterThanOrEqual?: number,
        durationLessThanOrEqual?: number,
        durationEquals?: number,
        durationNotEquals?: number,
        durationSpecified?: boolean,
        durationIn?: Array<number>,
        durationNotIn?: Array<number>,
        timezoneContains?: string,
        timezoneDoesNotContain?: string,
        timezoneEquals?: string,
        timezoneNotEquals?: string,
        timezoneSpecified?: boolean,
        timezoneIn?: Array<string>,
        timezoneNotIn?: Array<string>,
        cancelReasonContains?: string,
        cancelReasonDoesNotContain?: string,
        cancelReasonEquals?: string,
        cancelReasonNotEquals?: string,
        cancelReasonSpecified?: boolean,
        cancelReasonIn?: Array<string>,
        cancelReasonNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdEquals?: string,
        patientIdIdNotEquals?: string,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<string>,
        patientIdIdNotIn?: Array<string>,
        locationIdIdEquals?: string,
        locationIdIdNotEquals?: string,
        locationIdIdSpecified?: boolean,
        locationIdIdIn?: Array<string>,
        locationIdIdNotIn?: Array<string>,
        providerIdIdEquals?: string,
        providerIdIdNotEquals?: string,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<string>,
        providerIdIdNotIn?: Array<string>,
        primaryInsuranceIdGreaterThan?: number,
        primaryInsuranceIdLessThan?: number,
        primaryInsuranceIdGreaterThanOrEqual?: number,
        primaryInsuranceIdLessThanOrEqual?: number,
        primaryInsuranceIdEquals?: number,
        primaryInsuranceIdNotEquals?: number,
        primaryInsuranceIdSpecified?: boolean,
        primaryInsuranceIdIn?: Array<number>,
        primaryInsuranceIdNotIn?: Array<number>,
        secondaryInsuranceIdGreaterThan?: number,
        secondaryInsuranceIdLessThan?: number,
        secondaryInsuranceIdGreaterThanOrEqual?: number,
        secondaryInsuranceIdLessThanOrEqual?: number,
        secondaryInsuranceIdEquals?: number,
        secondaryInsuranceIdNotEquals?: number,
        secondaryInsuranceIdSpecified?: boolean,
        secondaryInsuranceIdIn?: Array<number>,
        secondaryInsuranceIdNotIn?: Array<number>,
        intakeFormIdGreaterThan?: number,
        intakeFormIdLessThan?: number,
        intakeFormIdGreaterThanOrEqual?: number,
        intakeFormIdLessThanOrEqual?: number,
        intakeFormIdEquals?: number,
        intakeFormIdNotEquals?: number,
        intakeFormIdSpecified?: boolean,
        intakeFormIdIn?: Array<number>,
        intakeFormIdNotIn?: Array<number>,
        rescheduledIdIdGreaterThan?: number,
        rescheduledIdIdLessThan?: number,
        rescheduledIdIdGreaterThanOrEqual?: number,
        rescheduledIdIdLessThanOrEqual?: number,
        rescheduledIdIdEquals?: number,
        rescheduledIdIdNotEquals?: number,
        rescheduledIdIdSpecified?: boolean,
        rescheduledIdIdIn?: Array<number>,
        rescheduledIdIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/appointments/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'startTime.greaterThan': startTimeGreaterThan,
                'startTime.lessThan': startTimeLessThan,
                'startTime.greaterThanOrEqual': startTimeGreaterThanOrEqual,
                'startTime.lessThanOrEqual': startTimeLessThanOrEqual,
                'startTime.equals': startTimeEquals,
                'startTime.notEquals': startTimeNotEquals,
                'startTime.specified': startTimeSpecified,
                'startTime.in': startTimeIn,
                'startTime.notIn': startTimeNotIn,
                'endTime.greaterThan': endTimeGreaterThan,
                'endTime.lessThan': endTimeLessThan,
                'endTime.greaterThanOrEqual': endTimeGreaterThanOrEqual,
                'endTime.lessThanOrEqual': endTimeLessThanOrEqual,
                'endTime.equals': endTimeEquals,
                'endTime.notEquals': endTimeNotEquals,
                'endTime.specified': endTimeSpecified,
                'endTime.in': endTimeIn,
                'endTime.notIn': endTimeNotIn,
                'mode.equals': modeEquals,
                'mode.notEquals': modeNotEquals,
                'mode.specified': modeSpecified,
                'mode.in': modeIn,
                'mode.notIn': modeNotIn,
                'room.contains': roomContains,
                'room.doesNotContain': roomDoesNotContain,
                'room.equals': roomEquals,
                'room.notEquals': roomNotEquals,
                'room.specified': roomSpecified,
                'room.in': roomIn,
                'room.notIn': roomNotIn,
                'paymentType.equals': paymentTypeEquals,
                'paymentType.notEquals': paymentTypeNotEquals,
                'paymentType.specified': paymentTypeSpecified,
                'paymentType.in': paymentTypeIn,
                'paymentType.notIn': paymentTypeNotIn,
                'reason.contains': reasonContains,
                'reason.doesNotContain': reasonDoesNotContain,
                'reason.equals': reasonEquals,
                'reason.notEquals': reasonNotEquals,
                'reason.specified': reasonSpecified,
                'reason.in': reasonIn,
                'reason.notIn': reasonNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'duration.greaterThan': durationGreaterThan,
                'duration.lessThan': durationLessThan,
                'duration.greaterThanOrEqual': durationGreaterThanOrEqual,
                'duration.lessThanOrEqual': durationLessThanOrEqual,
                'duration.equals': durationEquals,
                'duration.notEquals': durationNotEquals,
                'duration.specified': durationSpecified,
                'duration.in': durationIn,
                'duration.notIn': durationNotIn,
                'timezone.contains': timezoneContains,
                'timezone.doesNotContain': timezoneDoesNotContain,
                'timezone.equals': timezoneEquals,
                'timezone.notEquals': timezoneNotEquals,
                'timezone.specified': timezoneSpecified,
                'timezone.in': timezoneIn,
                'timezone.notIn': timezoneNotIn,
                'cancelReason.contains': cancelReasonContains,
                'cancelReason.doesNotContain': cancelReasonDoesNotContain,
                'cancelReason.equals': cancelReasonEquals,
                'cancelReason.notEquals': cancelReasonNotEquals,
                'cancelReason.specified': cancelReasonSpecified,
                'cancelReason.in': cancelReasonIn,
                'cancelReason.notIn': cancelReasonNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'locationIdId.equals': locationIdIdEquals,
                'locationIdId.notEquals': locationIdIdNotEquals,
                'locationIdId.specified': locationIdIdSpecified,
                'locationIdId.in': locationIdIdIn,
                'locationIdId.notIn': locationIdIdNotIn,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'primaryInsuranceId.greaterThan': primaryInsuranceIdGreaterThan,
                'primaryInsuranceId.lessThan': primaryInsuranceIdLessThan,
                'primaryInsuranceId.greaterThanOrEqual': primaryInsuranceIdGreaterThanOrEqual,
                'primaryInsuranceId.lessThanOrEqual': primaryInsuranceIdLessThanOrEqual,
                'primaryInsuranceId.equals': primaryInsuranceIdEquals,
                'primaryInsuranceId.notEquals': primaryInsuranceIdNotEquals,
                'primaryInsuranceId.specified': primaryInsuranceIdSpecified,
                'primaryInsuranceId.in': primaryInsuranceIdIn,
                'primaryInsuranceId.notIn': primaryInsuranceIdNotIn,
                'secondaryInsuranceId.greaterThan': secondaryInsuranceIdGreaterThan,
                'secondaryInsuranceId.lessThan': secondaryInsuranceIdLessThan,
                'secondaryInsuranceId.greaterThanOrEqual': secondaryInsuranceIdGreaterThanOrEqual,
                'secondaryInsuranceId.lessThanOrEqual': secondaryInsuranceIdLessThanOrEqual,
                'secondaryInsuranceId.equals': secondaryInsuranceIdEquals,
                'secondaryInsuranceId.notEquals': secondaryInsuranceIdNotEquals,
                'secondaryInsuranceId.specified': secondaryInsuranceIdSpecified,
                'secondaryInsuranceId.in': secondaryInsuranceIdIn,
                'secondaryInsuranceId.notIn': secondaryInsuranceIdNotIn,
                'intakeFormId.greaterThan': intakeFormIdGreaterThan,
                'intakeFormId.lessThan': intakeFormIdLessThan,
                'intakeFormId.greaterThanOrEqual': intakeFormIdGreaterThanOrEqual,
                'intakeFormId.lessThanOrEqual': intakeFormIdLessThanOrEqual,
                'intakeFormId.equals': intakeFormIdEquals,
                'intakeFormId.notEquals': intakeFormIdNotEquals,
                'intakeFormId.specified': intakeFormIdSpecified,
                'intakeFormId.in': intakeFormIdIn,
                'intakeFormId.notIn': intakeFormIdNotIn,
                'rescheduledIdId.greaterThan': rescheduledIdIdGreaterThan,
                'rescheduledIdId.lessThan': rescheduledIdIdLessThan,
                'rescheduledIdId.greaterThanOrEqual': rescheduledIdIdGreaterThanOrEqual,
                'rescheduledIdId.lessThanOrEqual': rescheduledIdIdLessThanOrEqual,
                'rescheduledIdId.equals': rescheduledIdIdEquals,
                'rescheduledIdId.notEquals': rescheduledIdIdNotEquals,
                'rescheduledIdId.specified': rescheduledIdIdSpecified,
                'rescheduledIdId.in': rescheduledIdIdIn,
                'rescheduledIdId.notIn': rescheduledIdIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
