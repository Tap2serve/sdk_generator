/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AddressDTO } from '../models/AddressDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class AddressResourceService {

    /**
     * @param id
     * @returns AddressDTO OK
     * @throws ApiError
     */
    public static getAddress(
        id: number,
    ): CancelablePromise<AddressDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/addresses/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns AddressDTO OK
     * @throws ApiError
     */
    public static updateAddress(
        id: number,
        requestBody: AddressDTO,
    ): CancelablePromise<AddressDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/addresses/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteAddress(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/addresses/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns AddressDTO OK
     * @throws ApiError
     */
    public static partialUpdateAddress(
        id: number,
        requestBody: AddressDTO,
    ): CancelablePromise<AddressDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/addresses/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param line1Contains
     * @param line1DoesNotContain
     * @param line1Equals
     * @param line1NotEquals
     * @param line1Specified
     * @param line1In
     * @param line1NotIn
     * @param line2Contains
     * @param line2DoesNotContain
     * @param line2Equals
     * @param line2NotEquals
     * @param line2Specified
     * @param line2In
     * @param line2NotIn
     * @param cityContains
     * @param cityDoesNotContain
     * @param cityEquals
     * @param cityNotEquals
     * @param citySpecified
     * @param cityIn
     * @param cityNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param zipCodeGreaterThan
     * @param zipCodeLessThan
     * @param zipCodeGreaterThanOrEqual
     * @param zipCodeLessThanOrEqual
     * @param zipCodeEquals
     * @param zipCodeNotEquals
     * @param zipCodeSpecified
     * @param zipCodeIn
     * @param zipCodeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param providerGroupPhysicalAddressIdGreaterThan
     * @param providerGroupPhysicalAddressIdLessThan
     * @param providerGroupPhysicalAddressIdGreaterThanOrEqual
     * @param providerGroupPhysicalAddressIdLessThanOrEqual
     * @param providerGroupPhysicalAddressIdEquals
     * @param providerGroupPhysicalAddressIdNotEquals
     * @param providerGroupPhysicalAddressIdSpecified
     * @param providerGroupPhysicalAddressIdIn
     * @param providerGroupPhysicalAddressIdNotIn
     * @param providerGroupBillingAddressIdGreaterThan
     * @param providerGroupBillingAddressIdLessThan
     * @param providerGroupBillingAddressIdGreaterThanOrEqual
     * @param providerGroupBillingAddressIdLessThanOrEqual
     * @param providerGroupBillingAddressIdEquals
     * @param providerGroupBillingAddressIdNotEquals
     * @param providerGroupBillingAddressIdSpecified
     * @param providerGroupBillingAddressIdIn
     * @param providerGroupBillingAddressIdNotIn
     * @param locationPhysicalAddressIdGreaterThan
     * @param locationPhysicalAddressIdLessThan
     * @param locationPhysicalAddressIdGreaterThanOrEqual
     * @param locationPhysicalAddressIdLessThanOrEqual
     * @param locationPhysicalAddressIdEquals
     * @param locationPhysicalAddressIdNotEquals
     * @param locationPhysicalAddressIdSpecified
     * @param locationPhysicalAddressIdIn
     * @param locationPhysicalAddressIdNotIn
     * @param locationBillingAddressIdGreaterThan
     * @param locationBillingAddressIdLessThan
     * @param locationBillingAddressIdGreaterThanOrEqual
     * @param locationBillingAddressIdLessThanOrEqual
     * @param locationBillingAddressIdEquals
     * @param locationBillingAddressIdNotEquals
     * @param locationBillingAddressIdSpecified
     * @param locationBillingAddressIdIn
     * @param locationBillingAddressIdNotIn
     * @param pharmacyStoreIdGreaterThan
     * @param pharmacyStoreIdLessThan
     * @param pharmacyStoreIdGreaterThanOrEqual
     * @param pharmacyStoreIdLessThanOrEqual
     * @param pharmacyStoreIdEquals
     * @param pharmacyStoreIdNotEquals
     * @param pharmacyStoreIdSpecified
     * @param pharmacyStoreIdIn
     * @param pharmacyStoreIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param insurancePolicyHolderIdGreaterThan
     * @param insurancePolicyHolderIdLessThan
     * @param insurancePolicyHolderIdGreaterThanOrEqual
     * @param insurancePolicyHolderIdLessThanOrEqual
     * @param insurancePolicyHolderIdEquals
     * @param insurancePolicyHolderIdNotEquals
     * @param insurancePolicyHolderIdSpecified
     * @param insurancePolicyHolderIdIn
     * @param insurancePolicyHolderIdNotIn
     * @param diagnosticCentreIdGreaterThan
     * @param diagnosticCentreIdLessThan
     * @param diagnosticCentreIdGreaterThanOrEqual
     * @param diagnosticCentreIdLessThanOrEqual
     * @param diagnosticCentreIdEquals
     * @param diagnosticCentreIdNotEquals
     * @param diagnosticCentreIdSpecified
     * @param diagnosticCentreIdIn
     * @param diagnosticCentreIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns AddressDTO OK
     * @throws ApiError
     */
    public static getAllAddresses(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        line1Contains?: string,
        line1DoesNotContain?: string,
        line1Equals?: string,
        line1NotEquals?: string,
        line1Specified?: boolean,
        line1In?: Array<string>,
        line1NotIn?: Array<string>,
        line2Contains?: string,
        line2DoesNotContain?: string,
        line2Equals?: string,
        line2NotEquals?: string,
        line2Specified?: boolean,
        line2In?: Array<string>,
        line2NotIn?: Array<string>,
        cityContains?: string,
        cityDoesNotContain?: string,
        cityEquals?: string,
        cityNotEquals?: string,
        citySpecified?: boolean,
        cityIn?: Array<string>,
        cityNotIn?: Array<string>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        zipCodeGreaterThan?: number,
        zipCodeLessThan?: number,
        zipCodeGreaterThanOrEqual?: number,
        zipCodeLessThanOrEqual?: number,
        zipCodeEquals?: number,
        zipCodeNotEquals?: number,
        zipCodeSpecified?: boolean,
        zipCodeIn?: Array<number>,
        zipCodeNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        providerGroupPhysicalAddressIdGreaterThan?: number,
        providerGroupPhysicalAddressIdLessThan?: number,
        providerGroupPhysicalAddressIdGreaterThanOrEqual?: number,
        providerGroupPhysicalAddressIdLessThanOrEqual?: number,
        providerGroupPhysicalAddressIdEquals?: number,
        providerGroupPhysicalAddressIdNotEquals?: number,
        providerGroupPhysicalAddressIdSpecified?: boolean,
        providerGroupPhysicalAddressIdIn?: Array<number>,
        providerGroupPhysicalAddressIdNotIn?: Array<number>,
        providerGroupBillingAddressIdGreaterThan?: number,
        providerGroupBillingAddressIdLessThan?: number,
        providerGroupBillingAddressIdGreaterThanOrEqual?: number,
        providerGroupBillingAddressIdLessThanOrEqual?: number,
        providerGroupBillingAddressIdEquals?: number,
        providerGroupBillingAddressIdNotEquals?: number,
        providerGroupBillingAddressIdSpecified?: boolean,
        providerGroupBillingAddressIdIn?: Array<number>,
        providerGroupBillingAddressIdNotIn?: Array<number>,
        locationPhysicalAddressIdGreaterThan?: number,
        locationPhysicalAddressIdLessThan?: number,
        locationPhysicalAddressIdGreaterThanOrEqual?: number,
        locationPhysicalAddressIdLessThanOrEqual?: number,
        locationPhysicalAddressIdEquals?: number,
        locationPhysicalAddressIdNotEquals?: number,
        locationPhysicalAddressIdSpecified?: boolean,
        locationPhysicalAddressIdIn?: Array<number>,
        locationPhysicalAddressIdNotIn?: Array<number>,
        locationBillingAddressIdGreaterThan?: number,
        locationBillingAddressIdLessThan?: number,
        locationBillingAddressIdGreaterThanOrEqual?: number,
        locationBillingAddressIdLessThanOrEqual?: number,
        locationBillingAddressIdEquals?: number,
        locationBillingAddressIdNotEquals?: number,
        locationBillingAddressIdSpecified?: boolean,
        locationBillingAddressIdIn?: Array<number>,
        locationBillingAddressIdNotIn?: Array<number>,
        pharmacyStoreIdGreaterThan?: number,
        pharmacyStoreIdLessThan?: number,
        pharmacyStoreIdGreaterThanOrEqual?: number,
        pharmacyStoreIdLessThanOrEqual?: number,
        pharmacyStoreIdEquals?: number,
        pharmacyStoreIdNotEquals?: number,
        pharmacyStoreIdSpecified?: boolean,
        pharmacyStoreIdIn?: Array<number>,
        pharmacyStoreIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        insurancePolicyHolderIdGreaterThan?: number,
        insurancePolicyHolderIdLessThan?: number,
        insurancePolicyHolderIdGreaterThanOrEqual?: number,
        insurancePolicyHolderIdLessThanOrEqual?: number,
        insurancePolicyHolderIdEquals?: number,
        insurancePolicyHolderIdNotEquals?: number,
        insurancePolicyHolderIdSpecified?: boolean,
        insurancePolicyHolderIdIn?: Array<number>,
        insurancePolicyHolderIdNotIn?: Array<number>,
        diagnosticCentreIdGreaterThan?: number,
        diagnosticCentreIdLessThan?: number,
        diagnosticCentreIdGreaterThanOrEqual?: number,
        diagnosticCentreIdLessThanOrEqual?: number,
        diagnosticCentreIdEquals?: number,
        diagnosticCentreIdNotEquals?: number,
        diagnosticCentreIdSpecified?: boolean,
        diagnosticCentreIdIn?: Array<number>,
        diagnosticCentreIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<AddressDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/addresses',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'line1.contains': line1Contains,
                'line1.doesNotContain': line1DoesNotContain,
                'line1.equals': line1Equals,
                'line1.notEquals': line1NotEquals,
                'line1.specified': line1Specified,
                'line1.in': line1In,
                'line1.notIn': line1NotIn,
                'line2.contains': line2Contains,
                'line2.doesNotContain': line2DoesNotContain,
                'line2.equals': line2Equals,
                'line2.notEquals': line2NotEquals,
                'line2.specified': line2Specified,
                'line2.in': line2In,
                'line2.notIn': line2NotIn,
                'city.contains': cityContains,
                'city.doesNotContain': cityDoesNotContain,
                'city.equals': cityEquals,
                'city.notEquals': cityNotEquals,
                'city.specified': citySpecified,
                'city.in': cityIn,
                'city.notIn': cityNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'zipCode.greaterThan': zipCodeGreaterThan,
                'zipCode.lessThan': zipCodeLessThan,
                'zipCode.greaterThanOrEqual': zipCodeGreaterThanOrEqual,
                'zipCode.lessThanOrEqual': zipCodeLessThanOrEqual,
                'zipCode.equals': zipCodeEquals,
                'zipCode.notEquals': zipCodeNotEquals,
                'zipCode.specified': zipCodeSpecified,
                'zipCode.in': zipCodeIn,
                'zipCode.notIn': zipCodeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'providerGroupPhysicalAddressId.greaterThan': providerGroupPhysicalAddressIdGreaterThan,
                'providerGroupPhysicalAddressId.lessThan': providerGroupPhysicalAddressIdLessThan,
                'providerGroupPhysicalAddressId.greaterThanOrEqual': providerGroupPhysicalAddressIdGreaterThanOrEqual,
                'providerGroupPhysicalAddressId.lessThanOrEqual': providerGroupPhysicalAddressIdLessThanOrEqual,
                'providerGroupPhysicalAddressId.equals': providerGroupPhysicalAddressIdEquals,
                'providerGroupPhysicalAddressId.notEquals': providerGroupPhysicalAddressIdNotEquals,
                'providerGroupPhysicalAddressId.specified': providerGroupPhysicalAddressIdSpecified,
                'providerGroupPhysicalAddressId.in': providerGroupPhysicalAddressIdIn,
                'providerGroupPhysicalAddressId.notIn': providerGroupPhysicalAddressIdNotIn,
                'providerGroupBillingAddressId.greaterThan': providerGroupBillingAddressIdGreaterThan,
                'providerGroupBillingAddressId.lessThan': providerGroupBillingAddressIdLessThan,
                'providerGroupBillingAddressId.greaterThanOrEqual': providerGroupBillingAddressIdGreaterThanOrEqual,
                'providerGroupBillingAddressId.lessThanOrEqual': providerGroupBillingAddressIdLessThanOrEqual,
                'providerGroupBillingAddressId.equals': providerGroupBillingAddressIdEquals,
                'providerGroupBillingAddressId.notEquals': providerGroupBillingAddressIdNotEquals,
                'providerGroupBillingAddressId.specified': providerGroupBillingAddressIdSpecified,
                'providerGroupBillingAddressId.in': providerGroupBillingAddressIdIn,
                'providerGroupBillingAddressId.notIn': providerGroupBillingAddressIdNotIn,
                'locationPhysicalAddressId.greaterThan': locationPhysicalAddressIdGreaterThan,
                'locationPhysicalAddressId.lessThan': locationPhysicalAddressIdLessThan,
                'locationPhysicalAddressId.greaterThanOrEqual': locationPhysicalAddressIdGreaterThanOrEqual,
                'locationPhysicalAddressId.lessThanOrEqual': locationPhysicalAddressIdLessThanOrEqual,
                'locationPhysicalAddressId.equals': locationPhysicalAddressIdEquals,
                'locationPhysicalAddressId.notEquals': locationPhysicalAddressIdNotEquals,
                'locationPhysicalAddressId.specified': locationPhysicalAddressIdSpecified,
                'locationPhysicalAddressId.in': locationPhysicalAddressIdIn,
                'locationPhysicalAddressId.notIn': locationPhysicalAddressIdNotIn,
                'locationBillingAddressId.greaterThan': locationBillingAddressIdGreaterThan,
                'locationBillingAddressId.lessThan': locationBillingAddressIdLessThan,
                'locationBillingAddressId.greaterThanOrEqual': locationBillingAddressIdGreaterThanOrEqual,
                'locationBillingAddressId.lessThanOrEqual': locationBillingAddressIdLessThanOrEqual,
                'locationBillingAddressId.equals': locationBillingAddressIdEquals,
                'locationBillingAddressId.notEquals': locationBillingAddressIdNotEquals,
                'locationBillingAddressId.specified': locationBillingAddressIdSpecified,
                'locationBillingAddressId.in': locationBillingAddressIdIn,
                'locationBillingAddressId.notIn': locationBillingAddressIdNotIn,
                'pharmacyStoreId.greaterThan': pharmacyStoreIdGreaterThan,
                'pharmacyStoreId.lessThan': pharmacyStoreIdLessThan,
                'pharmacyStoreId.greaterThanOrEqual': pharmacyStoreIdGreaterThanOrEqual,
                'pharmacyStoreId.lessThanOrEqual': pharmacyStoreIdLessThanOrEqual,
                'pharmacyStoreId.equals': pharmacyStoreIdEquals,
                'pharmacyStoreId.notEquals': pharmacyStoreIdNotEquals,
                'pharmacyStoreId.specified': pharmacyStoreIdSpecified,
                'pharmacyStoreId.in': pharmacyStoreIdIn,
                'pharmacyStoreId.notIn': pharmacyStoreIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'insurancePolicyHolderId.greaterThan': insurancePolicyHolderIdGreaterThan,
                'insurancePolicyHolderId.lessThan': insurancePolicyHolderIdLessThan,
                'insurancePolicyHolderId.greaterThanOrEqual': insurancePolicyHolderIdGreaterThanOrEqual,
                'insurancePolicyHolderId.lessThanOrEqual': insurancePolicyHolderIdLessThanOrEqual,
                'insurancePolicyHolderId.equals': insurancePolicyHolderIdEquals,
                'insurancePolicyHolderId.notEquals': insurancePolicyHolderIdNotEquals,
                'insurancePolicyHolderId.specified': insurancePolicyHolderIdSpecified,
                'insurancePolicyHolderId.in': insurancePolicyHolderIdIn,
                'insurancePolicyHolderId.notIn': insurancePolicyHolderIdNotIn,
                'diagnosticCentreId.greaterThan': diagnosticCentreIdGreaterThan,
                'diagnosticCentreId.lessThan': diagnosticCentreIdLessThan,
                'diagnosticCentreId.greaterThanOrEqual': diagnosticCentreIdGreaterThanOrEqual,
                'diagnosticCentreId.lessThanOrEqual': diagnosticCentreIdLessThanOrEqual,
                'diagnosticCentreId.equals': diagnosticCentreIdEquals,
                'diagnosticCentreId.notEquals': diagnosticCentreIdNotEquals,
                'diagnosticCentreId.specified': diagnosticCentreIdSpecified,
                'diagnosticCentreId.in': diagnosticCentreIdIn,
                'diagnosticCentreId.notIn': diagnosticCentreIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns AddressDTO OK
     * @throws ApiError
     */
    public static createAddress(
        requestBody: AddressDTO,
    ): CancelablePromise<AddressDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/addresses',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param line1Contains
     * @param line1DoesNotContain
     * @param line1Equals
     * @param line1NotEquals
     * @param line1Specified
     * @param line1In
     * @param line1NotIn
     * @param line2Contains
     * @param line2DoesNotContain
     * @param line2Equals
     * @param line2NotEquals
     * @param line2Specified
     * @param line2In
     * @param line2NotIn
     * @param cityContains
     * @param cityDoesNotContain
     * @param cityEquals
     * @param cityNotEquals
     * @param citySpecified
     * @param cityIn
     * @param cityNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param zipCodeGreaterThan
     * @param zipCodeLessThan
     * @param zipCodeGreaterThanOrEqual
     * @param zipCodeLessThanOrEqual
     * @param zipCodeEquals
     * @param zipCodeNotEquals
     * @param zipCodeSpecified
     * @param zipCodeIn
     * @param zipCodeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param providerGroupPhysicalAddressIdGreaterThan
     * @param providerGroupPhysicalAddressIdLessThan
     * @param providerGroupPhysicalAddressIdGreaterThanOrEqual
     * @param providerGroupPhysicalAddressIdLessThanOrEqual
     * @param providerGroupPhysicalAddressIdEquals
     * @param providerGroupPhysicalAddressIdNotEquals
     * @param providerGroupPhysicalAddressIdSpecified
     * @param providerGroupPhysicalAddressIdIn
     * @param providerGroupPhysicalAddressIdNotIn
     * @param providerGroupBillingAddressIdGreaterThan
     * @param providerGroupBillingAddressIdLessThan
     * @param providerGroupBillingAddressIdGreaterThanOrEqual
     * @param providerGroupBillingAddressIdLessThanOrEqual
     * @param providerGroupBillingAddressIdEquals
     * @param providerGroupBillingAddressIdNotEquals
     * @param providerGroupBillingAddressIdSpecified
     * @param providerGroupBillingAddressIdIn
     * @param providerGroupBillingAddressIdNotIn
     * @param locationPhysicalAddressIdGreaterThan
     * @param locationPhysicalAddressIdLessThan
     * @param locationPhysicalAddressIdGreaterThanOrEqual
     * @param locationPhysicalAddressIdLessThanOrEqual
     * @param locationPhysicalAddressIdEquals
     * @param locationPhysicalAddressIdNotEquals
     * @param locationPhysicalAddressIdSpecified
     * @param locationPhysicalAddressIdIn
     * @param locationPhysicalAddressIdNotIn
     * @param locationBillingAddressIdGreaterThan
     * @param locationBillingAddressIdLessThan
     * @param locationBillingAddressIdGreaterThanOrEqual
     * @param locationBillingAddressIdLessThanOrEqual
     * @param locationBillingAddressIdEquals
     * @param locationBillingAddressIdNotEquals
     * @param locationBillingAddressIdSpecified
     * @param locationBillingAddressIdIn
     * @param locationBillingAddressIdNotIn
     * @param pharmacyStoreIdGreaterThan
     * @param pharmacyStoreIdLessThan
     * @param pharmacyStoreIdGreaterThanOrEqual
     * @param pharmacyStoreIdLessThanOrEqual
     * @param pharmacyStoreIdEquals
     * @param pharmacyStoreIdNotEquals
     * @param pharmacyStoreIdSpecified
     * @param pharmacyStoreIdIn
     * @param pharmacyStoreIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param insurancePolicyHolderIdGreaterThan
     * @param insurancePolicyHolderIdLessThan
     * @param insurancePolicyHolderIdGreaterThanOrEqual
     * @param insurancePolicyHolderIdLessThanOrEqual
     * @param insurancePolicyHolderIdEquals
     * @param insurancePolicyHolderIdNotEquals
     * @param insurancePolicyHolderIdSpecified
     * @param insurancePolicyHolderIdIn
     * @param insurancePolicyHolderIdNotIn
     * @param diagnosticCentreIdGreaterThan
     * @param diagnosticCentreIdLessThan
     * @param diagnosticCentreIdGreaterThanOrEqual
     * @param diagnosticCentreIdLessThanOrEqual
     * @param diagnosticCentreIdEquals
     * @param diagnosticCentreIdNotEquals
     * @param diagnosticCentreIdSpecified
     * @param diagnosticCentreIdIn
     * @param diagnosticCentreIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countAddresses(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        line1Contains?: string,
        line1DoesNotContain?: string,
        line1Equals?: string,
        line1NotEquals?: string,
        line1Specified?: boolean,
        line1In?: Array<string>,
        line1NotIn?: Array<string>,
        line2Contains?: string,
        line2DoesNotContain?: string,
        line2Equals?: string,
        line2NotEquals?: string,
        line2Specified?: boolean,
        line2In?: Array<string>,
        line2NotIn?: Array<string>,
        cityContains?: string,
        cityDoesNotContain?: string,
        cityEquals?: string,
        cityNotEquals?: string,
        citySpecified?: boolean,
        cityIn?: Array<string>,
        cityNotIn?: Array<string>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        zipCodeGreaterThan?: number,
        zipCodeLessThan?: number,
        zipCodeGreaterThanOrEqual?: number,
        zipCodeLessThanOrEqual?: number,
        zipCodeEquals?: number,
        zipCodeNotEquals?: number,
        zipCodeSpecified?: boolean,
        zipCodeIn?: Array<number>,
        zipCodeNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        providerGroupPhysicalAddressIdGreaterThan?: number,
        providerGroupPhysicalAddressIdLessThan?: number,
        providerGroupPhysicalAddressIdGreaterThanOrEqual?: number,
        providerGroupPhysicalAddressIdLessThanOrEqual?: number,
        providerGroupPhysicalAddressIdEquals?: number,
        providerGroupPhysicalAddressIdNotEquals?: number,
        providerGroupPhysicalAddressIdSpecified?: boolean,
        providerGroupPhysicalAddressIdIn?: Array<number>,
        providerGroupPhysicalAddressIdNotIn?: Array<number>,
        providerGroupBillingAddressIdGreaterThan?: number,
        providerGroupBillingAddressIdLessThan?: number,
        providerGroupBillingAddressIdGreaterThanOrEqual?: number,
        providerGroupBillingAddressIdLessThanOrEqual?: number,
        providerGroupBillingAddressIdEquals?: number,
        providerGroupBillingAddressIdNotEquals?: number,
        providerGroupBillingAddressIdSpecified?: boolean,
        providerGroupBillingAddressIdIn?: Array<number>,
        providerGroupBillingAddressIdNotIn?: Array<number>,
        locationPhysicalAddressIdGreaterThan?: number,
        locationPhysicalAddressIdLessThan?: number,
        locationPhysicalAddressIdGreaterThanOrEqual?: number,
        locationPhysicalAddressIdLessThanOrEqual?: number,
        locationPhysicalAddressIdEquals?: number,
        locationPhysicalAddressIdNotEquals?: number,
        locationPhysicalAddressIdSpecified?: boolean,
        locationPhysicalAddressIdIn?: Array<number>,
        locationPhysicalAddressIdNotIn?: Array<number>,
        locationBillingAddressIdGreaterThan?: number,
        locationBillingAddressIdLessThan?: number,
        locationBillingAddressIdGreaterThanOrEqual?: number,
        locationBillingAddressIdLessThanOrEqual?: number,
        locationBillingAddressIdEquals?: number,
        locationBillingAddressIdNotEquals?: number,
        locationBillingAddressIdSpecified?: boolean,
        locationBillingAddressIdIn?: Array<number>,
        locationBillingAddressIdNotIn?: Array<number>,
        pharmacyStoreIdGreaterThan?: number,
        pharmacyStoreIdLessThan?: number,
        pharmacyStoreIdGreaterThanOrEqual?: number,
        pharmacyStoreIdLessThanOrEqual?: number,
        pharmacyStoreIdEquals?: number,
        pharmacyStoreIdNotEquals?: number,
        pharmacyStoreIdSpecified?: boolean,
        pharmacyStoreIdIn?: Array<number>,
        pharmacyStoreIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        insurancePolicyHolderIdGreaterThan?: number,
        insurancePolicyHolderIdLessThan?: number,
        insurancePolicyHolderIdGreaterThanOrEqual?: number,
        insurancePolicyHolderIdLessThanOrEqual?: number,
        insurancePolicyHolderIdEquals?: number,
        insurancePolicyHolderIdNotEquals?: number,
        insurancePolicyHolderIdSpecified?: boolean,
        insurancePolicyHolderIdIn?: Array<number>,
        insurancePolicyHolderIdNotIn?: Array<number>,
        diagnosticCentreIdGreaterThan?: number,
        diagnosticCentreIdLessThan?: number,
        diagnosticCentreIdGreaterThanOrEqual?: number,
        diagnosticCentreIdLessThanOrEqual?: number,
        diagnosticCentreIdEquals?: number,
        diagnosticCentreIdNotEquals?: number,
        diagnosticCentreIdSpecified?: boolean,
        diagnosticCentreIdIn?: Array<number>,
        diagnosticCentreIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/addresses/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'line1.contains': line1Contains,
                'line1.doesNotContain': line1DoesNotContain,
                'line1.equals': line1Equals,
                'line1.notEquals': line1NotEquals,
                'line1.specified': line1Specified,
                'line1.in': line1In,
                'line1.notIn': line1NotIn,
                'line2.contains': line2Contains,
                'line2.doesNotContain': line2DoesNotContain,
                'line2.equals': line2Equals,
                'line2.notEquals': line2NotEquals,
                'line2.specified': line2Specified,
                'line2.in': line2In,
                'line2.notIn': line2NotIn,
                'city.contains': cityContains,
                'city.doesNotContain': cityDoesNotContain,
                'city.equals': cityEquals,
                'city.notEquals': cityNotEquals,
                'city.specified': citySpecified,
                'city.in': cityIn,
                'city.notIn': cityNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'zipCode.greaterThan': zipCodeGreaterThan,
                'zipCode.lessThan': zipCodeLessThan,
                'zipCode.greaterThanOrEqual': zipCodeGreaterThanOrEqual,
                'zipCode.lessThanOrEqual': zipCodeLessThanOrEqual,
                'zipCode.equals': zipCodeEquals,
                'zipCode.notEquals': zipCodeNotEquals,
                'zipCode.specified': zipCodeSpecified,
                'zipCode.in': zipCodeIn,
                'zipCode.notIn': zipCodeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'providerGroupPhysicalAddressId.greaterThan': providerGroupPhysicalAddressIdGreaterThan,
                'providerGroupPhysicalAddressId.lessThan': providerGroupPhysicalAddressIdLessThan,
                'providerGroupPhysicalAddressId.greaterThanOrEqual': providerGroupPhysicalAddressIdGreaterThanOrEqual,
                'providerGroupPhysicalAddressId.lessThanOrEqual': providerGroupPhysicalAddressIdLessThanOrEqual,
                'providerGroupPhysicalAddressId.equals': providerGroupPhysicalAddressIdEquals,
                'providerGroupPhysicalAddressId.notEquals': providerGroupPhysicalAddressIdNotEquals,
                'providerGroupPhysicalAddressId.specified': providerGroupPhysicalAddressIdSpecified,
                'providerGroupPhysicalAddressId.in': providerGroupPhysicalAddressIdIn,
                'providerGroupPhysicalAddressId.notIn': providerGroupPhysicalAddressIdNotIn,
                'providerGroupBillingAddressId.greaterThan': providerGroupBillingAddressIdGreaterThan,
                'providerGroupBillingAddressId.lessThan': providerGroupBillingAddressIdLessThan,
                'providerGroupBillingAddressId.greaterThanOrEqual': providerGroupBillingAddressIdGreaterThanOrEqual,
                'providerGroupBillingAddressId.lessThanOrEqual': providerGroupBillingAddressIdLessThanOrEqual,
                'providerGroupBillingAddressId.equals': providerGroupBillingAddressIdEquals,
                'providerGroupBillingAddressId.notEquals': providerGroupBillingAddressIdNotEquals,
                'providerGroupBillingAddressId.specified': providerGroupBillingAddressIdSpecified,
                'providerGroupBillingAddressId.in': providerGroupBillingAddressIdIn,
                'providerGroupBillingAddressId.notIn': providerGroupBillingAddressIdNotIn,
                'locationPhysicalAddressId.greaterThan': locationPhysicalAddressIdGreaterThan,
                'locationPhysicalAddressId.lessThan': locationPhysicalAddressIdLessThan,
                'locationPhysicalAddressId.greaterThanOrEqual': locationPhysicalAddressIdGreaterThanOrEqual,
                'locationPhysicalAddressId.lessThanOrEqual': locationPhysicalAddressIdLessThanOrEqual,
                'locationPhysicalAddressId.equals': locationPhysicalAddressIdEquals,
                'locationPhysicalAddressId.notEquals': locationPhysicalAddressIdNotEquals,
                'locationPhysicalAddressId.specified': locationPhysicalAddressIdSpecified,
                'locationPhysicalAddressId.in': locationPhysicalAddressIdIn,
                'locationPhysicalAddressId.notIn': locationPhysicalAddressIdNotIn,
                'locationBillingAddressId.greaterThan': locationBillingAddressIdGreaterThan,
                'locationBillingAddressId.lessThan': locationBillingAddressIdLessThan,
                'locationBillingAddressId.greaterThanOrEqual': locationBillingAddressIdGreaterThanOrEqual,
                'locationBillingAddressId.lessThanOrEqual': locationBillingAddressIdLessThanOrEqual,
                'locationBillingAddressId.equals': locationBillingAddressIdEquals,
                'locationBillingAddressId.notEquals': locationBillingAddressIdNotEquals,
                'locationBillingAddressId.specified': locationBillingAddressIdSpecified,
                'locationBillingAddressId.in': locationBillingAddressIdIn,
                'locationBillingAddressId.notIn': locationBillingAddressIdNotIn,
                'pharmacyStoreId.greaterThan': pharmacyStoreIdGreaterThan,
                'pharmacyStoreId.lessThan': pharmacyStoreIdLessThan,
                'pharmacyStoreId.greaterThanOrEqual': pharmacyStoreIdGreaterThanOrEqual,
                'pharmacyStoreId.lessThanOrEqual': pharmacyStoreIdLessThanOrEqual,
                'pharmacyStoreId.equals': pharmacyStoreIdEquals,
                'pharmacyStoreId.notEquals': pharmacyStoreIdNotEquals,
                'pharmacyStoreId.specified': pharmacyStoreIdSpecified,
                'pharmacyStoreId.in': pharmacyStoreIdIn,
                'pharmacyStoreId.notIn': pharmacyStoreIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'insurancePolicyHolderId.greaterThan': insurancePolicyHolderIdGreaterThan,
                'insurancePolicyHolderId.lessThan': insurancePolicyHolderIdLessThan,
                'insurancePolicyHolderId.greaterThanOrEqual': insurancePolicyHolderIdGreaterThanOrEqual,
                'insurancePolicyHolderId.lessThanOrEqual': insurancePolicyHolderIdLessThanOrEqual,
                'insurancePolicyHolderId.equals': insurancePolicyHolderIdEquals,
                'insurancePolicyHolderId.notEquals': insurancePolicyHolderIdNotEquals,
                'insurancePolicyHolderId.specified': insurancePolicyHolderIdSpecified,
                'insurancePolicyHolderId.in': insurancePolicyHolderIdIn,
                'insurancePolicyHolderId.notIn': insurancePolicyHolderIdNotIn,
                'diagnosticCentreId.greaterThan': diagnosticCentreIdGreaterThan,
                'diagnosticCentreId.lessThan': diagnosticCentreIdLessThan,
                'diagnosticCentreId.greaterThanOrEqual': diagnosticCentreIdGreaterThanOrEqual,
                'diagnosticCentreId.lessThanOrEqual': diagnosticCentreIdLessThanOrEqual,
                'diagnosticCentreId.equals': diagnosticCentreIdEquals,
                'diagnosticCentreId.notEquals': diagnosticCentreIdNotEquals,
                'diagnosticCentreId.specified': diagnosticCentreIdSpecified,
                'diagnosticCentreId.in': diagnosticCentreIdIn,
                'diagnosticCentreId.notIn': diagnosticCentreIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
