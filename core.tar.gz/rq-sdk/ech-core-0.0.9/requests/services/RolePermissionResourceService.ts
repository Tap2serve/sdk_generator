/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RolePermissionDTO } from '../models/RolePermissionDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class RolePermissionResourceService {

    /**
     * @param id
     * @returns RolePermissionDTO OK
     * @throws ApiError
     */
    public static getRolePermission(
        id: number,
    ): CancelablePromise<RolePermissionDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/role-permissions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns RolePermissionDTO OK
     * @throws ApiError
     */
    public static updateRolePermission(
        id: number,
        requestBody: RolePermissionDTO,
    ): CancelablePromise<RolePermissionDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/role-permissions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteRolePermission(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/role-permissions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns RolePermissionDTO OK
     * @throws ApiError
     */
    public static partialUpdateRolePermission(
        id: number,
        requestBody: RolePermissionDTO,
    ): CancelablePromise<RolePermissionDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/role-permissions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param roleIdIdGreaterThan
     * @param roleIdIdLessThan
     * @param roleIdIdGreaterThanOrEqual
     * @param roleIdIdLessThanOrEqual
     * @param roleIdIdEquals
     * @param roleIdIdNotEquals
     * @param roleIdIdSpecified
     * @param roleIdIdIn
     * @param roleIdIdNotIn
     * @param permissionIdIdGreaterThan
     * @param permissionIdIdLessThan
     * @param permissionIdIdGreaterThanOrEqual
     * @param permissionIdIdLessThanOrEqual
     * @param permissionIdIdEquals
     * @param permissionIdIdNotEquals
     * @param permissionIdIdSpecified
     * @param permissionIdIdIn
     * @param permissionIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns RolePermissionDTO OK
     * @throws ApiError
     */
    public static getAllRolePermissions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        roleIdIdGreaterThan?: number,
        roleIdIdLessThan?: number,
        roleIdIdGreaterThanOrEqual?: number,
        roleIdIdLessThanOrEqual?: number,
        roleIdIdEquals?: number,
        roleIdIdNotEquals?: number,
        roleIdIdSpecified?: boolean,
        roleIdIdIn?: Array<number>,
        roleIdIdNotIn?: Array<number>,
        permissionIdIdGreaterThan?: number,
        permissionIdIdLessThan?: number,
        permissionIdIdGreaterThanOrEqual?: number,
        permissionIdIdLessThanOrEqual?: number,
        permissionIdIdEquals?: number,
        permissionIdIdNotEquals?: number,
        permissionIdIdSpecified?: boolean,
        permissionIdIdIn?: Array<number>,
        permissionIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<RolePermissionDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/role-permissions',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'roleIdId.greaterThan': roleIdIdGreaterThan,
                'roleIdId.lessThan': roleIdIdLessThan,
                'roleIdId.greaterThanOrEqual': roleIdIdGreaterThanOrEqual,
                'roleIdId.lessThanOrEqual': roleIdIdLessThanOrEqual,
                'roleIdId.equals': roleIdIdEquals,
                'roleIdId.notEquals': roleIdIdNotEquals,
                'roleIdId.specified': roleIdIdSpecified,
                'roleIdId.in': roleIdIdIn,
                'roleIdId.notIn': roleIdIdNotIn,
                'permissionIdId.greaterThan': permissionIdIdGreaterThan,
                'permissionIdId.lessThan': permissionIdIdLessThan,
                'permissionIdId.greaterThanOrEqual': permissionIdIdGreaterThanOrEqual,
                'permissionIdId.lessThanOrEqual': permissionIdIdLessThanOrEqual,
                'permissionIdId.equals': permissionIdIdEquals,
                'permissionIdId.notEquals': permissionIdIdNotEquals,
                'permissionIdId.specified': permissionIdIdSpecified,
                'permissionIdId.in': permissionIdIdIn,
                'permissionIdId.notIn': permissionIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns RolePermissionDTO OK
     * @throws ApiError
     */
    public static createRolePermission(
        requestBody: RolePermissionDTO,
    ): CancelablePromise<RolePermissionDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/role-permissions',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param roleIdIdGreaterThan
     * @param roleIdIdLessThan
     * @param roleIdIdGreaterThanOrEqual
     * @param roleIdIdLessThanOrEqual
     * @param roleIdIdEquals
     * @param roleIdIdNotEquals
     * @param roleIdIdSpecified
     * @param roleIdIdIn
     * @param roleIdIdNotIn
     * @param permissionIdIdGreaterThan
     * @param permissionIdIdLessThan
     * @param permissionIdIdGreaterThanOrEqual
     * @param permissionIdIdLessThanOrEqual
     * @param permissionIdIdEquals
     * @param permissionIdIdNotEquals
     * @param permissionIdIdSpecified
     * @param permissionIdIdIn
     * @param permissionIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countRolePermissions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        roleIdIdGreaterThan?: number,
        roleIdIdLessThan?: number,
        roleIdIdGreaterThanOrEqual?: number,
        roleIdIdLessThanOrEqual?: number,
        roleIdIdEquals?: number,
        roleIdIdNotEquals?: number,
        roleIdIdSpecified?: boolean,
        roleIdIdIn?: Array<number>,
        roleIdIdNotIn?: Array<number>,
        permissionIdIdGreaterThan?: number,
        permissionIdIdLessThan?: number,
        permissionIdIdGreaterThanOrEqual?: number,
        permissionIdIdLessThanOrEqual?: number,
        permissionIdIdEquals?: number,
        permissionIdIdNotEquals?: number,
        permissionIdIdSpecified?: boolean,
        permissionIdIdIn?: Array<number>,
        permissionIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/role-permissions/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'roleIdId.greaterThan': roleIdIdGreaterThan,
                'roleIdId.lessThan': roleIdIdLessThan,
                'roleIdId.greaterThanOrEqual': roleIdIdGreaterThanOrEqual,
                'roleIdId.lessThanOrEqual': roleIdIdLessThanOrEqual,
                'roleIdId.equals': roleIdIdEquals,
                'roleIdId.notEquals': roleIdIdNotEquals,
                'roleIdId.specified': roleIdIdSpecified,
                'roleIdId.in': roleIdIdIn,
                'roleIdId.notIn': roleIdIdNotIn,
                'permissionIdId.greaterThan': permissionIdIdGreaterThan,
                'permissionIdId.lessThan': permissionIdIdLessThan,
                'permissionIdId.greaterThanOrEqual': permissionIdIdGreaterThanOrEqual,
                'permissionIdId.lessThanOrEqual': permissionIdIdLessThanOrEqual,
                'permissionIdId.equals': permissionIdIdEquals,
                'permissionIdId.notEquals': permissionIdIdNotEquals,
                'permissionIdId.specified': permissionIdIdSpecified,
                'permissionIdId.in': permissionIdIdIn,
                'permissionIdId.notIn': permissionIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
