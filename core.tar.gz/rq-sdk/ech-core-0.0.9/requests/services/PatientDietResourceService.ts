/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientDietDTO } from '../models/PatientDietDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientDietResourceService {

    /**
     * @param id
     * @returns PatientDietDTO OK
     * @throws ApiError
     */
    public static getPatientDiet(
        id: number,
    ): CancelablePromise<PatientDietDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-diets/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientDietDTO OK
     * @throws ApiError
     */
    public static updatePatientDiet(
        id: number,
        requestBody: PatientDietDTO,
    ): CancelablePromise<PatientDietDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-diets/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientDiet(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-diets/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientDietDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientDiet(
        id: number,
        requestBody: PatientDietDTO,
    ): CancelablePromise<PatientDietDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-diets/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientDietDTO OK
     * @throws ApiError
     */
    public static getAllPatientDiets(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientDietDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-diets',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientDietDTO OK
     * @throws ApiError
     */
    public static createPatientDiet(
        requestBody: PatientDietDTO,
    ): CancelablePromise<PatientDietDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-diets',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientDiets(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-diets/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
