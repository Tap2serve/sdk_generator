/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { NotificationDTO } from '../models/NotificationDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class NotificationResourceService {

    /**
     * @param id
     * @returns NotificationDTO OK
     * @throws ApiError
     */
    public static getNotification(
        id: number,
    ): CancelablePromise<NotificationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/notifications/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns NotificationDTO OK
     * @throws ApiError
     */
    public static updateNotification(
        id: number,
        requestBody: NotificationDTO,
    ): CancelablePromise<NotificationDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/notifications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteNotification(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/notifications/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns NotificationDTO OK
     * @throws ApiError
     */
    public static partialUpdateNotification(
        id: number,
        requestBody: NotificationDTO,
    ): CancelablePromise<NotificationDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/notifications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param dateGreaterThan
     * @param dateLessThan
     * @param dateGreaterThanOrEqual
     * @param dateLessThanOrEqual
     * @param dateEquals
     * @param dateNotEquals
     * @param dateSpecified
     * @param dateIn
     * @param dateNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param messageContains
     * @param messageDoesNotContain
     * @param messageEquals
     * @param messageNotEquals
     * @param messageSpecified
     * @param messageIn
     * @param messageNotIn
     * @param consumedEquals
     * @param consumedNotEquals
     * @param consumedSpecified
     * @param consumedIn
     * @param consumedNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param receipientIdGreaterThan
     * @param receipientIdLessThan
     * @param receipientIdGreaterThanOrEqual
     * @param receipientIdLessThanOrEqual
     * @param receipientIdEquals
     * @param receipientIdNotEquals
     * @param receipientIdSpecified
     * @param receipientIdIn
     * @param receipientIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns NotificationDTO OK
     * @throws ApiError
     */
    public static getAllNotifications(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        dateGreaterThan?: string,
        dateLessThan?: string,
        dateGreaterThanOrEqual?: string,
        dateLessThanOrEqual?: string,
        dateEquals?: string,
        dateNotEquals?: string,
        dateSpecified?: boolean,
        dateIn?: Array<string>,
        dateNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        messageContains?: string,
        messageDoesNotContain?: string,
        messageEquals?: string,
        messageNotEquals?: string,
        messageSpecified?: boolean,
        messageIn?: Array<string>,
        messageNotIn?: Array<string>,
        consumedEquals?: boolean,
        consumedNotEquals?: boolean,
        consumedSpecified?: boolean,
        consumedIn?: Array<boolean>,
        consumedNotIn?: Array<boolean>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        receipientIdGreaterThan?: number,
        receipientIdLessThan?: number,
        receipientIdGreaterThanOrEqual?: number,
        receipientIdLessThanOrEqual?: number,
        receipientIdEquals?: number,
        receipientIdNotEquals?: number,
        receipientIdSpecified?: boolean,
        receipientIdIn?: Array<number>,
        receipientIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<NotificationDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/notifications',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'date.greaterThan': dateGreaterThan,
                'date.lessThan': dateLessThan,
                'date.greaterThanOrEqual': dateGreaterThanOrEqual,
                'date.lessThanOrEqual': dateLessThanOrEqual,
                'date.equals': dateEquals,
                'date.notEquals': dateNotEquals,
                'date.specified': dateSpecified,
                'date.in': dateIn,
                'date.notIn': dateNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'message.contains': messageContains,
                'message.doesNotContain': messageDoesNotContain,
                'message.equals': messageEquals,
                'message.notEquals': messageNotEquals,
                'message.specified': messageSpecified,
                'message.in': messageIn,
                'message.notIn': messageNotIn,
                'consumed.equals': consumedEquals,
                'consumed.notEquals': consumedNotEquals,
                'consumed.specified': consumedSpecified,
                'consumed.in': consumedIn,
                'consumed.notIn': consumedNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'receipientId.greaterThan': receipientIdGreaterThan,
                'receipientId.lessThan': receipientIdLessThan,
                'receipientId.greaterThanOrEqual': receipientIdGreaterThanOrEqual,
                'receipientId.lessThanOrEqual': receipientIdLessThanOrEqual,
                'receipientId.equals': receipientIdEquals,
                'receipientId.notEquals': receipientIdNotEquals,
                'receipientId.specified': receipientIdSpecified,
                'receipientId.in': receipientIdIn,
                'receipientId.notIn': receipientIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns NotificationDTO OK
     * @throws ApiError
     */
    public static createNotification(
        requestBody: NotificationDTO,
    ): CancelablePromise<NotificationDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/notifications',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param dateGreaterThan
     * @param dateLessThan
     * @param dateGreaterThanOrEqual
     * @param dateLessThanOrEqual
     * @param dateEquals
     * @param dateNotEquals
     * @param dateSpecified
     * @param dateIn
     * @param dateNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param messageContains
     * @param messageDoesNotContain
     * @param messageEquals
     * @param messageNotEquals
     * @param messageSpecified
     * @param messageIn
     * @param messageNotIn
     * @param consumedEquals
     * @param consumedNotEquals
     * @param consumedSpecified
     * @param consumedIn
     * @param consumedNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param receipientIdGreaterThan
     * @param receipientIdLessThan
     * @param receipientIdGreaterThanOrEqual
     * @param receipientIdLessThanOrEqual
     * @param receipientIdEquals
     * @param receipientIdNotEquals
     * @param receipientIdSpecified
     * @param receipientIdIn
     * @param receipientIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countNotifications(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        dateGreaterThan?: string,
        dateLessThan?: string,
        dateGreaterThanOrEqual?: string,
        dateLessThanOrEqual?: string,
        dateEquals?: string,
        dateNotEquals?: string,
        dateSpecified?: boolean,
        dateIn?: Array<string>,
        dateNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        messageContains?: string,
        messageDoesNotContain?: string,
        messageEquals?: string,
        messageNotEquals?: string,
        messageSpecified?: boolean,
        messageIn?: Array<string>,
        messageNotIn?: Array<string>,
        consumedEquals?: boolean,
        consumedNotEquals?: boolean,
        consumedSpecified?: boolean,
        consumedIn?: Array<boolean>,
        consumedNotIn?: Array<boolean>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        receipientIdGreaterThan?: number,
        receipientIdLessThan?: number,
        receipientIdGreaterThanOrEqual?: number,
        receipientIdLessThanOrEqual?: number,
        receipientIdEquals?: number,
        receipientIdNotEquals?: number,
        receipientIdSpecified?: boolean,
        receipientIdIn?: Array<number>,
        receipientIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/notifications/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'date.greaterThan': dateGreaterThan,
                'date.lessThan': dateLessThan,
                'date.greaterThanOrEqual': dateGreaterThanOrEqual,
                'date.lessThanOrEqual': dateLessThanOrEqual,
                'date.equals': dateEquals,
                'date.notEquals': dateNotEquals,
                'date.specified': dateSpecified,
                'date.in': dateIn,
                'date.notIn': dateNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'message.contains': messageContains,
                'message.doesNotContain': messageDoesNotContain,
                'message.equals': messageEquals,
                'message.notEquals': messageNotEquals,
                'message.specified': messageSpecified,
                'message.in': messageIn,
                'message.notIn': messageNotIn,
                'consumed.equals': consumedEquals,
                'consumed.notEquals': consumedNotEquals,
                'consumed.specified': consumedSpecified,
                'consumed.in': consumedIn,
                'consumed.notIn': consumedNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'receipientId.greaterThan': receipientIdGreaterThan,
                'receipientId.lessThan': receipientIdLessThan,
                'receipientId.greaterThanOrEqual': receipientIdGreaterThanOrEqual,
                'receipientId.lessThanOrEqual': receipientIdLessThanOrEqual,
                'receipientId.equals': receipientIdEquals,
                'receipientId.notEquals': receipientIdNotEquals,
                'receipientId.specified': receipientIdSpecified,
                'receipientId.in': receipientIdIn,
                'receipientId.notIn': receipientIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
