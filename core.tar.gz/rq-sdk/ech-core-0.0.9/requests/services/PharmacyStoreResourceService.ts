/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PharmacyStoreDTO } from '../models/PharmacyStoreDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PharmacyStoreResourceService {

    /**
     * @param id
     * @returns PharmacyStoreDTO OK
     * @throws ApiError
     */
    public static getPharmacyStore(
        id: number,
    ): CancelablePromise<PharmacyStoreDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/pharmacy-stores/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PharmacyStoreDTO OK
     * @throws ApiError
     */
    public static updatePharmacyStore(
        id: number,
        requestBody: PharmacyStoreDTO,
    ): CancelablePromise<PharmacyStoreDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/pharmacy-stores/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePharmacyStore(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/pharmacy-stores/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PharmacyStoreDTO OK
     * @throws ApiError
     */
    public static partialUpdatePharmacyStore(
        id: number,
        requestBody: PharmacyStoreDTO,
    ): CancelablePromise<PharmacyStoreDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/pharmacy-stores/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param contactNumberContains
     * @param contactNumberDoesNotContain
     * @param contactNumberEquals
     * @param contactNumberNotEquals
     * @param contactNumberSpecified
     * @param contactNumberIn
     * @param contactNumberNotIn
     * @param faxNumberContains
     * @param faxNumberDoesNotContain
     * @param faxNumberEquals
     * @param faxNumberNotEquals
     * @param faxNumberSpecified
     * @param faxNumberIn
     * @param faxNumberNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param addressIdIdGreaterThan
     * @param addressIdIdLessThan
     * @param addressIdIdGreaterThanOrEqual
     * @param addressIdIdLessThanOrEqual
     * @param addressIdIdEquals
     * @param addressIdIdNotEquals
     * @param addressIdIdSpecified
     * @param addressIdIdIn
     * @param addressIdIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PharmacyStoreDTO OK
     * @throws ApiError
     */
    public static getAllPharmacyStores(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        contactNumberContains?: string,
        contactNumberDoesNotContain?: string,
        contactNumberEquals?: string,
        contactNumberNotEquals?: string,
        contactNumberSpecified?: boolean,
        contactNumberIn?: Array<string>,
        contactNumberNotIn?: Array<string>,
        faxNumberContains?: string,
        faxNumberDoesNotContain?: string,
        faxNumberEquals?: string,
        faxNumberNotEquals?: string,
        faxNumberSpecified?: boolean,
        faxNumberIn?: Array<string>,
        faxNumberNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        addressIdIdGreaterThan?: number,
        addressIdIdLessThan?: number,
        addressIdIdGreaterThanOrEqual?: number,
        addressIdIdLessThanOrEqual?: number,
        addressIdIdEquals?: number,
        addressIdIdNotEquals?: number,
        addressIdIdSpecified?: boolean,
        addressIdIdIn?: Array<number>,
        addressIdIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PharmacyStoreDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/pharmacy-stores',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'contactNumber.contains': contactNumberContains,
                'contactNumber.doesNotContain': contactNumberDoesNotContain,
                'contactNumber.equals': contactNumberEquals,
                'contactNumber.notEquals': contactNumberNotEquals,
                'contactNumber.specified': contactNumberSpecified,
                'contactNumber.in': contactNumberIn,
                'contactNumber.notIn': contactNumberNotIn,
                'faxNumber.contains': faxNumberContains,
                'faxNumber.doesNotContain': faxNumberDoesNotContain,
                'faxNumber.equals': faxNumberEquals,
                'faxNumber.notEquals': faxNumberNotEquals,
                'faxNumber.specified': faxNumberSpecified,
                'faxNumber.in': faxNumberIn,
                'faxNumber.notIn': faxNumberNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'addressIdId.greaterThan': addressIdIdGreaterThan,
                'addressIdId.lessThan': addressIdIdLessThan,
                'addressIdId.greaterThanOrEqual': addressIdIdGreaterThanOrEqual,
                'addressIdId.lessThanOrEqual': addressIdIdLessThanOrEqual,
                'addressIdId.equals': addressIdIdEquals,
                'addressIdId.notEquals': addressIdIdNotEquals,
                'addressIdId.specified': addressIdIdSpecified,
                'addressIdId.in': addressIdIdIn,
                'addressIdId.notIn': addressIdIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PharmacyStoreDTO OK
     * @throws ApiError
     */
    public static createPharmacyStore(
        requestBody: PharmacyStoreDTO,
    ): CancelablePromise<PharmacyStoreDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/pharmacy-stores',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param contactNumberContains
     * @param contactNumberDoesNotContain
     * @param contactNumberEquals
     * @param contactNumberNotEquals
     * @param contactNumberSpecified
     * @param contactNumberIn
     * @param contactNumberNotIn
     * @param faxNumberContains
     * @param faxNumberDoesNotContain
     * @param faxNumberEquals
     * @param faxNumberNotEquals
     * @param faxNumberSpecified
     * @param faxNumberIn
     * @param faxNumberNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param addressIdIdGreaterThan
     * @param addressIdIdLessThan
     * @param addressIdIdGreaterThanOrEqual
     * @param addressIdIdLessThanOrEqual
     * @param addressIdIdEquals
     * @param addressIdIdNotEquals
     * @param addressIdIdSpecified
     * @param addressIdIdIn
     * @param addressIdIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPharmacyStores(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        contactNumberContains?: string,
        contactNumberDoesNotContain?: string,
        contactNumberEquals?: string,
        contactNumberNotEquals?: string,
        contactNumberSpecified?: boolean,
        contactNumberIn?: Array<string>,
        contactNumberNotIn?: Array<string>,
        faxNumberContains?: string,
        faxNumberDoesNotContain?: string,
        faxNumberEquals?: string,
        faxNumberNotEquals?: string,
        faxNumberSpecified?: boolean,
        faxNumberIn?: Array<string>,
        faxNumberNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        addressIdIdGreaterThan?: number,
        addressIdIdLessThan?: number,
        addressIdIdGreaterThanOrEqual?: number,
        addressIdIdLessThanOrEqual?: number,
        addressIdIdEquals?: number,
        addressIdIdNotEquals?: number,
        addressIdIdSpecified?: boolean,
        addressIdIdIn?: Array<number>,
        addressIdIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/pharmacy-stores/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'contactNumber.contains': contactNumberContains,
                'contactNumber.doesNotContain': contactNumberDoesNotContain,
                'contactNumber.equals': contactNumberEquals,
                'contactNumber.notEquals': contactNumberNotEquals,
                'contactNumber.specified': contactNumberSpecified,
                'contactNumber.in': contactNumberIn,
                'contactNumber.notIn': contactNumberNotIn,
                'faxNumber.contains': faxNumberContains,
                'faxNumber.doesNotContain': faxNumberDoesNotContain,
                'faxNumber.equals': faxNumberEquals,
                'faxNumber.notEquals': faxNumberNotEquals,
                'faxNumber.specified': faxNumberSpecified,
                'faxNumber.in': faxNumberIn,
                'faxNumber.notIn': faxNumberNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'addressIdId.greaterThan': addressIdIdGreaterThan,
                'addressIdId.lessThan': addressIdIdLessThan,
                'addressIdId.greaterThanOrEqual': addressIdIdGreaterThanOrEqual,
                'addressIdId.lessThanOrEqual': addressIdIdLessThanOrEqual,
                'addressIdId.equals': addressIdIdEquals,
                'addressIdId.notEquals': addressIdIdNotEquals,
                'addressIdId.specified': addressIdIdSpecified,
                'addressIdId.in': addressIdIdIn,
                'addressIdId.notIn': addressIdIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
