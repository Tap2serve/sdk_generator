/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeMedicalHistoryDTO } from '../models/IntakeMedicalHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeMedicalHistoryResourceService {

    /**
     * @param id
     * @returns IntakeMedicalHistoryDTO OK
     * @throws ApiError
     */
    public static getIntakeMedicalHistory(
        id: number,
    ): CancelablePromise<IntakeMedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medical-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeMedicalHistoryDTO OK
     * @throws ApiError
     */
    public static updateIntakeMedicalHistory(
        id: number,
        requestBody: IntakeMedicalHistoryDTO,
    ): CancelablePromise<IntakeMedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-medical-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeMedicalHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-medical-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeMedicalHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeMedicalHistory(
        id: number,
        requestBody: IntakeMedicalHistoryDTO,
    ): CancelablePromise<IntakeMedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-medical-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param medicalHistoryIdIdGreaterThan
     * @param medicalHistoryIdIdLessThan
     * @param medicalHistoryIdIdGreaterThanOrEqual
     * @param medicalHistoryIdIdLessThanOrEqual
     * @param medicalHistoryIdIdEquals
     * @param medicalHistoryIdIdNotEquals
     * @param medicalHistoryIdIdSpecified
     * @param medicalHistoryIdIdIn
     * @param medicalHistoryIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeMedicalHistoryDTO OK
     * @throws ApiError
     */
    public static getAllIntakeMedicalHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        medicalHistoryIdIdGreaterThan?: number,
        medicalHistoryIdIdLessThan?: number,
        medicalHistoryIdIdGreaterThanOrEqual?: number,
        medicalHistoryIdIdLessThanOrEqual?: number,
        medicalHistoryIdIdEquals?: number,
        medicalHistoryIdIdNotEquals?: number,
        medicalHistoryIdIdSpecified?: boolean,
        medicalHistoryIdIdIn?: Array<number>,
        medicalHistoryIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeMedicalHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medical-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'medicalHistoryIdId.greaterThan': medicalHistoryIdIdGreaterThan,
                'medicalHistoryIdId.lessThan': medicalHistoryIdIdLessThan,
                'medicalHistoryIdId.greaterThanOrEqual': medicalHistoryIdIdGreaterThanOrEqual,
                'medicalHistoryIdId.lessThanOrEqual': medicalHistoryIdIdLessThanOrEqual,
                'medicalHistoryIdId.equals': medicalHistoryIdIdEquals,
                'medicalHistoryIdId.notEquals': medicalHistoryIdIdNotEquals,
                'medicalHistoryIdId.specified': medicalHistoryIdIdSpecified,
                'medicalHistoryIdId.in': medicalHistoryIdIdIn,
                'medicalHistoryIdId.notIn': medicalHistoryIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeMedicalHistoryDTO OK
     * @throws ApiError
     */
    public static createIntakeMedicalHistory(
        requestBody: IntakeMedicalHistoryDTO,
    ): CancelablePromise<IntakeMedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-medical-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param medicalHistoryIdIdGreaterThan
     * @param medicalHistoryIdIdLessThan
     * @param medicalHistoryIdIdGreaterThanOrEqual
     * @param medicalHistoryIdIdLessThanOrEqual
     * @param medicalHistoryIdIdEquals
     * @param medicalHistoryIdIdNotEquals
     * @param medicalHistoryIdIdSpecified
     * @param medicalHistoryIdIdIn
     * @param medicalHistoryIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeMedicalHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        medicalHistoryIdIdGreaterThan?: number,
        medicalHistoryIdIdLessThan?: number,
        medicalHistoryIdIdGreaterThanOrEqual?: number,
        medicalHistoryIdIdLessThanOrEqual?: number,
        medicalHistoryIdIdEquals?: number,
        medicalHistoryIdIdNotEquals?: number,
        medicalHistoryIdIdSpecified?: boolean,
        medicalHistoryIdIdIn?: Array<number>,
        medicalHistoryIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-medical-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'medicalHistoryIdId.greaterThan': medicalHistoryIdIdGreaterThan,
                'medicalHistoryIdId.lessThan': medicalHistoryIdIdLessThan,
                'medicalHistoryIdId.greaterThanOrEqual': medicalHistoryIdIdGreaterThanOrEqual,
                'medicalHistoryIdId.lessThanOrEqual': medicalHistoryIdIdLessThanOrEqual,
                'medicalHistoryIdId.equals': medicalHistoryIdIdEquals,
                'medicalHistoryIdId.notEquals': medicalHistoryIdIdNotEquals,
                'medicalHistoryIdId.specified': medicalHistoryIdIdSpecified,
                'medicalHistoryIdId.in': medicalHistoryIdIdIn,
                'medicalHistoryIdId.notIn': medicalHistoryIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
