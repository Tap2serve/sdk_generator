/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FeeScheduleDTO } from '../models/FeeScheduleDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class FeeScheduleResourceService {

    /**
     * @param id
     * @returns FeeScheduleDTO OK
     * @throws ApiError
     */
    public static getFeeSchedule(
        id: number,
    ): CancelablePromise<FeeScheduleDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/fee-schedules/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns FeeScheduleDTO OK
     * @throws ApiError
     */
    public static updateFeeSchedule(
        id: number,
        requestBody: FeeScheduleDTO,
    ): CancelablePromise<FeeScheduleDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/fee-schedules/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns FeeScheduleDTO OK
     * @throws ApiError
     */
    public static partialUpdateFeeSchedule(
        id: number,
        requestBody: FeeScheduleDTO,
    ): CancelablePromise<FeeScheduleDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/fee-schedules/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeTypeContains
     * @param codeTypeDoesNotContain
     * @param codeTypeEquals
     * @param codeTypeNotEquals
     * @param codeTypeSpecified
     * @param codeTypeIn
     * @param codeTypeNotIn
     * @param procedureCodeContains
     * @param procedureCodeDoesNotContain
     * @param procedureCodeEquals
     * @param procedureCodeNotEquals
     * @param procedureCodeSpecified
     * @param procedureCodeIn
     * @param procedureCodeNotIn
     * @param modifierContains
     * @param modifierDoesNotContain
     * @param modifierEquals
     * @param modifierNotEquals
     * @param modifierSpecified
     * @param modifierIn
     * @param modifierNotIn
     * @param ndcCodeContains
     * @param ndcCodeDoesNotContain
     * @param ndcCodeEquals
     * @param ndcCodeNotEquals
     * @param ndcCodeSpecified
     * @param ndcCodeIn
     * @param ndcCodeNotIn
     * @param amountGreaterThan
     * @param amountLessThan
     * @param amountGreaterThanOrEqual
     * @param amountLessThanOrEqual
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param ndcQuantityGreaterThan
     * @param ndcQuantityLessThan
     * @param ndcQuantityGreaterThanOrEqual
     * @param ndcQuantityLessThanOrEqual
     * @param ndcQuantityEquals
     * @param ndcQuantityNotEquals
     * @param ndcQuantitySpecified
     * @param ndcQuantityIn
     * @param ndcQuantityNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns FeeScheduleDTO OK
     * @throws ApiError
     */
    public static getAllFeeSchedules(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeTypeContains?: string,
        codeTypeDoesNotContain?: string,
        codeTypeEquals?: string,
        codeTypeNotEquals?: string,
        codeTypeSpecified?: boolean,
        codeTypeIn?: Array<string>,
        codeTypeNotIn?: Array<string>,
        procedureCodeContains?: string,
        procedureCodeDoesNotContain?: string,
        procedureCodeEquals?: string,
        procedureCodeNotEquals?: string,
        procedureCodeSpecified?: boolean,
        procedureCodeIn?: Array<string>,
        procedureCodeNotIn?: Array<string>,
        modifierContains?: string,
        modifierDoesNotContain?: string,
        modifierEquals?: string,
        modifierNotEquals?: string,
        modifierSpecified?: boolean,
        modifierIn?: Array<string>,
        modifierNotIn?: Array<string>,
        ndcCodeContains?: string,
        ndcCodeDoesNotContain?: string,
        ndcCodeEquals?: string,
        ndcCodeNotEquals?: string,
        ndcCodeSpecified?: boolean,
        ndcCodeIn?: Array<string>,
        ndcCodeNotIn?: Array<string>,
        amountGreaterThan?: number,
        amountLessThan?: number,
        amountGreaterThanOrEqual?: number,
        amountLessThanOrEqual?: number,
        amountEquals?: number,
        amountNotEquals?: number,
        amountSpecified?: boolean,
        amountIn?: Array<number>,
        amountNotIn?: Array<number>,
        ndcQuantityGreaterThan?: number,
        ndcQuantityLessThan?: number,
        ndcQuantityGreaterThanOrEqual?: number,
        ndcQuantityLessThanOrEqual?: number,
        ndcQuantityEquals?: number,
        ndcQuantityNotEquals?: number,
        ndcQuantitySpecified?: boolean,
        ndcQuantityIn?: Array<number>,
        ndcQuantityNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<FeeScheduleDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/fee-schedules',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'codeType.contains': codeTypeContains,
                'codeType.doesNotContain': codeTypeDoesNotContain,
                'codeType.equals': codeTypeEquals,
                'codeType.notEquals': codeTypeNotEquals,
                'codeType.specified': codeTypeSpecified,
                'codeType.in': codeTypeIn,
                'codeType.notIn': codeTypeNotIn,
                'procedureCode.contains': procedureCodeContains,
                'procedureCode.doesNotContain': procedureCodeDoesNotContain,
                'procedureCode.equals': procedureCodeEquals,
                'procedureCode.notEquals': procedureCodeNotEquals,
                'procedureCode.specified': procedureCodeSpecified,
                'procedureCode.in': procedureCodeIn,
                'procedureCode.notIn': procedureCodeNotIn,
                'modifier.contains': modifierContains,
                'modifier.doesNotContain': modifierDoesNotContain,
                'modifier.equals': modifierEquals,
                'modifier.notEquals': modifierNotEquals,
                'modifier.specified': modifierSpecified,
                'modifier.in': modifierIn,
                'modifier.notIn': modifierNotIn,
                'ndcCode.contains': ndcCodeContains,
                'ndcCode.doesNotContain': ndcCodeDoesNotContain,
                'ndcCode.equals': ndcCodeEquals,
                'ndcCode.notEquals': ndcCodeNotEquals,
                'ndcCode.specified': ndcCodeSpecified,
                'ndcCode.in': ndcCodeIn,
                'ndcCode.notIn': ndcCodeNotIn,
                'amount.greaterThan': amountGreaterThan,
                'amount.lessThan': amountLessThan,
                'amount.greaterThanOrEqual': amountGreaterThanOrEqual,
                'amount.lessThanOrEqual': amountLessThanOrEqual,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'ndcQuantity.greaterThan': ndcQuantityGreaterThan,
                'ndcQuantity.lessThan': ndcQuantityLessThan,
                'ndcQuantity.greaterThanOrEqual': ndcQuantityGreaterThanOrEqual,
                'ndcQuantity.lessThanOrEqual': ndcQuantityLessThanOrEqual,
                'ndcQuantity.equals': ndcQuantityEquals,
                'ndcQuantity.notEquals': ndcQuantityNotEquals,
                'ndcQuantity.specified': ndcQuantitySpecified,
                'ndcQuantity.in': ndcQuantityIn,
                'ndcQuantity.notIn': ndcQuantityNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns FeeScheduleDTO OK
     * @throws ApiError
     */
    public static createFeeSchedule(
        requestBody: FeeScheduleDTO,
    ): CancelablePromise<FeeScheduleDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/fee-schedules',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param feeScheduleUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deleteFeeSchedule(
        feeScheduleUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/fee-schedules/{feeScheduleUuid}',
            path: {
                'feeScheduleUuid': feeScheduleUuid,
            },
        });
    }

    /**
     * @param activeStatus
     * @param feeScheduleUuid
     * @returns any OK
     * @throws ApiError
     */
    public static changeActiveStatus(
        activeStatus: boolean,
        feeScheduleUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/fee-schedules/{feeScheduleUuid}',
            path: {
                'feeScheduleUuid': feeScheduleUuid,
            },
            query: {
                'activeStatus': activeStatus,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeTypeContains
     * @param codeTypeDoesNotContain
     * @param codeTypeEquals
     * @param codeTypeNotEquals
     * @param codeTypeSpecified
     * @param codeTypeIn
     * @param codeTypeNotIn
     * @param procedureCodeContains
     * @param procedureCodeDoesNotContain
     * @param procedureCodeEquals
     * @param procedureCodeNotEquals
     * @param procedureCodeSpecified
     * @param procedureCodeIn
     * @param procedureCodeNotIn
     * @param modifierContains
     * @param modifierDoesNotContain
     * @param modifierEquals
     * @param modifierNotEquals
     * @param modifierSpecified
     * @param modifierIn
     * @param modifierNotIn
     * @param ndcCodeContains
     * @param ndcCodeDoesNotContain
     * @param ndcCodeEquals
     * @param ndcCodeNotEquals
     * @param ndcCodeSpecified
     * @param ndcCodeIn
     * @param ndcCodeNotIn
     * @param amountGreaterThan
     * @param amountLessThan
     * @param amountGreaterThanOrEqual
     * @param amountLessThanOrEqual
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param ndcQuantityGreaterThan
     * @param ndcQuantityLessThan
     * @param ndcQuantityGreaterThanOrEqual
     * @param ndcQuantityLessThanOrEqual
     * @param ndcQuantityEquals
     * @param ndcQuantityNotEquals
     * @param ndcQuantitySpecified
     * @param ndcQuantityIn
     * @param ndcQuantityNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param providerIdIdGreaterThan
     * @param providerIdIdLessThan
     * @param providerIdIdGreaterThanOrEqual
     * @param providerIdIdLessThanOrEqual
     * @param providerIdIdEquals
     * @param providerIdIdNotEquals
     * @param providerIdIdSpecified
     * @param providerIdIdIn
     * @param providerIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countFeeSchedules(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeTypeContains?: string,
        codeTypeDoesNotContain?: string,
        codeTypeEquals?: string,
        codeTypeNotEquals?: string,
        codeTypeSpecified?: boolean,
        codeTypeIn?: Array<string>,
        codeTypeNotIn?: Array<string>,
        procedureCodeContains?: string,
        procedureCodeDoesNotContain?: string,
        procedureCodeEquals?: string,
        procedureCodeNotEquals?: string,
        procedureCodeSpecified?: boolean,
        procedureCodeIn?: Array<string>,
        procedureCodeNotIn?: Array<string>,
        modifierContains?: string,
        modifierDoesNotContain?: string,
        modifierEquals?: string,
        modifierNotEquals?: string,
        modifierSpecified?: boolean,
        modifierIn?: Array<string>,
        modifierNotIn?: Array<string>,
        ndcCodeContains?: string,
        ndcCodeDoesNotContain?: string,
        ndcCodeEquals?: string,
        ndcCodeNotEquals?: string,
        ndcCodeSpecified?: boolean,
        ndcCodeIn?: Array<string>,
        ndcCodeNotIn?: Array<string>,
        amountGreaterThan?: number,
        amountLessThan?: number,
        amountGreaterThanOrEqual?: number,
        amountLessThanOrEqual?: number,
        amountEquals?: number,
        amountNotEquals?: number,
        amountSpecified?: boolean,
        amountIn?: Array<number>,
        amountNotIn?: Array<number>,
        ndcQuantityGreaterThan?: number,
        ndcQuantityLessThan?: number,
        ndcQuantityGreaterThanOrEqual?: number,
        ndcQuantityLessThanOrEqual?: number,
        ndcQuantityEquals?: number,
        ndcQuantityNotEquals?: number,
        ndcQuantitySpecified?: boolean,
        ndcQuantityIn?: Array<number>,
        ndcQuantityNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        providerIdIdGreaterThan?: number,
        providerIdIdLessThan?: number,
        providerIdIdGreaterThanOrEqual?: number,
        providerIdIdLessThanOrEqual?: number,
        providerIdIdEquals?: number,
        providerIdIdNotEquals?: number,
        providerIdIdSpecified?: boolean,
        providerIdIdIn?: Array<number>,
        providerIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/fee-schedules/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'codeType.contains': codeTypeContains,
                'codeType.doesNotContain': codeTypeDoesNotContain,
                'codeType.equals': codeTypeEquals,
                'codeType.notEquals': codeTypeNotEquals,
                'codeType.specified': codeTypeSpecified,
                'codeType.in': codeTypeIn,
                'codeType.notIn': codeTypeNotIn,
                'procedureCode.contains': procedureCodeContains,
                'procedureCode.doesNotContain': procedureCodeDoesNotContain,
                'procedureCode.equals': procedureCodeEquals,
                'procedureCode.notEquals': procedureCodeNotEquals,
                'procedureCode.specified': procedureCodeSpecified,
                'procedureCode.in': procedureCodeIn,
                'procedureCode.notIn': procedureCodeNotIn,
                'modifier.contains': modifierContains,
                'modifier.doesNotContain': modifierDoesNotContain,
                'modifier.equals': modifierEquals,
                'modifier.notEquals': modifierNotEquals,
                'modifier.specified': modifierSpecified,
                'modifier.in': modifierIn,
                'modifier.notIn': modifierNotIn,
                'ndcCode.contains': ndcCodeContains,
                'ndcCode.doesNotContain': ndcCodeDoesNotContain,
                'ndcCode.equals': ndcCodeEquals,
                'ndcCode.notEquals': ndcCodeNotEquals,
                'ndcCode.specified': ndcCodeSpecified,
                'ndcCode.in': ndcCodeIn,
                'ndcCode.notIn': ndcCodeNotIn,
                'amount.greaterThan': amountGreaterThan,
                'amount.lessThan': amountLessThan,
                'amount.greaterThanOrEqual': amountGreaterThanOrEqual,
                'amount.lessThanOrEqual': amountLessThanOrEqual,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'ndcQuantity.greaterThan': ndcQuantityGreaterThan,
                'ndcQuantity.lessThan': ndcQuantityLessThan,
                'ndcQuantity.greaterThanOrEqual': ndcQuantityGreaterThanOrEqual,
                'ndcQuantity.lessThanOrEqual': ndcQuantityLessThanOrEqual,
                'ndcQuantity.equals': ndcQuantityEquals,
                'ndcQuantity.notEquals': ndcQuantityNotEquals,
                'ndcQuantity.specified': ndcQuantitySpecified,
                'ndcQuantity.in': ndcQuantityIn,
                'ndcQuantity.notIn': ndcQuantityNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'providerIdId.greaterThan': providerIdIdGreaterThan,
                'providerIdId.lessThan': providerIdIdLessThan,
                'providerIdId.greaterThanOrEqual': providerIdIdGreaterThanOrEqual,
                'providerIdId.lessThanOrEqual': providerIdIdLessThanOrEqual,
                'providerIdId.equals': providerIdIdEquals,
                'providerIdId.notEquals': providerIdIdNotEquals,
                'providerIdId.specified': providerIdIdSpecified,
                'providerIdId.in': providerIdIdIn,
                'providerIdId.notIn': providerIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
