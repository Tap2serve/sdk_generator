/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { LicensedStatesDTO } from '../models/LicensedStatesDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class LicensedStatesResourceService {

    /**
     * @param id
     * @returns LicensedStatesDTO OK
     * @throws ApiError
     */
    public static getLicensedStates(
        id: number,
    ): CancelablePromise<LicensedStatesDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/licensed-states/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns LicensedStatesDTO OK
     * @throws ApiError
     */
    public static updateLicensedStates(
        id: number,
        requestBody: LicensedStatesDTO,
    ): CancelablePromise<LicensedStatesDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/licensed-states/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteLicensedStates(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/licensed-states/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns LicensedStatesDTO OK
     * @throws ApiError
     */
    public static partialUpdateLicensedStates(
        id: number,
        requestBody: LicensedStatesDTO,
    ): CancelablePromise<LicensedStatesDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/licensed-states/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns LicensedStatesDTO OK
     * @throws ApiError
     */
    public static getAllLicensedStates(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<LicensedStatesDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/licensed-states',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns LicensedStatesDTO OK
     * @throws ApiError
     */
    public static createLicensedStates(
        requestBody: LicensedStatesDTO,
    ): CancelablePromise<LicensedStatesDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/licensed-states',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param providerIdGreaterThan
     * @param providerIdLessThan
     * @param providerIdGreaterThanOrEqual
     * @param providerIdLessThanOrEqual
     * @param providerIdEquals
     * @param providerIdNotEquals
     * @param providerIdSpecified
     * @param providerIdIn
     * @param providerIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countLicensedStates(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        providerIdGreaterThan?: number,
        providerIdLessThan?: number,
        providerIdGreaterThanOrEqual?: number,
        providerIdLessThanOrEqual?: number,
        providerIdEquals?: number,
        providerIdNotEquals?: number,
        providerIdSpecified?: boolean,
        providerIdIn?: Array<number>,
        providerIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/licensed-states/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'providerId.greaterThan': providerIdGreaterThan,
                'providerId.lessThan': providerIdLessThan,
                'providerId.greaterThanOrEqual': providerIdGreaterThanOrEqual,
                'providerId.lessThanOrEqual': providerIdLessThanOrEqual,
                'providerId.equals': providerIdEquals,
                'providerId.notEquals': providerIdNotEquals,
                'providerId.specified': providerIdSpecified,
                'providerId.in': providerIdIn,
                'providerId.notIn': providerIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
