/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EncounterDiagnosisDTO } from '../models/EncounterDiagnosisDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class EncounterDiagnosisResourceService {

    /**
     * @param id
     * @returns EncounterDiagnosisDTO OK
     * @throws ApiError
     */
    public static getEncounterDiagnosis(
        id: number,
    ): CancelablePromise<EncounterDiagnosisDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-diagnoses/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterDiagnosisDTO OK
     * @throws ApiError
     */
    public static updateEncounterDiagnosis(
        id: number,
        requestBody: EncounterDiagnosisDTO,
    ): CancelablePromise<EncounterDiagnosisDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/encounter-diagnoses/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteEncounterDiagnosis(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/encounter-diagnoses/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterDiagnosisDTO OK
     * @throws ApiError
     */
    public static partialUpdateEncounterDiagnosis(
        id: number,
        requestBody: EncounterDiagnosisDTO,
    ): CancelablePromise<EncounterDiagnosisDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/encounter-diagnoses/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeContains
     * @param codeDoesNotContain
     * @param codeEquals
     * @param codeNotEquals
     * @param codeSpecified
     * @param codeIn
     * @param codeNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns EncounterDiagnosisDTO OK
     * @throws ApiError
     */
    public static getAllEncounterDiagnoses(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeContains?: string,
        codeDoesNotContain?: string,
        codeEquals?: string,
        codeNotEquals?: string,
        codeSpecified?: boolean,
        codeIn?: Array<string>,
        codeNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<EncounterDiagnosisDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-diagnoses',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'code.contains': codeContains,
                'code.doesNotContain': codeDoesNotContain,
                'code.equals': codeEquals,
                'code.notEquals': codeNotEquals,
                'code.specified': codeSpecified,
                'code.in': codeIn,
                'code.notIn': codeNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns EncounterDiagnosisDTO OK
     * @throws ApiError
     */
    public static createEncounterDiagnosis(
        requestBody: EncounterDiagnosisDTO,
    ): CancelablePromise<EncounterDiagnosisDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/encounter-diagnoses',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeContains
     * @param codeDoesNotContain
     * @param codeEquals
     * @param codeNotEquals
     * @param codeSpecified
     * @param codeIn
     * @param codeNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countEncounterDiagnoses(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeContains?: string,
        codeDoesNotContain?: string,
        codeEquals?: string,
        codeNotEquals?: string,
        codeSpecified?: boolean,
        codeIn?: Array<string>,
        codeNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-diagnoses/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'code.contains': codeContains,
                'code.doesNotContain': codeDoesNotContain,
                'code.equals': codeEquals,
                'code.notEquals': codeNotEquals,
                'code.specified': codeSpecified,
                'code.in': codeIn,
                'code.notIn': codeNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
