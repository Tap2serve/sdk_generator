/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeVaccineDTO } from '../models/IntakeVaccineDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeVaccineResourceService {

    /**
     * @param id
     * @returns IntakeVaccineDTO OK
     * @throws ApiError
     */
    public static getIntakeVaccine(
        id: number,
    ): CancelablePromise<IntakeVaccineDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-vaccines/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeVaccineDTO OK
     * @throws ApiError
     */
    public static updateIntakeVaccine(
        id: number,
        requestBody: IntakeVaccineDTO,
    ): CancelablePromise<IntakeVaccineDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-vaccines/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeVaccine(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-vaccines/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeVaccineDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeVaccine(
        id: number,
        requestBody: IntakeVaccineDTO,
    ): CancelablePromise<IntakeVaccineDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-vaccines/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param administerDayGreaterThan
     * @param administerDayLessThan
     * @param administerDayGreaterThanOrEqual
     * @param administerDayLessThanOrEqual
     * @param administerDayEquals
     * @param administerDayNotEquals
     * @param administerDaySpecified
     * @param administerDayIn
     * @param administerDayNotIn
     * @param administeredByGreaterThan
     * @param administeredByLessThan
     * @param administeredByGreaterThanOrEqual
     * @param administeredByLessThanOrEqual
     * @param administeredByEquals
     * @param administeredByNotEquals
     * @param administeredBySpecified
     * @param administeredByIn
     * @param administeredByNotIn
     * @param expiryDateGreaterThan
     * @param expiryDateLessThan
     * @param expiryDateGreaterThanOrEqual
     * @param expiryDateLessThanOrEqual
     * @param expiryDateEquals
     * @param expiryDateNotEquals
     * @param expiryDateSpecified
     * @param expiryDateIn
     * @param expiryDateNotIn
     * @param amountGreaterThan
     * @param amountLessThan
     * @param amountGreaterThanOrEqual
     * @param amountLessThanOrEqual
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param routeContains
     * @param routeDoesNotContain
     * @param routeEquals
     * @param routeNotEquals
     * @param routeSpecified
     * @param routeIn
     * @param routeNotIn
     * @param siteContains
     * @param siteDoesNotContain
     * @param siteEquals
     * @param siteNotEquals
     * @param siteSpecified
     * @param siteIn
     * @param siteNotIn
     * @param manufacturerContains
     * @param manufacturerDoesNotContain
     * @param manufacturerEquals
     * @param manufacturerNotEquals
     * @param manufacturerSpecified
     * @param manufacturerIn
     * @param manufacturerNotIn
     * @param lotContains
     * @param lotDoesNotContain
     * @param lotEquals
     * @param lotNotEquals
     * @param lotSpecified
     * @param lotIn
     * @param lotNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param vaccineIdIdGreaterThan
     * @param vaccineIdIdLessThan
     * @param vaccineIdIdGreaterThanOrEqual
     * @param vaccineIdIdLessThanOrEqual
     * @param vaccineIdIdEquals
     * @param vaccineIdIdNotEquals
     * @param vaccineIdIdSpecified
     * @param vaccineIdIdIn
     * @param vaccineIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeVaccineDTO OK
     * @throws ApiError
     */
    public static getAllIntakeVaccines(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        administerDayGreaterThan?: string,
        administerDayLessThan?: string,
        administerDayGreaterThanOrEqual?: string,
        administerDayLessThanOrEqual?: string,
        administerDayEquals?: string,
        administerDayNotEquals?: string,
        administerDaySpecified?: boolean,
        administerDayIn?: Array<string>,
        administerDayNotIn?: Array<string>,
        administeredByGreaterThan?: number,
        administeredByLessThan?: number,
        administeredByGreaterThanOrEqual?: number,
        administeredByLessThanOrEqual?: number,
        administeredByEquals?: number,
        administeredByNotEquals?: number,
        administeredBySpecified?: boolean,
        administeredByIn?: Array<number>,
        administeredByNotIn?: Array<number>,
        expiryDateGreaterThan?: string,
        expiryDateLessThan?: string,
        expiryDateGreaterThanOrEqual?: string,
        expiryDateLessThanOrEqual?: string,
        expiryDateEquals?: string,
        expiryDateNotEquals?: string,
        expiryDateSpecified?: boolean,
        expiryDateIn?: Array<string>,
        expiryDateNotIn?: Array<string>,
        amountGreaterThan?: number,
        amountLessThan?: number,
        amountGreaterThanOrEqual?: number,
        amountLessThanOrEqual?: number,
        amountEquals?: number,
        amountNotEquals?: number,
        amountSpecified?: boolean,
        amountIn?: Array<number>,
        amountNotIn?: Array<number>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        routeContains?: string,
        routeDoesNotContain?: string,
        routeEquals?: string,
        routeNotEquals?: string,
        routeSpecified?: boolean,
        routeIn?: Array<string>,
        routeNotIn?: Array<string>,
        siteContains?: string,
        siteDoesNotContain?: string,
        siteEquals?: string,
        siteNotEquals?: string,
        siteSpecified?: boolean,
        siteIn?: Array<string>,
        siteNotIn?: Array<string>,
        manufacturerContains?: string,
        manufacturerDoesNotContain?: string,
        manufacturerEquals?: string,
        manufacturerNotEquals?: string,
        manufacturerSpecified?: boolean,
        manufacturerIn?: Array<string>,
        manufacturerNotIn?: Array<string>,
        lotContains?: string,
        lotDoesNotContain?: string,
        lotEquals?: string,
        lotNotEquals?: string,
        lotSpecified?: boolean,
        lotIn?: Array<string>,
        lotNotIn?: Array<string>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        vaccineIdIdGreaterThan?: number,
        vaccineIdIdLessThan?: number,
        vaccineIdIdGreaterThanOrEqual?: number,
        vaccineIdIdLessThanOrEqual?: number,
        vaccineIdIdEquals?: number,
        vaccineIdIdNotEquals?: number,
        vaccineIdIdSpecified?: boolean,
        vaccineIdIdIn?: Array<number>,
        vaccineIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeVaccineDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-vaccines',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'administerDay.greaterThan': administerDayGreaterThan,
                'administerDay.lessThan': administerDayLessThan,
                'administerDay.greaterThanOrEqual': administerDayGreaterThanOrEqual,
                'administerDay.lessThanOrEqual': administerDayLessThanOrEqual,
                'administerDay.equals': administerDayEquals,
                'administerDay.notEquals': administerDayNotEquals,
                'administerDay.specified': administerDaySpecified,
                'administerDay.in': administerDayIn,
                'administerDay.notIn': administerDayNotIn,
                'administeredBy.greaterThan': administeredByGreaterThan,
                'administeredBy.lessThan': administeredByLessThan,
                'administeredBy.greaterThanOrEqual': administeredByGreaterThanOrEqual,
                'administeredBy.lessThanOrEqual': administeredByLessThanOrEqual,
                'administeredBy.equals': administeredByEquals,
                'administeredBy.notEquals': administeredByNotEquals,
                'administeredBy.specified': administeredBySpecified,
                'administeredBy.in': administeredByIn,
                'administeredBy.notIn': administeredByNotIn,
                'expiryDate.greaterThan': expiryDateGreaterThan,
                'expiryDate.lessThan': expiryDateLessThan,
                'expiryDate.greaterThanOrEqual': expiryDateGreaterThanOrEqual,
                'expiryDate.lessThanOrEqual': expiryDateLessThanOrEqual,
                'expiryDate.equals': expiryDateEquals,
                'expiryDate.notEquals': expiryDateNotEquals,
                'expiryDate.specified': expiryDateSpecified,
                'expiryDate.in': expiryDateIn,
                'expiryDate.notIn': expiryDateNotIn,
                'amount.greaterThan': amountGreaterThan,
                'amount.lessThan': amountLessThan,
                'amount.greaterThanOrEqual': amountGreaterThanOrEqual,
                'amount.lessThanOrEqual': amountLessThanOrEqual,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'route.contains': routeContains,
                'route.doesNotContain': routeDoesNotContain,
                'route.equals': routeEquals,
                'route.notEquals': routeNotEquals,
                'route.specified': routeSpecified,
                'route.in': routeIn,
                'route.notIn': routeNotIn,
                'site.contains': siteContains,
                'site.doesNotContain': siteDoesNotContain,
                'site.equals': siteEquals,
                'site.notEquals': siteNotEquals,
                'site.specified': siteSpecified,
                'site.in': siteIn,
                'site.notIn': siteNotIn,
                'manufacturer.contains': manufacturerContains,
                'manufacturer.doesNotContain': manufacturerDoesNotContain,
                'manufacturer.equals': manufacturerEquals,
                'manufacturer.notEquals': manufacturerNotEquals,
                'manufacturer.specified': manufacturerSpecified,
                'manufacturer.in': manufacturerIn,
                'manufacturer.notIn': manufacturerNotIn,
                'lot.contains': lotContains,
                'lot.doesNotContain': lotDoesNotContain,
                'lot.equals': lotEquals,
                'lot.notEquals': lotNotEquals,
                'lot.specified': lotSpecified,
                'lot.in': lotIn,
                'lot.notIn': lotNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'vaccineIdId.greaterThan': vaccineIdIdGreaterThan,
                'vaccineIdId.lessThan': vaccineIdIdLessThan,
                'vaccineIdId.greaterThanOrEqual': vaccineIdIdGreaterThanOrEqual,
                'vaccineIdId.lessThanOrEqual': vaccineIdIdLessThanOrEqual,
                'vaccineIdId.equals': vaccineIdIdEquals,
                'vaccineIdId.notEquals': vaccineIdIdNotEquals,
                'vaccineIdId.specified': vaccineIdIdSpecified,
                'vaccineIdId.in': vaccineIdIdIn,
                'vaccineIdId.notIn': vaccineIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeVaccineDTO OK
     * @throws ApiError
     */
    public static createIntakeVaccine(
        requestBody: IntakeVaccineDTO,
    ): CancelablePromise<IntakeVaccineDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-vaccines',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param administerDayGreaterThan
     * @param administerDayLessThan
     * @param administerDayGreaterThanOrEqual
     * @param administerDayLessThanOrEqual
     * @param administerDayEquals
     * @param administerDayNotEquals
     * @param administerDaySpecified
     * @param administerDayIn
     * @param administerDayNotIn
     * @param administeredByGreaterThan
     * @param administeredByLessThan
     * @param administeredByGreaterThanOrEqual
     * @param administeredByLessThanOrEqual
     * @param administeredByEquals
     * @param administeredByNotEquals
     * @param administeredBySpecified
     * @param administeredByIn
     * @param administeredByNotIn
     * @param expiryDateGreaterThan
     * @param expiryDateLessThan
     * @param expiryDateGreaterThanOrEqual
     * @param expiryDateLessThanOrEqual
     * @param expiryDateEquals
     * @param expiryDateNotEquals
     * @param expiryDateSpecified
     * @param expiryDateIn
     * @param expiryDateNotIn
     * @param amountGreaterThan
     * @param amountLessThan
     * @param amountGreaterThanOrEqual
     * @param amountLessThanOrEqual
     * @param amountEquals
     * @param amountNotEquals
     * @param amountSpecified
     * @param amountIn
     * @param amountNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param routeContains
     * @param routeDoesNotContain
     * @param routeEquals
     * @param routeNotEquals
     * @param routeSpecified
     * @param routeIn
     * @param routeNotIn
     * @param siteContains
     * @param siteDoesNotContain
     * @param siteEquals
     * @param siteNotEquals
     * @param siteSpecified
     * @param siteIn
     * @param siteNotIn
     * @param manufacturerContains
     * @param manufacturerDoesNotContain
     * @param manufacturerEquals
     * @param manufacturerNotEquals
     * @param manufacturerSpecified
     * @param manufacturerIn
     * @param manufacturerNotIn
     * @param lotContains
     * @param lotDoesNotContain
     * @param lotEquals
     * @param lotNotEquals
     * @param lotSpecified
     * @param lotIn
     * @param lotNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param vaccineIdIdGreaterThan
     * @param vaccineIdIdLessThan
     * @param vaccineIdIdGreaterThanOrEqual
     * @param vaccineIdIdLessThanOrEqual
     * @param vaccineIdIdEquals
     * @param vaccineIdIdNotEquals
     * @param vaccineIdIdSpecified
     * @param vaccineIdIdIn
     * @param vaccineIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeVaccines(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        administerDayGreaterThan?: string,
        administerDayLessThan?: string,
        administerDayGreaterThanOrEqual?: string,
        administerDayLessThanOrEqual?: string,
        administerDayEquals?: string,
        administerDayNotEquals?: string,
        administerDaySpecified?: boolean,
        administerDayIn?: Array<string>,
        administerDayNotIn?: Array<string>,
        administeredByGreaterThan?: number,
        administeredByLessThan?: number,
        administeredByGreaterThanOrEqual?: number,
        administeredByLessThanOrEqual?: number,
        administeredByEquals?: number,
        administeredByNotEquals?: number,
        administeredBySpecified?: boolean,
        administeredByIn?: Array<number>,
        administeredByNotIn?: Array<number>,
        expiryDateGreaterThan?: string,
        expiryDateLessThan?: string,
        expiryDateGreaterThanOrEqual?: string,
        expiryDateLessThanOrEqual?: string,
        expiryDateEquals?: string,
        expiryDateNotEquals?: string,
        expiryDateSpecified?: boolean,
        expiryDateIn?: Array<string>,
        expiryDateNotIn?: Array<string>,
        amountGreaterThan?: number,
        amountLessThan?: number,
        amountGreaterThanOrEqual?: number,
        amountLessThanOrEqual?: number,
        amountEquals?: number,
        amountNotEquals?: number,
        amountSpecified?: boolean,
        amountIn?: Array<number>,
        amountNotIn?: Array<number>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        routeContains?: string,
        routeDoesNotContain?: string,
        routeEquals?: string,
        routeNotEquals?: string,
        routeSpecified?: boolean,
        routeIn?: Array<string>,
        routeNotIn?: Array<string>,
        siteContains?: string,
        siteDoesNotContain?: string,
        siteEquals?: string,
        siteNotEquals?: string,
        siteSpecified?: boolean,
        siteIn?: Array<string>,
        siteNotIn?: Array<string>,
        manufacturerContains?: string,
        manufacturerDoesNotContain?: string,
        manufacturerEquals?: string,
        manufacturerNotEquals?: string,
        manufacturerSpecified?: boolean,
        manufacturerIn?: Array<string>,
        manufacturerNotIn?: Array<string>,
        lotContains?: string,
        lotDoesNotContain?: string,
        lotEquals?: string,
        lotNotEquals?: string,
        lotSpecified?: boolean,
        lotIn?: Array<string>,
        lotNotIn?: Array<string>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        vaccineIdIdGreaterThan?: number,
        vaccineIdIdLessThan?: number,
        vaccineIdIdGreaterThanOrEqual?: number,
        vaccineIdIdLessThanOrEqual?: number,
        vaccineIdIdEquals?: number,
        vaccineIdIdNotEquals?: number,
        vaccineIdIdSpecified?: boolean,
        vaccineIdIdIn?: Array<number>,
        vaccineIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-vaccines/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'administerDay.greaterThan': administerDayGreaterThan,
                'administerDay.lessThan': administerDayLessThan,
                'administerDay.greaterThanOrEqual': administerDayGreaterThanOrEqual,
                'administerDay.lessThanOrEqual': administerDayLessThanOrEqual,
                'administerDay.equals': administerDayEquals,
                'administerDay.notEquals': administerDayNotEquals,
                'administerDay.specified': administerDaySpecified,
                'administerDay.in': administerDayIn,
                'administerDay.notIn': administerDayNotIn,
                'administeredBy.greaterThan': administeredByGreaterThan,
                'administeredBy.lessThan': administeredByLessThan,
                'administeredBy.greaterThanOrEqual': administeredByGreaterThanOrEqual,
                'administeredBy.lessThanOrEqual': administeredByLessThanOrEqual,
                'administeredBy.equals': administeredByEquals,
                'administeredBy.notEquals': administeredByNotEquals,
                'administeredBy.specified': administeredBySpecified,
                'administeredBy.in': administeredByIn,
                'administeredBy.notIn': administeredByNotIn,
                'expiryDate.greaterThan': expiryDateGreaterThan,
                'expiryDate.lessThan': expiryDateLessThan,
                'expiryDate.greaterThanOrEqual': expiryDateGreaterThanOrEqual,
                'expiryDate.lessThanOrEqual': expiryDateLessThanOrEqual,
                'expiryDate.equals': expiryDateEquals,
                'expiryDate.notEquals': expiryDateNotEquals,
                'expiryDate.specified': expiryDateSpecified,
                'expiryDate.in': expiryDateIn,
                'expiryDate.notIn': expiryDateNotIn,
                'amount.greaterThan': amountGreaterThan,
                'amount.lessThan': amountLessThan,
                'amount.greaterThanOrEqual': amountGreaterThanOrEqual,
                'amount.lessThanOrEqual': amountLessThanOrEqual,
                'amount.equals': amountEquals,
                'amount.notEquals': amountNotEquals,
                'amount.specified': amountSpecified,
                'amount.in': amountIn,
                'amount.notIn': amountNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'route.contains': routeContains,
                'route.doesNotContain': routeDoesNotContain,
                'route.equals': routeEquals,
                'route.notEquals': routeNotEquals,
                'route.specified': routeSpecified,
                'route.in': routeIn,
                'route.notIn': routeNotIn,
                'site.contains': siteContains,
                'site.doesNotContain': siteDoesNotContain,
                'site.equals': siteEquals,
                'site.notEquals': siteNotEquals,
                'site.specified': siteSpecified,
                'site.in': siteIn,
                'site.notIn': siteNotIn,
                'manufacturer.contains': manufacturerContains,
                'manufacturer.doesNotContain': manufacturerDoesNotContain,
                'manufacturer.equals': manufacturerEquals,
                'manufacturer.notEquals': manufacturerNotEquals,
                'manufacturer.specified': manufacturerSpecified,
                'manufacturer.in': manufacturerIn,
                'manufacturer.notIn': manufacturerNotIn,
                'lot.contains': lotContains,
                'lot.doesNotContain': lotDoesNotContain,
                'lot.equals': lotEquals,
                'lot.notEquals': lotNotEquals,
                'lot.specified': lotSpecified,
                'lot.in': lotIn,
                'lot.notIn': lotNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'vaccineIdId.greaterThan': vaccineIdIdGreaterThan,
                'vaccineIdId.lessThan': vaccineIdIdLessThan,
                'vaccineIdId.greaterThanOrEqual': vaccineIdIdGreaterThanOrEqual,
                'vaccineIdId.lessThanOrEqual': vaccineIdIdLessThanOrEqual,
                'vaccineIdId.equals': vaccineIdIdEquals,
                'vaccineIdId.notEquals': vaccineIdIdNotEquals,
                'vaccineIdId.specified': vaccineIdIdSpecified,
                'vaccineIdId.in': vaccineIdIdIn,
                'vaccineIdId.notIn': vaccineIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
