/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientAuthorizationDTO } from '../models/PatientAuthorizationDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientAuthorizationResourceService {

    /**
     * @param id
     * @returns PatientAuthorizationDTO OK
     * @throws ApiError
     */
    public static getPatientAuthorization(
        id: number,
    ): CancelablePromise<PatientAuthorizationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-authorizations/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAuthorizationDTO OK
     * @throws ApiError
     */
    public static updatePatientAuthorization(
        id: number,
        requestBody: PatientAuthorizationDTO,
    ): CancelablePromise<PatientAuthorizationDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-authorizations/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientAuthorization(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-authorizations/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAuthorizationDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientAuthorization(
        id: number,
        requestBody: PatientAuthorizationDTO,
    ): CancelablePromise<PatientAuthorizationDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-authorizations/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param authorizationNumberContains
     * @param authorizationNumberDoesNotContain
     * @param authorizationNumberEquals
     * @param authorizationNumberNotEquals
     * @param authorizationNumberSpecified
     * @param authorizationNumberIn
     * @param authorizationNumberNotIn
     * @param effectiveStartDateGreaterThan
     * @param effectiveStartDateLessThan
     * @param effectiveStartDateGreaterThanOrEqual
     * @param effectiveStartDateLessThanOrEqual
     * @param effectiveStartDateEquals
     * @param effectiveStartDateNotEquals
     * @param effectiveStartDateSpecified
     * @param effectiveStartDateIn
     * @param effectiveStartDateNotIn
     * @param effectiveEndDateGreaterThan
     * @param effectiveEndDateLessThan
     * @param effectiveEndDateGreaterThanOrEqual
     * @param effectiveEndDateLessThanOrEqual
     * @param effectiveEndDateEquals
     * @param effectiveEndDateNotEquals
     * @param effectiveEndDateSpecified
     * @param effectiveEndDateIn
     * @param effectiveEndDateNotIn
     * @param numberOfVisitGreaterThan
     * @param numberOfVisitLessThan
     * @param numberOfVisitGreaterThanOrEqual
     * @param numberOfVisitLessThanOrEqual
     * @param numberOfVisitEquals
     * @param numberOfVisitNotEquals
     * @param numberOfVisitSpecified
     * @param numberOfVisitIn
     * @param numberOfVisitNotIn
     * @param procedureCodeContains
     * @param procedureCodeDoesNotContain
     * @param procedureCodeEquals
     * @param procedureCodeNotEquals
     * @param procedureCodeSpecified
     * @param procedureCodeIn
     * @param procedureCodeNotIn
     * @param specialityGreaterThan
     * @param specialityLessThan
     * @param specialityGreaterThanOrEqual
     * @param specialityLessThanOrEqual
     * @param specialityEquals
     * @param specialityNotEquals
     * @param specialitySpecified
     * @param specialityIn
     * @param specialityNotIn
     * @param visitRemainingContains
     * @param visitRemainingDoesNotContain
     * @param visitRemainingEquals
     * @param visitRemainingNotEquals
     * @param visitRemainingSpecified
     * @param visitRemainingIn
     * @param visitRemainingNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientAuthorizationDTO OK
     * @throws ApiError
     */
    public static getAllPatientAuthorizations(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        authorizationNumberContains?: string,
        authorizationNumberDoesNotContain?: string,
        authorizationNumberEquals?: string,
        authorizationNumberNotEquals?: string,
        authorizationNumberSpecified?: boolean,
        authorizationNumberIn?: Array<string>,
        authorizationNumberNotIn?: Array<string>,
        effectiveStartDateGreaterThan?: string,
        effectiveStartDateLessThan?: string,
        effectiveStartDateGreaterThanOrEqual?: string,
        effectiveStartDateLessThanOrEqual?: string,
        effectiveStartDateEquals?: string,
        effectiveStartDateNotEquals?: string,
        effectiveStartDateSpecified?: boolean,
        effectiveStartDateIn?: Array<string>,
        effectiveStartDateNotIn?: Array<string>,
        effectiveEndDateGreaterThan?: string,
        effectiveEndDateLessThan?: string,
        effectiveEndDateGreaterThanOrEqual?: string,
        effectiveEndDateLessThanOrEqual?: string,
        effectiveEndDateEquals?: string,
        effectiveEndDateNotEquals?: string,
        effectiveEndDateSpecified?: boolean,
        effectiveEndDateIn?: Array<string>,
        effectiveEndDateNotIn?: Array<string>,
        numberOfVisitGreaterThan?: number,
        numberOfVisitLessThan?: number,
        numberOfVisitGreaterThanOrEqual?: number,
        numberOfVisitLessThanOrEqual?: number,
        numberOfVisitEquals?: number,
        numberOfVisitNotEquals?: number,
        numberOfVisitSpecified?: boolean,
        numberOfVisitIn?: Array<number>,
        numberOfVisitNotIn?: Array<number>,
        procedureCodeContains?: string,
        procedureCodeDoesNotContain?: string,
        procedureCodeEquals?: string,
        procedureCodeNotEquals?: string,
        procedureCodeSpecified?: boolean,
        procedureCodeIn?: Array<string>,
        procedureCodeNotIn?: Array<string>,
        specialityGreaterThan?: number,
        specialityLessThan?: number,
        specialityGreaterThanOrEqual?: number,
        specialityLessThanOrEqual?: number,
        specialityEquals?: number,
        specialityNotEquals?: number,
        specialitySpecified?: boolean,
        specialityIn?: Array<number>,
        specialityNotIn?: Array<number>,
        visitRemainingContains?: string,
        visitRemainingDoesNotContain?: string,
        visitRemainingEquals?: string,
        visitRemainingNotEquals?: string,
        visitRemainingSpecified?: boolean,
        visitRemainingIn?: Array<string>,
        visitRemainingNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientAuthorizationDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-authorizations',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'authorizationNumber.contains': authorizationNumberContains,
                'authorizationNumber.doesNotContain': authorizationNumberDoesNotContain,
                'authorizationNumber.equals': authorizationNumberEquals,
                'authorizationNumber.notEquals': authorizationNumberNotEquals,
                'authorizationNumber.specified': authorizationNumberSpecified,
                'authorizationNumber.in': authorizationNumberIn,
                'authorizationNumber.notIn': authorizationNumberNotIn,
                'effectiveStartDate.greaterThan': effectiveStartDateGreaterThan,
                'effectiveStartDate.lessThan': effectiveStartDateLessThan,
                'effectiveStartDate.greaterThanOrEqual': effectiveStartDateGreaterThanOrEqual,
                'effectiveStartDate.lessThanOrEqual': effectiveStartDateLessThanOrEqual,
                'effectiveStartDate.equals': effectiveStartDateEquals,
                'effectiveStartDate.notEquals': effectiveStartDateNotEquals,
                'effectiveStartDate.specified': effectiveStartDateSpecified,
                'effectiveStartDate.in': effectiveStartDateIn,
                'effectiveStartDate.notIn': effectiveStartDateNotIn,
                'effectiveEndDate.greaterThan': effectiveEndDateGreaterThan,
                'effectiveEndDate.lessThan': effectiveEndDateLessThan,
                'effectiveEndDate.greaterThanOrEqual': effectiveEndDateGreaterThanOrEqual,
                'effectiveEndDate.lessThanOrEqual': effectiveEndDateLessThanOrEqual,
                'effectiveEndDate.equals': effectiveEndDateEquals,
                'effectiveEndDate.notEquals': effectiveEndDateNotEquals,
                'effectiveEndDate.specified': effectiveEndDateSpecified,
                'effectiveEndDate.in': effectiveEndDateIn,
                'effectiveEndDate.notIn': effectiveEndDateNotIn,
                'numberOfVisit.greaterThan': numberOfVisitGreaterThan,
                'numberOfVisit.lessThan': numberOfVisitLessThan,
                'numberOfVisit.greaterThanOrEqual': numberOfVisitGreaterThanOrEqual,
                'numberOfVisit.lessThanOrEqual': numberOfVisitLessThanOrEqual,
                'numberOfVisit.equals': numberOfVisitEquals,
                'numberOfVisit.notEquals': numberOfVisitNotEquals,
                'numberOfVisit.specified': numberOfVisitSpecified,
                'numberOfVisit.in': numberOfVisitIn,
                'numberOfVisit.notIn': numberOfVisitNotIn,
                'procedureCode.contains': procedureCodeContains,
                'procedureCode.doesNotContain': procedureCodeDoesNotContain,
                'procedureCode.equals': procedureCodeEquals,
                'procedureCode.notEquals': procedureCodeNotEquals,
                'procedureCode.specified': procedureCodeSpecified,
                'procedureCode.in': procedureCodeIn,
                'procedureCode.notIn': procedureCodeNotIn,
                'speciality.greaterThan': specialityGreaterThan,
                'speciality.lessThan': specialityLessThan,
                'speciality.greaterThanOrEqual': specialityGreaterThanOrEqual,
                'speciality.lessThanOrEqual': specialityLessThanOrEqual,
                'speciality.equals': specialityEquals,
                'speciality.notEquals': specialityNotEquals,
                'speciality.specified': specialitySpecified,
                'speciality.in': specialityIn,
                'speciality.notIn': specialityNotIn,
                'visitRemaining.contains': visitRemainingContains,
                'visitRemaining.doesNotContain': visitRemainingDoesNotContain,
                'visitRemaining.equals': visitRemainingEquals,
                'visitRemaining.notEquals': visitRemainingNotEquals,
                'visitRemaining.specified': visitRemainingSpecified,
                'visitRemaining.in': visitRemainingIn,
                'visitRemaining.notIn': visitRemainingNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientAuthorizationDTO OK
     * @throws ApiError
     */
    public static createPatientAuthorization(
        requestBody: PatientAuthorizationDTO,
    ): CancelablePromise<PatientAuthorizationDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-authorizations',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param authorizationNumberContains
     * @param authorizationNumberDoesNotContain
     * @param authorizationNumberEquals
     * @param authorizationNumberNotEquals
     * @param authorizationNumberSpecified
     * @param authorizationNumberIn
     * @param authorizationNumberNotIn
     * @param effectiveStartDateGreaterThan
     * @param effectiveStartDateLessThan
     * @param effectiveStartDateGreaterThanOrEqual
     * @param effectiveStartDateLessThanOrEqual
     * @param effectiveStartDateEquals
     * @param effectiveStartDateNotEquals
     * @param effectiveStartDateSpecified
     * @param effectiveStartDateIn
     * @param effectiveStartDateNotIn
     * @param effectiveEndDateGreaterThan
     * @param effectiveEndDateLessThan
     * @param effectiveEndDateGreaterThanOrEqual
     * @param effectiveEndDateLessThanOrEqual
     * @param effectiveEndDateEquals
     * @param effectiveEndDateNotEquals
     * @param effectiveEndDateSpecified
     * @param effectiveEndDateIn
     * @param effectiveEndDateNotIn
     * @param numberOfVisitGreaterThan
     * @param numberOfVisitLessThan
     * @param numberOfVisitGreaterThanOrEqual
     * @param numberOfVisitLessThanOrEqual
     * @param numberOfVisitEquals
     * @param numberOfVisitNotEquals
     * @param numberOfVisitSpecified
     * @param numberOfVisitIn
     * @param numberOfVisitNotIn
     * @param procedureCodeContains
     * @param procedureCodeDoesNotContain
     * @param procedureCodeEquals
     * @param procedureCodeNotEquals
     * @param procedureCodeSpecified
     * @param procedureCodeIn
     * @param procedureCodeNotIn
     * @param specialityGreaterThan
     * @param specialityLessThan
     * @param specialityGreaterThanOrEqual
     * @param specialityLessThanOrEqual
     * @param specialityEquals
     * @param specialityNotEquals
     * @param specialitySpecified
     * @param specialityIn
     * @param specialityNotIn
     * @param visitRemainingContains
     * @param visitRemainingDoesNotContain
     * @param visitRemainingEquals
     * @param visitRemainingNotEquals
     * @param visitRemainingSpecified
     * @param visitRemainingIn
     * @param visitRemainingNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientAuthorizations(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        authorizationNumberContains?: string,
        authorizationNumberDoesNotContain?: string,
        authorizationNumberEquals?: string,
        authorizationNumberNotEquals?: string,
        authorizationNumberSpecified?: boolean,
        authorizationNumberIn?: Array<string>,
        authorizationNumberNotIn?: Array<string>,
        effectiveStartDateGreaterThan?: string,
        effectiveStartDateLessThan?: string,
        effectiveStartDateGreaterThanOrEqual?: string,
        effectiveStartDateLessThanOrEqual?: string,
        effectiveStartDateEquals?: string,
        effectiveStartDateNotEquals?: string,
        effectiveStartDateSpecified?: boolean,
        effectiveStartDateIn?: Array<string>,
        effectiveStartDateNotIn?: Array<string>,
        effectiveEndDateGreaterThan?: string,
        effectiveEndDateLessThan?: string,
        effectiveEndDateGreaterThanOrEqual?: string,
        effectiveEndDateLessThanOrEqual?: string,
        effectiveEndDateEquals?: string,
        effectiveEndDateNotEquals?: string,
        effectiveEndDateSpecified?: boolean,
        effectiveEndDateIn?: Array<string>,
        effectiveEndDateNotIn?: Array<string>,
        numberOfVisitGreaterThan?: number,
        numberOfVisitLessThan?: number,
        numberOfVisitGreaterThanOrEqual?: number,
        numberOfVisitLessThanOrEqual?: number,
        numberOfVisitEquals?: number,
        numberOfVisitNotEquals?: number,
        numberOfVisitSpecified?: boolean,
        numberOfVisitIn?: Array<number>,
        numberOfVisitNotIn?: Array<number>,
        procedureCodeContains?: string,
        procedureCodeDoesNotContain?: string,
        procedureCodeEquals?: string,
        procedureCodeNotEquals?: string,
        procedureCodeSpecified?: boolean,
        procedureCodeIn?: Array<string>,
        procedureCodeNotIn?: Array<string>,
        specialityGreaterThan?: number,
        specialityLessThan?: number,
        specialityGreaterThanOrEqual?: number,
        specialityLessThanOrEqual?: number,
        specialityEquals?: number,
        specialityNotEquals?: number,
        specialitySpecified?: boolean,
        specialityIn?: Array<number>,
        specialityNotIn?: Array<number>,
        visitRemainingContains?: string,
        visitRemainingDoesNotContain?: string,
        visitRemainingEquals?: string,
        visitRemainingNotEquals?: string,
        visitRemainingSpecified?: boolean,
        visitRemainingIn?: Array<string>,
        visitRemainingNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-authorizations/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'authorizationNumber.contains': authorizationNumberContains,
                'authorizationNumber.doesNotContain': authorizationNumberDoesNotContain,
                'authorizationNumber.equals': authorizationNumberEquals,
                'authorizationNumber.notEquals': authorizationNumberNotEquals,
                'authorizationNumber.specified': authorizationNumberSpecified,
                'authorizationNumber.in': authorizationNumberIn,
                'authorizationNumber.notIn': authorizationNumberNotIn,
                'effectiveStartDate.greaterThan': effectiveStartDateGreaterThan,
                'effectiveStartDate.lessThan': effectiveStartDateLessThan,
                'effectiveStartDate.greaterThanOrEqual': effectiveStartDateGreaterThanOrEqual,
                'effectiveStartDate.lessThanOrEqual': effectiveStartDateLessThanOrEqual,
                'effectiveStartDate.equals': effectiveStartDateEquals,
                'effectiveStartDate.notEquals': effectiveStartDateNotEquals,
                'effectiveStartDate.specified': effectiveStartDateSpecified,
                'effectiveStartDate.in': effectiveStartDateIn,
                'effectiveStartDate.notIn': effectiveStartDateNotIn,
                'effectiveEndDate.greaterThan': effectiveEndDateGreaterThan,
                'effectiveEndDate.lessThan': effectiveEndDateLessThan,
                'effectiveEndDate.greaterThanOrEqual': effectiveEndDateGreaterThanOrEqual,
                'effectiveEndDate.lessThanOrEqual': effectiveEndDateLessThanOrEqual,
                'effectiveEndDate.equals': effectiveEndDateEquals,
                'effectiveEndDate.notEquals': effectiveEndDateNotEquals,
                'effectiveEndDate.specified': effectiveEndDateSpecified,
                'effectiveEndDate.in': effectiveEndDateIn,
                'effectiveEndDate.notIn': effectiveEndDateNotIn,
                'numberOfVisit.greaterThan': numberOfVisitGreaterThan,
                'numberOfVisit.lessThan': numberOfVisitLessThan,
                'numberOfVisit.greaterThanOrEqual': numberOfVisitGreaterThanOrEqual,
                'numberOfVisit.lessThanOrEqual': numberOfVisitLessThanOrEqual,
                'numberOfVisit.equals': numberOfVisitEquals,
                'numberOfVisit.notEquals': numberOfVisitNotEquals,
                'numberOfVisit.specified': numberOfVisitSpecified,
                'numberOfVisit.in': numberOfVisitIn,
                'numberOfVisit.notIn': numberOfVisitNotIn,
                'procedureCode.contains': procedureCodeContains,
                'procedureCode.doesNotContain': procedureCodeDoesNotContain,
                'procedureCode.equals': procedureCodeEquals,
                'procedureCode.notEquals': procedureCodeNotEquals,
                'procedureCode.specified': procedureCodeSpecified,
                'procedureCode.in': procedureCodeIn,
                'procedureCode.notIn': procedureCodeNotIn,
                'speciality.greaterThan': specialityGreaterThan,
                'speciality.lessThan': specialityLessThan,
                'speciality.greaterThanOrEqual': specialityGreaterThanOrEqual,
                'speciality.lessThanOrEqual': specialityLessThanOrEqual,
                'speciality.equals': specialityEquals,
                'speciality.notEquals': specialityNotEquals,
                'speciality.specified': specialitySpecified,
                'speciality.in': specialityIn,
                'speciality.notIn': specialityNotIn,
                'visitRemaining.contains': visitRemainingContains,
                'visitRemaining.doesNotContain': visitRemainingDoesNotContain,
                'visitRemaining.equals': visitRemainingEquals,
                'visitRemaining.notEquals': visitRemainingNotEquals,
                'visitRemaining.specified': visitRemainingSpecified,
                'visitRemaining.in': visitRemainingIn,
                'visitRemaining.notIn': visitRemainingNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
