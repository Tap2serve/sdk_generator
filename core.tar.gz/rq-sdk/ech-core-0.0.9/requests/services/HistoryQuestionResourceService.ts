/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { HistoryQuestionDTO } from '../models/HistoryQuestionDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class HistoryQuestionResourceService {

    /**
     * @param id
     * @returns HistoryQuestionDTO OK
     * @throws ApiError
     */
    public static getHistoryQuestion(
        id: number,
    ): CancelablePromise<HistoryQuestionDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/history-questions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns HistoryQuestionDTO OK
     * @throws ApiError
     */
    public static updateHistoryQuestion(
        id: number,
        requestBody: HistoryQuestionDTO,
    ): CancelablePromise<HistoryQuestionDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/history-questions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteHistoryQuestion(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/history-questions/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns HistoryQuestionDTO OK
     * @throws ApiError
     */
    public static partialUpdateHistoryQuestion(
        id: number,
        requestBody: HistoryQuestionDTO,
    ): CancelablePromise<HistoryQuestionDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/history-questions/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param questionContains
     * @param questionDoesNotContain
     * @param questionEquals
     * @param questionNotEquals
     * @param questionSpecified
     * @param questionIn
     * @param questionNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param psychologicalHistoryIdGreaterThan
     * @param psychologicalHistoryIdLessThan
     * @param psychologicalHistoryIdGreaterThanOrEqual
     * @param psychologicalHistoryIdLessThanOrEqual
     * @param psychologicalHistoryIdEquals
     * @param psychologicalHistoryIdNotEquals
     * @param psychologicalHistoryIdSpecified
     * @param psychologicalHistoryIdIn
     * @param psychologicalHistoryIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param patientDietIdGreaterThan
     * @param patientDietIdLessThan
     * @param patientDietIdGreaterThanOrEqual
     * @param patientDietIdLessThanOrEqual
     * @param patientDietIdEquals
     * @param patientDietIdNotEquals
     * @param patientDietIdSpecified
     * @param patientDietIdIn
     * @param patientDietIdNotIn
     * @param habbitIdGreaterThan
     * @param habbitIdLessThan
     * @param habbitIdGreaterThanOrEqual
     * @param habbitIdLessThanOrEqual
     * @param habbitIdEquals
     * @param habbitIdNotEquals
     * @param habbitIdSpecified
     * @param habbitIdIn
     * @param habbitIdNotIn
     * @param socialHistoryIdGreaterThan
     * @param socialHistoryIdLessThan
     * @param socialHistoryIdGreaterThanOrEqual
     * @param socialHistoryIdLessThanOrEqual
     * @param socialHistoryIdEquals
     * @param socialHistoryIdNotEquals
     * @param socialHistoryIdSpecified
     * @param socialHistoryIdIn
     * @param socialHistoryIdNotIn
     * @param patientFunctionalStatusIdGreaterThan
     * @param patientFunctionalStatusIdLessThan
     * @param patientFunctionalStatusIdGreaterThanOrEqual
     * @param patientFunctionalStatusIdLessThanOrEqual
     * @param patientFunctionalStatusIdEquals
     * @param patientFunctionalStatusIdNotEquals
     * @param patientFunctionalStatusIdSpecified
     * @param patientFunctionalStatusIdIn
     * @param patientFunctionalStatusIdNotIn
     * @param exerciseHistoryIdGreaterThan
     * @param exerciseHistoryIdLessThan
     * @param exerciseHistoryIdGreaterThanOrEqual
     * @param exerciseHistoryIdLessThanOrEqual
     * @param exerciseHistoryIdEquals
     * @param exerciseHistoryIdNotEquals
     * @param exerciseHistoryIdSpecified
     * @param exerciseHistoryIdIn
     * @param exerciseHistoryIdNotIn
     * @param patientCognitiveStatusIdGreaterThan
     * @param patientCognitiveStatusIdLessThan
     * @param patientCognitiveStatusIdGreaterThanOrEqual
     * @param patientCognitiveStatusIdLessThanOrEqual
     * @param patientCognitiveStatusIdEquals
     * @param patientCognitiveStatusIdNotEquals
     * @param patientCognitiveStatusIdSpecified
     * @param patientCognitiveStatusIdIn
     * @param patientCognitiveStatusIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns HistoryQuestionDTO OK
     * @throws ApiError
     */
    public static getAllHistoryQuestions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        questionContains?: string,
        questionDoesNotContain?: string,
        questionEquals?: string,
        questionNotEquals?: string,
        questionSpecified?: boolean,
        questionIn?: Array<string>,
        questionNotIn?: Array<string>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        psychologicalHistoryIdGreaterThan?: number,
        psychologicalHistoryIdLessThan?: number,
        psychologicalHistoryIdGreaterThanOrEqual?: number,
        psychologicalHistoryIdLessThanOrEqual?: number,
        psychologicalHistoryIdEquals?: number,
        psychologicalHistoryIdNotEquals?: number,
        psychologicalHistoryIdSpecified?: boolean,
        psychologicalHistoryIdIn?: Array<number>,
        psychologicalHistoryIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        patientDietIdGreaterThan?: number,
        patientDietIdLessThan?: number,
        patientDietIdGreaterThanOrEqual?: number,
        patientDietIdLessThanOrEqual?: number,
        patientDietIdEquals?: number,
        patientDietIdNotEquals?: number,
        patientDietIdSpecified?: boolean,
        patientDietIdIn?: Array<number>,
        patientDietIdNotIn?: Array<number>,
        habbitIdGreaterThan?: number,
        habbitIdLessThan?: number,
        habbitIdGreaterThanOrEqual?: number,
        habbitIdLessThanOrEqual?: number,
        habbitIdEquals?: number,
        habbitIdNotEquals?: number,
        habbitIdSpecified?: boolean,
        habbitIdIn?: Array<number>,
        habbitIdNotIn?: Array<number>,
        socialHistoryIdGreaterThan?: number,
        socialHistoryIdLessThan?: number,
        socialHistoryIdGreaterThanOrEqual?: number,
        socialHistoryIdLessThanOrEqual?: number,
        socialHistoryIdEquals?: number,
        socialHistoryIdNotEquals?: number,
        socialHistoryIdSpecified?: boolean,
        socialHistoryIdIn?: Array<number>,
        socialHistoryIdNotIn?: Array<number>,
        patientFunctionalStatusIdGreaterThan?: number,
        patientFunctionalStatusIdLessThan?: number,
        patientFunctionalStatusIdGreaterThanOrEqual?: number,
        patientFunctionalStatusIdLessThanOrEqual?: number,
        patientFunctionalStatusIdEquals?: number,
        patientFunctionalStatusIdNotEquals?: number,
        patientFunctionalStatusIdSpecified?: boolean,
        patientFunctionalStatusIdIn?: Array<number>,
        patientFunctionalStatusIdNotIn?: Array<number>,
        exerciseHistoryIdGreaterThan?: number,
        exerciseHistoryIdLessThan?: number,
        exerciseHistoryIdGreaterThanOrEqual?: number,
        exerciseHistoryIdLessThanOrEqual?: number,
        exerciseHistoryIdEquals?: number,
        exerciseHistoryIdNotEquals?: number,
        exerciseHistoryIdSpecified?: boolean,
        exerciseHistoryIdIn?: Array<number>,
        exerciseHistoryIdNotIn?: Array<number>,
        patientCognitiveStatusIdGreaterThan?: number,
        patientCognitiveStatusIdLessThan?: number,
        patientCognitiveStatusIdGreaterThanOrEqual?: number,
        patientCognitiveStatusIdLessThanOrEqual?: number,
        patientCognitiveStatusIdEquals?: number,
        patientCognitiveStatusIdNotEquals?: number,
        patientCognitiveStatusIdSpecified?: boolean,
        patientCognitiveStatusIdIn?: Array<number>,
        patientCognitiveStatusIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<HistoryQuestionDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/history-questions',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'question.contains': questionContains,
                'question.doesNotContain': questionDoesNotContain,
                'question.equals': questionEquals,
                'question.notEquals': questionNotEquals,
                'question.specified': questionSpecified,
                'question.in': questionIn,
                'question.notIn': questionNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'psychologicalHistoryId.greaterThan': psychologicalHistoryIdGreaterThan,
                'psychologicalHistoryId.lessThan': psychologicalHistoryIdLessThan,
                'psychologicalHistoryId.greaterThanOrEqual': psychologicalHistoryIdGreaterThanOrEqual,
                'psychologicalHistoryId.lessThanOrEqual': psychologicalHistoryIdLessThanOrEqual,
                'psychologicalHistoryId.equals': psychologicalHistoryIdEquals,
                'psychologicalHistoryId.notEquals': psychologicalHistoryIdNotEquals,
                'psychologicalHistoryId.specified': psychologicalHistoryIdSpecified,
                'psychologicalHistoryId.in': psychologicalHistoryIdIn,
                'psychologicalHistoryId.notIn': psychologicalHistoryIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'patientDietId.greaterThan': patientDietIdGreaterThan,
                'patientDietId.lessThan': patientDietIdLessThan,
                'patientDietId.greaterThanOrEqual': patientDietIdGreaterThanOrEqual,
                'patientDietId.lessThanOrEqual': patientDietIdLessThanOrEqual,
                'patientDietId.equals': patientDietIdEquals,
                'patientDietId.notEquals': patientDietIdNotEquals,
                'patientDietId.specified': patientDietIdSpecified,
                'patientDietId.in': patientDietIdIn,
                'patientDietId.notIn': patientDietIdNotIn,
                'habbitId.greaterThan': habbitIdGreaterThan,
                'habbitId.lessThan': habbitIdLessThan,
                'habbitId.greaterThanOrEqual': habbitIdGreaterThanOrEqual,
                'habbitId.lessThanOrEqual': habbitIdLessThanOrEqual,
                'habbitId.equals': habbitIdEquals,
                'habbitId.notEquals': habbitIdNotEquals,
                'habbitId.specified': habbitIdSpecified,
                'habbitId.in': habbitIdIn,
                'habbitId.notIn': habbitIdNotIn,
                'socialHistoryId.greaterThan': socialHistoryIdGreaterThan,
                'socialHistoryId.lessThan': socialHistoryIdLessThan,
                'socialHistoryId.greaterThanOrEqual': socialHistoryIdGreaterThanOrEqual,
                'socialHistoryId.lessThanOrEqual': socialHistoryIdLessThanOrEqual,
                'socialHistoryId.equals': socialHistoryIdEquals,
                'socialHistoryId.notEquals': socialHistoryIdNotEquals,
                'socialHistoryId.specified': socialHistoryIdSpecified,
                'socialHistoryId.in': socialHistoryIdIn,
                'socialHistoryId.notIn': socialHistoryIdNotIn,
                'patientFunctionalStatusId.greaterThan': patientFunctionalStatusIdGreaterThan,
                'patientFunctionalStatusId.lessThan': patientFunctionalStatusIdLessThan,
                'patientFunctionalStatusId.greaterThanOrEqual': patientFunctionalStatusIdGreaterThanOrEqual,
                'patientFunctionalStatusId.lessThanOrEqual': patientFunctionalStatusIdLessThanOrEqual,
                'patientFunctionalStatusId.equals': patientFunctionalStatusIdEquals,
                'patientFunctionalStatusId.notEquals': patientFunctionalStatusIdNotEquals,
                'patientFunctionalStatusId.specified': patientFunctionalStatusIdSpecified,
                'patientFunctionalStatusId.in': patientFunctionalStatusIdIn,
                'patientFunctionalStatusId.notIn': patientFunctionalStatusIdNotIn,
                'exerciseHistoryId.greaterThan': exerciseHistoryIdGreaterThan,
                'exerciseHistoryId.lessThan': exerciseHistoryIdLessThan,
                'exerciseHistoryId.greaterThanOrEqual': exerciseHistoryIdGreaterThanOrEqual,
                'exerciseHistoryId.lessThanOrEqual': exerciseHistoryIdLessThanOrEqual,
                'exerciseHistoryId.equals': exerciseHistoryIdEquals,
                'exerciseHistoryId.notEquals': exerciseHistoryIdNotEquals,
                'exerciseHistoryId.specified': exerciseHistoryIdSpecified,
                'exerciseHistoryId.in': exerciseHistoryIdIn,
                'exerciseHistoryId.notIn': exerciseHistoryIdNotIn,
                'patientCognitiveStatusId.greaterThan': patientCognitiveStatusIdGreaterThan,
                'patientCognitiveStatusId.lessThan': patientCognitiveStatusIdLessThan,
                'patientCognitiveStatusId.greaterThanOrEqual': patientCognitiveStatusIdGreaterThanOrEqual,
                'patientCognitiveStatusId.lessThanOrEqual': patientCognitiveStatusIdLessThanOrEqual,
                'patientCognitiveStatusId.equals': patientCognitiveStatusIdEquals,
                'patientCognitiveStatusId.notEquals': patientCognitiveStatusIdNotEquals,
                'patientCognitiveStatusId.specified': patientCognitiveStatusIdSpecified,
                'patientCognitiveStatusId.in': patientCognitiveStatusIdIn,
                'patientCognitiveStatusId.notIn': patientCognitiveStatusIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns HistoryQuestionDTO OK
     * @throws ApiError
     */
    public static createHistoryQuestion(
        requestBody: HistoryQuestionDTO,
    ): CancelablePromise<HistoryQuestionDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/history-questions',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param questionContains
     * @param questionDoesNotContain
     * @param questionEquals
     * @param questionNotEquals
     * @param questionSpecified
     * @param questionIn
     * @param questionNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param psychologicalHistoryIdGreaterThan
     * @param psychologicalHistoryIdLessThan
     * @param psychologicalHistoryIdGreaterThanOrEqual
     * @param psychologicalHistoryIdLessThanOrEqual
     * @param psychologicalHistoryIdEquals
     * @param psychologicalHistoryIdNotEquals
     * @param psychologicalHistoryIdSpecified
     * @param psychologicalHistoryIdIn
     * @param psychologicalHistoryIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param patientDietIdGreaterThan
     * @param patientDietIdLessThan
     * @param patientDietIdGreaterThanOrEqual
     * @param patientDietIdLessThanOrEqual
     * @param patientDietIdEquals
     * @param patientDietIdNotEquals
     * @param patientDietIdSpecified
     * @param patientDietIdIn
     * @param patientDietIdNotIn
     * @param habbitIdGreaterThan
     * @param habbitIdLessThan
     * @param habbitIdGreaterThanOrEqual
     * @param habbitIdLessThanOrEqual
     * @param habbitIdEquals
     * @param habbitIdNotEquals
     * @param habbitIdSpecified
     * @param habbitIdIn
     * @param habbitIdNotIn
     * @param socialHistoryIdGreaterThan
     * @param socialHistoryIdLessThan
     * @param socialHistoryIdGreaterThanOrEqual
     * @param socialHistoryIdLessThanOrEqual
     * @param socialHistoryIdEquals
     * @param socialHistoryIdNotEquals
     * @param socialHistoryIdSpecified
     * @param socialHistoryIdIn
     * @param socialHistoryIdNotIn
     * @param patientFunctionalStatusIdGreaterThan
     * @param patientFunctionalStatusIdLessThan
     * @param patientFunctionalStatusIdGreaterThanOrEqual
     * @param patientFunctionalStatusIdLessThanOrEqual
     * @param patientFunctionalStatusIdEquals
     * @param patientFunctionalStatusIdNotEquals
     * @param patientFunctionalStatusIdSpecified
     * @param patientFunctionalStatusIdIn
     * @param patientFunctionalStatusIdNotIn
     * @param exerciseHistoryIdGreaterThan
     * @param exerciseHistoryIdLessThan
     * @param exerciseHistoryIdGreaterThanOrEqual
     * @param exerciseHistoryIdLessThanOrEqual
     * @param exerciseHistoryIdEquals
     * @param exerciseHistoryIdNotEquals
     * @param exerciseHistoryIdSpecified
     * @param exerciseHistoryIdIn
     * @param exerciseHistoryIdNotIn
     * @param patientCognitiveStatusIdGreaterThan
     * @param patientCognitiveStatusIdLessThan
     * @param patientCognitiveStatusIdGreaterThanOrEqual
     * @param patientCognitiveStatusIdLessThanOrEqual
     * @param patientCognitiveStatusIdEquals
     * @param patientCognitiveStatusIdNotEquals
     * @param patientCognitiveStatusIdSpecified
     * @param patientCognitiveStatusIdIn
     * @param patientCognitiveStatusIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countHistoryQuestions(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        questionContains?: string,
        questionDoesNotContain?: string,
        questionEquals?: string,
        questionNotEquals?: string,
        questionSpecified?: boolean,
        questionIn?: Array<string>,
        questionNotIn?: Array<string>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        psychologicalHistoryIdGreaterThan?: number,
        psychologicalHistoryIdLessThan?: number,
        psychologicalHistoryIdGreaterThanOrEqual?: number,
        psychologicalHistoryIdLessThanOrEqual?: number,
        psychologicalHistoryIdEquals?: number,
        psychologicalHistoryIdNotEquals?: number,
        psychologicalHistoryIdSpecified?: boolean,
        psychologicalHistoryIdIn?: Array<number>,
        psychologicalHistoryIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        patientDietIdGreaterThan?: number,
        patientDietIdLessThan?: number,
        patientDietIdGreaterThanOrEqual?: number,
        patientDietIdLessThanOrEqual?: number,
        patientDietIdEquals?: number,
        patientDietIdNotEquals?: number,
        patientDietIdSpecified?: boolean,
        patientDietIdIn?: Array<number>,
        patientDietIdNotIn?: Array<number>,
        habbitIdGreaterThan?: number,
        habbitIdLessThan?: number,
        habbitIdGreaterThanOrEqual?: number,
        habbitIdLessThanOrEqual?: number,
        habbitIdEquals?: number,
        habbitIdNotEquals?: number,
        habbitIdSpecified?: boolean,
        habbitIdIn?: Array<number>,
        habbitIdNotIn?: Array<number>,
        socialHistoryIdGreaterThan?: number,
        socialHistoryIdLessThan?: number,
        socialHistoryIdGreaterThanOrEqual?: number,
        socialHistoryIdLessThanOrEqual?: number,
        socialHistoryIdEquals?: number,
        socialHistoryIdNotEquals?: number,
        socialHistoryIdSpecified?: boolean,
        socialHistoryIdIn?: Array<number>,
        socialHistoryIdNotIn?: Array<number>,
        patientFunctionalStatusIdGreaterThan?: number,
        patientFunctionalStatusIdLessThan?: number,
        patientFunctionalStatusIdGreaterThanOrEqual?: number,
        patientFunctionalStatusIdLessThanOrEqual?: number,
        patientFunctionalStatusIdEquals?: number,
        patientFunctionalStatusIdNotEquals?: number,
        patientFunctionalStatusIdSpecified?: boolean,
        patientFunctionalStatusIdIn?: Array<number>,
        patientFunctionalStatusIdNotIn?: Array<number>,
        exerciseHistoryIdGreaterThan?: number,
        exerciseHistoryIdLessThan?: number,
        exerciseHistoryIdGreaterThanOrEqual?: number,
        exerciseHistoryIdLessThanOrEqual?: number,
        exerciseHistoryIdEquals?: number,
        exerciseHistoryIdNotEquals?: number,
        exerciseHistoryIdSpecified?: boolean,
        exerciseHistoryIdIn?: Array<number>,
        exerciseHistoryIdNotIn?: Array<number>,
        patientCognitiveStatusIdGreaterThan?: number,
        patientCognitiveStatusIdLessThan?: number,
        patientCognitiveStatusIdGreaterThanOrEqual?: number,
        patientCognitiveStatusIdLessThanOrEqual?: number,
        patientCognitiveStatusIdEquals?: number,
        patientCognitiveStatusIdNotEquals?: number,
        patientCognitiveStatusIdSpecified?: boolean,
        patientCognitiveStatusIdIn?: Array<number>,
        patientCognitiveStatusIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/history-questions/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'question.contains': questionContains,
                'question.doesNotContain': questionDoesNotContain,
                'question.equals': questionEquals,
                'question.notEquals': questionNotEquals,
                'question.specified': questionSpecified,
                'question.in': questionIn,
                'question.notIn': questionNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'psychologicalHistoryId.greaterThan': psychologicalHistoryIdGreaterThan,
                'psychologicalHistoryId.lessThan': psychologicalHistoryIdLessThan,
                'psychologicalHistoryId.greaterThanOrEqual': psychologicalHistoryIdGreaterThanOrEqual,
                'psychologicalHistoryId.lessThanOrEqual': psychologicalHistoryIdLessThanOrEqual,
                'psychologicalHistoryId.equals': psychologicalHistoryIdEquals,
                'psychologicalHistoryId.notEquals': psychologicalHistoryIdNotEquals,
                'psychologicalHistoryId.specified': psychologicalHistoryIdSpecified,
                'psychologicalHistoryId.in': psychologicalHistoryIdIn,
                'psychologicalHistoryId.notIn': psychologicalHistoryIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'patientDietId.greaterThan': patientDietIdGreaterThan,
                'patientDietId.lessThan': patientDietIdLessThan,
                'patientDietId.greaterThanOrEqual': patientDietIdGreaterThanOrEqual,
                'patientDietId.lessThanOrEqual': patientDietIdLessThanOrEqual,
                'patientDietId.equals': patientDietIdEquals,
                'patientDietId.notEquals': patientDietIdNotEquals,
                'patientDietId.specified': patientDietIdSpecified,
                'patientDietId.in': patientDietIdIn,
                'patientDietId.notIn': patientDietIdNotIn,
                'habbitId.greaterThan': habbitIdGreaterThan,
                'habbitId.lessThan': habbitIdLessThan,
                'habbitId.greaterThanOrEqual': habbitIdGreaterThanOrEqual,
                'habbitId.lessThanOrEqual': habbitIdLessThanOrEqual,
                'habbitId.equals': habbitIdEquals,
                'habbitId.notEquals': habbitIdNotEquals,
                'habbitId.specified': habbitIdSpecified,
                'habbitId.in': habbitIdIn,
                'habbitId.notIn': habbitIdNotIn,
                'socialHistoryId.greaterThan': socialHistoryIdGreaterThan,
                'socialHistoryId.lessThan': socialHistoryIdLessThan,
                'socialHistoryId.greaterThanOrEqual': socialHistoryIdGreaterThanOrEqual,
                'socialHistoryId.lessThanOrEqual': socialHistoryIdLessThanOrEqual,
                'socialHistoryId.equals': socialHistoryIdEquals,
                'socialHistoryId.notEquals': socialHistoryIdNotEquals,
                'socialHistoryId.specified': socialHistoryIdSpecified,
                'socialHistoryId.in': socialHistoryIdIn,
                'socialHistoryId.notIn': socialHistoryIdNotIn,
                'patientFunctionalStatusId.greaterThan': patientFunctionalStatusIdGreaterThan,
                'patientFunctionalStatusId.lessThan': patientFunctionalStatusIdLessThan,
                'patientFunctionalStatusId.greaterThanOrEqual': patientFunctionalStatusIdGreaterThanOrEqual,
                'patientFunctionalStatusId.lessThanOrEqual': patientFunctionalStatusIdLessThanOrEqual,
                'patientFunctionalStatusId.equals': patientFunctionalStatusIdEquals,
                'patientFunctionalStatusId.notEquals': patientFunctionalStatusIdNotEquals,
                'patientFunctionalStatusId.specified': patientFunctionalStatusIdSpecified,
                'patientFunctionalStatusId.in': patientFunctionalStatusIdIn,
                'patientFunctionalStatusId.notIn': patientFunctionalStatusIdNotIn,
                'exerciseHistoryId.greaterThan': exerciseHistoryIdGreaterThan,
                'exerciseHistoryId.lessThan': exerciseHistoryIdLessThan,
                'exerciseHistoryId.greaterThanOrEqual': exerciseHistoryIdGreaterThanOrEqual,
                'exerciseHistoryId.lessThanOrEqual': exerciseHistoryIdLessThanOrEqual,
                'exerciseHistoryId.equals': exerciseHistoryIdEquals,
                'exerciseHistoryId.notEquals': exerciseHistoryIdNotEquals,
                'exerciseHistoryId.specified': exerciseHistoryIdSpecified,
                'exerciseHistoryId.in': exerciseHistoryIdIn,
                'exerciseHistoryId.notIn': exerciseHistoryIdNotIn,
                'patientCognitiveStatusId.greaterThan': patientCognitiveStatusIdGreaterThan,
                'patientCognitiveStatusId.lessThan': patientCognitiveStatusIdLessThan,
                'patientCognitiveStatusId.greaterThanOrEqual': patientCognitiveStatusIdGreaterThanOrEqual,
                'patientCognitiveStatusId.lessThanOrEqual': patientCognitiveStatusIdLessThanOrEqual,
                'patientCognitiveStatusId.equals': patientCognitiveStatusIdEquals,
                'patientCognitiveStatusId.notEquals': patientCognitiveStatusIdNotEquals,
                'patientCognitiveStatusId.specified': patientCognitiveStatusIdSpecified,
                'patientCognitiveStatusId.in': patientCognitiveStatusIdIn,
                'patientCognitiveStatusId.notIn': patientCognitiveStatusIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
