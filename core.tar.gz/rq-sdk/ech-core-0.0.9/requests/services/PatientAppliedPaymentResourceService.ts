/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientAppliedPaymentDTO } from '../models/PatientAppliedPaymentDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientAppliedPaymentResourceService {

    /**
     * @param id
     * @returns PatientAppliedPaymentDTO OK
     * @throws ApiError
     */
    public static getPatientAppliedPayment(
        id: number,
    ): CancelablePromise<PatientAppliedPaymentDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-applied-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAppliedPaymentDTO OK
     * @throws ApiError
     */
    public static updatePatientAppliedPayment(
        id: number,
        requestBody: PatientAppliedPaymentDTO,
    ): CancelablePromise<PatientAppliedPaymentDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-applied-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientAppliedPayment(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-applied-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientAppliedPaymentDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientAppliedPayment(
        id: number,
        requestBody: PatientAppliedPaymentDTO,
    ): CancelablePromise<PatientAppliedPaymentDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-applied-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param paymentIdIdGreaterThan
     * @param paymentIdIdLessThan
     * @param paymentIdIdGreaterThanOrEqual
     * @param paymentIdIdLessThanOrEqual
     * @param paymentIdIdEquals
     * @param paymentIdIdNotEquals
     * @param paymentIdIdSpecified
     * @param paymentIdIdIn
     * @param paymentIdIdNotIn
     * @param superBillIdIdGreaterThan
     * @param superBillIdIdLessThan
     * @param superBillIdIdGreaterThanOrEqual
     * @param superBillIdIdLessThanOrEqual
     * @param superBillIdIdEquals
     * @param superBillIdIdNotEquals
     * @param superBillIdIdSpecified
     * @param superBillIdIdIn
     * @param superBillIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientAppliedPaymentDTO OK
     * @throws ApiError
     */
    public static getAllPatientAppliedPayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        paymentIdIdGreaterThan?: number,
        paymentIdIdLessThan?: number,
        paymentIdIdGreaterThanOrEqual?: number,
        paymentIdIdLessThanOrEqual?: number,
        paymentIdIdEquals?: number,
        paymentIdIdNotEquals?: number,
        paymentIdIdSpecified?: boolean,
        paymentIdIdIn?: Array<number>,
        paymentIdIdNotIn?: Array<number>,
        superBillIdIdGreaterThan?: number,
        superBillIdIdLessThan?: number,
        superBillIdIdGreaterThanOrEqual?: number,
        superBillIdIdLessThanOrEqual?: number,
        superBillIdIdEquals?: number,
        superBillIdIdNotEquals?: number,
        superBillIdIdSpecified?: boolean,
        superBillIdIdIn?: Array<number>,
        superBillIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientAppliedPaymentDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-applied-payments',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'paymentIdId.greaterThan': paymentIdIdGreaterThan,
                'paymentIdId.lessThan': paymentIdIdLessThan,
                'paymentIdId.greaterThanOrEqual': paymentIdIdGreaterThanOrEqual,
                'paymentIdId.lessThanOrEqual': paymentIdIdLessThanOrEqual,
                'paymentIdId.equals': paymentIdIdEquals,
                'paymentIdId.notEquals': paymentIdIdNotEquals,
                'paymentIdId.specified': paymentIdIdSpecified,
                'paymentIdId.in': paymentIdIdIn,
                'paymentIdId.notIn': paymentIdIdNotIn,
                'superBillIdId.greaterThan': superBillIdIdGreaterThan,
                'superBillIdId.lessThan': superBillIdIdLessThan,
                'superBillIdId.greaterThanOrEqual': superBillIdIdGreaterThanOrEqual,
                'superBillIdId.lessThanOrEqual': superBillIdIdLessThanOrEqual,
                'superBillIdId.equals': superBillIdIdEquals,
                'superBillIdId.notEquals': superBillIdIdNotEquals,
                'superBillIdId.specified': superBillIdIdSpecified,
                'superBillIdId.in': superBillIdIdIn,
                'superBillIdId.notIn': superBillIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientAppliedPaymentDTO OK
     * @throws ApiError
     */
    public static createPatientAppliedPayment(
        requestBody: PatientAppliedPaymentDTO,
    ): CancelablePromise<PatientAppliedPaymentDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-applied-payments',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param paymentIdIdGreaterThan
     * @param paymentIdIdLessThan
     * @param paymentIdIdGreaterThanOrEqual
     * @param paymentIdIdLessThanOrEqual
     * @param paymentIdIdEquals
     * @param paymentIdIdNotEquals
     * @param paymentIdIdSpecified
     * @param paymentIdIdIn
     * @param paymentIdIdNotIn
     * @param superBillIdIdGreaterThan
     * @param superBillIdIdLessThan
     * @param superBillIdIdGreaterThanOrEqual
     * @param superBillIdIdLessThanOrEqual
     * @param superBillIdIdEquals
     * @param superBillIdIdNotEquals
     * @param superBillIdIdSpecified
     * @param superBillIdIdIn
     * @param superBillIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientAppliedPayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        paymentIdIdGreaterThan?: number,
        paymentIdIdLessThan?: number,
        paymentIdIdGreaterThanOrEqual?: number,
        paymentIdIdLessThanOrEqual?: number,
        paymentIdIdEquals?: number,
        paymentIdIdNotEquals?: number,
        paymentIdIdSpecified?: boolean,
        paymentIdIdIn?: Array<number>,
        paymentIdIdNotIn?: Array<number>,
        superBillIdIdGreaterThan?: number,
        superBillIdIdLessThan?: number,
        superBillIdIdGreaterThanOrEqual?: number,
        superBillIdIdLessThanOrEqual?: number,
        superBillIdIdEquals?: number,
        superBillIdIdNotEquals?: number,
        superBillIdIdSpecified?: boolean,
        superBillIdIdIn?: Array<number>,
        superBillIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-applied-payments/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'paymentIdId.greaterThan': paymentIdIdGreaterThan,
                'paymentIdId.lessThan': paymentIdIdLessThan,
                'paymentIdId.greaterThanOrEqual': paymentIdIdGreaterThanOrEqual,
                'paymentIdId.lessThanOrEqual': paymentIdIdLessThanOrEqual,
                'paymentIdId.equals': paymentIdIdEquals,
                'paymentIdId.notEquals': paymentIdIdNotEquals,
                'paymentIdId.specified': paymentIdIdSpecified,
                'paymentIdId.in': paymentIdIdIn,
                'paymentIdId.notIn': paymentIdIdNotIn,
                'superBillIdId.greaterThan': superBillIdIdGreaterThan,
                'superBillIdId.lessThan': superBillIdIdLessThan,
                'superBillIdId.greaterThanOrEqual': superBillIdIdGreaterThanOrEqual,
                'superBillIdId.lessThanOrEqual': superBillIdIdLessThanOrEqual,
                'superBillIdId.equals': superBillIdIdEquals,
                'superBillIdId.notEquals': superBillIdIdNotEquals,
                'superBillIdId.specified': superBillIdIdSpecified,
                'superBillIdId.in': superBillIdIdIn,
                'superBillIdId.notIn': superBillIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
