/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeSocialHistoryDTO } from '../models/IntakeSocialHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeSocialHistoryResourceService {

    /**
     * @param id
     * @returns IntakeSocialHistoryDTO OK
     * @throws ApiError
     */
    public static getIntakeSocialHistory(
        id: number,
    ): CancelablePromise<IntakeSocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-social-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeSocialHistoryDTO OK
     * @throws ApiError
     */
    public static updateIntakeSocialHistory(
        id: number,
        requestBody: IntakeSocialHistoryDTO,
    ): CancelablePromise<IntakeSocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-social-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeSocialHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-social-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeSocialHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeSocialHistory(
        id: number,
        requestBody: IntakeSocialHistoryDTO,
    ): CancelablePromise<IntakeSocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-social-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param socialHistoryIdIdGreaterThan
     * @param socialHistoryIdIdLessThan
     * @param socialHistoryIdIdGreaterThanOrEqual
     * @param socialHistoryIdIdLessThanOrEqual
     * @param socialHistoryIdIdEquals
     * @param socialHistoryIdIdNotEquals
     * @param socialHistoryIdIdSpecified
     * @param socialHistoryIdIdIn
     * @param socialHistoryIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeSocialHistoryDTO OK
     * @throws ApiError
     */
    public static getAllIntakeSocialHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        socialHistoryIdIdGreaterThan?: number,
        socialHistoryIdIdLessThan?: number,
        socialHistoryIdIdGreaterThanOrEqual?: number,
        socialHistoryIdIdLessThanOrEqual?: number,
        socialHistoryIdIdEquals?: number,
        socialHistoryIdIdNotEquals?: number,
        socialHistoryIdIdSpecified?: boolean,
        socialHistoryIdIdIn?: Array<number>,
        socialHistoryIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeSocialHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-social-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'socialHistoryIdId.greaterThan': socialHistoryIdIdGreaterThan,
                'socialHistoryIdId.lessThan': socialHistoryIdIdLessThan,
                'socialHistoryIdId.greaterThanOrEqual': socialHistoryIdIdGreaterThanOrEqual,
                'socialHistoryIdId.lessThanOrEqual': socialHistoryIdIdLessThanOrEqual,
                'socialHistoryIdId.equals': socialHistoryIdIdEquals,
                'socialHistoryIdId.notEquals': socialHistoryIdIdNotEquals,
                'socialHistoryIdId.specified': socialHistoryIdIdSpecified,
                'socialHistoryIdId.in': socialHistoryIdIdIn,
                'socialHistoryIdId.notIn': socialHistoryIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeSocialHistoryDTO OK
     * @throws ApiError
     */
    public static createIntakeSocialHistory(
        requestBody: IntakeSocialHistoryDTO,
    ): CancelablePromise<IntakeSocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-social-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeFormIdIdGreaterThan
     * @param intakeFormIdIdLessThan
     * @param intakeFormIdIdGreaterThanOrEqual
     * @param intakeFormIdIdLessThanOrEqual
     * @param intakeFormIdIdEquals
     * @param intakeFormIdIdNotEquals
     * @param intakeFormIdIdSpecified
     * @param intakeFormIdIdIn
     * @param intakeFormIdIdNotIn
     * @param socialHistoryIdIdGreaterThan
     * @param socialHistoryIdIdLessThan
     * @param socialHistoryIdIdGreaterThanOrEqual
     * @param socialHistoryIdIdLessThanOrEqual
     * @param socialHistoryIdIdEquals
     * @param socialHistoryIdIdNotEquals
     * @param socialHistoryIdIdSpecified
     * @param socialHistoryIdIdIn
     * @param socialHistoryIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeSocialHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeFormIdIdGreaterThan?: number,
        intakeFormIdIdLessThan?: number,
        intakeFormIdIdGreaterThanOrEqual?: number,
        intakeFormIdIdLessThanOrEqual?: number,
        intakeFormIdIdEquals?: number,
        intakeFormIdIdNotEquals?: number,
        intakeFormIdIdSpecified?: boolean,
        intakeFormIdIdIn?: Array<number>,
        intakeFormIdIdNotIn?: Array<number>,
        socialHistoryIdIdGreaterThan?: number,
        socialHistoryIdIdLessThan?: number,
        socialHistoryIdIdGreaterThanOrEqual?: number,
        socialHistoryIdIdLessThanOrEqual?: number,
        socialHistoryIdIdEquals?: number,
        socialHistoryIdIdNotEquals?: number,
        socialHistoryIdIdSpecified?: boolean,
        socialHistoryIdIdIn?: Array<number>,
        socialHistoryIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-social-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeFormIdId.greaterThan': intakeFormIdIdGreaterThan,
                'intakeFormIdId.lessThan': intakeFormIdIdLessThan,
                'intakeFormIdId.greaterThanOrEqual': intakeFormIdIdGreaterThanOrEqual,
                'intakeFormIdId.lessThanOrEqual': intakeFormIdIdLessThanOrEqual,
                'intakeFormIdId.equals': intakeFormIdIdEquals,
                'intakeFormIdId.notEquals': intakeFormIdIdNotEquals,
                'intakeFormIdId.specified': intakeFormIdIdSpecified,
                'intakeFormIdId.in': intakeFormIdIdIn,
                'intakeFormIdId.notIn': intakeFormIdIdNotIn,
                'socialHistoryIdId.greaterThan': socialHistoryIdIdGreaterThan,
                'socialHistoryIdId.lessThan': socialHistoryIdIdLessThan,
                'socialHistoryIdId.greaterThanOrEqual': socialHistoryIdIdGreaterThanOrEqual,
                'socialHistoryIdId.lessThanOrEqual': socialHistoryIdIdLessThanOrEqual,
                'socialHistoryIdId.equals': socialHistoryIdIdEquals,
                'socialHistoryIdId.notEquals': socialHistoryIdIdNotEquals,
                'socialHistoryIdId.specified': socialHistoryIdIdSpecified,
                'socialHistoryIdId.in': socialHistoryIdIdIn,
                'socialHistoryIdId.notIn': socialHistoryIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
