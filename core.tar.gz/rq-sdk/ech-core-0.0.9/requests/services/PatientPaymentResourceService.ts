/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PatientPaymentDTO } from '../models/PatientPaymentDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientPaymentResourceService {

    /**
     * @param id
     * @returns PatientPaymentDTO OK
     * @throws ApiError
     */
    public static getPatientPayment(
        id: number,
    ): CancelablePromise<PatientPaymentDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientPaymentDTO OK
     * @throws ApiError
     */
    public static updatePatientPayment(
        id: number,
        requestBody: PatientPaymentDTO,
    ): CancelablePromise<PatientPaymentDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientPayment(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-payments/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientPaymentDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientPayment(
        id: number,
        requestBody: PatientPaymentDTO,
    ): CancelablePromise<PatientPaymentDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-payments/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param paymentModeContains
     * @param paymentModeDoesNotContain
     * @param paymentModeEquals
     * @param paymentModeNotEquals
     * @param paymentModeSpecified
     * @param paymentModeIn
     * @param paymentModeNotIn
     * @param paymentMethodContains
     * @param paymentMethodDoesNotContain
     * @param paymentMethodEquals
     * @param paymentMethodNotEquals
     * @param paymentMethodSpecified
     * @param paymentMethodIn
     * @param paymentMethodNotIn
     * @param paymentIdContains
     * @param paymentIdDoesNotContain
     * @param paymentIdEquals
     * @param paymentIdNotEquals
     * @param paymentIdSpecified
     * @param paymentIdIn
     * @param paymentIdNotIn
     * @param payerNameContains
     * @param payerNameDoesNotContain
     * @param payerNameEquals
     * @param payerNameNotEquals
     * @param payerNameSpecified
     * @param payerNameIn
     * @param payerNameNotIn
     * @param transactionIdContains
     * @param transactionIdDoesNotContain
     * @param transactionIdEquals
     * @param transactionIdNotEquals
     * @param transactionIdSpecified
     * @param transactionIdIn
     * @param transactionIdNotIn
     * @param transactionAmountGreaterThan
     * @param transactionAmountLessThan
     * @param transactionAmountGreaterThanOrEqual
     * @param transactionAmountLessThanOrEqual
     * @param transactionAmountEquals
     * @param transactionAmountNotEquals
     * @param transactionAmountSpecified
     * @param transactionAmountIn
     * @param transactionAmountNotIn
     * @param transactionDateGreaterThan
     * @param transactionDateLessThan
     * @param transactionDateGreaterThanOrEqual
     * @param transactionDateLessThanOrEqual
     * @param transactionDateEquals
     * @param transactionDateNotEquals
     * @param transactionDateSpecified
     * @param transactionDateIn
     * @param transactionDateNotIn
     * @param sourceContains
     * @param sourceDoesNotContain
     * @param sourceEquals
     * @param sourceNotEquals
     * @param sourceSpecified
     * @param sourceIn
     * @param sourceNotIn
     * @param referenceNumberGreaterThan
     * @param referenceNumberLessThan
     * @param referenceNumberGreaterThanOrEqual
     * @param referenceNumberLessThanOrEqual
     * @param referenceNumberEquals
     * @param referenceNumberNotEquals
     * @param referenceNumberSpecified
     * @param referenceNumberIn
     * @param referenceNumberNotIn
     * @param cardNumberGreaterThan
     * @param cardNumberLessThan
     * @param cardNumberGreaterThanOrEqual
     * @param cardNumberLessThanOrEqual
     * @param cardNumberEquals
     * @param cardNumberNotEquals
     * @param cardNumberSpecified
     * @param cardNumberIn
     * @param cardNumberNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param unappliedAmountGreaterThan
     * @param unappliedAmountLessThan
     * @param unappliedAmountGreaterThanOrEqual
     * @param unappliedAmountLessThanOrEqual
     * @param unappliedAmountEquals
     * @param unappliedAmountNotEquals
     * @param unappliedAmountSpecified
     * @param unappliedAmountIn
     * @param unappliedAmountNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param patientAppliedPaymentIdGreaterThan
     * @param patientAppliedPaymentIdLessThan
     * @param patientAppliedPaymentIdGreaterThanOrEqual
     * @param patientAppliedPaymentIdLessThanOrEqual
     * @param patientAppliedPaymentIdEquals
     * @param patientAppliedPaymentIdNotEquals
     * @param patientAppliedPaymentIdSpecified
     * @param patientAppliedPaymentIdIn
     * @param patientAppliedPaymentIdNotIn
     * @param insurancePaymentIdGreaterThan
     * @param insurancePaymentIdLessThan
     * @param insurancePaymentIdGreaterThanOrEqual
     * @param insurancePaymentIdLessThanOrEqual
     * @param insurancePaymentIdEquals
     * @param insurancePaymentIdNotEquals
     * @param insurancePaymentIdSpecified
     * @param insurancePaymentIdIn
     * @param insurancePaymentIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientPaymentDTO OK
     * @throws ApiError
     */
    public static getAllPatientPayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        paymentModeContains?: string,
        paymentModeDoesNotContain?: string,
        paymentModeEquals?: string,
        paymentModeNotEquals?: string,
        paymentModeSpecified?: boolean,
        paymentModeIn?: Array<string>,
        paymentModeNotIn?: Array<string>,
        paymentMethodContains?: string,
        paymentMethodDoesNotContain?: string,
        paymentMethodEquals?: string,
        paymentMethodNotEquals?: string,
        paymentMethodSpecified?: boolean,
        paymentMethodIn?: Array<string>,
        paymentMethodNotIn?: Array<string>,
        paymentIdContains?: string,
        paymentIdDoesNotContain?: string,
        paymentIdEquals?: string,
        paymentIdNotEquals?: string,
        paymentIdSpecified?: boolean,
        paymentIdIn?: Array<string>,
        paymentIdNotIn?: Array<string>,
        payerNameContains?: string,
        payerNameDoesNotContain?: string,
        payerNameEquals?: string,
        payerNameNotEquals?: string,
        payerNameSpecified?: boolean,
        payerNameIn?: Array<string>,
        payerNameNotIn?: Array<string>,
        transactionIdContains?: string,
        transactionIdDoesNotContain?: string,
        transactionIdEquals?: string,
        transactionIdNotEquals?: string,
        transactionIdSpecified?: boolean,
        transactionIdIn?: Array<string>,
        transactionIdNotIn?: Array<string>,
        transactionAmountGreaterThan?: number,
        transactionAmountLessThan?: number,
        transactionAmountGreaterThanOrEqual?: number,
        transactionAmountLessThanOrEqual?: number,
        transactionAmountEquals?: number,
        transactionAmountNotEquals?: number,
        transactionAmountSpecified?: boolean,
        transactionAmountIn?: Array<number>,
        transactionAmountNotIn?: Array<number>,
        transactionDateGreaterThan?: string,
        transactionDateLessThan?: string,
        transactionDateGreaterThanOrEqual?: string,
        transactionDateLessThanOrEqual?: string,
        transactionDateEquals?: string,
        transactionDateNotEquals?: string,
        transactionDateSpecified?: boolean,
        transactionDateIn?: Array<string>,
        transactionDateNotIn?: Array<string>,
        sourceContains?: string,
        sourceDoesNotContain?: string,
        sourceEquals?: string,
        sourceNotEquals?: string,
        sourceSpecified?: boolean,
        sourceIn?: Array<string>,
        sourceNotIn?: Array<string>,
        referenceNumberGreaterThan?: number,
        referenceNumberLessThan?: number,
        referenceNumberGreaterThanOrEqual?: number,
        referenceNumberLessThanOrEqual?: number,
        referenceNumberEquals?: number,
        referenceNumberNotEquals?: number,
        referenceNumberSpecified?: boolean,
        referenceNumberIn?: Array<number>,
        referenceNumberNotIn?: Array<number>,
        cardNumberGreaterThan?: number,
        cardNumberLessThan?: number,
        cardNumberGreaterThanOrEqual?: number,
        cardNumberLessThanOrEqual?: number,
        cardNumberEquals?: number,
        cardNumberNotEquals?: number,
        cardNumberSpecified?: boolean,
        cardNumberIn?: Array<number>,
        cardNumberNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        unappliedAmountGreaterThan?: number,
        unappliedAmountLessThan?: number,
        unappliedAmountGreaterThanOrEqual?: number,
        unappliedAmountLessThanOrEqual?: number,
        unappliedAmountEquals?: number,
        unappliedAmountNotEquals?: number,
        unappliedAmountSpecified?: boolean,
        unappliedAmountIn?: Array<number>,
        unappliedAmountNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        patientAppliedPaymentIdGreaterThan?: number,
        patientAppliedPaymentIdLessThan?: number,
        patientAppliedPaymentIdGreaterThanOrEqual?: number,
        patientAppliedPaymentIdLessThanOrEqual?: number,
        patientAppliedPaymentIdEquals?: number,
        patientAppliedPaymentIdNotEquals?: number,
        patientAppliedPaymentIdSpecified?: boolean,
        patientAppliedPaymentIdIn?: Array<number>,
        patientAppliedPaymentIdNotIn?: Array<number>,
        insurancePaymentIdGreaterThan?: number,
        insurancePaymentIdLessThan?: number,
        insurancePaymentIdGreaterThanOrEqual?: number,
        insurancePaymentIdLessThanOrEqual?: number,
        insurancePaymentIdEquals?: number,
        insurancePaymentIdNotEquals?: number,
        insurancePaymentIdSpecified?: boolean,
        insurancePaymentIdIn?: Array<number>,
        insurancePaymentIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientPaymentDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-payments',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'paymentMode.contains': paymentModeContains,
                'paymentMode.doesNotContain': paymentModeDoesNotContain,
                'paymentMode.equals': paymentModeEquals,
                'paymentMode.notEquals': paymentModeNotEquals,
                'paymentMode.specified': paymentModeSpecified,
                'paymentMode.in': paymentModeIn,
                'paymentMode.notIn': paymentModeNotIn,
                'paymentMethod.contains': paymentMethodContains,
                'paymentMethod.doesNotContain': paymentMethodDoesNotContain,
                'paymentMethod.equals': paymentMethodEquals,
                'paymentMethod.notEquals': paymentMethodNotEquals,
                'paymentMethod.specified': paymentMethodSpecified,
                'paymentMethod.in': paymentMethodIn,
                'paymentMethod.notIn': paymentMethodNotIn,
                'paymentId.contains': paymentIdContains,
                'paymentId.doesNotContain': paymentIdDoesNotContain,
                'paymentId.equals': paymentIdEquals,
                'paymentId.notEquals': paymentIdNotEquals,
                'paymentId.specified': paymentIdSpecified,
                'paymentId.in': paymentIdIn,
                'paymentId.notIn': paymentIdNotIn,
                'payerName.contains': payerNameContains,
                'payerName.doesNotContain': payerNameDoesNotContain,
                'payerName.equals': payerNameEquals,
                'payerName.notEquals': payerNameNotEquals,
                'payerName.specified': payerNameSpecified,
                'payerName.in': payerNameIn,
                'payerName.notIn': payerNameNotIn,
                'transactionId.contains': transactionIdContains,
                'transactionId.doesNotContain': transactionIdDoesNotContain,
                'transactionId.equals': transactionIdEquals,
                'transactionId.notEquals': transactionIdNotEquals,
                'transactionId.specified': transactionIdSpecified,
                'transactionId.in': transactionIdIn,
                'transactionId.notIn': transactionIdNotIn,
                'transactionAmount.greaterThan': transactionAmountGreaterThan,
                'transactionAmount.lessThan': transactionAmountLessThan,
                'transactionAmount.greaterThanOrEqual': transactionAmountGreaterThanOrEqual,
                'transactionAmount.lessThanOrEqual': transactionAmountLessThanOrEqual,
                'transactionAmount.equals': transactionAmountEquals,
                'transactionAmount.notEquals': transactionAmountNotEquals,
                'transactionAmount.specified': transactionAmountSpecified,
                'transactionAmount.in': transactionAmountIn,
                'transactionAmount.notIn': transactionAmountNotIn,
                'transactionDate.greaterThan': transactionDateGreaterThan,
                'transactionDate.lessThan': transactionDateLessThan,
                'transactionDate.greaterThanOrEqual': transactionDateGreaterThanOrEqual,
                'transactionDate.lessThanOrEqual': transactionDateLessThanOrEqual,
                'transactionDate.equals': transactionDateEquals,
                'transactionDate.notEquals': transactionDateNotEquals,
                'transactionDate.specified': transactionDateSpecified,
                'transactionDate.in': transactionDateIn,
                'transactionDate.notIn': transactionDateNotIn,
                'source.contains': sourceContains,
                'source.doesNotContain': sourceDoesNotContain,
                'source.equals': sourceEquals,
                'source.notEquals': sourceNotEquals,
                'source.specified': sourceSpecified,
                'source.in': sourceIn,
                'source.notIn': sourceNotIn,
                'referenceNumber.greaterThan': referenceNumberGreaterThan,
                'referenceNumber.lessThan': referenceNumberLessThan,
                'referenceNumber.greaterThanOrEqual': referenceNumberGreaterThanOrEqual,
                'referenceNumber.lessThanOrEqual': referenceNumberLessThanOrEqual,
                'referenceNumber.equals': referenceNumberEquals,
                'referenceNumber.notEquals': referenceNumberNotEquals,
                'referenceNumber.specified': referenceNumberSpecified,
                'referenceNumber.in': referenceNumberIn,
                'referenceNumber.notIn': referenceNumberNotIn,
                'cardNumber.greaterThan': cardNumberGreaterThan,
                'cardNumber.lessThan': cardNumberLessThan,
                'cardNumber.greaterThanOrEqual': cardNumberGreaterThanOrEqual,
                'cardNumber.lessThanOrEqual': cardNumberLessThanOrEqual,
                'cardNumber.equals': cardNumberEquals,
                'cardNumber.notEquals': cardNumberNotEquals,
                'cardNumber.specified': cardNumberSpecified,
                'cardNumber.in': cardNumberIn,
                'cardNumber.notIn': cardNumberNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'unappliedAmount.greaterThan': unappliedAmountGreaterThan,
                'unappliedAmount.lessThan': unappliedAmountLessThan,
                'unappliedAmount.greaterThanOrEqual': unappliedAmountGreaterThanOrEqual,
                'unappliedAmount.lessThanOrEqual': unappliedAmountLessThanOrEqual,
                'unappliedAmount.equals': unappliedAmountEquals,
                'unappliedAmount.notEquals': unappliedAmountNotEquals,
                'unappliedAmount.specified': unappliedAmountSpecified,
                'unappliedAmount.in': unappliedAmountIn,
                'unappliedAmount.notIn': unappliedAmountNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'patientAppliedPaymentId.greaterThan': patientAppliedPaymentIdGreaterThan,
                'patientAppliedPaymentId.lessThan': patientAppliedPaymentIdLessThan,
                'patientAppliedPaymentId.greaterThanOrEqual': patientAppliedPaymentIdGreaterThanOrEqual,
                'patientAppliedPaymentId.lessThanOrEqual': patientAppliedPaymentIdLessThanOrEqual,
                'patientAppliedPaymentId.equals': patientAppliedPaymentIdEquals,
                'patientAppliedPaymentId.notEquals': patientAppliedPaymentIdNotEquals,
                'patientAppliedPaymentId.specified': patientAppliedPaymentIdSpecified,
                'patientAppliedPaymentId.in': patientAppliedPaymentIdIn,
                'patientAppliedPaymentId.notIn': patientAppliedPaymentIdNotIn,
                'insurancePaymentId.greaterThan': insurancePaymentIdGreaterThan,
                'insurancePaymentId.lessThan': insurancePaymentIdLessThan,
                'insurancePaymentId.greaterThanOrEqual': insurancePaymentIdGreaterThanOrEqual,
                'insurancePaymentId.lessThanOrEqual': insurancePaymentIdLessThanOrEqual,
                'insurancePaymentId.equals': insurancePaymentIdEquals,
                'insurancePaymentId.notEquals': insurancePaymentIdNotEquals,
                'insurancePaymentId.specified': insurancePaymentIdSpecified,
                'insurancePaymentId.in': insurancePaymentIdIn,
                'insurancePaymentId.notIn': insurancePaymentIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientPaymentDTO OK
     * @throws ApiError
     */
    public static createPatientPayment(
        requestBody: PatientPaymentDTO,
    ): CancelablePromise<PatientPaymentDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-payments',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param paymentModeContains
     * @param paymentModeDoesNotContain
     * @param paymentModeEquals
     * @param paymentModeNotEquals
     * @param paymentModeSpecified
     * @param paymentModeIn
     * @param paymentModeNotIn
     * @param paymentMethodContains
     * @param paymentMethodDoesNotContain
     * @param paymentMethodEquals
     * @param paymentMethodNotEquals
     * @param paymentMethodSpecified
     * @param paymentMethodIn
     * @param paymentMethodNotIn
     * @param paymentIdContains
     * @param paymentIdDoesNotContain
     * @param paymentIdEquals
     * @param paymentIdNotEquals
     * @param paymentIdSpecified
     * @param paymentIdIn
     * @param paymentIdNotIn
     * @param payerNameContains
     * @param payerNameDoesNotContain
     * @param payerNameEquals
     * @param payerNameNotEquals
     * @param payerNameSpecified
     * @param payerNameIn
     * @param payerNameNotIn
     * @param transactionIdContains
     * @param transactionIdDoesNotContain
     * @param transactionIdEquals
     * @param transactionIdNotEquals
     * @param transactionIdSpecified
     * @param transactionIdIn
     * @param transactionIdNotIn
     * @param transactionAmountGreaterThan
     * @param transactionAmountLessThan
     * @param transactionAmountGreaterThanOrEqual
     * @param transactionAmountLessThanOrEqual
     * @param transactionAmountEquals
     * @param transactionAmountNotEquals
     * @param transactionAmountSpecified
     * @param transactionAmountIn
     * @param transactionAmountNotIn
     * @param transactionDateGreaterThan
     * @param transactionDateLessThan
     * @param transactionDateGreaterThanOrEqual
     * @param transactionDateLessThanOrEqual
     * @param transactionDateEquals
     * @param transactionDateNotEquals
     * @param transactionDateSpecified
     * @param transactionDateIn
     * @param transactionDateNotIn
     * @param sourceContains
     * @param sourceDoesNotContain
     * @param sourceEquals
     * @param sourceNotEquals
     * @param sourceSpecified
     * @param sourceIn
     * @param sourceNotIn
     * @param referenceNumberGreaterThan
     * @param referenceNumberLessThan
     * @param referenceNumberGreaterThanOrEqual
     * @param referenceNumberLessThanOrEqual
     * @param referenceNumberEquals
     * @param referenceNumberNotEquals
     * @param referenceNumberSpecified
     * @param referenceNumberIn
     * @param referenceNumberNotIn
     * @param cardNumberGreaterThan
     * @param cardNumberLessThan
     * @param cardNumberGreaterThanOrEqual
     * @param cardNumberLessThanOrEqual
     * @param cardNumberEquals
     * @param cardNumberNotEquals
     * @param cardNumberSpecified
     * @param cardNumberIn
     * @param cardNumberNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param appliedAmountGreaterThan
     * @param appliedAmountLessThan
     * @param appliedAmountGreaterThanOrEqual
     * @param appliedAmountLessThanOrEqual
     * @param appliedAmountEquals
     * @param appliedAmountNotEquals
     * @param appliedAmountSpecified
     * @param appliedAmountIn
     * @param appliedAmountNotIn
     * @param unappliedAmountGreaterThan
     * @param unappliedAmountLessThan
     * @param unappliedAmountGreaterThanOrEqual
     * @param unappliedAmountLessThanOrEqual
     * @param unappliedAmountEquals
     * @param unappliedAmountNotEquals
     * @param unappliedAmountSpecified
     * @param unappliedAmountIn
     * @param unappliedAmountNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param patientAppliedPaymentIdGreaterThan
     * @param patientAppliedPaymentIdLessThan
     * @param patientAppliedPaymentIdGreaterThanOrEqual
     * @param patientAppliedPaymentIdLessThanOrEqual
     * @param patientAppliedPaymentIdEquals
     * @param patientAppliedPaymentIdNotEquals
     * @param patientAppliedPaymentIdSpecified
     * @param patientAppliedPaymentIdIn
     * @param patientAppliedPaymentIdNotIn
     * @param insurancePaymentIdGreaterThan
     * @param insurancePaymentIdLessThan
     * @param insurancePaymentIdGreaterThanOrEqual
     * @param insurancePaymentIdLessThanOrEqual
     * @param insurancePaymentIdEquals
     * @param insurancePaymentIdNotEquals
     * @param insurancePaymentIdSpecified
     * @param insurancePaymentIdIn
     * @param insurancePaymentIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientPayments(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        paymentModeContains?: string,
        paymentModeDoesNotContain?: string,
        paymentModeEquals?: string,
        paymentModeNotEquals?: string,
        paymentModeSpecified?: boolean,
        paymentModeIn?: Array<string>,
        paymentModeNotIn?: Array<string>,
        paymentMethodContains?: string,
        paymentMethodDoesNotContain?: string,
        paymentMethodEquals?: string,
        paymentMethodNotEquals?: string,
        paymentMethodSpecified?: boolean,
        paymentMethodIn?: Array<string>,
        paymentMethodNotIn?: Array<string>,
        paymentIdContains?: string,
        paymentIdDoesNotContain?: string,
        paymentIdEquals?: string,
        paymentIdNotEquals?: string,
        paymentIdSpecified?: boolean,
        paymentIdIn?: Array<string>,
        paymentIdNotIn?: Array<string>,
        payerNameContains?: string,
        payerNameDoesNotContain?: string,
        payerNameEquals?: string,
        payerNameNotEquals?: string,
        payerNameSpecified?: boolean,
        payerNameIn?: Array<string>,
        payerNameNotIn?: Array<string>,
        transactionIdContains?: string,
        transactionIdDoesNotContain?: string,
        transactionIdEquals?: string,
        transactionIdNotEquals?: string,
        transactionIdSpecified?: boolean,
        transactionIdIn?: Array<string>,
        transactionIdNotIn?: Array<string>,
        transactionAmountGreaterThan?: number,
        transactionAmountLessThan?: number,
        transactionAmountGreaterThanOrEqual?: number,
        transactionAmountLessThanOrEqual?: number,
        transactionAmountEquals?: number,
        transactionAmountNotEquals?: number,
        transactionAmountSpecified?: boolean,
        transactionAmountIn?: Array<number>,
        transactionAmountNotIn?: Array<number>,
        transactionDateGreaterThan?: string,
        transactionDateLessThan?: string,
        transactionDateGreaterThanOrEqual?: string,
        transactionDateLessThanOrEqual?: string,
        transactionDateEquals?: string,
        transactionDateNotEquals?: string,
        transactionDateSpecified?: boolean,
        transactionDateIn?: Array<string>,
        transactionDateNotIn?: Array<string>,
        sourceContains?: string,
        sourceDoesNotContain?: string,
        sourceEquals?: string,
        sourceNotEquals?: string,
        sourceSpecified?: boolean,
        sourceIn?: Array<string>,
        sourceNotIn?: Array<string>,
        referenceNumberGreaterThan?: number,
        referenceNumberLessThan?: number,
        referenceNumberGreaterThanOrEqual?: number,
        referenceNumberLessThanOrEqual?: number,
        referenceNumberEquals?: number,
        referenceNumberNotEquals?: number,
        referenceNumberSpecified?: boolean,
        referenceNumberIn?: Array<number>,
        referenceNumberNotIn?: Array<number>,
        cardNumberGreaterThan?: number,
        cardNumberLessThan?: number,
        cardNumberGreaterThanOrEqual?: number,
        cardNumberLessThanOrEqual?: number,
        cardNumberEquals?: number,
        cardNumberNotEquals?: number,
        cardNumberSpecified?: boolean,
        cardNumberIn?: Array<number>,
        cardNumberNotIn?: Array<number>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        appliedAmountGreaterThan?: number,
        appliedAmountLessThan?: number,
        appliedAmountGreaterThanOrEqual?: number,
        appliedAmountLessThanOrEqual?: number,
        appliedAmountEquals?: number,
        appliedAmountNotEquals?: number,
        appliedAmountSpecified?: boolean,
        appliedAmountIn?: Array<number>,
        appliedAmountNotIn?: Array<number>,
        unappliedAmountGreaterThan?: number,
        unappliedAmountLessThan?: number,
        unappliedAmountGreaterThanOrEqual?: number,
        unappliedAmountLessThanOrEqual?: number,
        unappliedAmountEquals?: number,
        unappliedAmountNotEquals?: number,
        unappliedAmountSpecified?: boolean,
        unappliedAmountIn?: Array<number>,
        unappliedAmountNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        patientAppliedPaymentIdGreaterThan?: number,
        patientAppliedPaymentIdLessThan?: number,
        patientAppliedPaymentIdGreaterThanOrEqual?: number,
        patientAppliedPaymentIdLessThanOrEqual?: number,
        patientAppliedPaymentIdEquals?: number,
        patientAppliedPaymentIdNotEquals?: number,
        patientAppliedPaymentIdSpecified?: boolean,
        patientAppliedPaymentIdIn?: Array<number>,
        patientAppliedPaymentIdNotIn?: Array<number>,
        insurancePaymentIdGreaterThan?: number,
        insurancePaymentIdLessThan?: number,
        insurancePaymentIdGreaterThanOrEqual?: number,
        insurancePaymentIdLessThanOrEqual?: number,
        insurancePaymentIdEquals?: number,
        insurancePaymentIdNotEquals?: number,
        insurancePaymentIdSpecified?: boolean,
        insurancePaymentIdIn?: Array<number>,
        insurancePaymentIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-payments/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'paymentMode.contains': paymentModeContains,
                'paymentMode.doesNotContain': paymentModeDoesNotContain,
                'paymentMode.equals': paymentModeEquals,
                'paymentMode.notEquals': paymentModeNotEquals,
                'paymentMode.specified': paymentModeSpecified,
                'paymentMode.in': paymentModeIn,
                'paymentMode.notIn': paymentModeNotIn,
                'paymentMethod.contains': paymentMethodContains,
                'paymentMethod.doesNotContain': paymentMethodDoesNotContain,
                'paymentMethod.equals': paymentMethodEquals,
                'paymentMethod.notEquals': paymentMethodNotEquals,
                'paymentMethod.specified': paymentMethodSpecified,
                'paymentMethod.in': paymentMethodIn,
                'paymentMethod.notIn': paymentMethodNotIn,
                'paymentId.contains': paymentIdContains,
                'paymentId.doesNotContain': paymentIdDoesNotContain,
                'paymentId.equals': paymentIdEquals,
                'paymentId.notEquals': paymentIdNotEquals,
                'paymentId.specified': paymentIdSpecified,
                'paymentId.in': paymentIdIn,
                'paymentId.notIn': paymentIdNotIn,
                'payerName.contains': payerNameContains,
                'payerName.doesNotContain': payerNameDoesNotContain,
                'payerName.equals': payerNameEquals,
                'payerName.notEquals': payerNameNotEquals,
                'payerName.specified': payerNameSpecified,
                'payerName.in': payerNameIn,
                'payerName.notIn': payerNameNotIn,
                'transactionId.contains': transactionIdContains,
                'transactionId.doesNotContain': transactionIdDoesNotContain,
                'transactionId.equals': transactionIdEquals,
                'transactionId.notEquals': transactionIdNotEquals,
                'transactionId.specified': transactionIdSpecified,
                'transactionId.in': transactionIdIn,
                'transactionId.notIn': transactionIdNotIn,
                'transactionAmount.greaterThan': transactionAmountGreaterThan,
                'transactionAmount.lessThan': transactionAmountLessThan,
                'transactionAmount.greaterThanOrEqual': transactionAmountGreaterThanOrEqual,
                'transactionAmount.lessThanOrEqual': transactionAmountLessThanOrEqual,
                'transactionAmount.equals': transactionAmountEquals,
                'transactionAmount.notEquals': transactionAmountNotEquals,
                'transactionAmount.specified': transactionAmountSpecified,
                'transactionAmount.in': transactionAmountIn,
                'transactionAmount.notIn': transactionAmountNotIn,
                'transactionDate.greaterThan': transactionDateGreaterThan,
                'transactionDate.lessThan': transactionDateLessThan,
                'transactionDate.greaterThanOrEqual': transactionDateGreaterThanOrEqual,
                'transactionDate.lessThanOrEqual': transactionDateLessThanOrEqual,
                'transactionDate.equals': transactionDateEquals,
                'transactionDate.notEquals': transactionDateNotEquals,
                'transactionDate.specified': transactionDateSpecified,
                'transactionDate.in': transactionDateIn,
                'transactionDate.notIn': transactionDateNotIn,
                'source.contains': sourceContains,
                'source.doesNotContain': sourceDoesNotContain,
                'source.equals': sourceEquals,
                'source.notEquals': sourceNotEquals,
                'source.specified': sourceSpecified,
                'source.in': sourceIn,
                'source.notIn': sourceNotIn,
                'referenceNumber.greaterThan': referenceNumberGreaterThan,
                'referenceNumber.lessThan': referenceNumberLessThan,
                'referenceNumber.greaterThanOrEqual': referenceNumberGreaterThanOrEqual,
                'referenceNumber.lessThanOrEqual': referenceNumberLessThanOrEqual,
                'referenceNumber.equals': referenceNumberEquals,
                'referenceNumber.notEquals': referenceNumberNotEquals,
                'referenceNumber.specified': referenceNumberSpecified,
                'referenceNumber.in': referenceNumberIn,
                'referenceNumber.notIn': referenceNumberNotIn,
                'cardNumber.greaterThan': cardNumberGreaterThan,
                'cardNumber.lessThan': cardNumberLessThan,
                'cardNumber.greaterThanOrEqual': cardNumberGreaterThanOrEqual,
                'cardNumber.lessThanOrEqual': cardNumberLessThanOrEqual,
                'cardNumber.equals': cardNumberEquals,
                'cardNumber.notEquals': cardNumberNotEquals,
                'cardNumber.specified': cardNumberSpecified,
                'cardNumber.in': cardNumberIn,
                'cardNumber.notIn': cardNumberNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'appliedAmount.greaterThan': appliedAmountGreaterThan,
                'appliedAmount.lessThan': appliedAmountLessThan,
                'appliedAmount.greaterThanOrEqual': appliedAmountGreaterThanOrEqual,
                'appliedAmount.lessThanOrEqual': appliedAmountLessThanOrEqual,
                'appliedAmount.equals': appliedAmountEquals,
                'appliedAmount.notEquals': appliedAmountNotEquals,
                'appliedAmount.specified': appliedAmountSpecified,
                'appliedAmount.in': appliedAmountIn,
                'appliedAmount.notIn': appliedAmountNotIn,
                'unappliedAmount.greaterThan': unappliedAmountGreaterThan,
                'unappliedAmount.lessThan': unappliedAmountLessThan,
                'unappliedAmount.greaterThanOrEqual': unappliedAmountGreaterThanOrEqual,
                'unappliedAmount.lessThanOrEqual': unappliedAmountLessThanOrEqual,
                'unappliedAmount.equals': unappliedAmountEquals,
                'unappliedAmount.notEquals': unappliedAmountNotEquals,
                'unappliedAmount.specified': unappliedAmountSpecified,
                'unappliedAmount.in': unappliedAmountIn,
                'unappliedAmount.notIn': unappliedAmountNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'patientAppliedPaymentId.greaterThan': patientAppliedPaymentIdGreaterThan,
                'patientAppliedPaymentId.lessThan': patientAppliedPaymentIdLessThan,
                'patientAppliedPaymentId.greaterThanOrEqual': patientAppliedPaymentIdGreaterThanOrEqual,
                'patientAppliedPaymentId.lessThanOrEqual': patientAppliedPaymentIdLessThanOrEqual,
                'patientAppliedPaymentId.equals': patientAppliedPaymentIdEquals,
                'patientAppliedPaymentId.notEquals': patientAppliedPaymentIdNotEquals,
                'patientAppliedPaymentId.specified': patientAppliedPaymentIdSpecified,
                'patientAppliedPaymentId.in': patientAppliedPaymentIdIn,
                'patientAppliedPaymentId.notIn': patientAppliedPaymentIdNotIn,
                'insurancePaymentId.greaterThan': insurancePaymentIdGreaterThan,
                'insurancePaymentId.lessThan': insurancePaymentIdLessThan,
                'insurancePaymentId.greaterThanOrEqual': insurancePaymentIdGreaterThanOrEqual,
                'insurancePaymentId.lessThanOrEqual': insurancePaymentIdLessThanOrEqual,
                'insurancePaymentId.equals': insurancePaymentIdEquals,
                'insurancePaymentId.notEquals': insurancePaymentIdNotEquals,
                'insurancePaymentId.specified': insurancePaymentIdSpecified,
                'insurancePaymentId.in': insurancePaymentIdIn,
                'insurancePaymentId.notIn': insurancePaymentIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
