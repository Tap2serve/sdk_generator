/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CountryDTO } from '../models/CountryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class CountryResourceService {

    /**
     * @param id
     * @returns CountryDTO OK
     * @throws ApiError
     */
    public static getCountry(
        id: number,
    ): CancelablePromise<CountryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/countries/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns CountryDTO OK
     * @throws ApiError
     */
    public static updateCountry(
        id: number,
        requestBody: CountryDTO,
    ): CancelablePromise<CountryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/countries/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteCountry(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/countries/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns CountryDTO OK
     * @throws ApiError
     */
    public static partialUpdateCountry(
        id: number,
        requestBody: CountryDTO,
    ): CancelablePromise<CountryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/countries/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param stateIsoContains
     * @param stateIsoDoesNotContain
     * @param stateIsoEquals
     * @param stateIsoNotEquals
     * @param stateIsoSpecified
     * @param stateIsoIn
     * @param stateIsoNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns CountryDTO OK
     * @throws ApiError
     */
    public static getAllCountries(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        stateIsoContains?: string,
        stateIsoDoesNotContain?: string,
        stateIsoEquals?: string,
        stateIsoNotEquals?: string,
        stateIsoSpecified?: boolean,
        stateIsoIn?: Array<string>,
        stateIsoNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<CountryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/countries',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'stateIso.contains': stateIsoContains,
                'stateIso.doesNotContain': stateIsoDoesNotContain,
                'stateIso.equals': stateIsoEquals,
                'stateIso.notEquals': stateIsoNotEquals,
                'stateIso.specified': stateIsoSpecified,
                'stateIso.in': stateIsoIn,
                'stateIso.notIn': stateIsoNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns CountryDTO OK
     * @throws ApiError
     */
    public static createCountry(
        requestBody: CountryDTO,
    ): CancelablePromise<CountryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/countries',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param stateContains
     * @param stateDoesNotContain
     * @param stateEquals
     * @param stateNotEquals
     * @param stateSpecified
     * @param stateIn
     * @param stateNotIn
     * @param countryContains
     * @param countryDoesNotContain
     * @param countryEquals
     * @param countryNotEquals
     * @param countrySpecified
     * @param countryIn
     * @param countryNotIn
     * @param stateIsoContains
     * @param stateIsoDoesNotContain
     * @param stateIsoEquals
     * @param stateIsoNotEquals
     * @param stateIsoSpecified
     * @param stateIsoIn
     * @param stateIsoNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countCountries(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        stateContains?: string,
        stateDoesNotContain?: string,
        stateEquals?: string,
        stateNotEquals?: string,
        stateSpecified?: boolean,
        stateIn?: Array<string>,
        stateNotIn?: Array<string>,
        countryContains?: string,
        countryDoesNotContain?: string,
        countryEquals?: string,
        countryNotEquals?: string,
        countrySpecified?: boolean,
        countryIn?: Array<string>,
        countryNotIn?: Array<string>,
        stateIsoContains?: string,
        stateIsoDoesNotContain?: string,
        stateIsoEquals?: string,
        stateIsoNotEquals?: string,
        stateIsoSpecified?: boolean,
        stateIsoIn?: Array<string>,
        stateIsoNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/countries/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'state.contains': stateContains,
                'state.doesNotContain': stateDoesNotContain,
                'state.equals': stateEquals,
                'state.notEquals': stateNotEquals,
                'state.specified': stateSpecified,
                'state.in': stateIn,
                'state.notIn': stateNotIn,
                'country.contains': countryContains,
                'country.doesNotContain': countryDoesNotContain,
                'country.equals': countryEquals,
                'country.notEquals': countryNotEquals,
                'country.specified': countrySpecified,
                'country.in': countryIn,
                'country.notIn': countryNotIn,
                'stateIso.contains': stateIsoContains,
                'stateIso.doesNotContain': stateIsoDoesNotContain,
                'stateIso.equals': stateIsoEquals,
                'stateIso.notEquals': stateIsoNotEquals,
                'stateIso.specified': stateIsoSpecified,
                'stateIso.in': stateIsoIn,
                'stateIso.notIn': stateIsoNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'distinct': distinct,
            },
        });
    }

}
