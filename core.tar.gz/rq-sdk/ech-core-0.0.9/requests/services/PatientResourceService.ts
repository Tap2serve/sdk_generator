/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PagePatientDTO } from '../models/PagePatientDTO';
import type { PatientDTO } from '../models/PatientDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientResourceService {

    /**
     * @param id
     * @param requestBody
     * @returns PatientDTO OK
     * @throws ApiError
     */
    public static updatePatient(
        id: number,
        requestBody: PatientDTO,
    ): CancelablePromise<PatientDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patients/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatient(
        id: number,
        requestBody: PatientDTO,
    ): CancelablePromise<PatientDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patients/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PagePatientDTO OK
     * @throws ApiError
     */
    public static getAllPatients(
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PagePatientDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patients',
            query: {
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientDTO OK
     * @throws ApiError
     */
    public static createPatient(
        requestBody: PatientDTO,
    ): CancelablePromise<PatientDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patients',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param patientUuid
     * @returns PatientDTO OK
     * @throws ApiError
     */
    public static getPatient(
        patientUuid: string,
    ): CancelablePromise<PatientDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patients/{patientUuid}',
            path: {
                'patientUuid': patientUuid,
            },
        });
    }

    /**
     * @param patientUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatient(
        patientUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patients/{patientUuid}',
            path: {
                'patientUuid': patientUuid,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param mrnContains
     * @param mrnDoesNotContain
     * @param mrnEquals
     * @param mrnNotEquals
     * @param mrnSpecified
     * @param mrnIn
     * @param mrnNotIn
     * @param firstNameUsedContains
     * @param firstNameUsedDoesNotContain
     * @param firstNameUsedEquals
     * @param firstNameUsedNotEquals
     * @param firstNameUsedSpecified
     * @param firstNameUsedIn
     * @param firstNameUsedNotIn
     * @param middleNameContains
     * @param middleNameDoesNotContain
     * @param middleNameEquals
     * @param middleNameNotEquals
     * @param middleNameSpecified
     * @param middleNameIn
     * @param middleNameNotIn
     * @param motherNameContains
     * @param motherNameDoesNotContain
     * @param motherNameEquals
     * @param motherNameNotEquals
     * @param motherNameSpecified
     * @param motherNameIn
     * @param motherNameNotIn
     * @param birthDateGreaterThan
     * @param birthDateLessThan
     * @param birthDateGreaterThanOrEqual
     * @param birthDateLessThanOrEqual
     * @param birthDateEquals
     * @param birthDateNotEquals
     * @param birthDateSpecified
     * @param birthDateIn
     * @param birthDateNotIn
     * @param genderEquals
     * @param genderNotEquals
     * @param genderSpecified
     * @param genderIn
     * @param genderNotIn
     * @param maritalStatusEquals
     * @param maritalStatusNotEquals
     * @param maritalStatusSpecified
     * @param maritalStatusIn
     * @param maritalStatusNotIn
     * @param ethnicityEquals
     * @param ethnicityNotEquals
     * @param ethnicitySpecified
     * @param ethnicityIn
     * @param ethnicityNotIn
     * @param raceEquals
     * @param raceNotEquals
     * @param raceSpecified
     * @param raceIn
     * @param raceNotIn
     * @param ssnContains
     * @param ssnDoesNotContain
     * @param ssnEquals
     * @param ssnNotEquals
     * @param ssnSpecified
     * @param ssnIn
     * @param ssnNotIn
     * @param languageContains
     * @param languageDoesNotContain
     * @param languageEquals
     * @param languageNotEquals
     * @param languageSpecified
     * @param languageIn
     * @param languageNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param emergContactFirstNameContains
     * @param emergContactFirstNameDoesNotContain
     * @param emergContactFirstNameEquals
     * @param emergContactFirstNameNotEquals
     * @param emergContactFirstNameSpecified
     * @param emergContactFirstNameIn
     * @param emergContactFirstNameNotIn
     * @param emergContactLastNameContains
     * @param emergContactLastNameDoesNotContain
     * @param emergContactLastNameEquals
     * @param emergContactLastNameNotEquals
     * @param emergContactLastNameSpecified
     * @param emergContactLastNameIn
     * @param emergContactLastNameNotIn
     * @param emergContactRelationEquals
     * @param emergContactRelationNotEquals
     * @param emergContactRelationSpecified
     * @param emergContactRelationIn
     * @param emergContactRelationNotIn
     * @param emergContactNumberContains
     * @param emergContactNumberDoesNotContain
     * @param emergContactNumberEquals
     * @param emergContactNumberNotEquals
     * @param emergContactNumberSpecified
     * @param emergContactNumberIn
     * @param emergContactNumberNotIn
     * @param emergContactEmailContains
     * @param emergContactEmailDoesNotContain
     * @param emergContactEmailEquals
     * @param emergContactEmailNotEquals
     * @param emergContactEmailSpecified
     * @param emergContactEmailIn
     * @param emergContactEmailNotIn
     * @param messageConsentEquals
     * @param messageConsentNotEquals
     * @param messageConsentSpecified
     * @param messageConsentIn
     * @param messageConsentNotIn
     * @param callConsentEquals
     * @param callConsentNotEquals
     * @param callConsentSpecified
     * @param callConsentIn
     * @param callConsentNotIn
     * @param emailConsentEquals
     * @param emailConsentNotEquals
     * @param emailConsentSpecified
     * @param emailConsentIn
     * @param emailConsentNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param sourceContains
     * @param sourceDoesNotContain
     * @param sourceEquals
     * @param sourceNotEquals
     * @param sourceSpecified
     * @param sourceIn
     * @param sourceNotIn
     * @param lastVisitGreaterThan
     * @param lastVisitLessThan
     * @param lastVisitGreaterThanOrEqual
     * @param lastVisitLessThanOrEqual
     * @param lastVisitEquals
     * @param lastVisitNotEquals
     * @param lastVisitSpecified
     * @param lastVisitIn
     * @param lastVisitNotIn
     * @param balanceGreaterThan
     * @param balanceLessThan
     * @param balanceGreaterThanOrEqual
     * @param balanceLessThanOrEqual
     * @param balanceEquals
     * @param balanceNotEquals
     * @param balanceSpecified
     * @param balanceIn
     * @param balanceNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param providerGroupIdEquals
     * @param providerGroupIdNotEquals
     * @param providerGroupIdSpecified
     * @param providerGroupIdIn
     * @param providerGroupIdNotIn
     * @param addressIdIdGreaterThan
     * @param addressIdIdLessThan
     * @param addressIdIdGreaterThanOrEqual
     * @param addressIdIdLessThanOrEqual
     * @param addressIdIdEquals
     * @param addressIdIdNotEquals
     * @param addressIdIdSpecified
     * @param addressIdIdIn
     * @param addressIdIdNotIn
     * @param defaultLocationIdIdGreaterThan
     * @param defaultLocationIdIdLessThan
     * @param defaultLocationIdIdGreaterThanOrEqual
     * @param defaultLocationIdIdLessThanOrEqual
     * @param defaultLocationIdIdEquals
     * @param defaultLocationIdIdNotEquals
     * @param defaultLocationIdIdSpecified
     * @param defaultLocationIdIdIn
     * @param defaultLocationIdIdNotIn
     * @param primaryProviderIdIdGreaterThan
     * @param primaryProviderIdIdLessThan
     * @param primaryProviderIdIdGreaterThanOrEqual
     * @param primaryProviderIdIdLessThanOrEqual
     * @param primaryProviderIdIdEquals
     * @param primaryProviderIdIdNotEquals
     * @param primaryProviderIdIdSpecified
     * @param primaryProviderIdIdIn
     * @param primaryProviderIdIdNotIn
     * @param preferredPharmacyIdGreaterThan
     * @param preferredPharmacyIdLessThan
     * @param preferredPharmacyIdGreaterThanOrEqual
     * @param preferredPharmacyIdLessThanOrEqual
     * @param preferredPharmacyIdEquals
     * @param preferredPharmacyIdNotEquals
     * @param preferredPharmacyIdSpecified
     * @param preferredPharmacyIdIn
     * @param preferredPharmacyIdNotIn
     * @param preferredLabsIdGreaterThan
     * @param preferredLabsIdLessThan
     * @param preferredLabsIdGreaterThanOrEqual
     * @param preferredLabsIdLessThanOrEqual
     * @param preferredLabsIdEquals
     * @param preferredLabsIdNotEquals
     * @param preferredLabsIdSpecified
     * @param preferredLabsIdIn
     * @param preferredLabsIdNotIn
     * @param preferredRadiologyIdGreaterThan
     * @param preferredRadiologyIdLessThan
     * @param preferredRadiologyIdGreaterThanOrEqual
     * @param preferredRadiologyIdLessThanOrEqual
     * @param preferredRadiologyIdEquals
     * @param preferredRadiologyIdNotEquals
     * @param preferredRadiologyIdSpecified
     * @param preferredRadiologyIdIn
     * @param preferredRadiologyIdNotIn
     * @param userIdIdGreaterThan
     * @param userIdIdLessThan
     * @param userIdIdGreaterThanOrEqual
     * @param userIdIdLessThanOrEqual
     * @param userIdIdEquals
     * @param userIdIdNotEquals
     * @param userIdIdSpecified
     * @param userIdIdIn
     * @param userIdIdNotIn
     * @param primaryInsuranceIdIdGreaterThan
     * @param primaryInsuranceIdIdLessThan
     * @param primaryInsuranceIdIdGreaterThanOrEqual
     * @param primaryInsuranceIdIdLessThanOrEqual
     * @param primaryInsuranceIdIdEquals
     * @param primaryInsuranceIdIdNotEquals
     * @param primaryInsuranceIdIdSpecified
     * @param primaryInsuranceIdIdIn
     * @param primaryInsuranceIdIdNotIn
     * @param psychologicalHistoryIdGreaterThan
     * @param psychologicalHistoryIdLessThan
     * @param psychologicalHistoryIdGreaterThanOrEqual
     * @param psychologicalHistoryIdLessThanOrEqual
     * @param psychologicalHistoryIdEquals
     * @param psychologicalHistoryIdNotEquals
     * @param psychologicalHistoryIdSpecified
     * @param psychologicalHistoryIdIn
     * @param psychologicalHistoryIdNotIn
     * @param prescriptionFormIdGreaterThan
     * @param prescriptionFormIdLessThan
     * @param prescriptionFormIdGreaterThanOrEqual
     * @param prescriptionFormIdLessThanOrEqual
     * @param prescriptionFormIdEquals
     * @param prescriptionFormIdNotEquals
     * @param prescriptionFormIdSpecified
     * @param prescriptionFormIdIn
     * @param prescriptionFormIdNotIn
     * @param patientDietIdGreaterThan
     * @param patientDietIdLessThan
     * @param patientDietIdGreaterThanOrEqual
     * @param patientDietIdLessThanOrEqual
     * @param patientDietIdEquals
     * @param patientDietIdNotEquals
     * @param patientDietIdSpecified
     * @param patientDietIdIn
     * @param patientDietIdNotIn
     * @param habbitIdGreaterThan
     * @param habbitIdLessThan
     * @param habbitIdGreaterThanOrEqual
     * @param habbitIdLessThanOrEqual
     * @param habbitIdEquals
     * @param habbitIdNotEquals
     * @param habbitIdSpecified
     * @param habbitIdIn
     * @param habbitIdNotIn
     * @param medicalHistoryIdGreaterThan
     * @param medicalHistoryIdLessThan
     * @param medicalHistoryIdGreaterThanOrEqual
     * @param medicalHistoryIdLessThanOrEqual
     * @param medicalHistoryIdEquals
     * @param medicalHistoryIdNotEquals
     * @param medicalHistoryIdSpecified
     * @param medicalHistoryIdIn
     * @param medicalHistoryIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param patientPermissionIdGreaterThan
     * @param patientPermissionIdLessThan
     * @param patientPermissionIdGreaterThanOrEqual
     * @param patientPermissionIdLessThanOrEqual
     * @param patientPermissionIdEquals
     * @param patientPermissionIdNotEquals
     * @param patientPermissionIdSpecified
     * @param patientPermissionIdIn
     * @param patientPermissionIdNotIn
     * @param surgicalHistoryIdGreaterThan
     * @param surgicalHistoryIdLessThan
     * @param surgicalHistoryIdGreaterThanOrEqual
     * @param surgicalHistoryIdLessThanOrEqual
     * @param surgicalHistoryIdEquals
     * @param surgicalHistoryIdNotEquals
     * @param surgicalHistoryIdSpecified
     * @param surgicalHistoryIdIn
     * @param surgicalHistoryIdNotIn
     * @param patientVitalIdGreaterThan
     * @param patientVitalIdLessThan
     * @param patientVitalIdGreaterThanOrEqual
     * @param patientVitalIdLessThanOrEqual
     * @param patientVitalIdEquals
     * @param patientVitalIdNotEquals
     * @param patientVitalIdSpecified
     * @param patientVitalIdIn
     * @param patientVitalIdNotIn
     * @param patientFunctionalStatusIdGreaterThan
     * @param patientFunctionalStatusIdLessThan
     * @param patientFunctionalStatusIdGreaterThanOrEqual
     * @param patientFunctionalStatusIdLessThanOrEqual
     * @param patientFunctionalStatusIdEquals
     * @param patientFunctionalStatusIdNotEquals
     * @param patientFunctionalStatusIdSpecified
     * @param patientFunctionalStatusIdIn
     * @param patientFunctionalStatusIdNotIn
     * @param patientVaccineIdGreaterThan
     * @param patientVaccineIdLessThan
     * @param patientVaccineIdGreaterThanOrEqual
     * @param patientVaccineIdLessThanOrEqual
     * @param patientVaccineIdEquals
     * @param patientVaccineIdNotEquals
     * @param patientVaccineIdSpecified
     * @param patientVaccineIdIn
     * @param patientVaccineIdNotIn
     * @param insurancePaymentIdGreaterThan
     * @param insurancePaymentIdLessThan
     * @param insurancePaymentIdGreaterThanOrEqual
     * @param insurancePaymentIdLessThanOrEqual
     * @param insurancePaymentIdEquals
     * @param insurancePaymentIdNotEquals
     * @param insurancePaymentIdSpecified
     * @param insurancePaymentIdIn
     * @param insurancePaymentIdNotIn
     * @param exerciseHistoryIdGreaterThan
     * @param exerciseHistoryIdLessThan
     * @param exerciseHistoryIdGreaterThanOrEqual
     * @param exerciseHistoryIdLessThanOrEqual
     * @param exerciseHistoryIdEquals
     * @param exerciseHistoryIdNotEquals
     * @param exerciseHistoryIdSpecified
     * @param exerciseHistoryIdIn
     * @param exerciseHistoryIdNotIn
     * @param patientCognitiveStatusIdGreaterThan
     * @param patientCognitiveStatusIdLessThan
     * @param patientCognitiveStatusIdGreaterThanOrEqual
     * @param patientCognitiveStatusIdLessThanOrEqual
     * @param patientCognitiveStatusIdEquals
     * @param patientCognitiveStatusIdNotEquals
     * @param patientCognitiveStatusIdSpecified
     * @param patientCognitiveStatusIdIn
     * @param patientCognitiveStatusIdNotIn
     * @param insuranceClaimIdGreaterThan
     * @param insuranceClaimIdLessThan
     * @param insuranceClaimIdGreaterThanOrEqual
     * @param insuranceClaimIdLessThanOrEqual
     * @param insuranceClaimIdEquals
     * @param insuranceClaimIdNotEquals
     * @param insuranceClaimIdSpecified
     * @param insuranceClaimIdIn
     * @param insuranceClaimIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatients(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        mrnContains?: string,
        mrnDoesNotContain?: string,
        mrnEquals?: string,
        mrnNotEquals?: string,
        mrnSpecified?: boolean,
        mrnIn?: Array<string>,
        mrnNotIn?: Array<string>,
        firstNameUsedContains?: string,
        firstNameUsedDoesNotContain?: string,
        firstNameUsedEquals?: string,
        firstNameUsedNotEquals?: string,
        firstNameUsedSpecified?: boolean,
        firstNameUsedIn?: Array<string>,
        firstNameUsedNotIn?: Array<string>,
        middleNameContains?: string,
        middleNameDoesNotContain?: string,
        middleNameEquals?: string,
        middleNameNotEquals?: string,
        middleNameSpecified?: boolean,
        middleNameIn?: Array<string>,
        middleNameNotIn?: Array<string>,
        motherNameContains?: string,
        motherNameDoesNotContain?: string,
        motherNameEquals?: string,
        motherNameNotEquals?: string,
        motherNameSpecified?: boolean,
        motherNameIn?: Array<string>,
        motherNameNotIn?: Array<string>,
        birthDateGreaterThan?: string,
        birthDateLessThan?: string,
        birthDateGreaterThanOrEqual?: string,
        birthDateLessThanOrEqual?: string,
        birthDateEquals?: string,
        birthDateNotEquals?: string,
        birthDateSpecified?: boolean,
        birthDateIn?: Array<string>,
        birthDateNotIn?: Array<string>,
        genderEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderNotEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderSpecified?: boolean,
        genderIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        genderNotIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        maritalStatusEquals?: 'MARRIED' | 'SINGLE' | 'DIVORCED' | 'WIDOWED',
        maritalStatusNotEquals?: 'MARRIED' | 'SINGLE' | 'DIVORCED' | 'WIDOWED',
        maritalStatusSpecified?: boolean,
        maritalStatusIn?: Array<'MARRIED' | 'SINGLE' | 'DIVORCED' | 'WIDOWED'>,
        maritalStatusNotIn?: Array<'MARRIED' | 'SINGLE' | 'DIVORCED' | 'WIDOWED'>,
        ethnicityEquals?: 'AFRICAN_AMERICAN' | 'ASIAN',
        ethnicityNotEquals?: 'AFRICAN_AMERICAN' | 'ASIAN',
        ethnicitySpecified?: boolean,
        ethnicityIn?: Array<'AFRICAN_AMERICAN' | 'ASIAN'>,
        ethnicityNotIn?: Array<'AFRICAN_AMERICAN' | 'ASIAN'>,
        raceEquals?: 'AFRICAN_AMERICAN' | 'ASIAN',
        raceNotEquals?: 'AFRICAN_AMERICAN' | 'ASIAN',
        raceSpecified?: boolean,
        raceIn?: Array<'AFRICAN_AMERICAN' | 'ASIAN'>,
        raceNotIn?: Array<'AFRICAN_AMERICAN' | 'ASIAN'>,
        ssnContains?: string,
        ssnDoesNotContain?: string,
        ssnEquals?: string,
        ssnNotEquals?: string,
        ssnSpecified?: boolean,
        ssnIn?: Array<string>,
        ssnNotIn?: Array<string>,
        languageContains?: string,
        languageDoesNotContain?: string,
        languageEquals?: string,
        languageNotEquals?: string,
        languageSpecified?: boolean,
        languageIn?: Array<string>,
        languageNotIn?: Array<string>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        emergContactFirstNameContains?: string,
        emergContactFirstNameDoesNotContain?: string,
        emergContactFirstNameEquals?: string,
        emergContactFirstNameNotEquals?: string,
        emergContactFirstNameSpecified?: boolean,
        emergContactFirstNameIn?: Array<string>,
        emergContactFirstNameNotIn?: Array<string>,
        emergContactLastNameContains?: string,
        emergContactLastNameDoesNotContain?: string,
        emergContactLastNameEquals?: string,
        emergContactLastNameNotEquals?: string,
        emergContactLastNameSpecified?: boolean,
        emergContactLastNameIn?: Array<string>,
        emergContactLastNameNotIn?: Array<string>,
        emergContactRelationEquals?: 'SELF' | 'CHILD' | 'SPOUSE',
        emergContactRelationNotEquals?: 'SELF' | 'CHILD' | 'SPOUSE',
        emergContactRelationSpecified?: boolean,
        emergContactRelationIn?: Array<'SELF' | 'CHILD' | 'SPOUSE'>,
        emergContactRelationNotIn?: Array<'SELF' | 'CHILD' | 'SPOUSE'>,
        emergContactNumberContains?: string,
        emergContactNumberDoesNotContain?: string,
        emergContactNumberEquals?: string,
        emergContactNumberNotEquals?: string,
        emergContactNumberSpecified?: boolean,
        emergContactNumberIn?: Array<string>,
        emergContactNumberNotIn?: Array<string>,
        emergContactEmailContains?: string,
        emergContactEmailDoesNotContain?: string,
        emergContactEmailEquals?: string,
        emergContactEmailNotEquals?: string,
        emergContactEmailSpecified?: boolean,
        emergContactEmailIn?: Array<string>,
        emergContactEmailNotIn?: Array<string>,
        messageConsentEquals?: boolean,
        messageConsentNotEquals?: boolean,
        messageConsentSpecified?: boolean,
        messageConsentIn?: Array<boolean>,
        messageConsentNotIn?: Array<boolean>,
        callConsentEquals?: boolean,
        callConsentNotEquals?: boolean,
        callConsentSpecified?: boolean,
        callConsentIn?: Array<boolean>,
        callConsentNotIn?: Array<boolean>,
        emailConsentEquals?: boolean,
        emailConsentNotEquals?: boolean,
        emailConsentSpecified?: boolean,
        emailConsentIn?: Array<boolean>,
        emailConsentNotIn?: Array<boolean>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        sourceContains?: string,
        sourceDoesNotContain?: string,
        sourceEquals?: string,
        sourceNotEquals?: string,
        sourceSpecified?: boolean,
        sourceIn?: Array<string>,
        sourceNotIn?: Array<string>,
        lastVisitGreaterThan?: string,
        lastVisitLessThan?: string,
        lastVisitGreaterThanOrEqual?: string,
        lastVisitLessThanOrEqual?: string,
        lastVisitEquals?: string,
        lastVisitNotEquals?: string,
        lastVisitSpecified?: boolean,
        lastVisitIn?: Array<string>,
        lastVisitNotIn?: Array<string>,
        balanceGreaterThan?: number,
        balanceLessThan?: number,
        balanceGreaterThanOrEqual?: number,
        balanceLessThanOrEqual?: number,
        balanceEquals?: number,
        balanceNotEquals?: number,
        balanceSpecified?: boolean,
        balanceIn?: Array<number>,
        balanceNotIn?: Array<number>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        providerGroupIdEquals?: string,
        providerGroupIdNotEquals?: string,
        providerGroupIdSpecified?: boolean,
        providerGroupIdIn?: Array<string>,
        providerGroupIdNotIn?: Array<string>,
        addressIdIdGreaterThan?: number,
        addressIdIdLessThan?: number,
        addressIdIdGreaterThanOrEqual?: number,
        addressIdIdLessThanOrEqual?: number,
        addressIdIdEquals?: number,
        addressIdIdNotEquals?: number,
        addressIdIdSpecified?: boolean,
        addressIdIdIn?: Array<number>,
        addressIdIdNotIn?: Array<number>,
        defaultLocationIdIdGreaterThan?: number,
        defaultLocationIdIdLessThan?: number,
        defaultLocationIdIdGreaterThanOrEqual?: number,
        defaultLocationIdIdLessThanOrEqual?: number,
        defaultLocationIdIdEquals?: number,
        defaultLocationIdIdNotEquals?: number,
        defaultLocationIdIdSpecified?: boolean,
        defaultLocationIdIdIn?: Array<number>,
        defaultLocationIdIdNotIn?: Array<number>,
        primaryProviderIdIdGreaterThan?: number,
        primaryProviderIdIdLessThan?: number,
        primaryProviderIdIdGreaterThanOrEqual?: number,
        primaryProviderIdIdLessThanOrEqual?: number,
        primaryProviderIdIdEquals?: number,
        primaryProviderIdIdNotEquals?: number,
        primaryProviderIdIdSpecified?: boolean,
        primaryProviderIdIdIn?: Array<number>,
        primaryProviderIdIdNotIn?: Array<number>,
        preferredPharmacyIdGreaterThan?: number,
        preferredPharmacyIdLessThan?: number,
        preferredPharmacyIdGreaterThanOrEqual?: number,
        preferredPharmacyIdLessThanOrEqual?: number,
        preferredPharmacyIdEquals?: number,
        preferredPharmacyIdNotEquals?: number,
        preferredPharmacyIdSpecified?: boolean,
        preferredPharmacyIdIn?: Array<number>,
        preferredPharmacyIdNotIn?: Array<number>,
        preferredLabsIdGreaterThan?: number,
        preferredLabsIdLessThan?: number,
        preferredLabsIdGreaterThanOrEqual?: number,
        preferredLabsIdLessThanOrEqual?: number,
        preferredLabsIdEquals?: number,
        preferredLabsIdNotEquals?: number,
        preferredLabsIdSpecified?: boolean,
        preferredLabsIdIn?: Array<number>,
        preferredLabsIdNotIn?: Array<number>,
        preferredRadiologyIdGreaterThan?: number,
        preferredRadiologyIdLessThan?: number,
        preferredRadiologyIdGreaterThanOrEqual?: number,
        preferredRadiologyIdLessThanOrEqual?: number,
        preferredRadiologyIdEquals?: number,
        preferredRadiologyIdNotEquals?: number,
        preferredRadiologyIdSpecified?: boolean,
        preferredRadiologyIdIn?: Array<number>,
        preferredRadiologyIdNotIn?: Array<number>,
        userIdIdGreaterThan?: number,
        userIdIdLessThan?: number,
        userIdIdGreaterThanOrEqual?: number,
        userIdIdLessThanOrEqual?: number,
        userIdIdEquals?: number,
        userIdIdNotEquals?: number,
        userIdIdSpecified?: boolean,
        userIdIdIn?: Array<number>,
        userIdIdNotIn?: Array<number>,
        primaryInsuranceIdIdGreaterThan?: number,
        primaryInsuranceIdIdLessThan?: number,
        primaryInsuranceIdIdGreaterThanOrEqual?: number,
        primaryInsuranceIdIdLessThanOrEqual?: number,
        primaryInsuranceIdIdEquals?: number,
        primaryInsuranceIdIdNotEquals?: number,
        primaryInsuranceIdIdSpecified?: boolean,
        primaryInsuranceIdIdIn?: Array<number>,
        primaryInsuranceIdIdNotIn?: Array<number>,
        psychologicalHistoryIdGreaterThan?: number,
        psychologicalHistoryIdLessThan?: number,
        psychologicalHistoryIdGreaterThanOrEqual?: number,
        psychologicalHistoryIdLessThanOrEqual?: number,
        psychologicalHistoryIdEquals?: number,
        psychologicalHistoryIdNotEquals?: number,
        psychologicalHistoryIdSpecified?: boolean,
        psychologicalHistoryIdIn?: Array<number>,
        psychologicalHistoryIdNotIn?: Array<number>,
        prescriptionFormIdGreaterThan?: number,
        prescriptionFormIdLessThan?: number,
        prescriptionFormIdGreaterThanOrEqual?: number,
        prescriptionFormIdLessThanOrEqual?: number,
        prescriptionFormIdEquals?: number,
        prescriptionFormIdNotEquals?: number,
        prescriptionFormIdSpecified?: boolean,
        prescriptionFormIdIn?: Array<number>,
        prescriptionFormIdNotIn?: Array<number>,
        patientDietIdGreaterThan?: number,
        patientDietIdLessThan?: number,
        patientDietIdGreaterThanOrEqual?: number,
        patientDietIdLessThanOrEqual?: number,
        patientDietIdEquals?: number,
        patientDietIdNotEquals?: number,
        patientDietIdSpecified?: boolean,
        patientDietIdIn?: Array<number>,
        patientDietIdNotIn?: Array<number>,
        habbitIdGreaterThan?: number,
        habbitIdLessThan?: number,
        habbitIdGreaterThanOrEqual?: number,
        habbitIdLessThanOrEqual?: number,
        habbitIdEquals?: number,
        habbitIdNotEquals?: number,
        habbitIdSpecified?: boolean,
        habbitIdIn?: Array<number>,
        habbitIdNotIn?: Array<number>,
        medicalHistoryIdGreaterThan?: number,
        medicalHistoryIdLessThan?: number,
        medicalHistoryIdGreaterThanOrEqual?: number,
        medicalHistoryIdLessThanOrEqual?: number,
        medicalHistoryIdEquals?: number,
        medicalHistoryIdNotEquals?: number,
        medicalHistoryIdSpecified?: boolean,
        medicalHistoryIdIn?: Array<number>,
        medicalHistoryIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        patientPermissionIdGreaterThan?: number,
        patientPermissionIdLessThan?: number,
        patientPermissionIdGreaterThanOrEqual?: number,
        patientPermissionIdLessThanOrEqual?: number,
        patientPermissionIdEquals?: number,
        patientPermissionIdNotEquals?: number,
        patientPermissionIdSpecified?: boolean,
        patientPermissionIdIn?: Array<number>,
        patientPermissionIdNotIn?: Array<number>,
        surgicalHistoryIdGreaterThan?: number,
        surgicalHistoryIdLessThan?: number,
        surgicalHistoryIdGreaterThanOrEqual?: number,
        surgicalHistoryIdLessThanOrEqual?: number,
        surgicalHistoryIdEquals?: number,
        surgicalHistoryIdNotEquals?: number,
        surgicalHistoryIdSpecified?: boolean,
        surgicalHistoryIdIn?: Array<number>,
        surgicalHistoryIdNotIn?: Array<number>,
        patientVitalIdGreaterThan?: number,
        patientVitalIdLessThan?: number,
        patientVitalIdGreaterThanOrEqual?: number,
        patientVitalIdLessThanOrEqual?: number,
        patientVitalIdEquals?: number,
        patientVitalIdNotEquals?: number,
        patientVitalIdSpecified?: boolean,
        patientVitalIdIn?: Array<number>,
        patientVitalIdNotIn?: Array<number>,
        patientFunctionalStatusIdGreaterThan?: number,
        patientFunctionalStatusIdLessThan?: number,
        patientFunctionalStatusIdGreaterThanOrEqual?: number,
        patientFunctionalStatusIdLessThanOrEqual?: number,
        patientFunctionalStatusIdEquals?: number,
        patientFunctionalStatusIdNotEquals?: number,
        patientFunctionalStatusIdSpecified?: boolean,
        patientFunctionalStatusIdIn?: Array<number>,
        patientFunctionalStatusIdNotIn?: Array<number>,
        patientVaccineIdGreaterThan?: number,
        patientVaccineIdLessThan?: number,
        patientVaccineIdGreaterThanOrEqual?: number,
        patientVaccineIdLessThanOrEqual?: number,
        patientVaccineIdEquals?: number,
        patientVaccineIdNotEquals?: number,
        patientVaccineIdSpecified?: boolean,
        patientVaccineIdIn?: Array<number>,
        patientVaccineIdNotIn?: Array<number>,
        insurancePaymentIdGreaterThan?: number,
        insurancePaymentIdLessThan?: number,
        insurancePaymentIdGreaterThanOrEqual?: number,
        insurancePaymentIdLessThanOrEqual?: number,
        insurancePaymentIdEquals?: number,
        insurancePaymentIdNotEquals?: number,
        insurancePaymentIdSpecified?: boolean,
        insurancePaymentIdIn?: Array<number>,
        insurancePaymentIdNotIn?: Array<number>,
        exerciseHistoryIdGreaterThan?: number,
        exerciseHistoryIdLessThan?: number,
        exerciseHistoryIdGreaterThanOrEqual?: number,
        exerciseHistoryIdLessThanOrEqual?: number,
        exerciseHistoryIdEquals?: number,
        exerciseHistoryIdNotEquals?: number,
        exerciseHistoryIdSpecified?: boolean,
        exerciseHistoryIdIn?: Array<number>,
        exerciseHistoryIdNotIn?: Array<number>,
        patientCognitiveStatusIdGreaterThan?: number,
        patientCognitiveStatusIdLessThan?: number,
        patientCognitiveStatusIdGreaterThanOrEqual?: number,
        patientCognitiveStatusIdLessThanOrEqual?: number,
        patientCognitiveStatusIdEquals?: number,
        patientCognitiveStatusIdNotEquals?: number,
        patientCognitiveStatusIdSpecified?: boolean,
        patientCognitiveStatusIdIn?: Array<number>,
        patientCognitiveStatusIdNotIn?: Array<number>,
        insuranceClaimIdGreaterThan?: number,
        insuranceClaimIdLessThan?: number,
        insuranceClaimIdGreaterThanOrEqual?: number,
        insuranceClaimIdLessThanOrEqual?: number,
        insuranceClaimIdEquals?: number,
        insuranceClaimIdNotEquals?: number,
        insuranceClaimIdSpecified?: boolean,
        insuranceClaimIdIn?: Array<number>,
        insuranceClaimIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patients/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'mrn.contains': mrnContains,
                'mrn.doesNotContain': mrnDoesNotContain,
                'mrn.equals': mrnEquals,
                'mrn.notEquals': mrnNotEquals,
                'mrn.specified': mrnSpecified,
                'mrn.in': mrnIn,
                'mrn.notIn': mrnNotIn,
                'firstNameUsed.contains': firstNameUsedContains,
                'firstNameUsed.doesNotContain': firstNameUsedDoesNotContain,
                'firstNameUsed.equals': firstNameUsedEquals,
                'firstNameUsed.notEquals': firstNameUsedNotEquals,
                'firstNameUsed.specified': firstNameUsedSpecified,
                'firstNameUsed.in': firstNameUsedIn,
                'firstNameUsed.notIn': firstNameUsedNotIn,
                'middleName.contains': middleNameContains,
                'middleName.doesNotContain': middleNameDoesNotContain,
                'middleName.equals': middleNameEquals,
                'middleName.notEquals': middleNameNotEquals,
                'middleName.specified': middleNameSpecified,
                'middleName.in': middleNameIn,
                'middleName.notIn': middleNameNotIn,
                'motherName.contains': motherNameContains,
                'motherName.doesNotContain': motherNameDoesNotContain,
                'motherName.equals': motherNameEquals,
                'motherName.notEquals': motherNameNotEquals,
                'motherName.specified': motherNameSpecified,
                'motherName.in': motherNameIn,
                'motherName.notIn': motherNameNotIn,
                'birthDate.greaterThan': birthDateGreaterThan,
                'birthDate.lessThan': birthDateLessThan,
                'birthDate.greaterThanOrEqual': birthDateGreaterThanOrEqual,
                'birthDate.lessThanOrEqual': birthDateLessThanOrEqual,
                'birthDate.equals': birthDateEquals,
                'birthDate.notEquals': birthDateNotEquals,
                'birthDate.specified': birthDateSpecified,
                'birthDate.in': birthDateIn,
                'birthDate.notIn': birthDateNotIn,
                'gender.equals': genderEquals,
                'gender.notEquals': genderNotEquals,
                'gender.specified': genderSpecified,
                'gender.in': genderIn,
                'gender.notIn': genderNotIn,
                'maritalStatus.equals': maritalStatusEquals,
                'maritalStatus.notEquals': maritalStatusNotEquals,
                'maritalStatus.specified': maritalStatusSpecified,
                'maritalStatus.in': maritalStatusIn,
                'maritalStatus.notIn': maritalStatusNotIn,
                'ethnicity.equals': ethnicityEquals,
                'ethnicity.notEquals': ethnicityNotEquals,
                'ethnicity.specified': ethnicitySpecified,
                'ethnicity.in': ethnicityIn,
                'ethnicity.notIn': ethnicityNotIn,
                'race.equals': raceEquals,
                'race.notEquals': raceNotEquals,
                'race.specified': raceSpecified,
                'race.in': raceIn,
                'race.notIn': raceNotIn,
                'ssn.contains': ssnContains,
                'ssn.doesNotContain': ssnDoesNotContain,
                'ssn.equals': ssnEquals,
                'ssn.notEquals': ssnNotEquals,
                'ssn.specified': ssnSpecified,
                'ssn.in': ssnIn,
                'ssn.notIn': ssnNotIn,
                'language.contains': languageContains,
                'language.doesNotContain': languageDoesNotContain,
                'language.equals': languageEquals,
                'language.notEquals': languageNotEquals,
                'language.specified': languageSpecified,
                'language.in': languageIn,
                'language.notIn': languageNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'emergContactFirstName.contains': emergContactFirstNameContains,
                'emergContactFirstName.doesNotContain': emergContactFirstNameDoesNotContain,
                'emergContactFirstName.equals': emergContactFirstNameEquals,
                'emergContactFirstName.notEquals': emergContactFirstNameNotEquals,
                'emergContactFirstName.specified': emergContactFirstNameSpecified,
                'emergContactFirstName.in': emergContactFirstNameIn,
                'emergContactFirstName.notIn': emergContactFirstNameNotIn,
                'emergContactLastName.contains': emergContactLastNameContains,
                'emergContactLastName.doesNotContain': emergContactLastNameDoesNotContain,
                'emergContactLastName.equals': emergContactLastNameEquals,
                'emergContactLastName.notEquals': emergContactLastNameNotEquals,
                'emergContactLastName.specified': emergContactLastNameSpecified,
                'emergContactLastName.in': emergContactLastNameIn,
                'emergContactLastName.notIn': emergContactLastNameNotIn,
                'emergContactRelation.equals': emergContactRelationEquals,
                'emergContactRelation.notEquals': emergContactRelationNotEquals,
                'emergContactRelation.specified': emergContactRelationSpecified,
                'emergContactRelation.in': emergContactRelationIn,
                'emergContactRelation.notIn': emergContactRelationNotIn,
                'emergContactNumber.contains': emergContactNumberContains,
                'emergContactNumber.doesNotContain': emergContactNumberDoesNotContain,
                'emergContactNumber.equals': emergContactNumberEquals,
                'emergContactNumber.notEquals': emergContactNumberNotEquals,
                'emergContactNumber.specified': emergContactNumberSpecified,
                'emergContactNumber.in': emergContactNumberIn,
                'emergContactNumber.notIn': emergContactNumberNotIn,
                'emergContactEmail.contains': emergContactEmailContains,
                'emergContactEmail.doesNotContain': emergContactEmailDoesNotContain,
                'emergContactEmail.equals': emergContactEmailEquals,
                'emergContactEmail.notEquals': emergContactEmailNotEquals,
                'emergContactEmail.specified': emergContactEmailSpecified,
                'emergContactEmail.in': emergContactEmailIn,
                'emergContactEmail.notIn': emergContactEmailNotIn,
                'messageConsent.equals': messageConsentEquals,
                'messageConsent.notEquals': messageConsentNotEquals,
                'messageConsent.specified': messageConsentSpecified,
                'messageConsent.in': messageConsentIn,
                'messageConsent.notIn': messageConsentNotIn,
                'callConsent.equals': callConsentEquals,
                'callConsent.notEquals': callConsentNotEquals,
                'callConsent.specified': callConsentSpecified,
                'callConsent.in': callConsentIn,
                'callConsent.notIn': callConsentNotIn,
                'emailConsent.equals': emailConsentEquals,
                'emailConsent.notEquals': emailConsentNotEquals,
                'emailConsent.specified': emailConsentSpecified,
                'emailConsent.in': emailConsentIn,
                'emailConsent.notIn': emailConsentNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'source.contains': sourceContains,
                'source.doesNotContain': sourceDoesNotContain,
                'source.equals': sourceEquals,
                'source.notEquals': sourceNotEquals,
                'source.specified': sourceSpecified,
                'source.in': sourceIn,
                'source.notIn': sourceNotIn,
                'lastVisit.greaterThan': lastVisitGreaterThan,
                'lastVisit.lessThan': lastVisitLessThan,
                'lastVisit.greaterThanOrEqual': lastVisitGreaterThanOrEqual,
                'lastVisit.lessThanOrEqual': lastVisitLessThanOrEqual,
                'lastVisit.equals': lastVisitEquals,
                'lastVisit.notEquals': lastVisitNotEquals,
                'lastVisit.specified': lastVisitSpecified,
                'lastVisit.in': lastVisitIn,
                'lastVisit.notIn': lastVisitNotIn,
                'balance.greaterThan': balanceGreaterThan,
                'balance.lessThan': balanceLessThan,
                'balance.greaterThanOrEqual': balanceGreaterThanOrEqual,
                'balance.lessThanOrEqual': balanceLessThanOrEqual,
                'balance.equals': balanceEquals,
                'balance.notEquals': balanceNotEquals,
                'balance.specified': balanceSpecified,
                'balance.in': balanceIn,
                'balance.notIn': balanceNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'providerGroupId.equals': providerGroupIdEquals,
                'providerGroupId.notEquals': providerGroupIdNotEquals,
                'providerGroupId.specified': providerGroupIdSpecified,
                'providerGroupId.in': providerGroupIdIn,
                'providerGroupId.notIn': providerGroupIdNotIn,
                'addressIdId.greaterThan': addressIdIdGreaterThan,
                'addressIdId.lessThan': addressIdIdLessThan,
                'addressIdId.greaterThanOrEqual': addressIdIdGreaterThanOrEqual,
                'addressIdId.lessThanOrEqual': addressIdIdLessThanOrEqual,
                'addressIdId.equals': addressIdIdEquals,
                'addressIdId.notEquals': addressIdIdNotEquals,
                'addressIdId.specified': addressIdIdSpecified,
                'addressIdId.in': addressIdIdIn,
                'addressIdId.notIn': addressIdIdNotIn,
                'defaultLocationIdId.greaterThan': defaultLocationIdIdGreaterThan,
                'defaultLocationIdId.lessThan': defaultLocationIdIdLessThan,
                'defaultLocationIdId.greaterThanOrEqual': defaultLocationIdIdGreaterThanOrEqual,
                'defaultLocationIdId.lessThanOrEqual': defaultLocationIdIdLessThanOrEqual,
                'defaultLocationIdId.equals': defaultLocationIdIdEquals,
                'defaultLocationIdId.notEquals': defaultLocationIdIdNotEquals,
                'defaultLocationIdId.specified': defaultLocationIdIdSpecified,
                'defaultLocationIdId.in': defaultLocationIdIdIn,
                'defaultLocationIdId.notIn': defaultLocationIdIdNotIn,
                'primaryProviderIdId.greaterThan': primaryProviderIdIdGreaterThan,
                'primaryProviderIdId.lessThan': primaryProviderIdIdLessThan,
                'primaryProviderIdId.greaterThanOrEqual': primaryProviderIdIdGreaterThanOrEqual,
                'primaryProviderIdId.lessThanOrEqual': primaryProviderIdIdLessThanOrEqual,
                'primaryProviderIdId.equals': primaryProviderIdIdEquals,
                'primaryProviderIdId.notEquals': primaryProviderIdIdNotEquals,
                'primaryProviderIdId.specified': primaryProviderIdIdSpecified,
                'primaryProviderIdId.in': primaryProviderIdIdIn,
                'primaryProviderIdId.notIn': primaryProviderIdIdNotIn,
                'preferredPharmacyId.greaterThan': preferredPharmacyIdGreaterThan,
                'preferredPharmacyId.lessThan': preferredPharmacyIdLessThan,
                'preferredPharmacyId.greaterThanOrEqual': preferredPharmacyIdGreaterThanOrEqual,
                'preferredPharmacyId.lessThanOrEqual': preferredPharmacyIdLessThanOrEqual,
                'preferredPharmacyId.equals': preferredPharmacyIdEquals,
                'preferredPharmacyId.notEquals': preferredPharmacyIdNotEquals,
                'preferredPharmacyId.specified': preferredPharmacyIdSpecified,
                'preferredPharmacyId.in': preferredPharmacyIdIn,
                'preferredPharmacyId.notIn': preferredPharmacyIdNotIn,
                'preferredLabsId.greaterThan': preferredLabsIdGreaterThan,
                'preferredLabsId.lessThan': preferredLabsIdLessThan,
                'preferredLabsId.greaterThanOrEqual': preferredLabsIdGreaterThanOrEqual,
                'preferredLabsId.lessThanOrEqual': preferredLabsIdLessThanOrEqual,
                'preferredLabsId.equals': preferredLabsIdEquals,
                'preferredLabsId.notEquals': preferredLabsIdNotEquals,
                'preferredLabsId.specified': preferredLabsIdSpecified,
                'preferredLabsId.in': preferredLabsIdIn,
                'preferredLabsId.notIn': preferredLabsIdNotIn,
                'preferredRadiologyId.greaterThan': preferredRadiologyIdGreaterThan,
                'preferredRadiologyId.lessThan': preferredRadiologyIdLessThan,
                'preferredRadiologyId.greaterThanOrEqual': preferredRadiologyIdGreaterThanOrEqual,
                'preferredRadiologyId.lessThanOrEqual': preferredRadiologyIdLessThanOrEqual,
                'preferredRadiologyId.equals': preferredRadiologyIdEquals,
                'preferredRadiologyId.notEquals': preferredRadiologyIdNotEquals,
                'preferredRadiologyId.specified': preferredRadiologyIdSpecified,
                'preferredRadiologyId.in': preferredRadiologyIdIn,
                'preferredRadiologyId.notIn': preferredRadiologyIdNotIn,
                'userIdId.greaterThan': userIdIdGreaterThan,
                'userIdId.lessThan': userIdIdLessThan,
                'userIdId.greaterThanOrEqual': userIdIdGreaterThanOrEqual,
                'userIdId.lessThanOrEqual': userIdIdLessThanOrEqual,
                'userIdId.equals': userIdIdEquals,
                'userIdId.notEquals': userIdIdNotEquals,
                'userIdId.specified': userIdIdSpecified,
                'userIdId.in': userIdIdIn,
                'userIdId.notIn': userIdIdNotIn,
                'primaryInsuranceIdId.greaterThan': primaryInsuranceIdIdGreaterThan,
                'primaryInsuranceIdId.lessThan': primaryInsuranceIdIdLessThan,
                'primaryInsuranceIdId.greaterThanOrEqual': primaryInsuranceIdIdGreaterThanOrEqual,
                'primaryInsuranceIdId.lessThanOrEqual': primaryInsuranceIdIdLessThanOrEqual,
                'primaryInsuranceIdId.equals': primaryInsuranceIdIdEquals,
                'primaryInsuranceIdId.notEquals': primaryInsuranceIdIdNotEquals,
                'primaryInsuranceIdId.specified': primaryInsuranceIdIdSpecified,
                'primaryInsuranceIdId.in': primaryInsuranceIdIdIn,
                'primaryInsuranceIdId.notIn': primaryInsuranceIdIdNotIn,
                'psychologicalHistoryId.greaterThan': psychologicalHistoryIdGreaterThan,
                'psychologicalHistoryId.lessThan': psychologicalHistoryIdLessThan,
                'psychologicalHistoryId.greaterThanOrEqual': psychologicalHistoryIdGreaterThanOrEqual,
                'psychologicalHistoryId.lessThanOrEqual': psychologicalHistoryIdLessThanOrEqual,
                'psychologicalHistoryId.equals': psychologicalHistoryIdEquals,
                'psychologicalHistoryId.notEquals': psychologicalHistoryIdNotEquals,
                'psychologicalHistoryId.specified': psychologicalHistoryIdSpecified,
                'psychologicalHistoryId.in': psychologicalHistoryIdIn,
                'psychologicalHistoryId.notIn': psychologicalHistoryIdNotIn,
                'prescriptionFormId.greaterThan': prescriptionFormIdGreaterThan,
                'prescriptionFormId.lessThan': prescriptionFormIdLessThan,
                'prescriptionFormId.greaterThanOrEqual': prescriptionFormIdGreaterThanOrEqual,
                'prescriptionFormId.lessThanOrEqual': prescriptionFormIdLessThanOrEqual,
                'prescriptionFormId.equals': prescriptionFormIdEquals,
                'prescriptionFormId.notEquals': prescriptionFormIdNotEquals,
                'prescriptionFormId.specified': prescriptionFormIdSpecified,
                'prescriptionFormId.in': prescriptionFormIdIn,
                'prescriptionFormId.notIn': prescriptionFormIdNotIn,
                'patientDietId.greaterThan': patientDietIdGreaterThan,
                'patientDietId.lessThan': patientDietIdLessThan,
                'patientDietId.greaterThanOrEqual': patientDietIdGreaterThanOrEqual,
                'patientDietId.lessThanOrEqual': patientDietIdLessThanOrEqual,
                'patientDietId.equals': patientDietIdEquals,
                'patientDietId.notEquals': patientDietIdNotEquals,
                'patientDietId.specified': patientDietIdSpecified,
                'patientDietId.in': patientDietIdIn,
                'patientDietId.notIn': patientDietIdNotIn,
                'habbitId.greaterThan': habbitIdGreaterThan,
                'habbitId.lessThan': habbitIdLessThan,
                'habbitId.greaterThanOrEqual': habbitIdGreaterThanOrEqual,
                'habbitId.lessThanOrEqual': habbitIdLessThanOrEqual,
                'habbitId.equals': habbitIdEquals,
                'habbitId.notEquals': habbitIdNotEquals,
                'habbitId.specified': habbitIdSpecified,
                'habbitId.in': habbitIdIn,
                'habbitId.notIn': habbitIdNotIn,
                'medicalHistoryId.greaterThan': medicalHistoryIdGreaterThan,
                'medicalHistoryId.lessThan': medicalHistoryIdLessThan,
                'medicalHistoryId.greaterThanOrEqual': medicalHistoryIdGreaterThanOrEqual,
                'medicalHistoryId.lessThanOrEqual': medicalHistoryIdLessThanOrEqual,
                'medicalHistoryId.equals': medicalHistoryIdEquals,
                'medicalHistoryId.notEquals': medicalHistoryIdNotEquals,
                'medicalHistoryId.specified': medicalHistoryIdSpecified,
                'medicalHistoryId.in': medicalHistoryIdIn,
                'medicalHistoryId.notIn': medicalHistoryIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'patientPermissionId.greaterThan': patientPermissionIdGreaterThan,
                'patientPermissionId.lessThan': patientPermissionIdLessThan,
                'patientPermissionId.greaterThanOrEqual': patientPermissionIdGreaterThanOrEqual,
                'patientPermissionId.lessThanOrEqual': patientPermissionIdLessThanOrEqual,
                'patientPermissionId.equals': patientPermissionIdEquals,
                'patientPermissionId.notEquals': patientPermissionIdNotEquals,
                'patientPermissionId.specified': patientPermissionIdSpecified,
                'patientPermissionId.in': patientPermissionIdIn,
                'patientPermissionId.notIn': patientPermissionIdNotIn,
                'surgicalHistoryId.greaterThan': surgicalHistoryIdGreaterThan,
                'surgicalHistoryId.lessThan': surgicalHistoryIdLessThan,
                'surgicalHistoryId.greaterThanOrEqual': surgicalHistoryIdGreaterThanOrEqual,
                'surgicalHistoryId.lessThanOrEqual': surgicalHistoryIdLessThanOrEqual,
                'surgicalHistoryId.equals': surgicalHistoryIdEquals,
                'surgicalHistoryId.notEquals': surgicalHistoryIdNotEquals,
                'surgicalHistoryId.specified': surgicalHistoryIdSpecified,
                'surgicalHistoryId.in': surgicalHistoryIdIn,
                'surgicalHistoryId.notIn': surgicalHistoryIdNotIn,
                'patientVitalId.greaterThan': patientVitalIdGreaterThan,
                'patientVitalId.lessThan': patientVitalIdLessThan,
                'patientVitalId.greaterThanOrEqual': patientVitalIdGreaterThanOrEqual,
                'patientVitalId.lessThanOrEqual': patientVitalIdLessThanOrEqual,
                'patientVitalId.equals': patientVitalIdEquals,
                'patientVitalId.notEquals': patientVitalIdNotEquals,
                'patientVitalId.specified': patientVitalIdSpecified,
                'patientVitalId.in': patientVitalIdIn,
                'patientVitalId.notIn': patientVitalIdNotIn,
                'patientFunctionalStatusId.greaterThan': patientFunctionalStatusIdGreaterThan,
                'patientFunctionalStatusId.lessThan': patientFunctionalStatusIdLessThan,
                'patientFunctionalStatusId.greaterThanOrEqual': patientFunctionalStatusIdGreaterThanOrEqual,
                'patientFunctionalStatusId.lessThanOrEqual': patientFunctionalStatusIdLessThanOrEqual,
                'patientFunctionalStatusId.equals': patientFunctionalStatusIdEquals,
                'patientFunctionalStatusId.notEquals': patientFunctionalStatusIdNotEquals,
                'patientFunctionalStatusId.specified': patientFunctionalStatusIdSpecified,
                'patientFunctionalStatusId.in': patientFunctionalStatusIdIn,
                'patientFunctionalStatusId.notIn': patientFunctionalStatusIdNotIn,
                'patientVaccineId.greaterThan': patientVaccineIdGreaterThan,
                'patientVaccineId.lessThan': patientVaccineIdLessThan,
                'patientVaccineId.greaterThanOrEqual': patientVaccineIdGreaterThanOrEqual,
                'patientVaccineId.lessThanOrEqual': patientVaccineIdLessThanOrEqual,
                'patientVaccineId.equals': patientVaccineIdEquals,
                'patientVaccineId.notEquals': patientVaccineIdNotEquals,
                'patientVaccineId.specified': patientVaccineIdSpecified,
                'patientVaccineId.in': patientVaccineIdIn,
                'patientVaccineId.notIn': patientVaccineIdNotIn,
                'insurancePaymentId.greaterThan': insurancePaymentIdGreaterThan,
                'insurancePaymentId.lessThan': insurancePaymentIdLessThan,
                'insurancePaymentId.greaterThanOrEqual': insurancePaymentIdGreaterThanOrEqual,
                'insurancePaymentId.lessThanOrEqual': insurancePaymentIdLessThanOrEqual,
                'insurancePaymentId.equals': insurancePaymentIdEquals,
                'insurancePaymentId.notEquals': insurancePaymentIdNotEquals,
                'insurancePaymentId.specified': insurancePaymentIdSpecified,
                'insurancePaymentId.in': insurancePaymentIdIn,
                'insurancePaymentId.notIn': insurancePaymentIdNotIn,
                'exerciseHistoryId.greaterThan': exerciseHistoryIdGreaterThan,
                'exerciseHistoryId.lessThan': exerciseHistoryIdLessThan,
                'exerciseHistoryId.greaterThanOrEqual': exerciseHistoryIdGreaterThanOrEqual,
                'exerciseHistoryId.lessThanOrEqual': exerciseHistoryIdLessThanOrEqual,
                'exerciseHistoryId.equals': exerciseHistoryIdEquals,
                'exerciseHistoryId.notEquals': exerciseHistoryIdNotEquals,
                'exerciseHistoryId.specified': exerciseHistoryIdSpecified,
                'exerciseHistoryId.in': exerciseHistoryIdIn,
                'exerciseHistoryId.notIn': exerciseHistoryIdNotIn,
                'patientCognitiveStatusId.greaterThan': patientCognitiveStatusIdGreaterThan,
                'patientCognitiveStatusId.lessThan': patientCognitiveStatusIdLessThan,
                'patientCognitiveStatusId.greaterThanOrEqual': patientCognitiveStatusIdGreaterThanOrEqual,
                'patientCognitiveStatusId.lessThanOrEqual': patientCognitiveStatusIdLessThanOrEqual,
                'patientCognitiveStatusId.equals': patientCognitiveStatusIdEquals,
                'patientCognitiveStatusId.notEquals': patientCognitiveStatusIdNotEquals,
                'patientCognitiveStatusId.specified': patientCognitiveStatusIdSpecified,
                'patientCognitiveStatusId.in': patientCognitiveStatusIdIn,
                'patientCognitiveStatusId.notIn': patientCognitiveStatusIdNotIn,
                'insuranceClaimId.greaterThan': insuranceClaimIdGreaterThan,
                'insuranceClaimId.lessThan': insuranceClaimIdLessThan,
                'insuranceClaimId.greaterThanOrEqual': insuranceClaimIdGreaterThanOrEqual,
                'insuranceClaimId.lessThanOrEqual': insuranceClaimIdLessThanOrEqual,
                'insuranceClaimId.equals': insuranceClaimIdEquals,
                'insuranceClaimId.notEquals': insuranceClaimIdNotEquals,
                'insuranceClaimId.specified': insuranceClaimIdSpecified,
                'insuranceClaimId.in': insuranceClaimIdIn,
                'insuranceClaimId.notIn': insuranceClaimIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
