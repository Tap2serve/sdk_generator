/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SocialHistoryDTO } from '../models/SocialHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class SocialHistoryResourceService {

    /**
     * @param id
     * @returns SocialHistoryDTO OK
     * @throws ApiError
     */
    public static getSocialHistory(
        id: number,
    ): CancelablePromise<SocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/social-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SocialHistoryDTO OK
     * @throws ApiError
     */
    public static updateSocialHistory(
        id: number,
        requestBody: SocialHistoryDTO,
    ): CancelablePromise<SocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/social-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteSocialHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/social-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SocialHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdateSocialHistory(
        id: number,
        requestBody: SocialHistoryDTO,
    ): CancelablePromise<SocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/social-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param recordedDateGreaterThan
     * @param recordedDateLessThan
     * @param recordedDateGreaterThanOrEqual
     * @param recordedDateLessThanOrEqual
     * @param recordedDateEquals
     * @param recordedDateNotEquals
     * @param recordedDateSpecified
     * @param recordedDateIn
     * @param recordedDateNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns SocialHistoryDTO OK
     * @throws ApiError
     */
    public static getAllSocialHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        recordedDateGreaterThan?: string,
        recordedDateLessThan?: string,
        recordedDateGreaterThanOrEqual?: string,
        recordedDateLessThanOrEqual?: string,
        recordedDateEquals?: string,
        recordedDateNotEquals?: string,
        recordedDateSpecified?: boolean,
        recordedDateIn?: Array<string>,
        recordedDateNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<SocialHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/social-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'recordedDate.greaterThan': recordedDateGreaterThan,
                'recordedDate.lessThan': recordedDateLessThan,
                'recordedDate.greaterThanOrEqual': recordedDateGreaterThanOrEqual,
                'recordedDate.lessThanOrEqual': recordedDateLessThanOrEqual,
                'recordedDate.equals': recordedDateEquals,
                'recordedDate.notEquals': recordedDateNotEquals,
                'recordedDate.specified': recordedDateSpecified,
                'recordedDate.in': recordedDateIn,
                'recordedDate.notIn': recordedDateNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns SocialHistoryDTO OK
     * @throws ApiError
     */
    public static createSocialHistory(
        requestBody: SocialHistoryDTO,
    ): CancelablePromise<SocialHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/social-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param recordedDateGreaterThan
     * @param recordedDateLessThan
     * @param recordedDateGreaterThanOrEqual
     * @param recordedDateLessThanOrEqual
     * @param recordedDateEquals
     * @param recordedDateNotEquals
     * @param recordedDateSpecified
     * @param recordedDateIn
     * @param recordedDateNotIn
     * @param titleContains
     * @param titleDoesNotContain
     * @param titleEquals
     * @param titleNotEquals
     * @param titleSpecified
     * @param titleIn
     * @param titleNotIn
     * @param answerContains
     * @param answerDoesNotContain
     * @param answerEquals
     * @param answerNotEquals
     * @param answerSpecified
     * @param answerIn
     * @param answerNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param questionIdGreaterThan
     * @param questionIdLessThan
     * @param questionIdGreaterThanOrEqual
     * @param questionIdLessThanOrEqual
     * @param questionIdEquals
     * @param questionIdNotEquals
     * @param questionIdSpecified
     * @param questionIdIn
     * @param questionIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countSocialHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        recordedDateGreaterThan?: string,
        recordedDateLessThan?: string,
        recordedDateGreaterThanOrEqual?: string,
        recordedDateLessThanOrEqual?: string,
        recordedDateEquals?: string,
        recordedDateNotEquals?: string,
        recordedDateSpecified?: boolean,
        recordedDateIn?: Array<string>,
        recordedDateNotIn?: Array<string>,
        titleContains?: string,
        titleDoesNotContain?: string,
        titleEquals?: string,
        titleNotEquals?: string,
        titleSpecified?: boolean,
        titleIn?: Array<string>,
        titleNotIn?: Array<string>,
        answerContains?: string,
        answerDoesNotContain?: string,
        answerEquals?: string,
        answerNotEquals?: string,
        answerSpecified?: boolean,
        answerIn?: Array<string>,
        answerNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        questionIdGreaterThan?: number,
        questionIdLessThan?: number,
        questionIdGreaterThanOrEqual?: number,
        questionIdLessThanOrEqual?: number,
        questionIdEquals?: number,
        questionIdNotEquals?: number,
        questionIdSpecified?: boolean,
        questionIdIn?: Array<number>,
        questionIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/social-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'recordedDate.greaterThan': recordedDateGreaterThan,
                'recordedDate.lessThan': recordedDateLessThan,
                'recordedDate.greaterThanOrEqual': recordedDateGreaterThanOrEqual,
                'recordedDate.lessThanOrEqual': recordedDateLessThanOrEqual,
                'recordedDate.equals': recordedDateEquals,
                'recordedDate.notEquals': recordedDateNotEquals,
                'recordedDate.specified': recordedDateSpecified,
                'recordedDate.in': recordedDateIn,
                'recordedDate.notIn': recordedDateNotIn,
                'title.contains': titleContains,
                'title.doesNotContain': titleDoesNotContain,
                'title.equals': titleEquals,
                'title.notEquals': titleNotEquals,
                'title.specified': titleSpecified,
                'title.in': titleIn,
                'title.notIn': titleNotIn,
                'answer.contains': answerContains,
                'answer.doesNotContain': answerDoesNotContain,
                'answer.equals': answerEquals,
                'answer.notEquals': answerNotEquals,
                'answer.specified': answerSpecified,
                'answer.in': answerIn,
                'answer.notIn': answerNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'questionId.greaterThan': questionIdGreaterThan,
                'questionId.lessThan': questionIdLessThan,
                'questionId.greaterThanOrEqual': questionIdGreaterThanOrEqual,
                'questionId.lessThanOrEqual': questionIdLessThanOrEqual,
                'questionId.equals': questionIdEquals,
                'questionId.notEquals': questionIdNotEquals,
                'questionId.specified': questionIdSpecified,
                'questionId.in': questionIdIn,
                'questionId.notIn': questionIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
