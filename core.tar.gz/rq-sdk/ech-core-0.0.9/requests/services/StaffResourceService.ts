/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Response } from '../models/Response';
import type { StaffDTO } from '../models/StaffDTO';
import type { UserProfileDTO } from '../models/UserProfileDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class StaffResourceService {

    /**
     * @param requestBody
     * @returns Response OK
     * @throws ApiError
     */
    public static updateStaff(
        requestBody: StaffDTO,
    ): CancelablePromise<Response> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/staffs',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param requestBody
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static createStaff(
        requestBody: StaffDTO,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/staffs',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param userUuid
     * @param isActive
     * @returns Response OK
     * @throws ApiError
     */
    public static updateStaffStatus(
        userUuid: string,
        isActive: boolean,
    ): CancelablePromise<Response> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/staffs/{userUuid}/status',
            path: {
                'userUuid': userUuid,
            },
            query: {
                'isActive': isActive,
            },
        });
    }

    /**
     * @param userUuid
     * @returns UserProfileDTO OK
     * @throws ApiError
     */
    public static getStaffByUserUuid(
        userUuid: string,
    ): CancelablePromise<UserProfileDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/staffs/{userUuid}',
            path: {
                'userUuid': userUuid,
            },
        });
    }

    /**
     * @param userUuid
     * @returns Response OK
     * @throws ApiError
     */
    public static remove(
        userUuid: string,
    ): CancelablePromise<Response> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/staffs/{userUuid}',
            path: {
                'userUuid': userUuid,
            },
        });
    }

}
