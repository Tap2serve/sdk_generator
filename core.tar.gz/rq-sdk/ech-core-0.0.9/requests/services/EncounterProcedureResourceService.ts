/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EncounterProcedureDTO } from '../models/EncounterProcedureDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class EncounterProcedureResourceService {

    /**
     * @param id
     * @returns EncounterProcedureDTO OK
     * @throws ApiError
     */
    public static getEncounterProcedure(
        id: number,
    ): CancelablePromise<EncounterProcedureDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-procedures/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterProcedureDTO OK
     * @throws ApiError
     */
    public static updateEncounterProcedure(
        id: number,
        requestBody: EncounterProcedureDTO,
    ): CancelablePromise<EncounterProcedureDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/encounter-procedures/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteEncounterProcedure(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/encounter-procedures/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns EncounterProcedureDTO OK
     * @throws ApiError
     */
    public static partialUpdateEncounterProcedure(
        id: number,
        requestBody: EncounterProcedureDTO,
    ): CancelablePromise<EncounterProcedureDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/encounter-procedures/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeContains
     * @param codeDoesNotContain
     * @param codeEquals
     * @param codeNotEquals
     * @param codeSpecified
     * @param codeIn
     * @param codeNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param modifierContains
     * @param modifierDoesNotContain
     * @param modifierEquals
     * @param modifierNotEquals
     * @param modifierSpecified
     * @param modifierIn
     * @param modifierNotIn
     * @param diagnosisPointerContains
     * @param diagnosisPointerDoesNotContain
     * @param diagnosisPointerEquals
     * @param diagnosisPointerNotEquals
     * @param diagnosisPointerSpecified
     * @param diagnosisPointerIn
     * @param diagnosisPointerNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param chargesGreaterThan
     * @param chargesLessThan
     * @param chargesGreaterThanOrEqual
     * @param chargesLessThanOrEqual
     * @param chargesEquals
     * @param chargesNotEquals
     * @param chargesSpecified
     * @param chargesIn
     * @param chargesNotIn
     * @param discountGreaterThan
     * @param discountLessThan
     * @param discountGreaterThanOrEqual
     * @param discountLessThanOrEqual
     * @param discountEquals
     * @param discountNotEquals
     * @param discountSpecified
     * @param discountIn
     * @param discountNotIn
     * @param taxGreaterThan
     * @param taxLessThan
     * @param taxGreaterThanOrEqual
     * @param taxLessThanOrEqual
     * @param taxEquals
     * @param taxNotEquals
     * @param taxSpecified
     * @param taxIn
     * @param taxNotIn
     * @param netGreaterThan
     * @param netLessThan
     * @param netGreaterThanOrEqual
     * @param netLessThanOrEqual
     * @param netEquals
     * @param netNotEquals
     * @param netSpecified
     * @param netIn
     * @param netNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns EncounterProcedureDTO OK
     * @throws ApiError
     */
    public static getAllEncounterProcedures(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeContains?: string,
        codeDoesNotContain?: string,
        codeEquals?: string,
        codeNotEquals?: string,
        codeSpecified?: boolean,
        codeIn?: Array<string>,
        codeNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        modifierContains?: string,
        modifierDoesNotContain?: string,
        modifierEquals?: string,
        modifierNotEquals?: string,
        modifierSpecified?: boolean,
        modifierIn?: Array<string>,
        modifierNotIn?: Array<string>,
        diagnosisPointerContains?: string,
        diagnosisPointerDoesNotContain?: string,
        diagnosisPointerEquals?: string,
        diagnosisPointerNotEquals?: string,
        diagnosisPointerSpecified?: boolean,
        diagnosisPointerIn?: Array<string>,
        diagnosisPointerNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        chargesGreaterThan?: number,
        chargesLessThan?: number,
        chargesGreaterThanOrEqual?: number,
        chargesLessThanOrEqual?: number,
        chargesEquals?: number,
        chargesNotEquals?: number,
        chargesSpecified?: boolean,
        chargesIn?: Array<number>,
        chargesNotIn?: Array<number>,
        discountGreaterThan?: number,
        discountLessThan?: number,
        discountGreaterThanOrEqual?: number,
        discountLessThanOrEqual?: number,
        discountEquals?: number,
        discountNotEquals?: number,
        discountSpecified?: boolean,
        discountIn?: Array<number>,
        discountNotIn?: Array<number>,
        taxGreaterThan?: number,
        taxLessThan?: number,
        taxGreaterThanOrEqual?: number,
        taxLessThanOrEqual?: number,
        taxEquals?: number,
        taxNotEquals?: number,
        taxSpecified?: boolean,
        taxIn?: Array<number>,
        taxNotIn?: Array<number>,
        netGreaterThan?: number,
        netLessThan?: number,
        netGreaterThanOrEqual?: number,
        netLessThanOrEqual?: number,
        netEquals?: number,
        netNotEquals?: number,
        netSpecified?: boolean,
        netIn?: Array<number>,
        netNotIn?: Array<number>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<EncounterProcedureDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-procedures',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'code.contains': codeContains,
                'code.doesNotContain': codeDoesNotContain,
                'code.equals': codeEquals,
                'code.notEquals': codeNotEquals,
                'code.specified': codeSpecified,
                'code.in': codeIn,
                'code.notIn': codeNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'modifier.contains': modifierContains,
                'modifier.doesNotContain': modifierDoesNotContain,
                'modifier.equals': modifierEquals,
                'modifier.notEquals': modifierNotEquals,
                'modifier.specified': modifierSpecified,
                'modifier.in': modifierIn,
                'modifier.notIn': modifierNotIn,
                'diagnosisPointer.contains': diagnosisPointerContains,
                'diagnosisPointer.doesNotContain': diagnosisPointerDoesNotContain,
                'diagnosisPointer.equals': diagnosisPointerEquals,
                'diagnosisPointer.notEquals': diagnosisPointerNotEquals,
                'diagnosisPointer.specified': diagnosisPointerSpecified,
                'diagnosisPointer.in': diagnosisPointerIn,
                'diagnosisPointer.notIn': diagnosisPointerNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'charges.greaterThan': chargesGreaterThan,
                'charges.lessThan': chargesLessThan,
                'charges.greaterThanOrEqual': chargesGreaterThanOrEqual,
                'charges.lessThanOrEqual': chargesLessThanOrEqual,
                'charges.equals': chargesEquals,
                'charges.notEquals': chargesNotEquals,
                'charges.specified': chargesSpecified,
                'charges.in': chargesIn,
                'charges.notIn': chargesNotIn,
                'discount.greaterThan': discountGreaterThan,
                'discount.lessThan': discountLessThan,
                'discount.greaterThanOrEqual': discountGreaterThanOrEqual,
                'discount.lessThanOrEqual': discountLessThanOrEqual,
                'discount.equals': discountEquals,
                'discount.notEquals': discountNotEquals,
                'discount.specified': discountSpecified,
                'discount.in': discountIn,
                'discount.notIn': discountNotIn,
                'tax.greaterThan': taxGreaterThan,
                'tax.lessThan': taxLessThan,
                'tax.greaterThanOrEqual': taxGreaterThanOrEqual,
                'tax.lessThanOrEqual': taxLessThanOrEqual,
                'tax.equals': taxEquals,
                'tax.notEquals': taxNotEquals,
                'tax.specified': taxSpecified,
                'tax.in': taxIn,
                'tax.notIn': taxNotIn,
                'net.greaterThan': netGreaterThan,
                'net.lessThan': netLessThan,
                'net.greaterThanOrEqual': netGreaterThanOrEqual,
                'net.lessThanOrEqual': netLessThanOrEqual,
                'net.equals': netEquals,
                'net.notEquals': netNotEquals,
                'net.specified': netSpecified,
                'net.in': netIn,
                'net.notIn': netNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns EncounterProcedureDTO OK
     * @throws ApiError
     */
    public static createEncounterProcedure(
        requestBody: EncounterProcedureDTO,
    ): CancelablePromise<EncounterProcedureDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/encounter-procedures',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param codeContains
     * @param codeDoesNotContain
     * @param codeEquals
     * @param codeNotEquals
     * @param codeSpecified
     * @param codeIn
     * @param codeNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param typeContains
     * @param typeDoesNotContain
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param modifierContains
     * @param modifierDoesNotContain
     * @param modifierEquals
     * @param modifierNotEquals
     * @param modifierSpecified
     * @param modifierIn
     * @param modifierNotIn
     * @param diagnosisPointerContains
     * @param diagnosisPointerDoesNotContain
     * @param diagnosisPointerEquals
     * @param diagnosisPointerNotEquals
     * @param diagnosisPointerSpecified
     * @param diagnosisPointerIn
     * @param diagnosisPointerNotIn
     * @param quantityGreaterThan
     * @param quantityLessThan
     * @param quantityGreaterThanOrEqual
     * @param quantityLessThanOrEqual
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param chargesGreaterThan
     * @param chargesLessThan
     * @param chargesGreaterThanOrEqual
     * @param chargesLessThanOrEqual
     * @param chargesEquals
     * @param chargesNotEquals
     * @param chargesSpecified
     * @param chargesIn
     * @param chargesNotIn
     * @param discountGreaterThan
     * @param discountLessThan
     * @param discountGreaterThanOrEqual
     * @param discountLessThanOrEqual
     * @param discountEquals
     * @param discountNotEquals
     * @param discountSpecified
     * @param discountIn
     * @param discountNotIn
     * @param taxGreaterThan
     * @param taxLessThan
     * @param taxGreaterThanOrEqual
     * @param taxLessThanOrEqual
     * @param taxEquals
     * @param taxNotEquals
     * @param taxSpecified
     * @param taxIn
     * @param taxNotIn
     * @param netGreaterThan
     * @param netLessThan
     * @param netGreaterThanOrEqual
     * @param netLessThanOrEqual
     * @param netEquals
     * @param netNotEquals
     * @param netSpecified
     * @param netIn
     * @param netNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param encounterIdIdGreaterThan
     * @param encounterIdIdLessThan
     * @param encounterIdIdGreaterThanOrEqual
     * @param encounterIdIdLessThanOrEqual
     * @param encounterIdIdEquals
     * @param encounterIdIdNotEquals
     * @param encounterIdIdSpecified
     * @param encounterIdIdIn
     * @param encounterIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countEncounterProcedures(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        codeContains?: string,
        codeDoesNotContain?: string,
        codeEquals?: string,
        codeNotEquals?: string,
        codeSpecified?: boolean,
        codeIn?: Array<string>,
        codeNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        typeContains?: string,
        typeDoesNotContain?: string,
        typeEquals?: string,
        typeNotEquals?: string,
        typeSpecified?: boolean,
        typeIn?: Array<string>,
        typeNotIn?: Array<string>,
        modifierContains?: string,
        modifierDoesNotContain?: string,
        modifierEquals?: string,
        modifierNotEquals?: string,
        modifierSpecified?: boolean,
        modifierIn?: Array<string>,
        modifierNotIn?: Array<string>,
        diagnosisPointerContains?: string,
        diagnosisPointerDoesNotContain?: string,
        diagnosisPointerEquals?: string,
        diagnosisPointerNotEquals?: string,
        diagnosisPointerSpecified?: boolean,
        diagnosisPointerIn?: Array<string>,
        diagnosisPointerNotIn?: Array<string>,
        quantityGreaterThan?: number,
        quantityLessThan?: number,
        quantityGreaterThanOrEqual?: number,
        quantityLessThanOrEqual?: number,
        quantityEquals?: number,
        quantityNotEquals?: number,
        quantitySpecified?: boolean,
        quantityIn?: Array<number>,
        quantityNotIn?: Array<number>,
        chargesGreaterThan?: number,
        chargesLessThan?: number,
        chargesGreaterThanOrEqual?: number,
        chargesLessThanOrEqual?: number,
        chargesEquals?: number,
        chargesNotEquals?: number,
        chargesSpecified?: boolean,
        chargesIn?: Array<number>,
        chargesNotIn?: Array<number>,
        discountGreaterThan?: number,
        discountLessThan?: number,
        discountGreaterThanOrEqual?: number,
        discountLessThanOrEqual?: number,
        discountEquals?: number,
        discountNotEquals?: number,
        discountSpecified?: boolean,
        discountIn?: Array<number>,
        discountNotIn?: Array<number>,
        taxGreaterThan?: number,
        taxLessThan?: number,
        taxGreaterThanOrEqual?: number,
        taxLessThanOrEqual?: number,
        taxEquals?: number,
        taxNotEquals?: number,
        taxSpecified?: boolean,
        taxIn?: Array<number>,
        taxNotIn?: Array<number>,
        netGreaterThan?: number,
        netLessThan?: number,
        netGreaterThanOrEqual?: number,
        netLessThanOrEqual?: number,
        netEquals?: number,
        netNotEquals?: number,
        netSpecified?: boolean,
        netIn?: Array<number>,
        netNotIn?: Array<number>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        encounterIdIdGreaterThan?: number,
        encounterIdIdLessThan?: number,
        encounterIdIdGreaterThanOrEqual?: number,
        encounterIdIdLessThanOrEqual?: number,
        encounterIdIdEquals?: number,
        encounterIdIdNotEquals?: number,
        encounterIdIdSpecified?: boolean,
        encounterIdIdIn?: Array<number>,
        encounterIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/encounter-procedures/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'code.contains': codeContains,
                'code.doesNotContain': codeDoesNotContain,
                'code.equals': codeEquals,
                'code.notEquals': codeNotEquals,
                'code.specified': codeSpecified,
                'code.in': codeIn,
                'code.notIn': codeNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'type.contains': typeContains,
                'type.doesNotContain': typeDoesNotContain,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'modifier.contains': modifierContains,
                'modifier.doesNotContain': modifierDoesNotContain,
                'modifier.equals': modifierEquals,
                'modifier.notEquals': modifierNotEquals,
                'modifier.specified': modifierSpecified,
                'modifier.in': modifierIn,
                'modifier.notIn': modifierNotIn,
                'diagnosisPointer.contains': diagnosisPointerContains,
                'diagnosisPointer.doesNotContain': diagnosisPointerDoesNotContain,
                'diagnosisPointer.equals': diagnosisPointerEquals,
                'diagnosisPointer.notEquals': diagnosisPointerNotEquals,
                'diagnosisPointer.specified': diagnosisPointerSpecified,
                'diagnosisPointer.in': diagnosisPointerIn,
                'diagnosisPointer.notIn': diagnosisPointerNotIn,
                'quantity.greaterThan': quantityGreaterThan,
                'quantity.lessThan': quantityLessThan,
                'quantity.greaterThanOrEqual': quantityGreaterThanOrEqual,
                'quantity.lessThanOrEqual': quantityLessThanOrEqual,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'charges.greaterThan': chargesGreaterThan,
                'charges.lessThan': chargesLessThan,
                'charges.greaterThanOrEqual': chargesGreaterThanOrEqual,
                'charges.lessThanOrEqual': chargesLessThanOrEqual,
                'charges.equals': chargesEquals,
                'charges.notEquals': chargesNotEquals,
                'charges.specified': chargesSpecified,
                'charges.in': chargesIn,
                'charges.notIn': chargesNotIn,
                'discount.greaterThan': discountGreaterThan,
                'discount.lessThan': discountLessThan,
                'discount.greaterThanOrEqual': discountGreaterThanOrEqual,
                'discount.lessThanOrEqual': discountLessThanOrEqual,
                'discount.equals': discountEquals,
                'discount.notEquals': discountNotEquals,
                'discount.specified': discountSpecified,
                'discount.in': discountIn,
                'discount.notIn': discountNotIn,
                'tax.greaterThan': taxGreaterThan,
                'tax.lessThan': taxLessThan,
                'tax.greaterThanOrEqual': taxGreaterThanOrEqual,
                'tax.lessThanOrEqual': taxLessThanOrEqual,
                'tax.equals': taxEquals,
                'tax.notEquals': taxNotEquals,
                'tax.specified': taxSpecified,
                'tax.in': taxIn,
                'tax.notIn': taxNotIn,
                'net.greaterThan': netGreaterThan,
                'net.lessThan': netLessThan,
                'net.greaterThanOrEqual': netGreaterThanOrEqual,
                'net.lessThanOrEqual': netLessThanOrEqual,
                'net.equals': netEquals,
                'net.notEquals': netNotEquals,
                'net.specified': netSpecified,
                'net.in': netIn,
                'net.notIn': netNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'encounterIdId.greaterThan': encounterIdIdGreaterThan,
                'encounterIdId.lessThan': encounterIdIdLessThan,
                'encounterIdId.greaterThanOrEqual': encounterIdIdGreaterThanOrEqual,
                'encounterIdId.lessThanOrEqual': encounterIdIdLessThanOrEqual,
                'encounterIdId.equals': encounterIdIdEquals,
                'encounterIdId.notEquals': encounterIdIdNotEquals,
                'encounterIdId.specified': encounterIdIdSpecified,
                'encounterIdId.in': encounterIdIdIn,
                'encounterIdId.notIn': encounterIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
