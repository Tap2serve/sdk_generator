/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Pageable } from '../models/Pageable';
import type { PageSpecialityDTO } from '../models/PageSpecialityDTO';
import type { ProviderDTO } from '../models/ProviderDTO';
import type { ProviderGroupDTO } from '../models/ProviderGroupDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ProviderResourceService {

    /**
     * @param id
     * @param requestBody
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static updateProvider(
        id: number,
        requestBody: ProviderDTO,
    ): CancelablePromise<ProviderDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/providers/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static partialUpdateProvider(
        id: number,
        requestBody: ProviderDTO,
    ): CancelablePromise<ProviderDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/providers/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static getProviderGroup(): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/providers/provider-group',
        });
    }

    /**
     * @param xTenantId
     * @param requestBody
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static updateProviderGroup(
        xTenantId: string,
        requestBody: ProviderGroupDTO,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/providers/provider-group',
            headers: {
                'X-TENANT-ID': xTenantId,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param medicalCredsContains
     * @param medicalCredsDoesNotContain
     * @param medicalCredsEquals
     * @param medicalCredsNotEquals
     * @param medicalCredsSpecified
     * @param medicalCredsIn
     * @param medicalCredsNotIn
     * @param genderEquals
     * @param genderNotEquals
     * @param genderSpecified
     * @param genderIn
     * @param genderNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param groupNpiContains
     * @param groupNpiDoesNotContain
     * @param groupNpiEquals
     * @param groupNpiNotEquals
     * @param groupNpiSpecified
     * @param groupNpiIn
     * @param groupNpiNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param licenseNumberContains
     * @param licenseNumberDoesNotContain
     * @param licenseNumberEquals
     * @param licenseNumberNotEquals
     * @param licenseNumberSpecified
     * @param licenseNumberIn
     * @param licenseNumberNotIn
     * @param experinceYearsContains
     * @param experinceYearsDoesNotContain
     * @param experinceYearsEquals
     * @param experinceYearsNotEquals
     * @param experinceYearsSpecified
     * @param experinceYearsIn
     * @param experinceYearsNotIn
     * @param taxonomyNumberContains
     * @param taxonomyNumberDoesNotContain
     * @param taxonomyNumberEquals
     * @param taxonomyNumberNotEquals
     * @param taxonomyNumberSpecified
     * @param taxonomyNumberIn
     * @param taxonomyNumberNotIn
     * @param focusedAreaContains
     * @param focusedAreaDoesNotContain
     * @param focusedAreaEquals
     * @param focusedAreaNotEquals
     * @param focusedAreaSpecified
     * @param focusedAreaIn
     * @param focusedAreaNotIn
     * @param hospitalAffilationContains
     * @param hospitalAffilationDoesNotContain
     * @param hospitalAffilationEquals
     * @param hospitalAffilationNotEquals
     * @param hospitalAffilationSpecified
     * @param hospitalAffilationIn
     * @param hospitalAffilationNotIn
     * @param ageGroupSeenContains
     * @param ageGroupSeenDoesNotContain
     * @param ageGroupSeenEquals
     * @param ageGroupSeenNotEquals
     * @param ageGroupSeenSpecified
     * @param ageGroupSeenIn
     * @param ageGroupSeenNotIn
     * @param languagesSpokenEquals
     * @param languagesSpokenNotEquals
     * @param languagesSpokenSpecified
     * @param languagesSpokenIn
     * @param languagesSpokenNotIn
     * @param priorAuthorisationContains
     * @param priorAuthorisationDoesNotContain
     * @param priorAuthorisationEquals
     * @param priorAuthorisationNotEquals
     * @param priorAuthorisationSpecified
     * @param priorAuthorisationIn
     * @param priorAuthorisationNotIn
     * @param secondOpinionContains
     * @param secondOpinionDoesNotContain
     * @param secondOpinionEquals
     * @param secondOpinionNotEquals
     * @param secondOpinionSpecified
     * @param secondOpinionIn
     * @param secondOpinionNotIn
     * @param acuteSpecialityContains
     * @param acuteSpecialityDoesNotContain
     * @param acuteSpecialityEquals
     * @param acuteSpecialityNotEquals
     * @param acuteSpecialitySpecified
     * @param acuteSpecialityIn
     * @param acuteSpecialityNotIn
     * @param bioContains
     * @param bioDoesNotContain
     * @param bioEquals
     * @param bioNotEquals
     * @param bioSpecified
     * @param bioIn
     * @param bioNotIn
     * @param expertiseContains
     * @param expertiseDoesNotContain
     * @param expertiseEquals
     * @param expertiseNotEquals
     * @param expertiseSpecified
     * @param expertiseIn
     * @param expertiseNotIn
     * @param experienceContains
     * @param experienceDoesNotContain
     * @param experienceEquals
     * @param experienceNotEquals
     * @param experienceSpecified
     * @param experienceIn
     * @param experienceNotIn
     * @param employmentRefNumberContains
     * @param employmentRefNumberDoesNotContain
     * @param employmentRefNumberEquals
     * @param employmentRefNumberNotEquals
     * @param employmentRefNumberSpecified
     * @param employmentRefNumberIn
     * @param employmentRefNumberNotIn
     * @param acceptNewPatientEquals
     * @param acceptNewPatientNotEquals
     * @param acceptNewPatientSpecified
     * @param acceptNewPatientIn
     * @param acceptNewPatientNotIn
     * @param acceptCashPayEquals
     * @param acceptCashPayNotEquals
     * @param acceptCashPaySpecified
     * @param acceptCashPayIn
     * @param acceptCashPayNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param licensedStatesIdGreaterThan
     * @param licensedStatesIdLessThan
     * @param licensedStatesIdGreaterThanOrEqual
     * @param licensedStatesIdLessThanOrEqual
     * @param licensedStatesIdEquals
     * @param licensedStatesIdNotEquals
     * @param licensedStatesIdSpecified
     * @param licensedStatesIdIn
     * @param licensedStatesIdNotIn
     * @param workLocationsIdGreaterThan
     * @param workLocationsIdLessThan
     * @param workLocationsIdGreaterThanOrEqual
     * @param workLocationsIdLessThanOrEqual
     * @param workLocationsIdEquals
     * @param workLocationsIdNotEquals
     * @param workLocationsIdSpecified
     * @param workLocationsIdIn
     * @param workLocationsIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param acceptedInsurancesIdGreaterThan
     * @param acceptedInsurancesIdLessThan
     * @param acceptedInsurancesIdGreaterThanOrEqual
     * @param acceptedInsurancesIdLessThanOrEqual
     * @param acceptedInsurancesIdEquals
     * @param acceptedInsurancesIdNotEquals
     * @param acceptedInsurancesIdSpecified
     * @param acceptedInsurancesIdIn
     * @param acceptedInsurancesIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param availabilityIdGreaterThan
     * @param availabilityIdLessThan
     * @param availabilityIdGreaterThanOrEqual
     * @param availabilityIdLessThanOrEqual
     * @param availabilityIdEquals
     * @param availabilityIdNotEquals
     * @param availabilityIdSpecified
     * @param availabilityIdIn
     * @param availabilityIdNotIn
     * @param patientMedicationIdGreaterThan
     * @param patientMedicationIdLessThan
     * @param patientMedicationIdGreaterThanOrEqual
     * @param patientMedicationIdLessThanOrEqual
     * @param patientMedicationIdEquals
     * @param patientMedicationIdNotEquals
     * @param patientMedicationIdSpecified
     * @param patientMedicationIdIn
     * @param patientMedicationIdNotIn
     * @param feeScheduleIdGreaterThan
     * @param feeScheduleIdLessThan
     * @param feeScheduleIdGreaterThanOrEqual
     * @param feeScheduleIdLessThanOrEqual
     * @param feeScheduleIdEquals
     * @param feeScheduleIdNotEquals
     * @param feeScheduleIdSpecified
     * @param feeScheduleIdIn
     * @param feeScheduleIdNotIn
     * @param insuranceClaimIdGreaterThan
     * @param insuranceClaimIdLessThan
     * @param insuranceClaimIdGreaterThanOrEqual
     * @param insuranceClaimIdLessThanOrEqual
     * @param insuranceClaimIdEquals
     * @param insuranceClaimIdNotEquals
     * @param insuranceClaimIdSpecified
     * @param insuranceClaimIdIn
     * @param insuranceClaimIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static getAllProviders(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        typeEquals?: 'MD' | 'PSYD' | 'LCSW',
        typeNotEquals?: 'MD' | 'PSYD' | 'LCSW',
        typeSpecified?: boolean,
        typeIn?: Array<'MD' | 'PSYD' | 'LCSW'>,
        typeNotIn?: Array<'MD' | 'PSYD' | 'LCSW'>,
        medicalCredsContains?: string,
        medicalCredsDoesNotContain?: string,
        medicalCredsEquals?: string,
        medicalCredsNotEquals?: string,
        medicalCredsSpecified?: boolean,
        medicalCredsIn?: Array<string>,
        medicalCredsNotIn?: Array<string>,
        genderEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderNotEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderSpecified?: boolean,
        genderIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        genderNotIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        groupNpiContains?: string,
        groupNpiDoesNotContain?: string,
        groupNpiEquals?: string,
        groupNpiNotEquals?: string,
        groupNpiSpecified?: boolean,
        groupNpiIn?: Array<string>,
        groupNpiNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        licenseNumberContains?: string,
        licenseNumberDoesNotContain?: string,
        licenseNumberEquals?: string,
        licenseNumberNotEquals?: string,
        licenseNumberSpecified?: boolean,
        licenseNumberIn?: Array<string>,
        licenseNumberNotIn?: Array<string>,
        experinceYearsContains?: string,
        experinceYearsDoesNotContain?: string,
        experinceYearsEquals?: string,
        experinceYearsNotEquals?: string,
        experinceYearsSpecified?: boolean,
        experinceYearsIn?: Array<string>,
        experinceYearsNotIn?: Array<string>,
        taxonomyNumberContains?: string,
        taxonomyNumberDoesNotContain?: string,
        taxonomyNumberEquals?: string,
        taxonomyNumberNotEquals?: string,
        taxonomyNumberSpecified?: boolean,
        taxonomyNumberIn?: Array<string>,
        taxonomyNumberNotIn?: Array<string>,
        focusedAreaContains?: string,
        focusedAreaDoesNotContain?: string,
        focusedAreaEquals?: string,
        focusedAreaNotEquals?: string,
        focusedAreaSpecified?: boolean,
        focusedAreaIn?: Array<string>,
        focusedAreaNotIn?: Array<string>,
        hospitalAffilationContains?: string,
        hospitalAffilationDoesNotContain?: string,
        hospitalAffilationEquals?: string,
        hospitalAffilationNotEquals?: string,
        hospitalAffilationSpecified?: boolean,
        hospitalAffilationIn?: Array<string>,
        hospitalAffilationNotIn?: Array<string>,
        ageGroupSeenContains?: string,
        ageGroupSeenDoesNotContain?: string,
        ageGroupSeenEquals?: string,
        ageGroupSeenNotEquals?: string,
        ageGroupSeenSpecified?: boolean,
        ageGroupSeenIn?: Array<string>,
        ageGroupSeenNotIn?: Array<string>,
        languagesSpokenEquals?: 'ENGLISH' | 'SPANISH' | 'OTHER',
        languagesSpokenNotEquals?: 'ENGLISH' | 'SPANISH' | 'OTHER',
        languagesSpokenSpecified?: boolean,
        languagesSpokenIn?: Array<'ENGLISH' | 'SPANISH' | 'OTHER'>,
        languagesSpokenNotIn?: Array<'ENGLISH' | 'SPANISH' | 'OTHER'>,
        priorAuthorisationContains?: string,
        priorAuthorisationDoesNotContain?: string,
        priorAuthorisationEquals?: string,
        priorAuthorisationNotEquals?: string,
        priorAuthorisationSpecified?: boolean,
        priorAuthorisationIn?: Array<string>,
        priorAuthorisationNotIn?: Array<string>,
        secondOpinionContains?: string,
        secondOpinionDoesNotContain?: string,
        secondOpinionEquals?: string,
        secondOpinionNotEquals?: string,
        secondOpinionSpecified?: boolean,
        secondOpinionIn?: Array<string>,
        secondOpinionNotIn?: Array<string>,
        acuteSpecialityContains?: string,
        acuteSpecialityDoesNotContain?: string,
        acuteSpecialityEquals?: string,
        acuteSpecialityNotEquals?: string,
        acuteSpecialitySpecified?: boolean,
        acuteSpecialityIn?: Array<string>,
        acuteSpecialityNotIn?: Array<string>,
        bioContains?: string,
        bioDoesNotContain?: string,
        bioEquals?: string,
        bioNotEquals?: string,
        bioSpecified?: boolean,
        bioIn?: Array<string>,
        bioNotIn?: Array<string>,
        expertiseContains?: string,
        expertiseDoesNotContain?: string,
        expertiseEquals?: string,
        expertiseNotEquals?: string,
        expertiseSpecified?: boolean,
        expertiseIn?: Array<string>,
        expertiseNotIn?: Array<string>,
        experienceContains?: string,
        experienceDoesNotContain?: string,
        experienceEquals?: string,
        experienceNotEquals?: string,
        experienceSpecified?: boolean,
        experienceIn?: Array<string>,
        experienceNotIn?: Array<string>,
        employmentRefNumberContains?: string,
        employmentRefNumberDoesNotContain?: string,
        employmentRefNumberEquals?: string,
        employmentRefNumberNotEquals?: string,
        employmentRefNumberSpecified?: boolean,
        employmentRefNumberIn?: Array<string>,
        employmentRefNumberNotIn?: Array<string>,
        acceptNewPatientEquals?: boolean,
        acceptNewPatientNotEquals?: boolean,
        acceptNewPatientSpecified?: boolean,
        acceptNewPatientIn?: Array<boolean>,
        acceptNewPatientNotIn?: Array<boolean>,
        acceptCashPayEquals?: boolean,
        acceptCashPayNotEquals?: boolean,
        acceptCashPaySpecified?: boolean,
        acceptCashPayIn?: Array<boolean>,
        acceptCashPayNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        licensedStatesIdGreaterThan?: number,
        licensedStatesIdLessThan?: number,
        licensedStatesIdGreaterThanOrEqual?: number,
        licensedStatesIdLessThanOrEqual?: number,
        licensedStatesIdEquals?: number,
        licensedStatesIdNotEquals?: number,
        licensedStatesIdSpecified?: boolean,
        licensedStatesIdIn?: Array<number>,
        licensedStatesIdNotIn?: Array<number>,
        workLocationsIdGreaterThan?: number,
        workLocationsIdLessThan?: number,
        workLocationsIdGreaterThanOrEqual?: number,
        workLocationsIdLessThanOrEqual?: number,
        workLocationsIdEquals?: number,
        workLocationsIdNotEquals?: number,
        workLocationsIdSpecified?: boolean,
        workLocationsIdIn?: Array<number>,
        workLocationsIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        acceptedInsurancesIdGreaterThan?: number,
        acceptedInsurancesIdLessThan?: number,
        acceptedInsurancesIdGreaterThanOrEqual?: number,
        acceptedInsurancesIdLessThanOrEqual?: number,
        acceptedInsurancesIdEquals?: number,
        acceptedInsurancesIdNotEquals?: number,
        acceptedInsurancesIdSpecified?: boolean,
        acceptedInsurancesIdIn?: Array<number>,
        acceptedInsurancesIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        availabilityIdGreaterThan?: number,
        availabilityIdLessThan?: number,
        availabilityIdGreaterThanOrEqual?: number,
        availabilityIdLessThanOrEqual?: number,
        availabilityIdEquals?: number,
        availabilityIdNotEquals?: number,
        availabilityIdSpecified?: boolean,
        availabilityIdIn?: Array<number>,
        availabilityIdNotIn?: Array<number>,
        patientMedicationIdGreaterThan?: number,
        patientMedicationIdLessThan?: number,
        patientMedicationIdGreaterThanOrEqual?: number,
        patientMedicationIdLessThanOrEqual?: number,
        patientMedicationIdEquals?: number,
        patientMedicationIdNotEquals?: number,
        patientMedicationIdSpecified?: boolean,
        patientMedicationIdIn?: Array<number>,
        patientMedicationIdNotIn?: Array<number>,
        feeScheduleIdGreaterThan?: number,
        feeScheduleIdLessThan?: number,
        feeScheduleIdGreaterThanOrEqual?: number,
        feeScheduleIdLessThanOrEqual?: number,
        feeScheduleIdEquals?: number,
        feeScheduleIdNotEquals?: number,
        feeScheduleIdSpecified?: boolean,
        feeScheduleIdIn?: Array<number>,
        feeScheduleIdNotIn?: Array<number>,
        insuranceClaimIdGreaterThan?: number,
        insuranceClaimIdLessThan?: number,
        insuranceClaimIdGreaterThanOrEqual?: number,
        insuranceClaimIdLessThanOrEqual?: number,
        insuranceClaimIdEquals?: number,
        insuranceClaimIdNotEquals?: number,
        insuranceClaimIdSpecified?: boolean,
        insuranceClaimIdIn?: Array<number>,
        insuranceClaimIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<ProviderDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/providers',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'medicalCreds.contains': medicalCredsContains,
                'medicalCreds.doesNotContain': medicalCredsDoesNotContain,
                'medicalCreds.equals': medicalCredsEquals,
                'medicalCreds.notEquals': medicalCredsNotEquals,
                'medicalCreds.specified': medicalCredsSpecified,
                'medicalCreds.in': medicalCredsIn,
                'medicalCreds.notIn': medicalCredsNotIn,
                'gender.equals': genderEquals,
                'gender.notEquals': genderNotEquals,
                'gender.specified': genderSpecified,
                'gender.in': genderIn,
                'gender.notIn': genderNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'groupNpi.contains': groupNpiContains,
                'groupNpi.doesNotContain': groupNpiDoesNotContain,
                'groupNpi.equals': groupNpiEquals,
                'groupNpi.notEquals': groupNpiNotEquals,
                'groupNpi.specified': groupNpiSpecified,
                'groupNpi.in': groupNpiIn,
                'groupNpi.notIn': groupNpiNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'licenseNumber.contains': licenseNumberContains,
                'licenseNumber.doesNotContain': licenseNumberDoesNotContain,
                'licenseNumber.equals': licenseNumberEquals,
                'licenseNumber.notEquals': licenseNumberNotEquals,
                'licenseNumber.specified': licenseNumberSpecified,
                'licenseNumber.in': licenseNumberIn,
                'licenseNumber.notIn': licenseNumberNotIn,
                'experinceYears.contains': experinceYearsContains,
                'experinceYears.doesNotContain': experinceYearsDoesNotContain,
                'experinceYears.equals': experinceYearsEquals,
                'experinceYears.notEquals': experinceYearsNotEquals,
                'experinceYears.specified': experinceYearsSpecified,
                'experinceYears.in': experinceYearsIn,
                'experinceYears.notIn': experinceYearsNotIn,
                'taxonomyNumber.contains': taxonomyNumberContains,
                'taxonomyNumber.doesNotContain': taxonomyNumberDoesNotContain,
                'taxonomyNumber.equals': taxonomyNumberEquals,
                'taxonomyNumber.notEquals': taxonomyNumberNotEquals,
                'taxonomyNumber.specified': taxonomyNumberSpecified,
                'taxonomyNumber.in': taxonomyNumberIn,
                'taxonomyNumber.notIn': taxonomyNumberNotIn,
                'focusedArea.contains': focusedAreaContains,
                'focusedArea.doesNotContain': focusedAreaDoesNotContain,
                'focusedArea.equals': focusedAreaEquals,
                'focusedArea.notEquals': focusedAreaNotEquals,
                'focusedArea.specified': focusedAreaSpecified,
                'focusedArea.in': focusedAreaIn,
                'focusedArea.notIn': focusedAreaNotIn,
                'hospitalAffilation.contains': hospitalAffilationContains,
                'hospitalAffilation.doesNotContain': hospitalAffilationDoesNotContain,
                'hospitalAffilation.equals': hospitalAffilationEquals,
                'hospitalAffilation.notEquals': hospitalAffilationNotEquals,
                'hospitalAffilation.specified': hospitalAffilationSpecified,
                'hospitalAffilation.in': hospitalAffilationIn,
                'hospitalAffilation.notIn': hospitalAffilationNotIn,
                'ageGroupSeen.contains': ageGroupSeenContains,
                'ageGroupSeen.doesNotContain': ageGroupSeenDoesNotContain,
                'ageGroupSeen.equals': ageGroupSeenEquals,
                'ageGroupSeen.notEquals': ageGroupSeenNotEquals,
                'ageGroupSeen.specified': ageGroupSeenSpecified,
                'ageGroupSeen.in': ageGroupSeenIn,
                'ageGroupSeen.notIn': ageGroupSeenNotIn,
                'languagesSpoken.equals': languagesSpokenEquals,
                'languagesSpoken.notEquals': languagesSpokenNotEquals,
                'languagesSpoken.specified': languagesSpokenSpecified,
                'languagesSpoken.in': languagesSpokenIn,
                'languagesSpoken.notIn': languagesSpokenNotIn,
                'priorAuthorisation.contains': priorAuthorisationContains,
                'priorAuthorisation.doesNotContain': priorAuthorisationDoesNotContain,
                'priorAuthorisation.equals': priorAuthorisationEquals,
                'priorAuthorisation.notEquals': priorAuthorisationNotEquals,
                'priorAuthorisation.specified': priorAuthorisationSpecified,
                'priorAuthorisation.in': priorAuthorisationIn,
                'priorAuthorisation.notIn': priorAuthorisationNotIn,
                'secondOpinion.contains': secondOpinionContains,
                'secondOpinion.doesNotContain': secondOpinionDoesNotContain,
                'secondOpinion.equals': secondOpinionEquals,
                'secondOpinion.notEquals': secondOpinionNotEquals,
                'secondOpinion.specified': secondOpinionSpecified,
                'secondOpinion.in': secondOpinionIn,
                'secondOpinion.notIn': secondOpinionNotIn,
                'acuteSpeciality.contains': acuteSpecialityContains,
                'acuteSpeciality.doesNotContain': acuteSpecialityDoesNotContain,
                'acuteSpeciality.equals': acuteSpecialityEquals,
                'acuteSpeciality.notEquals': acuteSpecialityNotEquals,
                'acuteSpeciality.specified': acuteSpecialitySpecified,
                'acuteSpeciality.in': acuteSpecialityIn,
                'acuteSpeciality.notIn': acuteSpecialityNotIn,
                'bio.contains': bioContains,
                'bio.doesNotContain': bioDoesNotContain,
                'bio.equals': bioEquals,
                'bio.notEquals': bioNotEquals,
                'bio.specified': bioSpecified,
                'bio.in': bioIn,
                'bio.notIn': bioNotIn,
                'expertise.contains': expertiseContains,
                'expertise.doesNotContain': expertiseDoesNotContain,
                'expertise.equals': expertiseEquals,
                'expertise.notEquals': expertiseNotEquals,
                'expertise.specified': expertiseSpecified,
                'expertise.in': expertiseIn,
                'expertise.notIn': expertiseNotIn,
                'experience.contains': experienceContains,
                'experience.doesNotContain': experienceDoesNotContain,
                'experience.equals': experienceEquals,
                'experience.notEquals': experienceNotEquals,
                'experience.specified': experienceSpecified,
                'experience.in': experienceIn,
                'experience.notIn': experienceNotIn,
                'employmentRefNumber.contains': employmentRefNumberContains,
                'employmentRefNumber.doesNotContain': employmentRefNumberDoesNotContain,
                'employmentRefNumber.equals': employmentRefNumberEquals,
                'employmentRefNumber.notEquals': employmentRefNumberNotEquals,
                'employmentRefNumber.specified': employmentRefNumberSpecified,
                'employmentRefNumber.in': employmentRefNumberIn,
                'employmentRefNumber.notIn': employmentRefNumberNotIn,
                'acceptNewPatient.equals': acceptNewPatientEquals,
                'acceptNewPatient.notEquals': acceptNewPatientNotEquals,
                'acceptNewPatient.specified': acceptNewPatientSpecified,
                'acceptNewPatient.in': acceptNewPatientIn,
                'acceptNewPatient.notIn': acceptNewPatientNotIn,
                'acceptCashPay.equals': acceptCashPayEquals,
                'acceptCashPay.notEquals': acceptCashPayNotEquals,
                'acceptCashPay.specified': acceptCashPaySpecified,
                'acceptCashPay.in': acceptCashPayIn,
                'acceptCashPay.notIn': acceptCashPayNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'licensedStatesId.greaterThan': licensedStatesIdGreaterThan,
                'licensedStatesId.lessThan': licensedStatesIdLessThan,
                'licensedStatesId.greaterThanOrEqual': licensedStatesIdGreaterThanOrEqual,
                'licensedStatesId.lessThanOrEqual': licensedStatesIdLessThanOrEqual,
                'licensedStatesId.equals': licensedStatesIdEquals,
                'licensedStatesId.notEquals': licensedStatesIdNotEquals,
                'licensedStatesId.specified': licensedStatesIdSpecified,
                'licensedStatesId.in': licensedStatesIdIn,
                'licensedStatesId.notIn': licensedStatesIdNotIn,
                'workLocationsId.greaterThan': workLocationsIdGreaterThan,
                'workLocationsId.lessThan': workLocationsIdLessThan,
                'workLocationsId.greaterThanOrEqual': workLocationsIdGreaterThanOrEqual,
                'workLocationsId.lessThanOrEqual': workLocationsIdLessThanOrEqual,
                'workLocationsId.equals': workLocationsIdEquals,
                'workLocationsId.notEquals': workLocationsIdNotEquals,
                'workLocationsId.specified': workLocationsIdSpecified,
                'workLocationsId.in': workLocationsIdIn,
                'workLocationsId.notIn': workLocationsIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'acceptedInsurancesId.greaterThan': acceptedInsurancesIdGreaterThan,
                'acceptedInsurancesId.lessThan': acceptedInsurancesIdLessThan,
                'acceptedInsurancesId.greaterThanOrEqual': acceptedInsurancesIdGreaterThanOrEqual,
                'acceptedInsurancesId.lessThanOrEqual': acceptedInsurancesIdLessThanOrEqual,
                'acceptedInsurancesId.equals': acceptedInsurancesIdEquals,
                'acceptedInsurancesId.notEquals': acceptedInsurancesIdNotEquals,
                'acceptedInsurancesId.specified': acceptedInsurancesIdSpecified,
                'acceptedInsurancesId.in': acceptedInsurancesIdIn,
                'acceptedInsurancesId.notIn': acceptedInsurancesIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'availabilityId.greaterThan': availabilityIdGreaterThan,
                'availabilityId.lessThan': availabilityIdLessThan,
                'availabilityId.greaterThanOrEqual': availabilityIdGreaterThanOrEqual,
                'availabilityId.lessThanOrEqual': availabilityIdLessThanOrEqual,
                'availabilityId.equals': availabilityIdEquals,
                'availabilityId.notEquals': availabilityIdNotEquals,
                'availabilityId.specified': availabilityIdSpecified,
                'availabilityId.in': availabilityIdIn,
                'availabilityId.notIn': availabilityIdNotIn,
                'patientMedicationId.greaterThan': patientMedicationIdGreaterThan,
                'patientMedicationId.lessThan': patientMedicationIdLessThan,
                'patientMedicationId.greaterThanOrEqual': patientMedicationIdGreaterThanOrEqual,
                'patientMedicationId.lessThanOrEqual': patientMedicationIdLessThanOrEqual,
                'patientMedicationId.equals': patientMedicationIdEquals,
                'patientMedicationId.notEquals': patientMedicationIdNotEquals,
                'patientMedicationId.specified': patientMedicationIdSpecified,
                'patientMedicationId.in': patientMedicationIdIn,
                'patientMedicationId.notIn': patientMedicationIdNotIn,
                'feeScheduleId.greaterThan': feeScheduleIdGreaterThan,
                'feeScheduleId.lessThan': feeScheduleIdLessThan,
                'feeScheduleId.greaterThanOrEqual': feeScheduleIdGreaterThanOrEqual,
                'feeScheduleId.lessThanOrEqual': feeScheduleIdLessThanOrEqual,
                'feeScheduleId.equals': feeScheduleIdEquals,
                'feeScheduleId.notEquals': feeScheduleIdNotEquals,
                'feeScheduleId.specified': feeScheduleIdSpecified,
                'feeScheduleId.in': feeScheduleIdIn,
                'feeScheduleId.notIn': feeScheduleIdNotIn,
                'insuranceClaimId.greaterThan': insuranceClaimIdGreaterThan,
                'insuranceClaimId.lessThan': insuranceClaimIdLessThan,
                'insuranceClaimId.greaterThanOrEqual': insuranceClaimIdGreaterThanOrEqual,
                'insuranceClaimId.lessThanOrEqual': insuranceClaimIdLessThanOrEqual,
                'insuranceClaimId.equals': insuranceClaimIdEquals,
                'insuranceClaimId.notEquals': insuranceClaimIdNotEquals,
                'insuranceClaimId.specified': insuranceClaimIdSpecified,
                'insuranceClaimId.in': insuranceClaimIdIn,
                'insuranceClaimId.notIn': insuranceClaimIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static createProvider(
        requestBody: ProviderDTO,
    ): CancelablePromise<ProviderDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/providers',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param uuid
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static getProvider(
        uuid: string,
    ): CancelablePromise<ProviderDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/providers/{uuid}',
            path: {
                'uuid': uuid,
            },
        });
    }

    /**
     * @param uuid
     * @returns any OK
     * @throws ApiError
     */
    public static deleteProvider(
        uuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/providers/{uuid}',
            path: {
                'uuid': uuid,
            },
        });
    }

    /**
     * @param pageable
     * @returns PageSpecialityDTO OK
     * @throws ApiError
     */
    public static getSpecialityList(
        pageable: Pageable,
    ): CancelablePromise<PageSpecialityDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/providers/speciality',
            query: {
                'pageable': pageable,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param medicalCredsContains
     * @param medicalCredsDoesNotContain
     * @param medicalCredsEquals
     * @param medicalCredsNotEquals
     * @param medicalCredsSpecified
     * @param medicalCredsIn
     * @param medicalCredsNotIn
     * @param genderEquals
     * @param genderNotEquals
     * @param genderSpecified
     * @param genderIn
     * @param genderNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param groupNpiContains
     * @param groupNpiDoesNotContain
     * @param groupNpiEquals
     * @param groupNpiNotEquals
     * @param groupNpiSpecified
     * @param groupNpiIn
     * @param groupNpiNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param licenseNumberContains
     * @param licenseNumberDoesNotContain
     * @param licenseNumberEquals
     * @param licenseNumberNotEquals
     * @param licenseNumberSpecified
     * @param licenseNumberIn
     * @param licenseNumberNotIn
     * @param experinceYearsContains
     * @param experinceYearsDoesNotContain
     * @param experinceYearsEquals
     * @param experinceYearsNotEquals
     * @param experinceYearsSpecified
     * @param experinceYearsIn
     * @param experinceYearsNotIn
     * @param taxonomyNumberContains
     * @param taxonomyNumberDoesNotContain
     * @param taxonomyNumberEquals
     * @param taxonomyNumberNotEquals
     * @param taxonomyNumberSpecified
     * @param taxonomyNumberIn
     * @param taxonomyNumberNotIn
     * @param focusedAreaContains
     * @param focusedAreaDoesNotContain
     * @param focusedAreaEquals
     * @param focusedAreaNotEquals
     * @param focusedAreaSpecified
     * @param focusedAreaIn
     * @param focusedAreaNotIn
     * @param hospitalAffilationContains
     * @param hospitalAffilationDoesNotContain
     * @param hospitalAffilationEquals
     * @param hospitalAffilationNotEquals
     * @param hospitalAffilationSpecified
     * @param hospitalAffilationIn
     * @param hospitalAffilationNotIn
     * @param ageGroupSeenContains
     * @param ageGroupSeenDoesNotContain
     * @param ageGroupSeenEquals
     * @param ageGroupSeenNotEquals
     * @param ageGroupSeenSpecified
     * @param ageGroupSeenIn
     * @param ageGroupSeenNotIn
     * @param languagesSpokenEquals
     * @param languagesSpokenNotEquals
     * @param languagesSpokenSpecified
     * @param languagesSpokenIn
     * @param languagesSpokenNotIn
     * @param priorAuthorisationContains
     * @param priorAuthorisationDoesNotContain
     * @param priorAuthorisationEquals
     * @param priorAuthorisationNotEquals
     * @param priorAuthorisationSpecified
     * @param priorAuthorisationIn
     * @param priorAuthorisationNotIn
     * @param secondOpinionContains
     * @param secondOpinionDoesNotContain
     * @param secondOpinionEquals
     * @param secondOpinionNotEquals
     * @param secondOpinionSpecified
     * @param secondOpinionIn
     * @param secondOpinionNotIn
     * @param acuteSpecialityContains
     * @param acuteSpecialityDoesNotContain
     * @param acuteSpecialityEquals
     * @param acuteSpecialityNotEquals
     * @param acuteSpecialitySpecified
     * @param acuteSpecialityIn
     * @param acuteSpecialityNotIn
     * @param bioContains
     * @param bioDoesNotContain
     * @param bioEquals
     * @param bioNotEquals
     * @param bioSpecified
     * @param bioIn
     * @param bioNotIn
     * @param expertiseContains
     * @param expertiseDoesNotContain
     * @param expertiseEquals
     * @param expertiseNotEquals
     * @param expertiseSpecified
     * @param expertiseIn
     * @param expertiseNotIn
     * @param experienceContains
     * @param experienceDoesNotContain
     * @param experienceEquals
     * @param experienceNotEquals
     * @param experienceSpecified
     * @param experienceIn
     * @param experienceNotIn
     * @param employmentRefNumberContains
     * @param employmentRefNumberDoesNotContain
     * @param employmentRefNumberEquals
     * @param employmentRefNumberNotEquals
     * @param employmentRefNumberSpecified
     * @param employmentRefNumberIn
     * @param employmentRefNumberNotIn
     * @param acceptNewPatientEquals
     * @param acceptNewPatientNotEquals
     * @param acceptNewPatientSpecified
     * @param acceptNewPatientIn
     * @param acceptNewPatientNotIn
     * @param acceptCashPayEquals
     * @param acceptCashPayNotEquals
     * @param acceptCashPaySpecified
     * @param acceptCashPayIn
     * @param acceptCashPayNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param licensedStatesIdGreaterThan
     * @param licensedStatesIdLessThan
     * @param licensedStatesIdGreaterThanOrEqual
     * @param licensedStatesIdLessThanOrEqual
     * @param licensedStatesIdEquals
     * @param licensedStatesIdNotEquals
     * @param licensedStatesIdSpecified
     * @param licensedStatesIdIn
     * @param licensedStatesIdNotIn
     * @param workLocationsIdGreaterThan
     * @param workLocationsIdLessThan
     * @param workLocationsIdGreaterThanOrEqual
     * @param workLocationsIdLessThanOrEqual
     * @param workLocationsIdEquals
     * @param workLocationsIdNotEquals
     * @param workLocationsIdSpecified
     * @param workLocationsIdIn
     * @param workLocationsIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param acceptedInsurancesIdGreaterThan
     * @param acceptedInsurancesIdLessThan
     * @param acceptedInsurancesIdGreaterThanOrEqual
     * @param acceptedInsurancesIdLessThanOrEqual
     * @param acceptedInsurancesIdEquals
     * @param acceptedInsurancesIdNotEquals
     * @param acceptedInsurancesIdSpecified
     * @param acceptedInsurancesIdIn
     * @param acceptedInsurancesIdNotIn
     * @param encounterIdGreaterThan
     * @param encounterIdLessThan
     * @param encounterIdGreaterThanOrEqual
     * @param encounterIdLessThanOrEqual
     * @param encounterIdEquals
     * @param encounterIdNotEquals
     * @param encounterIdSpecified
     * @param encounterIdIn
     * @param encounterIdNotIn
     * @param appointmentIdGreaterThan
     * @param appointmentIdLessThan
     * @param appointmentIdGreaterThanOrEqual
     * @param appointmentIdLessThanOrEqual
     * @param appointmentIdEquals
     * @param appointmentIdNotEquals
     * @param appointmentIdSpecified
     * @param appointmentIdIn
     * @param appointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param availabilityIdGreaterThan
     * @param availabilityIdLessThan
     * @param availabilityIdGreaterThanOrEqual
     * @param availabilityIdLessThanOrEqual
     * @param availabilityIdEquals
     * @param availabilityIdNotEquals
     * @param availabilityIdSpecified
     * @param availabilityIdIn
     * @param availabilityIdNotIn
     * @param patientMedicationIdGreaterThan
     * @param patientMedicationIdLessThan
     * @param patientMedicationIdGreaterThanOrEqual
     * @param patientMedicationIdLessThanOrEqual
     * @param patientMedicationIdEquals
     * @param patientMedicationIdNotEquals
     * @param patientMedicationIdSpecified
     * @param patientMedicationIdIn
     * @param patientMedicationIdNotIn
     * @param feeScheduleIdGreaterThan
     * @param feeScheduleIdLessThan
     * @param feeScheduleIdGreaterThanOrEqual
     * @param feeScheduleIdLessThanOrEqual
     * @param feeScheduleIdEquals
     * @param feeScheduleIdNotEquals
     * @param feeScheduleIdSpecified
     * @param feeScheduleIdIn
     * @param feeScheduleIdNotIn
     * @param insuranceClaimIdGreaterThan
     * @param insuranceClaimIdLessThan
     * @param insuranceClaimIdGreaterThanOrEqual
     * @param insuranceClaimIdLessThanOrEqual
     * @param insuranceClaimIdEquals
     * @param insuranceClaimIdNotEquals
     * @param insuranceClaimIdSpecified
     * @param insuranceClaimIdIn
     * @param insuranceClaimIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countProviders(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        typeEquals?: 'MD' | 'PSYD' | 'LCSW',
        typeNotEquals?: 'MD' | 'PSYD' | 'LCSW',
        typeSpecified?: boolean,
        typeIn?: Array<'MD' | 'PSYD' | 'LCSW'>,
        typeNotIn?: Array<'MD' | 'PSYD' | 'LCSW'>,
        medicalCredsContains?: string,
        medicalCredsDoesNotContain?: string,
        medicalCredsEquals?: string,
        medicalCredsNotEquals?: string,
        medicalCredsSpecified?: boolean,
        medicalCredsIn?: Array<string>,
        medicalCredsNotIn?: Array<string>,
        genderEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderNotEquals?: 'MALE' | 'FEMALE' | 'OTHER',
        genderSpecified?: boolean,
        genderIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        genderNotIn?: Array<'MALE' | 'FEMALE' | 'OTHER'>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        groupNpiContains?: string,
        groupNpiDoesNotContain?: string,
        groupNpiEquals?: string,
        groupNpiNotEquals?: string,
        groupNpiSpecified?: boolean,
        groupNpiIn?: Array<string>,
        groupNpiNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        licenseNumberContains?: string,
        licenseNumberDoesNotContain?: string,
        licenseNumberEquals?: string,
        licenseNumberNotEquals?: string,
        licenseNumberSpecified?: boolean,
        licenseNumberIn?: Array<string>,
        licenseNumberNotIn?: Array<string>,
        experinceYearsContains?: string,
        experinceYearsDoesNotContain?: string,
        experinceYearsEquals?: string,
        experinceYearsNotEquals?: string,
        experinceYearsSpecified?: boolean,
        experinceYearsIn?: Array<string>,
        experinceYearsNotIn?: Array<string>,
        taxonomyNumberContains?: string,
        taxonomyNumberDoesNotContain?: string,
        taxonomyNumberEquals?: string,
        taxonomyNumberNotEquals?: string,
        taxonomyNumberSpecified?: boolean,
        taxonomyNumberIn?: Array<string>,
        taxonomyNumberNotIn?: Array<string>,
        focusedAreaContains?: string,
        focusedAreaDoesNotContain?: string,
        focusedAreaEquals?: string,
        focusedAreaNotEquals?: string,
        focusedAreaSpecified?: boolean,
        focusedAreaIn?: Array<string>,
        focusedAreaNotIn?: Array<string>,
        hospitalAffilationContains?: string,
        hospitalAffilationDoesNotContain?: string,
        hospitalAffilationEquals?: string,
        hospitalAffilationNotEquals?: string,
        hospitalAffilationSpecified?: boolean,
        hospitalAffilationIn?: Array<string>,
        hospitalAffilationNotIn?: Array<string>,
        ageGroupSeenContains?: string,
        ageGroupSeenDoesNotContain?: string,
        ageGroupSeenEquals?: string,
        ageGroupSeenNotEquals?: string,
        ageGroupSeenSpecified?: boolean,
        ageGroupSeenIn?: Array<string>,
        ageGroupSeenNotIn?: Array<string>,
        languagesSpokenEquals?: 'ENGLISH' | 'SPANISH' | 'OTHER',
        languagesSpokenNotEquals?: 'ENGLISH' | 'SPANISH' | 'OTHER',
        languagesSpokenSpecified?: boolean,
        languagesSpokenIn?: Array<'ENGLISH' | 'SPANISH' | 'OTHER'>,
        languagesSpokenNotIn?: Array<'ENGLISH' | 'SPANISH' | 'OTHER'>,
        priorAuthorisationContains?: string,
        priorAuthorisationDoesNotContain?: string,
        priorAuthorisationEquals?: string,
        priorAuthorisationNotEquals?: string,
        priorAuthorisationSpecified?: boolean,
        priorAuthorisationIn?: Array<string>,
        priorAuthorisationNotIn?: Array<string>,
        secondOpinionContains?: string,
        secondOpinionDoesNotContain?: string,
        secondOpinionEquals?: string,
        secondOpinionNotEquals?: string,
        secondOpinionSpecified?: boolean,
        secondOpinionIn?: Array<string>,
        secondOpinionNotIn?: Array<string>,
        acuteSpecialityContains?: string,
        acuteSpecialityDoesNotContain?: string,
        acuteSpecialityEquals?: string,
        acuteSpecialityNotEquals?: string,
        acuteSpecialitySpecified?: boolean,
        acuteSpecialityIn?: Array<string>,
        acuteSpecialityNotIn?: Array<string>,
        bioContains?: string,
        bioDoesNotContain?: string,
        bioEquals?: string,
        bioNotEquals?: string,
        bioSpecified?: boolean,
        bioIn?: Array<string>,
        bioNotIn?: Array<string>,
        expertiseContains?: string,
        expertiseDoesNotContain?: string,
        expertiseEquals?: string,
        expertiseNotEquals?: string,
        expertiseSpecified?: boolean,
        expertiseIn?: Array<string>,
        expertiseNotIn?: Array<string>,
        experienceContains?: string,
        experienceDoesNotContain?: string,
        experienceEquals?: string,
        experienceNotEquals?: string,
        experienceSpecified?: boolean,
        experienceIn?: Array<string>,
        experienceNotIn?: Array<string>,
        employmentRefNumberContains?: string,
        employmentRefNumberDoesNotContain?: string,
        employmentRefNumberEquals?: string,
        employmentRefNumberNotEquals?: string,
        employmentRefNumberSpecified?: boolean,
        employmentRefNumberIn?: Array<string>,
        employmentRefNumberNotIn?: Array<string>,
        acceptNewPatientEquals?: boolean,
        acceptNewPatientNotEquals?: boolean,
        acceptNewPatientSpecified?: boolean,
        acceptNewPatientIn?: Array<boolean>,
        acceptNewPatientNotIn?: Array<boolean>,
        acceptCashPayEquals?: boolean,
        acceptCashPayNotEquals?: boolean,
        acceptCashPaySpecified?: boolean,
        acceptCashPayIn?: Array<boolean>,
        acceptCashPayNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        licensedStatesIdGreaterThan?: number,
        licensedStatesIdLessThan?: number,
        licensedStatesIdGreaterThanOrEqual?: number,
        licensedStatesIdLessThanOrEqual?: number,
        licensedStatesIdEquals?: number,
        licensedStatesIdNotEquals?: number,
        licensedStatesIdSpecified?: boolean,
        licensedStatesIdIn?: Array<number>,
        licensedStatesIdNotIn?: Array<number>,
        workLocationsIdGreaterThan?: number,
        workLocationsIdLessThan?: number,
        workLocationsIdGreaterThanOrEqual?: number,
        workLocationsIdLessThanOrEqual?: number,
        workLocationsIdEquals?: number,
        workLocationsIdNotEquals?: number,
        workLocationsIdSpecified?: boolean,
        workLocationsIdIn?: Array<number>,
        workLocationsIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        acceptedInsurancesIdGreaterThan?: number,
        acceptedInsurancesIdLessThan?: number,
        acceptedInsurancesIdGreaterThanOrEqual?: number,
        acceptedInsurancesIdLessThanOrEqual?: number,
        acceptedInsurancesIdEquals?: number,
        acceptedInsurancesIdNotEquals?: number,
        acceptedInsurancesIdSpecified?: boolean,
        acceptedInsurancesIdIn?: Array<number>,
        acceptedInsurancesIdNotIn?: Array<number>,
        encounterIdGreaterThan?: number,
        encounterIdLessThan?: number,
        encounterIdGreaterThanOrEqual?: number,
        encounterIdLessThanOrEqual?: number,
        encounterIdEquals?: number,
        encounterIdNotEquals?: number,
        encounterIdSpecified?: boolean,
        encounterIdIn?: Array<number>,
        encounterIdNotIn?: Array<number>,
        appointmentIdGreaterThan?: number,
        appointmentIdLessThan?: number,
        appointmentIdGreaterThanOrEqual?: number,
        appointmentIdLessThanOrEqual?: number,
        appointmentIdEquals?: number,
        appointmentIdNotEquals?: number,
        appointmentIdSpecified?: boolean,
        appointmentIdIn?: Array<number>,
        appointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        availabilityIdGreaterThan?: number,
        availabilityIdLessThan?: number,
        availabilityIdGreaterThanOrEqual?: number,
        availabilityIdLessThanOrEqual?: number,
        availabilityIdEquals?: number,
        availabilityIdNotEquals?: number,
        availabilityIdSpecified?: boolean,
        availabilityIdIn?: Array<number>,
        availabilityIdNotIn?: Array<number>,
        patientMedicationIdGreaterThan?: number,
        patientMedicationIdLessThan?: number,
        patientMedicationIdGreaterThanOrEqual?: number,
        patientMedicationIdLessThanOrEqual?: number,
        patientMedicationIdEquals?: number,
        patientMedicationIdNotEquals?: number,
        patientMedicationIdSpecified?: boolean,
        patientMedicationIdIn?: Array<number>,
        patientMedicationIdNotIn?: Array<number>,
        feeScheduleIdGreaterThan?: number,
        feeScheduleIdLessThan?: number,
        feeScheduleIdGreaterThanOrEqual?: number,
        feeScheduleIdLessThanOrEqual?: number,
        feeScheduleIdEquals?: number,
        feeScheduleIdNotEquals?: number,
        feeScheduleIdSpecified?: boolean,
        feeScheduleIdIn?: Array<number>,
        feeScheduleIdNotIn?: Array<number>,
        insuranceClaimIdGreaterThan?: number,
        insuranceClaimIdLessThan?: number,
        insuranceClaimIdGreaterThanOrEqual?: number,
        insuranceClaimIdLessThanOrEqual?: number,
        insuranceClaimIdEquals?: number,
        insuranceClaimIdNotEquals?: number,
        insuranceClaimIdSpecified?: boolean,
        insuranceClaimIdIn?: Array<number>,
        insuranceClaimIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/providers/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'medicalCreds.contains': medicalCredsContains,
                'medicalCreds.doesNotContain': medicalCredsDoesNotContain,
                'medicalCreds.equals': medicalCredsEquals,
                'medicalCreds.notEquals': medicalCredsNotEquals,
                'medicalCreds.specified': medicalCredsSpecified,
                'medicalCreds.in': medicalCredsIn,
                'medicalCreds.notIn': medicalCredsNotIn,
                'gender.equals': genderEquals,
                'gender.notEquals': genderNotEquals,
                'gender.specified': genderSpecified,
                'gender.in': genderIn,
                'gender.notIn': genderNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'groupNpi.contains': groupNpiContains,
                'groupNpi.doesNotContain': groupNpiDoesNotContain,
                'groupNpi.equals': groupNpiEquals,
                'groupNpi.notEquals': groupNpiNotEquals,
                'groupNpi.specified': groupNpiSpecified,
                'groupNpi.in': groupNpiIn,
                'groupNpi.notIn': groupNpiNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'licenseNumber.contains': licenseNumberContains,
                'licenseNumber.doesNotContain': licenseNumberDoesNotContain,
                'licenseNumber.equals': licenseNumberEquals,
                'licenseNumber.notEquals': licenseNumberNotEquals,
                'licenseNumber.specified': licenseNumberSpecified,
                'licenseNumber.in': licenseNumberIn,
                'licenseNumber.notIn': licenseNumberNotIn,
                'experinceYears.contains': experinceYearsContains,
                'experinceYears.doesNotContain': experinceYearsDoesNotContain,
                'experinceYears.equals': experinceYearsEquals,
                'experinceYears.notEquals': experinceYearsNotEquals,
                'experinceYears.specified': experinceYearsSpecified,
                'experinceYears.in': experinceYearsIn,
                'experinceYears.notIn': experinceYearsNotIn,
                'taxonomyNumber.contains': taxonomyNumberContains,
                'taxonomyNumber.doesNotContain': taxonomyNumberDoesNotContain,
                'taxonomyNumber.equals': taxonomyNumberEquals,
                'taxonomyNumber.notEquals': taxonomyNumberNotEquals,
                'taxonomyNumber.specified': taxonomyNumberSpecified,
                'taxonomyNumber.in': taxonomyNumberIn,
                'taxonomyNumber.notIn': taxonomyNumberNotIn,
                'focusedArea.contains': focusedAreaContains,
                'focusedArea.doesNotContain': focusedAreaDoesNotContain,
                'focusedArea.equals': focusedAreaEquals,
                'focusedArea.notEquals': focusedAreaNotEquals,
                'focusedArea.specified': focusedAreaSpecified,
                'focusedArea.in': focusedAreaIn,
                'focusedArea.notIn': focusedAreaNotIn,
                'hospitalAffilation.contains': hospitalAffilationContains,
                'hospitalAffilation.doesNotContain': hospitalAffilationDoesNotContain,
                'hospitalAffilation.equals': hospitalAffilationEquals,
                'hospitalAffilation.notEquals': hospitalAffilationNotEquals,
                'hospitalAffilation.specified': hospitalAffilationSpecified,
                'hospitalAffilation.in': hospitalAffilationIn,
                'hospitalAffilation.notIn': hospitalAffilationNotIn,
                'ageGroupSeen.contains': ageGroupSeenContains,
                'ageGroupSeen.doesNotContain': ageGroupSeenDoesNotContain,
                'ageGroupSeen.equals': ageGroupSeenEquals,
                'ageGroupSeen.notEquals': ageGroupSeenNotEquals,
                'ageGroupSeen.specified': ageGroupSeenSpecified,
                'ageGroupSeen.in': ageGroupSeenIn,
                'ageGroupSeen.notIn': ageGroupSeenNotIn,
                'languagesSpoken.equals': languagesSpokenEquals,
                'languagesSpoken.notEquals': languagesSpokenNotEquals,
                'languagesSpoken.specified': languagesSpokenSpecified,
                'languagesSpoken.in': languagesSpokenIn,
                'languagesSpoken.notIn': languagesSpokenNotIn,
                'priorAuthorisation.contains': priorAuthorisationContains,
                'priorAuthorisation.doesNotContain': priorAuthorisationDoesNotContain,
                'priorAuthorisation.equals': priorAuthorisationEquals,
                'priorAuthorisation.notEquals': priorAuthorisationNotEquals,
                'priorAuthorisation.specified': priorAuthorisationSpecified,
                'priorAuthorisation.in': priorAuthorisationIn,
                'priorAuthorisation.notIn': priorAuthorisationNotIn,
                'secondOpinion.contains': secondOpinionContains,
                'secondOpinion.doesNotContain': secondOpinionDoesNotContain,
                'secondOpinion.equals': secondOpinionEquals,
                'secondOpinion.notEquals': secondOpinionNotEquals,
                'secondOpinion.specified': secondOpinionSpecified,
                'secondOpinion.in': secondOpinionIn,
                'secondOpinion.notIn': secondOpinionNotIn,
                'acuteSpeciality.contains': acuteSpecialityContains,
                'acuteSpeciality.doesNotContain': acuteSpecialityDoesNotContain,
                'acuteSpeciality.equals': acuteSpecialityEquals,
                'acuteSpeciality.notEquals': acuteSpecialityNotEquals,
                'acuteSpeciality.specified': acuteSpecialitySpecified,
                'acuteSpeciality.in': acuteSpecialityIn,
                'acuteSpeciality.notIn': acuteSpecialityNotIn,
                'bio.contains': bioContains,
                'bio.doesNotContain': bioDoesNotContain,
                'bio.equals': bioEquals,
                'bio.notEquals': bioNotEquals,
                'bio.specified': bioSpecified,
                'bio.in': bioIn,
                'bio.notIn': bioNotIn,
                'expertise.contains': expertiseContains,
                'expertise.doesNotContain': expertiseDoesNotContain,
                'expertise.equals': expertiseEquals,
                'expertise.notEquals': expertiseNotEquals,
                'expertise.specified': expertiseSpecified,
                'expertise.in': expertiseIn,
                'expertise.notIn': expertiseNotIn,
                'experience.contains': experienceContains,
                'experience.doesNotContain': experienceDoesNotContain,
                'experience.equals': experienceEquals,
                'experience.notEquals': experienceNotEquals,
                'experience.specified': experienceSpecified,
                'experience.in': experienceIn,
                'experience.notIn': experienceNotIn,
                'employmentRefNumber.contains': employmentRefNumberContains,
                'employmentRefNumber.doesNotContain': employmentRefNumberDoesNotContain,
                'employmentRefNumber.equals': employmentRefNumberEquals,
                'employmentRefNumber.notEquals': employmentRefNumberNotEquals,
                'employmentRefNumber.specified': employmentRefNumberSpecified,
                'employmentRefNumber.in': employmentRefNumberIn,
                'employmentRefNumber.notIn': employmentRefNumberNotIn,
                'acceptNewPatient.equals': acceptNewPatientEquals,
                'acceptNewPatient.notEquals': acceptNewPatientNotEquals,
                'acceptNewPatient.specified': acceptNewPatientSpecified,
                'acceptNewPatient.in': acceptNewPatientIn,
                'acceptNewPatient.notIn': acceptNewPatientNotIn,
                'acceptCashPay.equals': acceptCashPayEquals,
                'acceptCashPay.notEquals': acceptCashPayNotEquals,
                'acceptCashPay.specified': acceptCashPaySpecified,
                'acceptCashPay.in': acceptCashPayIn,
                'acceptCashPay.notIn': acceptCashPayNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'licensedStatesId.greaterThan': licensedStatesIdGreaterThan,
                'licensedStatesId.lessThan': licensedStatesIdLessThan,
                'licensedStatesId.greaterThanOrEqual': licensedStatesIdGreaterThanOrEqual,
                'licensedStatesId.lessThanOrEqual': licensedStatesIdLessThanOrEqual,
                'licensedStatesId.equals': licensedStatesIdEquals,
                'licensedStatesId.notEquals': licensedStatesIdNotEquals,
                'licensedStatesId.specified': licensedStatesIdSpecified,
                'licensedStatesId.in': licensedStatesIdIn,
                'licensedStatesId.notIn': licensedStatesIdNotIn,
                'workLocationsId.greaterThan': workLocationsIdGreaterThan,
                'workLocationsId.lessThan': workLocationsIdLessThan,
                'workLocationsId.greaterThanOrEqual': workLocationsIdGreaterThanOrEqual,
                'workLocationsId.lessThanOrEqual': workLocationsIdLessThanOrEqual,
                'workLocationsId.equals': workLocationsIdEquals,
                'workLocationsId.notEquals': workLocationsIdNotEquals,
                'workLocationsId.specified': workLocationsIdSpecified,
                'workLocationsId.in': workLocationsIdIn,
                'workLocationsId.notIn': workLocationsIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'acceptedInsurancesId.greaterThan': acceptedInsurancesIdGreaterThan,
                'acceptedInsurancesId.lessThan': acceptedInsurancesIdLessThan,
                'acceptedInsurancesId.greaterThanOrEqual': acceptedInsurancesIdGreaterThanOrEqual,
                'acceptedInsurancesId.lessThanOrEqual': acceptedInsurancesIdLessThanOrEqual,
                'acceptedInsurancesId.equals': acceptedInsurancesIdEquals,
                'acceptedInsurancesId.notEquals': acceptedInsurancesIdNotEquals,
                'acceptedInsurancesId.specified': acceptedInsurancesIdSpecified,
                'acceptedInsurancesId.in': acceptedInsurancesIdIn,
                'acceptedInsurancesId.notIn': acceptedInsurancesIdNotIn,
                'encounterId.greaterThan': encounterIdGreaterThan,
                'encounterId.lessThan': encounterIdLessThan,
                'encounterId.greaterThanOrEqual': encounterIdGreaterThanOrEqual,
                'encounterId.lessThanOrEqual': encounterIdLessThanOrEqual,
                'encounterId.equals': encounterIdEquals,
                'encounterId.notEquals': encounterIdNotEquals,
                'encounterId.specified': encounterIdSpecified,
                'encounterId.in': encounterIdIn,
                'encounterId.notIn': encounterIdNotIn,
                'appointmentId.greaterThan': appointmentIdGreaterThan,
                'appointmentId.lessThan': appointmentIdLessThan,
                'appointmentId.greaterThanOrEqual': appointmentIdGreaterThanOrEqual,
                'appointmentId.lessThanOrEqual': appointmentIdLessThanOrEqual,
                'appointmentId.equals': appointmentIdEquals,
                'appointmentId.notEquals': appointmentIdNotEquals,
                'appointmentId.specified': appointmentIdSpecified,
                'appointmentId.in': appointmentIdIn,
                'appointmentId.notIn': appointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'availabilityId.greaterThan': availabilityIdGreaterThan,
                'availabilityId.lessThan': availabilityIdLessThan,
                'availabilityId.greaterThanOrEqual': availabilityIdGreaterThanOrEqual,
                'availabilityId.lessThanOrEqual': availabilityIdLessThanOrEqual,
                'availabilityId.equals': availabilityIdEquals,
                'availabilityId.notEquals': availabilityIdNotEquals,
                'availabilityId.specified': availabilityIdSpecified,
                'availabilityId.in': availabilityIdIn,
                'availabilityId.notIn': availabilityIdNotIn,
                'patientMedicationId.greaterThan': patientMedicationIdGreaterThan,
                'patientMedicationId.lessThan': patientMedicationIdLessThan,
                'patientMedicationId.greaterThanOrEqual': patientMedicationIdGreaterThanOrEqual,
                'patientMedicationId.lessThanOrEqual': patientMedicationIdLessThanOrEqual,
                'patientMedicationId.equals': patientMedicationIdEquals,
                'patientMedicationId.notEquals': patientMedicationIdNotEquals,
                'patientMedicationId.specified': patientMedicationIdSpecified,
                'patientMedicationId.in': patientMedicationIdIn,
                'patientMedicationId.notIn': patientMedicationIdNotIn,
                'feeScheduleId.greaterThan': feeScheduleIdGreaterThan,
                'feeScheduleId.lessThan': feeScheduleIdLessThan,
                'feeScheduleId.greaterThanOrEqual': feeScheduleIdGreaterThanOrEqual,
                'feeScheduleId.lessThanOrEqual': feeScheduleIdLessThanOrEqual,
                'feeScheduleId.equals': feeScheduleIdEquals,
                'feeScheduleId.notEquals': feeScheduleIdNotEquals,
                'feeScheduleId.specified': feeScheduleIdSpecified,
                'feeScheduleId.in': feeScheduleIdIn,
                'feeScheduleId.notIn': feeScheduleIdNotIn,
                'insuranceClaimId.greaterThan': insuranceClaimIdGreaterThan,
                'insuranceClaimId.lessThan': insuranceClaimIdLessThan,
                'insuranceClaimId.greaterThanOrEqual': insuranceClaimIdGreaterThanOrEqual,
                'insuranceClaimId.lessThanOrEqual': insuranceClaimIdLessThanOrEqual,
                'insuranceClaimId.equals': insuranceClaimIdEquals,
                'insuranceClaimId.notEquals': insuranceClaimIdNotEquals,
                'insuranceClaimId.specified': insuranceClaimIdSpecified,
                'insuranceClaimId.in': insuranceClaimIdIn,
                'insuranceClaimId.notIn': insuranceClaimIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
