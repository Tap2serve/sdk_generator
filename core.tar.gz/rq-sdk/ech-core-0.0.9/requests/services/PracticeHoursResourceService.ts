/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PracticeHoursDTO } from '../models/PracticeHoursDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PracticeHoursResourceService {

    /**
     * @param id
     * @returns PracticeHoursDTO OK
     * @throws ApiError
     */
    public static getPracticeHours(
        id: number,
    ): CancelablePromise<PracticeHoursDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/practice-hours/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PracticeHoursDTO OK
     * @throws ApiError
     */
    public static updatePracticeHours(
        id: number,
        requestBody: PracticeHoursDTO,
    ): CancelablePromise<PracticeHoursDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/practice-hours/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deletePracticeHours(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/practice-hours/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PracticeHoursDTO OK
     * @throws ApiError
     */
    public static partialUpdatePracticeHours(
        id: number,
        requestBody: PracticeHoursDTO,
    ): CancelablePromise<PracticeHoursDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/practice-hours/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param weekDayContains
     * @param weekDayDoesNotContain
     * @param weekDayEquals
     * @param weekDayNotEquals
     * @param weekDaySpecified
     * @param weekDayIn
     * @param weekDayNotIn
     * @param openingTimeContains
     * @param openingTimeDoesNotContain
     * @param openingTimeEquals
     * @param openingTimeNotEquals
     * @param openingTimeSpecified
     * @param openingTimeIn
     * @param openingTimeNotIn
     * @param closingTimeContains
     * @param closingTimeDoesNotContain
     * @param closingTimeEquals
     * @param closingTimeNotEquals
     * @param closingTimeSpecified
     * @param closingTimeIn
     * @param closingTimeNotIn
     * @param providerGroupIdGreaterThan
     * @param providerGroupIdLessThan
     * @param providerGroupIdGreaterThanOrEqual
     * @param providerGroupIdLessThanOrEqual
     * @param providerGroupIdEquals
     * @param providerGroupIdNotEquals
     * @param providerGroupIdSpecified
     * @param providerGroupIdIn
     * @param providerGroupIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PracticeHoursDTO OK
     * @throws ApiError
     */
    public static getAllPracticeHours(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        weekDayContains?: string,
        weekDayDoesNotContain?: string,
        weekDayEquals?: string,
        weekDayNotEquals?: string,
        weekDaySpecified?: boolean,
        weekDayIn?: Array<string>,
        weekDayNotIn?: Array<string>,
        openingTimeContains?: string,
        openingTimeDoesNotContain?: string,
        openingTimeEquals?: string,
        openingTimeNotEquals?: string,
        openingTimeSpecified?: boolean,
        openingTimeIn?: Array<string>,
        openingTimeNotIn?: Array<string>,
        closingTimeContains?: string,
        closingTimeDoesNotContain?: string,
        closingTimeEquals?: string,
        closingTimeNotEquals?: string,
        closingTimeSpecified?: boolean,
        closingTimeIn?: Array<string>,
        closingTimeNotIn?: Array<string>,
        providerGroupIdGreaterThan?: number,
        providerGroupIdLessThan?: number,
        providerGroupIdGreaterThanOrEqual?: number,
        providerGroupIdLessThanOrEqual?: number,
        providerGroupIdEquals?: number,
        providerGroupIdNotEquals?: number,
        providerGroupIdSpecified?: boolean,
        providerGroupIdIn?: Array<number>,
        providerGroupIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PracticeHoursDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/practice-hours',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'weekDay.contains': weekDayContains,
                'weekDay.doesNotContain': weekDayDoesNotContain,
                'weekDay.equals': weekDayEquals,
                'weekDay.notEquals': weekDayNotEquals,
                'weekDay.specified': weekDaySpecified,
                'weekDay.in': weekDayIn,
                'weekDay.notIn': weekDayNotIn,
                'openingTime.contains': openingTimeContains,
                'openingTime.doesNotContain': openingTimeDoesNotContain,
                'openingTime.equals': openingTimeEquals,
                'openingTime.notEquals': openingTimeNotEquals,
                'openingTime.specified': openingTimeSpecified,
                'openingTime.in': openingTimeIn,
                'openingTime.notIn': openingTimeNotIn,
                'closingTime.contains': closingTimeContains,
                'closingTime.doesNotContain': closingTimeDoesNotContain,
                'closingTime.equals': closingTimeEquals,
                'closingTime.notEquals': closingTimeNotEquals,
                'closingTime.specified': closingTimeSpecified,
                'closingTime.in': closingTimeIn,
                'closingTime.notIn': closingTimeNotIn,
                'providerGroupId.greaterThan': providerGroupIdGreaterThan,
                'providerGroupId.lessThan': providerGroupIdLessThan,
                'providerGroupId.greaterThanOrEqual': providerGroupIdGreaterThanOrEqual,
                'providerGroupId.lessThanOrEqual': providerGroupIdLessThanOrEqual,
                'providerGroupId.equals': providerGroupIdEquals,
                'providerGroupId.notEquals': providerGroupIdNotEquals,
                'providerGroupId.specified': providerGroupIdSpecified,
                'providerGroupId.in': providerGroupIdIn,
                'providerGroupId.notIn': providerGroupIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PracticeHoursDTO OK
     * @throws ApiError
     */
    public static createPracticeHours(
        requestBody: PracticeHoursDTO,
    ): CancelablePromise<PracticeHoursDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/practice-hours',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param weekDayContains
     * @param weekDayDoesNotContain
     * @param weekDayEquals
     * @param weekDayNotEquals
     * @param weekDaySpecified
     * @param weekDayIn
     * @param weekDayNotIn
     * @param openingTimeContains
     * @param openingTimeDoesNotContain
     * @param openingTimeEquals
     * @param openingTimeNotEquals
     * @param openingTimeSpecified
     * @param openingTimeIn
     * @param openingTimeNotIn
     * @param closingTimeContains
     * @param closingTimeDoesNotContain
     * @param closingTimeEquals
     * @param closingTimeNotEquals
     * @param closingTimeSpecified
     * @param closingTimeIn
     * @param closingTimeNotIn
     * @param providerGroupIdGreaterThan
     * @param providerGroupIdLessThan
     * @param providerGroupIdGreaterThanOrEqual
     * @param providerGroupIdLessThanOrEqual
     * @param providerGroupIdEquals
     * @param providerGroupIdNotEquals
     * @param providerGroupIdSpecified
     * @param providerGroupIdIn
     * @param providerGroupIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPracticeHours(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        weekDayContains?: string,
        weekDayDoesNotContain?: string,
        weekDayEquals?: string,
        weekDayNotEquals?: string,
        weekDaySpecified?: boolean,
        weekDayIn?: Array<string>,
        weekDayNotIn?: Array<string>,
        openingTimeContains?: string,
        openingTimeDoesNotContain?: string,
        openingTimeEquals?: string,
        openingTimeNotEquals?: string,
        openingTimeSpecified?: boolean,
        openingTimeIn?: Array<string>,
        openingTimeNotIn?: Array<string>,
        closingTimeContains?: string,
        closingTimeDoesNotContain?: string,
        closingTimeEquals?: string,
        closingTimeNotEquals?: string,
        closingTimeSpecified?: boolean,
        closingTimeIn?: Array<string>,
        closingTimeNotIn?: Array<string>,
        providerGroupIdGreaterThan?: number,
        providerGroupIdLessThan?: number,
        providerGroupIdGreaterThanOrEqual?: number,
        providerGroupIdLessThanOrEqual?: number,
        providerGroupIdEquals?: number,
        providerGroupIdNotEquals?: number,
        providerGroupIdSpecified?: boolean,
        providerGroupIdIn?: Array<number>,
        providerGroupIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/practice-hours/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'weekDay.contains': weekDayContains,
                'weekDay.doesNotContain': weekDayDoesNotContain,
                'weekDay.equals': weekDayEquals,
                'weekDay.notEquals': weekDayNotEquals,
                'weekDay.specified': weekDaySpecified,
                'weekDay.in': weekDayIn,
                'weekDay.notIn': weekDayNotIn,
                'openingTime.contains': openingTimeContains,
                'openingTime.doesNotContain': openingTimeDoesNotContain,
                'openingTime.equals': openingTimeEquals,
                'openingTime.notEquals': openingTimeNotEquals,
                'openingTime.specified': openingTimeSpecified,
                'openingTime.in': openingTimeIn,
                'openingTime.notIn': openingTimeNotIn,
                'closingTime.contains': closingTimeContains,
                'closingTime.doesNotContain': closingTimeDoesNotContain,
                'closingTime.equals': closingTimeEquals,
                'closingTime.notEquals': closingTimeNotEquals,
                'closingTime.specified': closingTimeSpecified,
                'closingTime.in': closingTimeIn,
                'closingTime.notIn': closingTimeNotIn,
                'providerGroupId.greaterThan': providerGroupIdGreaterThan,
                'providerGroupId.lessThan': providerGroupIdLessThan,
                'providerGroupId.greaterThanOrEqual': providerGroupIdGreaterThanOrEqual,
                'providerGroupId.lessThanOrEqual': providerGroupIdLessThanOrEqual,
                'providerGroupId.equals': providerGroupIdEquals,
                'providerGroupId.notEquals': providerGroupIdNotEquals,
                'providerGroupId.specified': providerGroupIdSpecified,
                'providerGroupId.in': providerGroupIdIn,
                'providerGroupId.notIn': providerGroupIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
