/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InsurancePayerDTO } from '../models/InsurancePayerDTO';
import type { Pageable } from '../models/Pageable';
import type { ProviderDTO } from '../models/ProviderDTO';
import type { ProviderGroupDTO } from '../models/ProviderGroupDTO';
import type { SpecialityDTO } from '../models/SpecialityDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ProviderGroupResourceService {

    /**
     * @param providerGroupUuid
     * @param requestBody
     * @returns any OK
     * @throws ApiError
     */
    public static updateProvider1(
        providerGroupUuid: string,
        requestBody: ProviderDTO,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/provider-groups/{providerGroupUuid}/provider',
            path: {
                'providerGroupUuid': providerGroupUuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param providerGroupUuid
     * @param requestBody
     * @returns any OK
     * @throws ApiError
     */
    public static createProvider1(
        providerGroupUuid: string,
        requestBody: ProviderDTO,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/provider-groups/{providerGroupUuid}/provider',
            path: {
                'providerGroupUuid': providerGroupUuid,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static getProviderGroup1(
        id: number,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns any OK
     * @throws ApiError
     */
    public static updateProviderGroup1(
        id: number,
        requestBody: ProviderGroupDTO,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/provider-groups/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param xTenantId
     * @param id
     * @param requestBody
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static partialUpdateProviderGroup(
        xTenantId: string,
        id: number,
        requestBody: ProviderGroupDTO,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/provider-groups/{id}',
            path: {
                'id': id,
            },
            headers: {
                'X-TENANT-ID': xTenantId,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static syncDatabaseSchema(
        id: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/provider-groups/provider-groups/{id}/sync',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param avatarContains
     * @param avatarDoesNotContain
     * @param avatarEquals
     * @param avatarNotEquals
     * @param avatarSpecified
     * @param avatarIn
     * @param avatarNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param phoneContains
     * @param phoneDoesNotContain
     * @param phoneEquals
     * @param phoneNotEquals
     * @param phoneSpecified
     * @param phoneIn
     * @param phoneNotIn
     * @param websiteContains
     * @param websiteDoesNotContain
     * @param websiteEquals
     * @param websiteNotEquals
     * @param websiteSpecified
     * @param websiteIn
     * @param websiteNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param schemaContains
     * @param schemaDoesNotContain
     * @param schemaEquals
     * @param schemaNotEquals
     * @param schemaSpecified
     * @param schemaIn
     * @param schemaNotIn
     * @param iamGroupContains
     * @param iamGroupDoesNotContain
     * @param iamGroupEquals
     * @param iamGroupNotEquals
     * @param iamGroupSpecified
     * @param iamGroupIn
     * @param iamGroupNotIn
     * @param subdomainContains
     * @param subdomainDoesNotContain
     * @param subdomainEquals
     * @param subdomainNotEquals
     * @param subdomainSpecified
     * @param subdomainIn
     * @param subdomainNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param providerCountGreaterThan
     * @param providerCountLessThan
     * @param providerCountGreaterThanOrEqual
     * @param providerCountLessThanOrEqual
     * @param providerCountEquals
     * @param providerCountNotEquals
     * @param providerCountSpecified
     * @param providerCountIn
     * @param providerCountNotIn
     * @param patientCountGreaterThan
     * @param patientCountLessThan
     * @param patientCountGreaterThanOrEqual
     * @param patientCountLessThanOrEqual
     * @param patientCountEquals
     * @param patientCountNotEquals
     * @param patientCountSpecified
     * @param patientCountIn
     * @param patientCountNotIn
     * @param appointmentCountGreaterThan
     * @param appointmentCountLessThan
     * @param appointmentCountGreaterThanOrEqual
     * @param appointmentCountLessThanOrEqual
     * @param appointmentCountEquals
     * @param appointmentCountNotEquals
     * @param appointmentCountSpecified
     * @param appointmentCountIn
     * @param appointmentCountNotIn
     * @param encounterCountGreaterThan
     * @param encounterCountLessThan
     * @param encounterCountGreaterThanOrEqual
     * @param encounterCountLessThanOrEqual
     * @param encounterCountEquals
     * @param encounterCountNotEquals
     * @param encounterCountSpecified
     * @param encounterCountIn
     * @param encounterCountNotIn
     * @param addressCheckBoxEquals
     * @param addressCheckBoxNotEquals
     * @param addressCheckBoxSpecified
     * @param addressCheckBoxIn
     * @param addressCheckBoxNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param physicalAddressIdIdGreaterThan
     * @param physicalAddressIdIdLessThan
     * @param physicalAddressIdIdGreaterThanOrEqual
     * @param physicalAddressIdIdLessThanOrEqual
     * @param physicalAddressIdIdEquals
     * @param physicalAddressIdIdNotEquals
     * @param physicalAddressIdIdSpecified
     * @param physicalAddressIdIdIn
     * @param physicalAddressIdIdNotIn
     * @param billingAddressIdIdGreaterThan
     * @param billingAddressIdIdLessThan
     * @param billingAddressIdIdGreaterThanOrEqual
     * @param billingAddressIdIdLessThanOrEqual
     * @param billingAddressIdIdEquals
     * @param billingAddressIdIdNotEquals
     * @param billingAddressIdIdSpecified
     * @param billingAddressIdIdIn
     * @param billingAddressIdIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param practiceHoursIdGreaterThan
     * @param practiceHoursIdLessThan
     * @param practiceHoursIdGreaterThanOrEqual
     * @param practiceHoursIdLessThanOrEqual
     * @param practiceHoursIdEquals
     * @param practiceHoursIdNotEquals
     * @param practiceHoursIdSpecified
     * @param practiceHoursIdIn
     * @param practiceHoursIdNotIn
     * @param dataImportIdGreaterThan
     * @param dataImportIdLessThan
     * @param dataImportIdGreaterThanOrEqual
     * @param dataImportIdLessThanOrEqual
     * @param dataImportIdEquals
     * @param dataImportIdNotEquals
     * @param dataImportIdSpecified
     * @param dataImportIdIn
     * @param dataImportIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static getAllProviderGroups(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        avatarContains?: string,
        avatarDoesNotContain?: string,
        avatarEquals?: string,
        avatarNotEquals?: string,
        avatarSpecified?: boolean,
        avatarIn?: Array<string>,
        avatarNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        phoneContains?: string,
        phoneDoesNotContain?: string,
        phoneEquals?: string,
        phoneNotEquals?: string,
        phoneSpecified?: boolean,
        phoneIn?: Array<string>,
        phoneNotIn?: Array<string>,
        websiteContains?: string,
        websiteDoesNotContain?: string,
        websiteEquals?: string,
        websiteNotEquals?: string,
        websiteSpecified?: boolean,
        websiteIn?: Array<string>,
        websiteNotIn?: Array<string>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        schemaContains?: string,
        schemaDoesNotContain?: string,
        schemaEquals?: string,
        schemaNotEquals?: string,
        schemaSpecified?: boolean,
        schemaIn?: Array<string>,
        schemaNotIn?: Array<string>,
        iamGroupContains?: string,
        iamGroupDoesNotContain?: string,
        iamGroupEquals?: string,
        iamGroupNotEquals?: string,
        iamGroupSpecified?: boolean,
        iamGroupIn?: Array<string>,
        iamGroupNotIn?: Array<string>,
        subdomainContains?: string,
        subdomainDoesNotContain?: string,
        subdomainEquals?: string,
        subdomainNotEquals?: string,
        subdomainSpecified?: boolean,
        subdomainIn?: Array<string>,
        subdomainNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        providerCountGreaterThan?: number,
        providerCountLessThan?: number,
        providerCountGreaterThanOrEqual?: number,
        providerCountLessThanOrEqual?: number,
        providerCountEquals?: number,
        providerCountNotEquals?: number,
        providerCountSpecified?: boolean,
        providerCountIn?: Array<number>,
        providerCountNotIn?: Array<number>,
        patientCountGreaterThan?: number,
        patientCountLessThan?: number,
        patientCountGreaterThanOrEqual?: number,
        patientCountLessThanOrEqual?: number,
        patientCountEquals?: number,
        patientCountNotEquals?: number,
        patientCountSpecified?: boolean,
        patientCountIn?: Array<number>,
        patientCountNotIn?: Array<number>,
        appointmentCountGreaterThan?: number,
        appointmentCountLessThan?: number,
        appointmentCountGreaterThanOrEqual?: number,
        appointmentCountLessThanOrEqual?: number,
        appointmentCountEquals?: number,
        appointmentCountNotEquals?: number,
        appointmentCountSpecified?: boolean,
        appointmentCountIn?: Array<number>,
        appointmentCountNotIn?: Array<number>,
        encounterCountGreaterThan?: number,
        encounterCountLessThan?: number,
        encounterCountGreaterThanOrEqual?: number,
        encounterCountLessThanOrEqual?: number,
        encounterCountEquals?: number,
        encounterCountNotEquals?: number,
        encounterCountSpecified?: boolean,
        encounterCountIn?: Array<number>,
        encounterCountNotIn?: Array<number>,
        addressCheckBoxEquals?: boolean,
        addressCheckBoxNotEquals?: boolean,
        addressCheckBoxSpecified?: boolean,
        addressCheckBoxIn?: Array<boolean>,
        addressCheckBoxNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        physicalAddressIdIdGreaterThan?: number,
        physicalAddressIdIdLessThan?: number,
        physicalAddressIdIdGreaterThanOrEqual?: number,
        physicalAddressIdIdLessThanOrEqual?: number,
        physicalAddressIdIdEquals?: number,
        physicalAddressIdIdNotEquals?: number,
        physicalAddressIdIdSpecified?: boolean,
        physicalAddressIdIdIn?: Array<number>,
        physicalAddressIdIdNotIn?: Array<number>,
        billingAddressIdIdGreaterThan?: number,
        billingAddressIdIdLessThan?: number,
        billingAddressIdIdGreaterThanOrEqual?: number,
        billingAddressIdIdLessThanOrEqual?: number,
        billingAddressIdIdEquals?: number,
        billingAddressIdIdNotEquals?: number,
        billingAddressIdIdSpecified?: boolean,
        billingAddressIdIdIn?: Array<number>,
        billingAddressIdIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        practiceHoursIdGreaterThan?: number,
        practiceHoursIdLessThan?: number,
        practiceHoursIdGreaterThanOrEqual?: number,
        practiceHoursIdLessThanOrEqual?: number,
        practiceHoursIdEquals?: number,
        practiceHoursIdNotEquals?: number,
        practiceHoursIdSpecified?: boolean,
        practiceHoursIdIn?: Array<number>,
        practiceHoursIdNotIn?: Array<number>,
        dataImportIdGreaterThan?: number,
        dataImportIdLessThan?: number,
        dataImportIdGreaterThanOrEqual?: number,
        dataImportIdLessThanOrEqual?: number,
        dataImportIdEquals?: number,
        dataImportIdNotEquals?: number,
        dataImportIdSpecified?: boolean,
        dataImportIdIn?: Array<number>,
        dataImportIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<ProviderGroupDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'avatar.contains': avatarContains,
                'avatar.doesNotContain': avatarDoesNotContain,
                'avatar.equals': avatarEquals,
                'avatar.notEquals': avatarNotEquals,
                'avatar.specified': avatarSpecified,
                'avatar.in': avatarIn,
                'avatar.notIn': avatarNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'phone.contains': phoneContains,
                'phone.doesNotContain': phoneDoesNotContain,
                'phone.equals': phoneEquals,
                'phone.notEquals': phoneNotEquals,
                'phone.specified': phoneSpecified,
                'phone.in': phoneIn,
                'phone.notIn': phoneNotIn,
                'website.contains': websiteContains,
                'website.doesNotContain': websiteDoesNotContain,
                'website.equals': websiteEquals,
                'website.notEquals': websiteNotEquals,
                'website.specified': websiteSpecified,
                'website.in': websiteIn,
                'website.notIn': websiteNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'schema.contains': schemaContains,
                'schema.doesNotContain': schemaDoesNotContain,
                'schema.equals': schemaEquals,
                'schema.notEquals': schemaNotEquals,
                'schema.specified': schemaSpecified,
                'schema.in': schemaIn,
                'schema.notIn': schemaNotIn,
                'iamGroup.contains': iamGroupContains,
                'iamGroup.doesNotContain': iamGroupDoesNotContain,
                'iamGroup.equals': iamGroupEquals,
                'iamGroup.notEquals': iamGroupNotEquals,
                'iamGroup.specified': iamGroupSpecified,
                'iamGroup.in': iamGroupIn,
                'iamGroup.notIn': iamGroupNotIn,
                'subdomain.contains': subdomainContains,
                'subdomain.doesNotContain': subdomainDoesNotContain,
                'subdomain.equals': subdomainEquals,
                'subdomain.notEquals': subdomainNotEquals,
                'subdomain.specified': subdomainSpecified,
                'subdomain.in': subdomainIn,
                'subdomain.notIn': subdomainNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'providerCount.greaterThan': providerCountGreaterThan,
                'providerCount.lessThan': providerCountLessThan,
                'providerCount.greaterThanOrEqual': providerCountGreaterThanOrEqual,
                'providerCount.lessThanOrEqual': providerCountLessThanOrEqual,
                'providerCount.equals': providerCountEquals,
                'providerCount.notEquals': providerCountNotEquals,
                'providerCount.specified': providerCountSpecified,
                'providerCount.in': providerCountIn,
                'providerCount.notIn': providerCountNotIn,
                'patientCount.greaterThan': patientCountGreaterThan,
                'patientCount.lessThan': patientCountLessThan,
                'patientCount.greaterThanOrEqual': patientCountGreaterThanOrEqual,
                'patientCount.lessThanOrEqual': patientCountLessThanOrEqual,
                'patientCount.equals': patientCountEquals,
                'patientCount.notEquals': patientCountNotEquals,
                'patientCount.specified': patientCountSpecified,
                'patientCount.in': patientCountIn,
                'patientCount.notIn': patientCountNotIn,
                'appointmentCount.greaterThan': appointmentCountGreaterThan,
                'appointmentCount.lessThan': appointmentCountLessThan,
                'appointmentCount.greaterThanOrEqual': appointmentCountGreaterThanOrEqual,
                'appointmentCount.lessThanOrEqual': appointmentCountLessThanOrEqual,
                'appointmentCount.equals': appointmentCountEquals,
                'appointmentCount.notEquals': appointmentCountNotEquals,
                'appointmentCount.specified': appointmentCountSpecified,
                'appointmentCount.in': appointmentCountIn,
                'appointmentCount.notIn': appointmentCountNotIn,
                'encounterCount.greaterThan': encounterCountGreaterThan,
                'encounterCount.lessThan': encounterCountLessThan,
                'encounterCount.greaterThanOrEqual': encounterCountGreaterThanOrEqual,
                'encounterCount.lessThanOrEqual': encounterCountLessThanOrEqual,
                'encounterCount.equals': encounterCountEquals,
                'encounterCount.notEquals': encounterCountNotEquals,
                'encounterCount.specified': encounterCountSpecified,
                'encounterCount.in': encounterCountIn,
                'encounterCount.notIn': encounterCountNotIn,
                'addressCheckBox.equals': addressCheckBoxEquals,
                'addressCheckBox.notEquals': addressCheckBoxNotEquals,
                'addressCheckBox.specified': addressCheckBoxSpecified,
                'addressCheckBox.in': addressCheckBoxIn,
                'addressCheckBox.notIn': addressCheckBoxNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'physicalAddressIdId.greaterThan': physicalAddressIdIdGreaterThan,
                'physicalAddressIdId.lessThan': physicalAddressIdIdLessThan,
                'physicalAddressIdId.greaterThanOrEqual': physicalAddressIdIdGreaterThanOrEqual,
                'physicalAddressIdId.lessThanOrEqual': physicalAddressIdIdLessThanOrEqual,
                'physicalAddressIdId.equals': physicalAddressIdIdEquals,
                'physicalAddressIdId.notEquals': physicalAddressIdIdNotEquals,
                'physicalAddressIdId.specified': physicalAddressIdIdSpecified,
                'physicalAddressIdId.in': physicalAddressIdIdIn,
                'physicalAddressIdId.notIn': physicalAddressIdIdNotIn,
                'billingAddressIdId.greaterThan': billingAddressIdIdGreaterThan,
                'billingAddressIdId.lessThan': billingAddressIdIdLessThan,
                'billingAddressIdId.greaterThanOrEqual': billingAddressIdIdGreaterThanOrEqual,
                'billingAddressIdId.lessThanOrEqual': billingAddressIdIdLessThanOrEqual,
                'billingAddressIdId.equals': billingAddressIdIdEquals,
                'billingAddressIdId.notEquals': billingAddressIdIdNotEquals,
                'billingAddressIdId.specified': billingAddressIdIdSpecified,
                'billingAddressIdId.in': billingAddressIdIdIn,
                'billingAddressIdId.notIn': billingAddressIdIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'practiceHoursId.greaterThan': practiceHoursIdGreaterThan,
                'practiceHoursId.lessThan': practiceHoursIdLessThan,
                'practiceHoursId.greaterThanOrEqual': practiceHoursIdGreaterThanOrEqual,
                'practiceHoursId.lessThanOrEqual': practiceHoursIdLessThanOrEqual,
                'practiceHoursId.equals': practiceHoursIdEquals,
                'practiceHoursId.notEquals': practiceHoursIdNotEquals,
                'practiceHoursId.specified': practiceHoursIdSpecified,
                'practiceHoursId.in': practiceHoursIdIn,
                'practiceHoursId.notIn': practiceHoursIdNotIn,
                'dataImportId.greaterThan': dataImportIdGreaterThan,
                'dataImportId.lessThan': dataImportIdLessThan,
                'dataImportId.greaterThanOrEqual': dataImportIdGreaterThanOrEqual,
                'dataImportId.lessThanOrEqual': dataImportIdLessThanOrEqual,
                'dataImportId.equals': dataImportIdEquals,
                'dataImportId.notEquals': dataImportIdNotEquals,
                'dataImportId.specified': dataImportIdSpecified,
                'dataImportId.in': dataImportIdIn,
                'dataImportId.notIn': dataImportIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static createProviderGroup(
        requestBody: ProviderGroupDTO,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/provider-groups',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param providerGroupUuid
     * @param pageable
     * @returns ProviderDTO OK
     * @throws ApiError
     */
    public static getAllProviders1(
        providerGroupUuid: string,
        pageable: Pageable,
    ): CancelablePromise<Array<ProviderDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/{providerGroupUuid}/provider/all',
            path: {
                'providerGroupUuid': providerGroupUuid,
            },
            query: {
                'pageable': pageable,
            },
        });
    }

    /**
     * @param providerGroupId
     * @param pageable
     * @returns SpecialityDTO OK
     * @throws ApiError
     */
    public static getSpecialities(
        providerGroupId: string,
        pageable: Pageable,
    ): CancelablePromise<Array<SpecialityDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/specialities/{providerGroupId}',
            path: {
                'providerGroupId': providerGroupId,
            },
            query: {
                'pageable': pageable,
            },
        });
    }

    /**
     * @param providerGroupId
     * @param pageable
     * @returns InsurancePayerDTO OK
     * @throws ApiError
     */
    public static getInsurancePayers(
        providerGroupId: string,
        pageable: Pageable,
    ): CancelablePromise<Array<InsurancePayerDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/insurancepayers/{providerGroupId}',
            path: {
                'providerGroupId': providerGroupId,
            },
            query: {
                'pageable': pageable,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param descriptionContains
     * @param descriptionDoesNotContain
     * @param descriptionEquals
     * @param descriptionNotEquals
     * @param descriptionSpecified
     * @param descriptionIn
     * @param descriptionNotIn
     * @param npiContains
     * @param npiDoesNotContain
     * @param npiEquals
     * @param npiNotEquals
     * @param npiSpecified
     * @param npiIn
     * @param npiNotIn
     * @param avatarContains
     * @param avatarDoesNotContain
     * @param avatarEquals
     * @param avatarNotEquals
     * @param avatarSpecified
     * @param avatarIn
     * @param avatarNotIn
     * @param emailContains
     * @param emailDoesNotContain
     * @param emailEquals
     * @param emailNotEquals
     * @param emailSpecified
     * @param emailIn
     * @param emailNotIn
     * @param phoneContains
     * @param phoneDoesNotContain
     * @param phoneEquals
     * @param phoneNotEquals
     * @param phoneSpecified
     * @param phoneIn
     * @param phoneNotIn
     * @param websiteContains
     * @param websiteDoesNotContain
     * @param websiteEquals
     * @param websiteNotEquals
     * @param websiteSpecified
     * @param websiteIn
     * @param websiteNotIn
     * @param faxContains
     * @param faxDoesNotContain
     * @param faxEquals
     * @param faxNotEquals
     * @param faxSpecified
     * @param faxIn
     * @param faxNotIn
     * @param schemaContains
     * @param schemaDoesNotContain
     * @param schemaEquals
     * @param schemaNotEquals
     * @param schemaSpecified
     * @param schemaIn
     * @param schemaNotIn
     * @param iamGroupContains
     * @param iamGroupDoesNotContain
     * @param iamGroupEquals
     * @param iamGroupNotEquals
     * @param iamGroupSpecified
     * @param iamGroupIn
     * @param iamGroupNotIn
     * @param subdomainContains
     * @param subdomainDoesNotContain
     * @param subdomainEquals
     * @param subdomainNotEquals
     * @param subdomainSpecified
     * @param subdomainIn
     * @param subdomainNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param providerCountGreaterThan
     * @param providerCountLessThan
     * @param providerCountGreaterThanOrEqual
     * @param providerCountLessThanOrEqual
     * @param providerCountEquals
     * @param providerCountNotEquals
     * @param providerCountSpecified
     * @param providerCountIn
     * @param providerCountNotIn
     * @param patientCountGreaterThan
     * @param patientCountLessThan
     * @param patientCountGreaterThanOrEqual
     * @param patientCountLessThanOrEqual
     * @param patientCountEquals
     * @param patientCountNotEquals
     * @param patientCountSpecified
     * @param patientCountIn
     * @param patientCountNotIn
     * @param appointmentCountGreaterThan
     * @param appointmentCountLessThan
     * @param appointmentCountGreaterThanOrEqual
     * @param appointmentCountLessThanOrEqual
     * @param appointmentCountEquals
     * @param appointmentCountNotEquals
     * @param appointmentCountSpecified
     * @param appointmentCountIn
     * @param appointmentCountNotIn
     * @param encounterCountGreaterThan
     * @param encounterCountLessThan
     * @param encounterCountGreaterThanOrEqual
     * @param encounterCountLessThanOrEqual
     * @param encounterCountEquals
     * @param encounterCountNotEquals
     * @param encounterCountSpecified
     * @param encounterCountIn
     * @param encounterCountNotIn
     * @param addressCheckBoxEquals
     * @param addressCheckBoxNotEquals
     * @param addressCheckBoxSpecified
     * @param addressCheckBoxIn
     * @param addressCheckBoxNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param physicalAddressIdIdGreaterThan
     * @param physicalAddressIdIdLessThan
     * @param physicalAddressIdIdGreaterThanOrEqual
     * @param physicalAddressIdIdLessThanOrEqual
     * @param physicalAddressIdIdEquals
     * @param physicalAddressIdIdNotEquals
     * @param physicalAddressIdIdSpecified
     * @param physicalAddressIdIdIn
     * @param physicalAddressIdIdNotIn
     * @param billingAddressIdIdGreaterThan
     * @param billingAddressIdIdLessThan
     * @param billingAddressIdIdGreaterThanOrEqual
     * @param billingAddressIdIdLessThanOrEqual
     * @param billingAddressIdIdEquals
     * @param billingAddressIdIdNotEquals
     * @param billingAddressIdIdSpecified
     * @param billingAddressIdIdIn
     * @param billingAddressIdIdNotIn
     * @param specialitiesIdGreaterThan
     * @param specialitiesIdLessThan
     * @param specialitiesIdGreaterThanOrEqual
     * @param specialitiesIdLessThanOrEqual
     * @param specialitiesIdEquals
     * @param specialitiesIdNotEquals
     * @param specialitiesIdSpecified
     * @param specialitiesIdIn
     * @param specialitiesIdNotIn
     * @param practiceHoursIdGreaterThan
     * @param practiceHoursIdLessThan
     * @param practiceHoursIdGreaterThanOrEqual
     * @param practiceHoursIdLessThanOrEqual
     * @param practiceHoursIdEquals
     * @param practiceHoursIdNotEquals
     * @param practiceHoursIdSpecified
     * @param practiceHoursIdIn
     * @param practiceHoursIdNotIn
     * @param dataImportIdGreaterThan
     * @param dataImportIdLessThan
     * @param dataImportIdGreaterThanOrEqual
     * @param dataImportIdLessThanOrEqual
     * @param dataImportIdEquals
     * @param dataImportIdNotEquals
     * @param dataImportIdSpecified
     * @param dataImportIdIn
     * @param dataImportIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countProviderGroups(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        descriptionContains?: string,
        descriptionDoesNotContain?: string,
        descriptionEquals?: string,
        descriptionNotEquals?: string,
        descriptionSpecified?: boolean,
        descriptionIn?: Array<string>,
        descriptionNotIn?: Array<string>,
        npiContains?: string,
        npiDoesNotContain?: string,
        npiEquals?: string,
        npiNotEquals?: string,
        npiSpecified?: boolean,
        npiIn?: Array<string>,
        npiNotIn?: Array<string>,
        avatarContains?: string,
        avatarDoesNotContain?: string,
        avatarEquals?: string,
        avatarNotEquals?: string,
        avatarSpecified?: boolean,
        avatarIn?: Array<string>,
        avatarNotIn?: Array<string>,
        emailContains?: string,
        emailDoesNotContain?: string,
        emailEquals?: string,
        emailNotEquals?: string,
        emailSpecified?: boolean,
        emailIn?: Array<string>,
        emailNotIn?: Array<string>,
        phoneContains?: string,
        phoneDoesNotContain?: string,
        phoneEquals?: string,
        phoneNotEquals?: string,
        phoneSpecified?: boolean,
        phoneIn?: Array<string>,
        phoneNotIn?: Array<string>,
        websiteContains?: string,
        websiteDoesNotContain?: string,
        websiteEquals?: string,
        websiteNotEquals?: string,
        websiteSpecified?: boolean,
        websiteIn?: Array<string>,
        websiteNotIn?: Array<string>,
        faxContains?: string,
        faxDoesNotContain?: string,
        faxEquals?: string,
        faxNotEquals?: string,
        faxSpecified?: boolean,
        faxIn?: Array<string>,
        faxNotIn?: Array<string>,
        schemaContains?: string,
        schemaDoesNotContain?: string,
        schemaEquals?: string,
        schemaNotEquals?: string,
        schemaSpecified?: boolean,
        schemaIn?: Array<string>,
        schemaNotIn?: Array<string>,
        iamGroupContains?: string,
        iamGroupDoesNotContain?: string,
        iamGroupEquals?: string,
        iamGroupNotEquals?: string,
        iamGroupSpecified?: boolean,
        iamGroupIn?: Array<string>,
        iamGroupNotIn?: Array<string>,
        subdomainContains?: string,
        subdomainDoesNotContain?: string,
        subdomainEquals?: string,
        subdomainNotEquals?: string,
        subdomainSpecified?: boolean,
        subdomainIn?: Array<string>,
        subdomainNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        providerCountGreaterThan?: number,
        providerCountLessThan?: number,
        providerCountGreaterThanOrEqual?: number,
        providerCountLessThanOrEqual?: number,
        providerCountEquals?: number,
        providerCountNotEquals?: number,
        providerCountSpecified?: boolean,
        providerCountIn?: Array<number>,
        providerCountNotIn?: Array<number>,
        patientCountGreaterThan?: number,
        patientCountLessThan?: number,
        patientCountGreaterThanOrEqual?: number,
        patientCountLessThanOrEqual?: number,
        patientCountEquals?: number,
        patientCountNotEquals?: number,
        patientCountSpecified?: boolean,
        patientCountIn?: Array<number>,
        patientCountNotIn?: Array<number>,
        appointmentCountGreaterThan?: number,
        appointmentCountLessThan?: number,
        appointmentCountGreaterThanOrEqual?: number,
        appointmentCountLessThanOrEqual?: number,
        appointmentCountEquals?: number,
        appointmentCountNotEquals?: number,
        appointmentCountSpecified?: boolean,
        appointmentCountIn?: Array<number>,
        appointmentCountNotIn?: Array<number>,
        encounterCountGreaterThan?: number,
        encounterCountLessThan?: number,
        encounterCountGreaterThanOrEqual?: number,
        encounterCountLessThanOrEqual?: number,
        encounterCountEquals?: number,
        encounterCountNotEquals?: number,
        encounterCountSpecified?: boolean,
        encounterCountIn?: Array<number>,
        encounterCountNotIn?: Array<number>,
        addressCheckBoxEquals?: boolean,
        addressCheckBoxNotEquals?: boolean,
        addressCheckBoxSpecified?: boolean,
        addressCheckBoxIn?: Array<boolean>,
        addressCheckBoxNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        physicalAddressIdIdGreaterThan?: number,
        physicalAddressIdIdLessThan?: number,
        physicalAddressIdIdGreaterThanOrEqual?: number,
        physicalAddressIdIdLessThanOrEqual?: number,
        physicalAddressIdIdEquals?: number,
        physicalAddressIdIdNotEquals?: number,
        physicalAddressIdIdSpecified?: boolean,
        physicalAddressIdIdIn?: Array<number>,
        physicalAddressIdIdNotIn?: Array<number>,
        billingAddressIdIdGreaterThan?: number,
        billingAddressIdIdLessThan?: number,
        billingAddressIdIdGreaterThanOrEqual?: number,
        billingAddressIdIdLessThanOrEqual?: number,
        billingAddressIdIdEquals?: number,
        billingAddressIdIdNotEquals?: number,
        billingAddressIdIdSpecified?: boolean,
        billingAddressIdIdIn?: Array<number>,
        billingAddressIdIdNotIn?: Array<number>,
        specialitiesIdGreaterThan?: number,
        specialitiesIdLessThan?: number,
        specialitiesIdGreaterThanOrEqual?: number,
        specialitiesIdLessThanOrEqual?: number,
        specialitiesIdEquals?: number,
        specialitiesIdNotEquals?: number,
        specialitiesIdSpecified?: boolean,
        specialitiesIdIn?: Array<number>,
        specialitiesIdNotIn?: Array<number>,
        practiceHoursIdGreaterThan?: number,
        practiceHoursIdLessThan?: number,
        practiceHoursIdGreaterThanOrEqual?: number,
        practiceHoursIdLessThanOrEqual?: number,
        practiceHoursIdEquals?: number,
        practiceHoursIdNotEquals?: number,
        practiceHoursIdSpecified?: boolean,
        practiceHoursIdIn?: Array<number>,
        practiceHoursIdNotIn?: Array<number>,
        dataImportIdGreaterThan?: number,
        dataImportIdLessThan?: number,
        dataImportIdGreaterThanOrEqual?: number,
        dataImportIdLessThanOrEqual?: number,
        dataImportIdEquals?: number,
        dataImportIdNotEquals?: number,
        dataImportIdSpecified?: boolean,
        dataImportIdIn?: Array<number>,
        dataImportIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'description.contains': descriptionContains,
                'description.doesNotContain': descriptionDoesNotContain,
                'description.equals': descriptionEquals,
                'description.notEquals': descriptionNotEquals,
                'description.specified': descriptionSpecified,
                'description.in': descriptionIn,
                'description.notIn': descriptionNotIn,
                'npi.contains': npiContains,
                'npi.doesNotContain': npiDoesNotContain,
                'npi.equals': npiEquals,
                'npi.notEquals': npiNotEquals,
                'npi.specified': npiSpecified,
                'npi.in': npiIn,
                'npi.notIn': npiNotIn,
                'avatar.contains': avatarContains,
                'avatar.doesNotContain': avatarDoesNotContain,
                'avatar.equals': avatarEquals,
                'avatar.notEquals': avatarNotEquals,
                'avatar.specified': avatarSpecified,
                'avatar.in': avatarIn,
                'avatar.notIn': avatarNotIn,
                'email.contains': emailContains,
                'email.doesNotContain': emailDoesNotContain,
                'email.equals': emailEquals,
                'email.notEquals': emailNotEquals,
                'email.specified': emailSpecified,
                'email.in': emailIn,
                'email.notIn': emailNotIn,
                'phone.contains': phoneContains,
                'phone.doesNotContain': phoneDoesNotContain,
                'phone.equals': phoneEquals,
                'phone.notEquals': phoneNotEquals,
                'phone.specified': phoneSpecified,
                'phone.in': phoneIn,
                'phone.notIn': phoneNotIn,
                'website.contains': websiteContains,
                'website.doesNotContain': websiteDoesNotContain,
                'website.equals': websiteEquals,
                'website.notEquals': websiteNotEquals,
                'website.specified': websiteSpecified,
                'website.in': websiteIn,
                'website.notIn': websiteNotIn,
                'fax.contains': faxContains,
                'fax.doesNotContain': faxDoesNotContain,
                'fax.equals': faxEquals,
                'fax.notEquals': faxNotEquals,
                'fax.specified': faxSpecified,
                'fax.in': faxIn,
                'fax.notIn': faxNotIn,
                'schema.contains': schemaContains,
                'schema.doesNotContain': schemaDoesNotContain,
                'schema.equals': schemaEquals,
                'schema.notEquals': schemaNotEquals,
                'schema.specified': schemaSpecified,
                'schema.in': schemaIn,
                'schema.notIn': schemaNotIn,
                'iamGroup.contains': iamGroupContains,
                'iamGroup.doesNotContain': iamGroupDoesNotContain,
                'iamGroup.equals': iamGroupEquals,
                'iamGroup.notEquals': iamGroupNotEquals,
                'iamGroup.specified': iamGroupSpecified,
                'iamGroup.in': iamGroupIn,
                'iamGroup.notIn': iamGroupNotIn,
                'subdomain.contains': subdomainContains,
                'subdomain.doesNotContain': subdomainDoesNotContain,
                'subdomain.equals': subdomainEquals,
                'subdomain.notEquals': subdomainNotEquals,
                'subdomain.specified': subdomainSpecified,
                'subdomain.in': subdomainIn,
                'subdomain.notIn': subdomainNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'providerCount.greaterThan': providerCountGreaterThan,
                'providerCount.lessThan': providerCountLessThan,
                'providerCount.greaterThanOrEqual': providerCountGreaterThanOrEqual,
                'providerCount.lessThanOrEqual': providerCountLessThanOrEqual,
                'providerCount.equals': providerCountEquals,
                'providerCount.notEquals': providerCountNotEquals,
                'providerCount.specified': providerCountSpecified,
                'providerCount.in': providerCountIn,
                'providerCount.notIn': providerCountNotIn,
                'patientCount.greaterThan': patientCountGreaterThan,
                'patientCount.lessThan': patientCountLessThan,
                'patientCount.greaterThanOrEqual': patientCountGreaterThanOrEqual,
                'patientCount.lessThanOrEqual': patientCountLessThanOrEqual,
                'patientCount.equals': patientCountEquals,
                'patientCount.notEquals': patientCountNotEquals,
                'patientCount.specified': patientCountSpecified,
                'patientCount.in': patientCountIn,
                'patientCount.notIn': patientCountNotIn,
                'appointmentCount.greaterThan': appointmentCountGreaterThan,
                'appointmentCount.lessThan': appointmentCountLessThan,
                'appointmentCount.greaterThanOrEqual': appointmentCountGreaterThanOrEqual,
                'appointmentCount.lessThanOrEqual': appointmentCountLessThanOrEqual,
                'appointmentCount.equals': appointmentCountEquals,
                'appointmentCount.notEquals': appointmentCountNotEquals,
                'appointmentCount.specified': appointmentCountSpecified,
                'appointmentCount.in': appointmentCountIn,
                'appointmentCount.notIn': appointmentCountNotIn,
                'encounterCount.greaterThan': encounterCountGreaterThan,
                'encounterCount.lessThan': encounterCountLessThan,
                'encounterCount.greaterThanOrEqual': encounterCountGreaterThanOrEqual,
                'encounterCount.lessThanOrEqual': encounterCountLessThanOrEqual,
                'encounterCount.equals': encounterCountEquals,
                'encounterCount.notEquals': encounterCountNotEquals,
                'encounterCount.specified': encounterCountSpecified,
                'encounterCount.in': encounterCountIn,
                'encounterCount.notIn': encounterCountNotIn,
                'addressCheckBox.equals': addressCheckBoxEquals,
                'addressCheckBox.notEquals': addressCheckBoxNotEquals,
                'addressCheckBox.specified': addressCheckBoxSpecified,
                'addressCheckBox.in': addressCheckBoxIn,
                'addressCheckBox.notIn': addressCheckBoxNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'physicalAddressIdId.greaterThan': physicalAddressIdIdGreaterThan,
                'physicalAddressIdId.lessThan': physicalAddressIdIdLessThan,
                'physicalAddressIdId.greaterThanOrEqual': physicalAddressIdIdGreaterThanOrEqual,
                'physicalAddressIdId.lessThanOrEqual': physicalAddressIdIdLessThanOrEqual,
                'physicalAddressIdId.equals': physicalAddressIdIdEquals,
                'physicalAddressIdId.notEquals': physicalAddressIdIdNotEquals,
                'physicalAddressIdId.specified': physicalAddressIdIdSpecified,
                'physicalAddressIdId.in': physicalAddressIdIdIn,
                'physicalAddressIdId.notIn': physicalAddressIdIdNotIn,
                'billingAddressIdId.greaterThan': billingAddressIdIdGreaterThan,
                'billingAddressIdId.lessThan': billingAddressIdIdLessThan,
                'billingAddressIdId.greaterThanOrEqual': billingAddressIdIdGreaterThanOrEqual,
                'billingAddressIdId.lessThanOrEqual': billingAddressIdIdLessThanOrEqual,
                'billingAddressIdId.equals': billingAddressIdIdEquals,
                'billingAddressIdId.notEquals': billingAddressIdIdNotEquals,
                'billingAddressIdId.specified': billingAddressIdIdSpecified,
                'billingAddressIdId.in': billingAddressIdIdIn,
                'billingAddressIdId.notIn': billingAddressIdIdNotIn,
                'specialitiesId.greaterThan': specialitiesIdGreaterThan,
                'specialitiesId.lessThan': specialitiesIdLessThan,
                'specialitiesId.greaterThanOrEqual': specialitiesIdGreaterThanOrEqual,
                'specialitiesId.lessThanOrEqual': specialitiesIdLessThanOrEqual,
                'specialitiesId.equals': specialitiesIdEquals,
                'specialitiesId.notEquals': specialitiesIdNotEquals,
                'specialitiesId.specified': specialitiesIdSpecified,
                'specialitiesId.in': specialitiesIdIn,
                'specialitiesId.notIn': specialitiesIdNotIn,
                'practiceHoursId.greaterThan': practiceHoursIdGreaterThan,
                'practiceHoursId.lessThan': practiceHoursIdLessThan,
                'practiceHoursId.greaterThanOrEqual': practiceHoursIdGreaterThanOrEqual,
                'practiceHoursId.lessThanOrEqual': practiceHoursIdLessThanOrEqual,
                'practiceHoursId.equals': practiceHoursIdEquals,
                'practiceHoursId.notEquals': practiceHoursIdNotEquals,
                'practiceHoursId.specified': practiceHoursIdSpecified,
                'practiceHoursId.in': practiceHoursIdIn,
                'practiceHoursId.notIn': practiceHoursIdNotIn,
                'dataImportId.greaterThan': dataImportIdGreaterThan,
                'dataImportId.lessThan': dataImportIdLessThan,
                'dataImportId.greaterThanOrEqual': dataImportIdGreaterThanOrEqual,
                'dataImportId.lessThanOrEqual': dataImportIdLessThanOrEqual,
                'dataImportId.equals': dataImportIdEquals,
                'dataImportId.notEquals': dataImportIdNotEquals,
                'dataImportId.specified': dataImportIdSpecified,
                'dataImportId.in': dataImportIdIn,
                'dataImportId.notIn': dataImportIdNotIn,
                'distinct': distinct,
            },
        });
    }

    /**
     * @param xTenantId
     * @param subdomain
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static getProviderGroupBySubdomain(
        xTenantId: string,
        subdomain: string,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/subdomain/{subdomain}',
            path: {
                'subdomain': subdomain,
            },
            headers: {
                'X-TENANT-ID': xTenantId,
            },
        });
    }

    /**
     * @param xTenantId
     * @param subdomain
     * @returns ProviderGroupDTO OK
     * @throws ApiError
     */
    public static getProviderGroupBySubdomain1(
        xTenantId: string,
        subdomain: string,
    ): CancelablePromise<ProviderGroupDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-groups/auth/subdomain/{subdomain}',
            path: {
                'subdomain': subdomain,
            },
            headers: {
                'X-TENANT-ID': xTenantId,
            },
        });
    }

    /**
     * @param uuid
     * @returns any OK
     * @throws ApiError
     */
    public static deleteProviderGroup(
        uuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/provider-groups/{uuid}',
            path: {
                'uuid': uuid,
            },
        });
    }

}
