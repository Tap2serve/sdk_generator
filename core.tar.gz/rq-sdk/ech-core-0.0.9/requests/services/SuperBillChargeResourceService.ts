/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SuperBillChargeDTO } from '../models/SuperBillChargeDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class SuperBillChargeResourceService {

    /**
     * @param id
     * @returns SuperBillChargeDTO OK
     * @throws ApiError
     */
    public static getSuperBillCharge(
        id: number,
    ): CancelablePromise<SuperBillChargeDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bill-charges/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SuperBillChargeDTO OK
     * @throws ApiError
     */
    public static updateSuperBillCharge(
        id: number,
        requestBody: SuperBillChargeDTO,
    ): CancelablePromise<SuperBillChargeDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/super-bill-charges/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteSuperBillCharge(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/super-bill-charges/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns SuperBillChargeDTO OK
     * @throws ApiError
     */
    public static partialUpdateSuperBillCharge(
        id: number,
        requestBody: SuperBillChargeDTO,
    ): CancelablePromise<SuperBillChargeDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/super-bill-charges/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param chargeTypeContains
     * @param chargeTypeDoesNotContain
     * @param chargeTypeEquals
     * @param chargeTypeNotEquals
     * @param chargeTypeSpecified
     * @param chargeTypeIn
     * @param chargeTypeNotIn
     * @param lineItemGreaterThan
     * @param lineItemLessThan
     * @param lineItemGreaterThanOrEqual
     * @param lineItemLessThanOrEqual
     * @param lineItemEquals
     * @param lineItemNotEquals
     * @param lineItemSpecified
     * @param lineItemIn
     * @param lineItemNotIn
     * @param chargesGreaterThan
     * @param chargesLessThan
     * @param chargesGreaterThanOrEqual
     * @param chargesLessThanOrEqual
     * @param chargesEquals
     * @param chargesNotEquals
     * @param chargesSpecified
     * @param chargesIn
     * @param chargesNotIn
     * @param discountGreaterThan
     * @param discountLessThan
     * @param discountGreaterThanOrEqual
     * @param discountLessThanOrEqual
     * @param discountEquals
     * @param discountNotEquals
     * @param discountSpecified
     * @param discountIn
     * @param discountNotIn
     * @param taxGreaterThan
     * @param taxLessThan
     * @param taxGreaterThanOrEqual
     * @param taxLessThanOrEqual
     * @param taxEquals
     * @param taxNotEquals
     * @param taxSpecified
     * @param taxIn
     * @param taxNotIn
     * @param netGreaterThan
     * @param netLessThan
     * @param netGreaterThanOrEqual
     * @param netLessThanOrEqual
     * @param netEquals
     * @param netNotEquals
     * @param netSpecified
     * @param netIn
     * @param netNotIn
     * @param superBillIdIdGreaterThan
     * @param superBillIdIdLessThan
     * @param superBillIdIdGreaterThanOrEqual
     * @param superBillIdIdLessThanOrEqual
     * @param superBillIdIdEquals
     * @param superBillIdIdNotEquals
     * @param superBillIdIdSpecified
     * @param superBillIdIdIn
     * @param superBillIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns SuperBillChargeDTO OK
     * @throws ApiError
     */
    public static getAllSuperBillCharges(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        chargeTypeContains?: string,
        chargeTypeDoesNotContain?: string,
        chargeTypeEquals?: string,
        chargeTypeNotEquals?: string,
        chargeTypeSpecified?: boolean,
        chargeTypeIn?: Array<string>,
        chargeTypeNotIn?: Array<string>,
        lineItemGreaterThan?: number,
        lineItemLessThan?: number,
        lineItemGreaterThanOrEqual?: number,
        lineItemLessThanOrEqual?: number,
        lineItemEquals?: number,
        lineItemNotEquals?: number,
        lineItemSpecified?: boolean,
        lineItemIn?: Array<number>,
        lineItemNotIn?: Array<number>,
        chargesGreaterThan?: number,
        chargesLessThan?: number,
        chargesGreaterThanOrEqual?: number,
        chargesLessThanOrEqual?: number,
        chargesEquals?: number,
        chargesNotEquals?: number,
        chargesSpecified?: boolean,
        chargesIn?: Array<number>,
        chargesNotIn?: Array<number>,
        discountGreaterThan?: number,
        discountLessThan?: number,
        discountGreaterThanOrEqual?: number,
        discountLessThanOrEqual?: number,
        discountEquals?: number,
        discountNotEquals?: number,
        discountSpecified?: boolean,
        discountIn?: Array<number>,
        discountNotIn?: Array<number>,
        taxGreaterThan?: number,
        taxLessThan?: number,
        taxGreaterThanOrEqual?: number,
        taxLessThanOrEqual?: number,
        taxEquals?: number,
        taxNotEquals?: number,
        taxSpecified?: boolean,
        taxIn?: Array<number>,
        taxNotIn?: Array<number>,
        netGreaterThan?: number,
        netLessThan?: number,
        netGreaterThanOrEqual?: number,
        netLessThanOrEqual?: number,
        netEquals?: number,
        netNotEquals?: number,
        netSpecified?: boolean,
        netIn?: Array<number>,
        netNotIn?: Array<number>,
        superBillIdIdGreaterThan?: number,
        superBillIdIdLessThan?: number,
        superBillIdIdGreaterThanOrEqual?: number,
        superBillIdIdLessThanOrEqual?: number,
        superBillIdIdEquals?: number,
        superBillIdIdNotEquals?: number,
        superBillIdIdSpecified?: boolean,
        superBillIdIdIn?: Array<number>,
        superBillIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<SuperBillChargeDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bill-charges',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'chargeType.contains': chargeTypeContains,
                'chargeType.doesNotContain': chargeTypeDoesNotContain,
                'chargeType.equals': chargeTypeEquals,
                'chargeType.notEquals': chargeTypeNotEquals,
                'chargeType.specified': chargeTypeSpecified,
                'chargeType.in': chargeTypeIn,
                'chargeType.notIn': chargeTypeNotIn,
                'lineItem.greaterThan': lineItemGreaterThan,
                'lineItem.lessThan': lineItemLessThan,
                'lineItem.greaterThanOrEqual': lineItemGreaterThanOrEqual,
                'lineItem.lessThanOrEqual': lineItemLessThanOrEqual,
                'lineItem.equals': lineItemEquals,
                'lineItem.notEquals': lineItemNotEquals,
                'lineItem.specified': lineItemSpecified,
                'lineItem.in': lineItemIn,
                'lineItem.notIn': lineItemNotIn,
                'charges.greaterThan': chargesGreaterThan,
                'charges.lessThan': chargesLessThan,
                'charges.greaterThanOrEqual': chargesGreaterThanOrEqual,
                'charges.lessThanOrEqual': chargesLessThanOrEqual,
                'charges.equals': chargesEquals,
                'charges.notEquals': chargesNotEquals,
                'charges.specified': chargesSpecified,
                'charges.in': chargesIn,
                'charges.notIn': chargesNotIn,
                'discount.greaterThan': discountGreaterThan,
                'discount.lessThan': discountLessThan,
                'discount.greaterThanOrEqual': discountGreaterThanOrEqual,
                'discount.lessThanOrEqual': discountLessThanOrEqual,
                'discount.equals': discountEquals,
                'discount.notEquals': discountNotEquals,
                'discount.specified': discountSpecified,
                'discount.in': discountIn,
                'discount.notIn': discountNotIn,
                'tax.greaterThan': taxGreaterThan,
                'tax.lessThan': taxLessThan,
                'tax.greaterThanOrEqual': taxGreaterThanOrEqual,
                'tax.lessThanOrEqual': taxLessThanOrEqual,
                'tax.equals': taxEquals,
                'tax.notEquals': taxNotEquals,
                'tax.specified': taxSpecified,
                'tax.in': taxIn,
                'tax.notIn': taxNotIn,
                'net.greaterThan': netGreaterThan,
                'net.lessThan': netLessThan,
                'net.greaterThanOrEqual': netGreaterThanOrEqual,
                'net.lessThanOrEqual': netLessThanOrEqual,
                'net.equals': netEquals,
                'net.notEquals': netNotEquals,
                'net.specified': netSpecified,
                'net.in': netIn,
                'net.notIn': netNotIn,
                'superBillIdId.greaterThan': superBillIdIdGreaterThan,
                'superBillIdId.lessThan': superBillIdIdLessThan,
                'superBillIdId.greaterThanOrEqual': superBillIdIdGreaterThanOrEqual,
                'superBillIdId.lessThanOrEqual': superBillIdIdLessThanOrEqual,
                'superBillIdId.equals': superBillIdIdEquals,
                'superBillIdId.notEquals': superBillIdIdNotEquals,
                'superBillIdId.specified': superBillIdIdSpecified,
                'superBillIdId.in': superBillIdIdIn,
                'superBillIdId.notIn': superBillIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns SuperBillChargeDTO OK
     * @throws ApiError
     */
    public static createSuperBillCharge(
        requestBody: SuperBillChargeDTO,
    ): CancelablePromise<SuperBillChargeDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/super-bill-charges',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param chargeTypeContains
     * @param chargeTypeDoesNotContain
     * @param chargeTypeEquals
     * @param chargeTypeNotEquals
     * @param chargeTypeSpecified
     * @param chargeTypeIn
     * @param chargeTypeNotIn
     * @param lineItemGreaterThan
     * @param lineItemLessThan
     * @param lineItemGreaterThanOrEqual
     * @param lineItemLessThanOrEqual
     * @param lineItemEquals
     * @param lineItemNotEquals
     * @param lineItemSpecified
     * @param lineItemIn
     * @param lineItemNotIn
     * @param chargesGreaterThan
     * @param chargesLessThan
     * @param chargesGreaterThanOrEqual
     * @param chargesLessThanOrEqual
     * @param chargesEquals
     * @param chargesNotEquals
     * @param chargesSpecified
     * @param chargesIn
     * @param chargesNotIn
     * @param discountGreaterThan
     * @param discountLessThan
     * @param discountGreaterThanOrEqual
     * @param discountLessThanOrEqual
     * @param discountEquals
     * @param discountNotEquals
     * @param discountSpecified
     * @param discountIn
     * @param discountNotIn
     * @param taxGreaterThan
     * @param taxLessThan
     * @param taxGreaterThanOrEqual
     * @param taxLessThanOrEqual
     * @param taxEquals
     * @param taxNotEquals
     * @param taxSpecified
     * @param taxIn
     * @param taxNotIn
     * @param netGreaterThan
     * @param netLessThan
     * @param netGreaterThanOrEqual
     * @param netLessThanOrEqual
     * @param netEquals
     * @param netNotEquals
     * @param netSpecified
     * @param netIn
     * @param netNotIn
     * @param superBillIdIdGreaterThan
     * @param superBillIdIdLessThan
     * @param superBillIdIdGreaterThanOrEqual
     * @param superBillIdIdLessThanOrEqual
     * @param superBillIdIdEquals
     * @param superBillIdIdNotEquals
     * @param superBillIdIdSpecified
     * @param superBillIdIdIn
     * @param superBillIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countSuperBillCharges(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        chargeTypeContains?: string,
        chargeTypeDoesNotContain?: string,
        chargeTypeEquals?: string,
        chargeTypeNotEquals?: string,
        chargeTypeSpecified?: boolean,
        chargeTypeIn?: Array<string>,
        chargeTypeNotIn?: Array<string>,
        lineItemGreaterThan?: number,
        lineItemLessThan?: number,
        lineItemGreaterThanOrEqual?: number,
        lineItemLessThanOrEqual?: number,
        lineItemEquals?: number,
        lineItemNotEquals?: number,
        lineItemSpecified?: boolean,
        lineItemIn?: Array<number>,
        lineItemNotIn?: Array<number>,
        chargesGreaterThan?: number,
        chargesLessThan?: number,
        chargesGreaterThanOrEqual?: number,
        chargesLessThanOrEqual?: number,
        chargesEquals?: number,
        chargesNotEquals?: number,
        chargesSpecified?: boolean,
        chargesIn?: Array<number>,
        chargesNotIn?: Array<number>,
        discountGreaterThan?: number,
        discountLessThan?: number,
        discountGreaterThanOrEqual?: number,
        discountLessThanOrEqual?: number,
        discountEquals?: number,
        discountNotEquals?: number,
        discountSpecified?: boolean,
        discountIn?: Array<number>,
        discountNotIn?: Array<number>,
        taxGreaterThan?: number,
        taxLessThan?: number,
        taxGreaterThanOrEqual?: number,
        taxLessThanOrEqual?: number,
        taxEquals?: number,
        taxNotEquals?: number,
        taxSpecified?: boolean,
        taxIn?: Array<number>,
        taxNotIn?: Array<number>,
        netGreaterThan?: number,
        netLessThan?: number,
        netGreaterThanOrEqual?: number,
        netLessThanOrEqual?: number,
        netEquals?: number,
        netNotEquals?: number,
        netSpecified?: boolean,
        netIn?: Array<number>,
        netNotIn?: Array<number>,
        superBillIdIdGreaterThan?: number,
        superBillIdIdLessThan?: number,
        superBillIdIdGreaterThanOrEqual?: number,
        superBillIdIdLessThanOrEqual?: number,
        superBillIdIdEquals?: number,
        superBillIdIdNotEquals?: number,
        superBillIdIdSpecified?: boolean,
        superBillIdIdIn?: Array<number>,
        superBillIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/super-bill-charges/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'chargeType.contains': chargeTypeContains,
                'chargeType.doesNotContain': chargeTypeDoesNotContain,
                'chargeType.equals': chargeTypeEquals,
                'chargeType.notEquals': chargeTypeNotEquals,
                'chargeType.specified': chargeTypeSpecified,
                'chargeType.in': chargeTypeIn,
                'chargeType.notIn': chargeTypeNotIn,
                'lineItem.greaterThan': lineItemGreaterThan,
                'lineItem.lessThan': lineItemLessThan,
                'lineItem.greaterThanOrEqual': lineItemGreaterThanOrEqual,
                'lineItem.lessThanOrEqual': lineItemLessThanOrEqual,
                'lineItem.equals': lineItemEquals,
                'lineItem.notEquals': lineItemNotEquals,
                'lineItem.specified': lineItemSpecified,
                'lineItem.in': lineItemIn,
                'lineItem.notIn': lineItemNotIn,
                'charges.greaterThan': chargesGreaterThan,
                'charges.lessThan': chargesLessThan,
                'charges.greaterThanOrEqual': chargesGreaterThanOrEqual,
                'charges.lessThanOrEqual': chargesLessThanOrEqual,
                'charges.equals': chargesEquals,
                'charges.notEquals': chargesNotEquals,
                'charges.specified': chargesSpecified,
                'charges.in': chargesIn,
                'charges.notIn': chargesNotIn,
                'discount.greaterThan': discountGreaterThan,
                'discount.lessThan': discountLessThan,
                'discount.greaterThanOrEqual': discountGreaterThanOrEqual,
                'discount.lessThanOrEqual': discountLessThanOrEqual,
                'discount.equals': discountEquals,
                'discount.notEquals': discountNotEquals,
                'discount.specified': discountSpecified,
                'discount.in': discountIn,
                'discount.notIn': discountNotIn,
                'tax.greaterThan': taxGreaterThan,
                'tax.lessThan': taxLessThan,
                'tax.greaterThanOrEqual': taxGreaterThanOrEqual,
                'tax.lessThanOrEqual': taxLessThanOrEqual,
                'tax.equals': taxEquals,
                'tax.notEquals': taxNotEquals,
                'tax.specified': taxSpecified,
                'tax.in': taxIn,
                'tax.notIn': taxNotIn,
                'net.greaterThan': netGreaterThan,
                'net.lessThan': netLessThan,
                'net.greaterThanOrEqual': netGreaterThanOrEqual,
                'net.lessThanOrEqual': netLessThanOrEqual,
                'net.equals': netEquals,
                'net.notEquals': netNotEquals,
                'net.specified': netSpecified,
                'net.in': netIn,
                'net.notIn': netNotIn,
                'superBillIdId.greaterThan': superBillIdIdGreaterThan,
                'superBillIdId.lessThan': superBillIdIdLessThan,
                'superBillIdId.greaterThanOrEqual': superBillIdIdGreaterThanOrEqual,
                'superBillIdId.lessThanOrEqual': superBillIdIdLessThanOrEqual,
                'superBillIdId.equals': superBillIdIdEquals,
                'superBillIdId.notEquals': superBillIdIdNotEquals,
                'superBillIdId.specified': superBillIdIdSpecified,
                'superBillIdId.in': superBillIdIdIn,
                'superBillIdId.notIn': superBillIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
