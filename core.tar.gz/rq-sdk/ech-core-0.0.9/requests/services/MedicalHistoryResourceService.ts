/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MedicalHistoryDTO } from '../models/MedicalHistoryDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class MedicalHistoryResourceService {

    /**
     * @param id
     * @returns MedicalHistoryDTO OK
     * @throws ApiError
     */
    public static getMedicalHistory(
        id: number,
    ): CancelablePromise<MedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/medical-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns MedicalHistoryDTO OK
     * @throws ApiError
     */
    public static updateMedicalHistory(
        id: number,
        requestBody: MedicalHistoryDTO,
    ): CancelablePromise<MedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/medical-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteMedicalHistory(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/medical-histories/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns MedicalHistoryDTO OK
     * @throws ApiError
     */
    public static partialUpdateMedicalHistory(
        id: number,
        requestBody: MedicalHistoryDTO,
    ): CancelablePromise<MedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/medical-histories/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param conditionNameContains
     * @param conditionNameDoesNotContain
     * @param conditionNameEquals
     * @param conditionNameNotEquals
     * @param conditionNameSpecified
     * @param conditionNameIn
     * @param conditionNameNotIn
     * @param dateGreaterThan
     * @param dateLessThan
     * @param dateGreaterThanOrEqual
     * @param dateLessThanOrEqual
     * @param dateEquals
     * @param dateNotEquals
     * @param dateSpecified
     * @param dateIn
     * @param dateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeMedicalHistoryIdGreaterThan
     * @param intakeMedicalHistoryIdLessThan
     * @param intakeMedicalHistoryIdGreaterThanOrEqual
     * @param intakeMedicalHistoryIdLessThanOrEqual
     * @param intakeMedicalHistoryIdEquals
     * @param intakeMedicalHistoryIdNotEquals
     * @param intakeMedicalHistoryIdSpecified
     * @param intakeMedicalHistoryIdIn
     * @param intakeMedicalHistoryIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns MedicalHistoryDTO OK
     * @throws ApiError
     */
    public static getAllMedicalHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        conditionNameContains?: string,
        conditionNameDoesNotContain?: string,
        conditionNameEquals?: string,
        conditionNameNotEquals?: string,
        conditionNameSpecified?: boolean,
        conditionNameIn?: Array<string>,
        conditionNameNotIn?: Array<string>,
        dateGreaterThan?: string,
        dateLessThan?: string,
        dateGreaterThanOrEqual?: string,
        dateLessThanOrEqual?: string,
        dateEquals?: string,
        dateNotEquals?: string,
        dateSpecified?: boolean,
        dateIn?: Array<string>,
        dateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeMedicalHistoryIdGreaterThan?: number,
        intakeMedicalHistoryIdLessThan?: number,
        intakeMedicalHistoryIdGreaterThanOrEqual?: number,
        intakeMedicalHistoryIdLessThanOrEqual?: number,
        intakeMedicalHistoryIdEquals?: number,
        intakeMedicalHistoryIdNotEquals?: number,
        intakeMedicalHistoryIdSpecified?: boolean,
        intakeMedicalHistoryIdIn?: Array<number>,
        intakeMedicalHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<MedicalHistoryDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/medical-histories',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'conditionName.contains': conditionNameContains,
                'conditionName.doesNotContain': conditionNameDoesNotContain,
                'conditionName.equals': conditionNameEquals,
                'conditionName.notEquals': conditionNameNotEquals,
                'conditionName.specified': conditionNameSpecified,
                'conditionName.in': conditionNameIn,
                'conditionName.notIn': conditionNameNotIn,
                'date.greaterThan': dateGreaterThan,
                'date.lessThan': dateLessThan,
                'date.greaterThanOrEqual': dateGreaterThanOrEqual,
                'date.lessThanOrEqual': dateLessThanOrEqual,
                'date.equals': dateEquals,
                'date.notEquals': dateNotEquals,
                'date.specified': dateSpecified,
                'date.in': dateIn,
                'date.notIn': dateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeMedicalHistoryId.greaterThan': intakeMedicalHistoryIdGreaterThan,
                'intakeMedicalHistoryId.lessThan': intakeMedicalHistoryIdLessThan,
                'intakeMedicalHistoryId.greaterThanOrEqual': intakeMedicalHistoryIdGreaterThanOrEqual,
                'intakeMedicalHistoryId.lessThanOrEqual': intakeMedicalHistoryIdLessThanOrEqual,
                'intakeMedicalHistoryId.equals': intakeMedicalHistoryIdEquals,
                'intakeMedicalHistoryId.notEquals': intakeMedicalHistoryIdNotEquals,
                'intakeMedicalHistoryId.specified': intakeMedicalHistoryIdSpecified,
                'intakeMedicalHistoryId.in': intakeMedicalHistoryIdIn,
                'intakeMedicalHistoryId.notIn': intakeMedicalHistoryIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns MedicalHistoryDTO OK
     * @throws ApiError
     */
    public static createMedicalHistory(
        requestBody: MedicalHistoryDTO,
    ): CancelablePromise<MedicalHistoryDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/medical-histories',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param conditionNameContains
     * @param conditionNameDoesNotContain
     * @param conditionNameEquals
     * @param conditionNameNotEquals
     * @param conditionNameSpecified
     * @param conditionNameIn
     * @param conditionNameNotIn
     * @param dateGreaterThan
     * @param dateLessThan
     * @param dateGreaterThanOrEqual
     * @param dateLessThanOrEqual
     * @param dateEquals
     * @param dateNotEquals
     * @param dateSpecified
     * @param dateIn
     * @param dateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeMedicalHistoryIdGreaterThan
     * @param intakeMedicalHistoryIdLessThan
     * @param intakeMedicalHistoryIdGreaterThanOrEqual
     * @param intakeMedicalHistoryIdLessThanOrEqual
     * @param intakeMedicalHistoryIdEquals
     * @param intakeMedicalHistoryIdNotEquals
     * @param intakeMedicalHistoryIdSpecified
     * @param intakeMedicalHistoryIdIn
     * @param intakeMedicalHistoryIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countMedicalHistories(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        conditionNameContains?: string,
        conditionNameDoesNotContain?: string,
        conditionNameEquals?: string,
        conditionNameNotEquals?: string,
        conditionNameSpecified?: boolean,
        conditionNameIn?: Array<string>,
        conditionNameNotIn?: Array<string>,
        dateGreaterThan?: string,
        dateLessThan?: string,
        dateGreaterThanOrEqual?: string,
        dateLessThanOrEqual?: string,
        dateEquals?: string,
        dateNotEquals?: string,
        dateSpecified?: boolean,
        dateIn?: Array<string>,
        dateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeMedicalHistoryIdGreaterThan?: number,
        intakeMedicalHistoryIdLessThan?: number,
        intakeMedicalHistoryIdGreaterThanOrEqual?: number,
        intakeMedicalHistoryIdLessThanOrEqual?: number,
        intakeMedicalHistoryIdEquals?: number,
        intakeMedicalHistoryIdNotEquals?: number,
        intakeMedicalHistoryIdSpecified?: boolean,
        intakeMedicalHistoryIdIn?: Array<number>,
        intakeMedicalHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/medical-histories/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'conditionName.contains': conditionNameContains,
                'conditionName.doesNotContain': conditionNameDoesNotContain,
                'conditionName.equals': conditionNameEquals,
                'conditionName.notEquals': conditionNameNotEquals,
                'conditionName.specified': conditionNameSpecified,
                'conditionName.in': conditionNameIn,
                'conditionName.notIn': conditionNameNotIn,
                'date.greaterThan': dateGreaterThan,
                'date.lessThan': dateLessThan,
                'date.greaterThanOrEqual': dateGreaterThanOrEqual,
                'date.lessThanOrEqual': dateLessThanOrEqual,
                'date.equals': dateEquals,
                'date.notEquals': dateNotEquals,
                'date.specified': dateSpecified,
                'date.in': dateIn,
                'date.notIn': dateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeMedicalHistoryId.greaterThan': intakeMedicalHistoryIdGreaterThan,
                'intakeMedicalHistoryId.lessThan': intakeMedicalHistoryIdLessThan,
                'intakeMedicalHistoryId.greaterThanOrEqual': intakeMedicalHistoryIdGreaterThanOrEqual,
                'intakeMedicalHistoryId.lessThanOrEqual': intakeMedicalHistoryIdLessThanOrEqual,
                'intakeMedicalHistoryId.equals': intakeMedicalHistoryIdEquals,
                'intakeMedicalHistoryId.notEquals': intakeMedicalHistoryIdNotEquals,
                'intakeMedicalHistoryId.specified': intakeMedicalHistoryIdSpecified,
                'intakeMedicalHistoryId.in': intakeMedicalHistoryIdIn,
                'intakeMedicalHistoryId.notIn': intakeMedicalHistoryIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
