/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PagePatientMedicationDTO } from '../models/PagePatientMedicationDTO';
import type { PatientMedicationDTO } from '../models/PatientMedicationDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class PatientMedicationResourceService {

    /**
     * @param id
     * @returns PatientMedicationDTO OK
     * @throws ApiError
     */
    public static getPatientMedication(
        id: number,
    ): CancelablePromise<PatientMedicationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-medications/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientMedicationDTO OK
     * @throws ApiError
     */
    public static updatePatientMedication(
        id: number,
        requestBody: PatientMedicationDTO,
    ): CancelablePromise<PatientMedicationDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/patient-medications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns PatientMedicationDTO OK
     * @throws ApiError
     */
    public static partialUpdatePatientMedication(
        id: number,
        requestBody: PatientMedicationDTO,
    ): CancelablePromise<PatientMedicationDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/patient-medications/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param prescribedByIdGreaterThan
     * @param prescribedByIdLessThan
     * @param prescribedByIdGreaterThanOrEqual
     * @param prescribedByIdLessThanOrEqual
     * @param prescribedByIdEquals
     * @param prescribedByIdNotEquals
     * @param prescribedByIdSpecified
     * @param prescribedByIdIn
     * @param prescribedByIdNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PatientMedicationDTO OK
     * @throws ApiError
     */
    public static getAllPatientMedications1(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        prescribedByIdGreaterThan?: number,
        prescribedByIdLessThan?: number,
        prescribedByIdGreaterThanOrEqual?: number,
        prescribedByIdLessThanOrEqual?: number,
        prescribedByIdEquals?: number,
        prescribedByIdNotEquals?: number,
        prescribedByIdSpecified?: boolean,
        prescribedByIdIn?: Array<number>,
        prescribedByIdNotIn?: Array<number>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<PatientMedicationDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-medications',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'prescribedById.greaterThan': prescribedByIdGreaterThan,
                'prescribedById.lessThan': prescribedByIdLessThan,
                'prescribedById.greaterThanOrEqual': prescribedByIdGreaterThanOrEqual,
                'prescribedById.lessThanOrEqual': prescribedByIdLessThanOrEqual,
                'prescribedById.equals': prescribedByIdEquals,
                'prescribedById.notEquals': prescribedByIdNotEquals,
                'prescribedById.specified': prescribedByIdSpecified,
                'prescribedById.in': prescribedByIdIn,
                'prescribedById.notIn': prescribedByIdNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns PatientMedicationDTO OK
     * @throws ApiError
     */
    public static createPatientMedication(
        requestBody: PatientMedicationDTO,
    ): CancelablePromise<PatientMedicationDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/patient-medications',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param patientUuid
     * @param status
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns PagePatientMedicationDTO OK
     * @throws ApiError
     */
    public static getAllPatientMedications(
        patientUuid: string,
        status: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<PagePatientMedicationDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient/{patientUuid}/medications',
            path: {
                'patientUuid': patientUuid,
            },
            query: {
                'page': page,
                'size': size,
                'sort': sort,
                'status': status,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param nameContains
     * @param nameDoesNotContain
     * @param nameEquals
     * @param nameNotEquals
     * @param nameSpecified
     * @param nameIn
     * @param nameNotIn
     * @param quantityContains
     * @param quantityDoesNotContain
     * @param quantityEquals
     * @param quantityNotEquals
     * @param quantitySpecified
     * @param quantityIn
     * @param quantityNotIn
     * @param unitContains
     * @param unitDoesNotContain
     * @param unitEquals
     * @param unitNotEquals
     * @param unitSpecified
     * @param unitIn
     * @param unitNotIn
     * @param doseContains
     * @param doseDoesNotContain
     * @param doseEquals
     * @param doseNotEquals
     * @param doseSpecified
     * @param doseIn
     * @param doseNotIn
     * @param startDateGreaterThan
     * @param startDateLessThan
     * @param startDateGreaterThanOrEqual
     * @param startDateLessThanOrEqual
     * @param startDateEquals
     * @param startDateNotEquals
     * @param startDateSpecified
     * @param startDateIn
     * @param startDateNotIn
     * @param endDateGreaterThan
     * @param endDateLessThan
     * @param endDateGreaterThanOrEqual
     * @param endDateLessThanOrEqual
     * @param endDateEquals
     * @param endDateNotEquals
     * @param endDateSpecified
     * @param endDateIn
     * @param endDateNotIn
     * @param noteContains
     * @param noteDoesNotContain
     * @param noteEquals
     * @param noteNotEquals
     * @param noteSpecified
     * @param noteIn
     * @param noteNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param approvedEquals
     * @param approvedNotEquals
     * @param approvedSpecified
     * @param approvedIn
     * @param approvedNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param prescribedByIdGreaterThan
     * @param prescribedByIdLessThan
     * @param prescribedByIdGreaterThanOrEqual
     * @param prescribedByIdLessThanOrEqual
     * @param prescribedByIdEquals
     * @param prescribedByIdNotEquals
     * @param prescribedByIdSpecified
     * @param prescribedByIdIn
     * @param prescribedByIdNotIn
     * @param medicationIdIdGreaterThan
     * @param medicationIdIdLessThan
     * @param medicationIdIdGreaterThanOrEqual
     * @param medicationIdIdLessThanOrEqual
     * @param medicationIdIdEquals
     * @param medicationIdIdNotEquals
     * @param medicationIdIdSpecified
     * @param medicationIdIdIn
     * @param medicationIdIdNotIn
     * @param patientIdIdGreaterThan
     * @param patientIdIdLessThan
     * @param patientIdIdGreaterThanOrEqual
     * @param patientIdIdLessThanOrEqual
     * @param patientIdIdEquals
     * @param patientIdIdNotEquals
     * @param patientIdIdSpecified
     * @param patientIdIdIn
     * @param patientIdIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countPatientMedications(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        nameContains?: string,
        nameDoesNotContain?: string,
        nameEquals?: string,
        nameNotEquals?: string,
        nameSpecified?: boolean,
        nameIn?: Array<string>,
        nameNotIn?: Array<string>,
        quantityContains?: string,
        quantityDoesNotContain?: string,
        quantityEquals?: string,
        quantityNotEquals?: string,
        quantitySpecified?: boolean,
        quantityIn?: Array<string>,
        quantityNotIn?: Array<string>,
        unitContains?: string,
        unitDoesNotContain?: string,
        unitEquals?: string,
        unitNotEquals?: string,
        unitSpecified?: boolean,
        unitIn?: Array<string>,
        unitNotIn?: Array<string>,
        doseContains?: string,
        doseDoesNotContain?: string,
        doseEquals?: string,
        doseNotEquals?: string,
        doseSpecified?: boolean,
        doseIn?: Array<string>,
        doseNotIn?: Array<string>,
        startDateGreaterThan?: string,
        startDateLessThan?: string,
        startDateGreaterThanOrEqual?: string,
        startDateLessThanOrEqual?: string,
        startDateEquals?: string,
        startDateNotEquals?: string,
        startDateSpecified?: boolean,
        startDateIn?: Array<string>,
        startDateNotIn?: Array<string>,
        endDateGreaterThan?: string,
        endDateLessThan?: string,
        endDateGreaterThanOrEqual?: string,
        endDateLessThanOrEqual?: string,
        endDateEquals?: string,
        endDateNotEquals?: string,
        endDateSpecified?: boolean,
        endDateIn?: Array<string>,
        endDateNotIn?: Array<string>,
        noteContains?: string,
        noteDoesNotContain?: string,
        noteEquals?: string,
        noteNotEquals?: string,
        noteSpecified?: boolean,
        noteIn?: Array<string>,
        noteNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        approvedEquals?: boolean,
        approvedNotEquals?: boolean,
        approvedSpecified?: boolean,
        approvedIn?: Array<boolean>,
        approvedNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        prescribedByIdGreaterThan?: number,
        prescribedByIdLessThan?: number,
        prescribedByIdGreaterThanOrEqual?: number,
        prescribedByIdLessThanOrEqual?: number,
        prescribedByIdEquals?: number,
        prescribedByIdNotEquals?: number,
        prescribedByIdSpecified?: boolean,
        prescribedByIdIn?: Array<number>,
        prescribedByIdNotIn?: Array<number>,
        medicationIdIdGreaterThan?: number,
        medicationIdIdLessThan?: number,
        medicationIdIdGreaterThanOrEqual?: number,
        medicationIdIdLessThanOrEqual?: number,
        medicationIdIdEquals?: number,
        medicationIdIdNotEquals?: number,
        medicationIdIdSpecified?: boolean,
        medicationIdIdIn?: Array<number>,
        medicationIdIdNotIn?: Array<number>,
        patientIdIdGreaterThan?: number,
        patientIdIdLessThan?: number,
        patientIdIdGreaterThanOrEqual?: number,
        patientIdIdLessThanOrEqual?: number,
        patientIdIdEquals?: number,
        patientIdIdNotEquals?: number,
        patientIdIdSpecified?: boolean,
        patientIdIdIn?: Array<number>,
        patientIdIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/patient-medications/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'name.contains': nameContains,
                'name.doesNotContain': nameDoesNotContain,
                'name.equals': nameEquals,
                'name.notEquals': nameNotEquals,
                'name.specified': nameSpecified,
                'name.in': nameIn,
                'name.notIn': nameNotIn,
                'quantity.contains': quantityContains,
                'quantity.doesNotContain': quantityDoesNotContain,
                'quantity.equals': quantityEquals,
                'quantity.notEquals': quantityNotEquals,
                'quantity.specified': quantitySpecified,
                'quantity.in': quantityIn,
                'quantity.notIn': quantityNotIn,
                'unit.contains': unitContains,
                'unit.doesNotContain': unitDoesNotContain,
                'unit.equals': unitEquals,
                'unit.notEquals': unitNotEquals,
                'unit.specified': unitSpecified,
                'unit.in': unitIn,
                'unit.notIn': unitNotIn,
                'dose.contains': doseContains,
                'dose.doesNotContain': doseDoesNotContain,
                'dose.equals': doseEquals,
                'dose.notEquals': doseNotEquals,
                'dose.specified': doseSpecified,
                'dose.in': doseIn,
                'dose.notIn': doseNotIn,
                'startDate.greaterThan': startDateGreaterThan,
                'startDate.lessThan': startDateLessThan,
                'startDate.greaterThanOrEqual': startDateGreaterThanOrEqual,
                'startDate.lessThanOrEqual': startDateLessThanOrEqual,
                'startDate.equals': startDateEquals,
                'startDate.notEquals': startDateNotEquals,
                'startDate.specified': startDateSpecified,
                'startDate.in': startDateIn,
                'startDate.notIn': startDateNotIn,
                'endDate.greaterThan': endDateGreaterThan,
                'endDate.lessThan': endDateLessThan,
                'endDate.greaterThanOrEqual': endDateGreaterThanOrEqual,
                'endDate.lessThanOrEqual': endDateLessThanOrEqual,
                'endDate.equals': endDateEquals,
                'endDate.notEquals': endDateNotEquals,
                'endDate.specified': endDateSpecified,
                'endDate.in': endDateIn,
                'endDate.notIn': endDateNotIn,
                'note.contains': noteContains,
                'note.doesNotContain': noteDoesNotContain,
                'note.equals': noteEquals,
                'note.notEquals': noteNotEquals,
                'note.specified': noteSpecified,
                'note.in': noteIn,
                'note.notIn': noteNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'approved.equals': approvedEquals,
                'approved.notEquals': approvedNotEquals,
                'approved.specified': approvedSpecified,
                'approved.in': approvedIn,
                'approved.notIn': approvedNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'prescribedById.greaterThan': prescribedByIdGreaterThan,
                'prescribedById.lessThan': prescribedByIdLessThan,
                'prescribedById.greaterThanOrEqual': prescribedByIdGreaterThanOrEqual,
                'prescribedById.lessThanOrEqual': prescribedByIdLessThanOrEqual,
                'prescribedById.equals': prescribedByIdEquals,
                'prescribedById.notEquals': prescribedByIdNotEquals,
                'prescribedById.specified': prescribedByIdSpecified,
                'prescribedById.in': prescribedByIdIn,
                'prescribedById.notIn': prescribedByIdNotIn,
                'medicationIdId.greaterThan': medicationIdIdGreaterThan,
                'medicationIdId.lessThan': medicationIdIdLessThan,
                'medicationIdId.greaterThanOrEqual': medicationIdIdGreaterThanOrEqual,
                'medicationIdId.lessThanOrEqual': medicationIdIdLessThanOrEqual,
                'medicationIdId.equals': medicationIdIdEquals,
                'medicationIdId.notEquals': medicationIdIdNotEquals,
                'medicationIdId.specified': medicationIdIdSpecified,
                'medicationIdId.in': medicationIdIdIn,
                'medicationIdId.notIn': medicationIdIdNotIn,
                'patientIdId.greaterThan': patientIdIdGreaterThan,
                'patientIdId.lessThan': patientIdIdLessThan,
                'patientIdId.greaterThanOrEqual': patientIdIdGreaterThanOrEqual,
                'patientIdId.lessThanOrEqual': patientIdIdLessThanOrEqual,
                'patientIdId.equals': patientIdIdEquals,
                'patientIdId.notEquals': patientIdIdNotEquals,
                'patientIdId.specified': patientIdIdSpecified,
                'patientIdId.in': patientIdIdIn,
                'patientIdId.notIn': patientIdIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'distinct': distinct,
            },
        });
    }

    /**
     * @param patientMedicationUuid
     * @returns any OK
     * @throws ApiError
     */
    public static deletePatientMedication(
        patientMedicationUuid: string,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/patient-medications/{patientMedicationUuid}',
            path: {
                'patientMedicationUuid': patientMedicationUuid,
            },
        });
    }

}
