/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InsurancePolicyHolderDTO } from '../models/InsurancePolicyHolderDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class InsurancePolicyHolderResourceService {

    /**
     * @param id
     * @returns InsurancePolicyHolderDTO OK
     * @throws ApiError
     */
    public static getInsurancePolicyHolder(
        id: number,
    ): CancelablePromise<InsurancePolicyHolderDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-policy-holders/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsurancePolicyHolderDTO OK
     * @throws ApiError
     */
    public static updateInsurancePolicyHolder(
        id: number,
        requestBody: InsurancePolicyHolderDTO,
    ): CancelablePromise<InsurancePolicyHolderDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/insurance-policy-holders/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteInsurancePolicyHolder(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/insurance-policy-holders/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsurancePolicyHolderDTO OK
     * @throws ApiError
     */
    public static partialUpdateInsurancePolicyHolder(
        id: number,
        requestBody: InsurancePolicyHolderDTO,
    ): CancelablePromise<InsurancePolicyHolderDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/insurance-policy-holders/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param firstNameContains
     * @param firstNameDoesNotContain
     * @param firstNameEquals
     * @param firstNameNotEquals
     * @param firstNameSpecified
     * @param firstNameIn
     * @param firstNameNotIn
     * @param lastNameContains
     * @param lastNameDoesNotContain
     * @param lastNameEquals
     * @param lastNameNotEquals
     * @param lastNameSpecified
     * @param lastNameIn
     * @param lastNameNotIn
     * @param dobGreaterThan
     * @param dobLessThan
     * @param dobGreaterThanOrEqual
     * @param dobLessThanOrEqual
     * @param dobEquals
     * @param dobNotEquals
     * @param dobSpecified
     * @param dobIn
     * @param dobNotIn
     * @param genderContains
     * @param genderDoesNotContain
     * @param genderEquals
     * @param genderNotEquals
     * @param genderSpecified
     * @param genderIn
     * @param genderNotIn
     * @param ssnContains
     * @param ssnDoesNotContain
     * @param ssnEquals
     * @param ssnNotEquals
     * @param ssnSpecified
     * @param ssnIn
     * @param ssnNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param addressIdIdGreaterThan
     * @param addressIdIdLessThan
     * @param addressIdIdGreaterThanOrEqual
     * @param addressIdIdLessThanOrEqual
     * @param addressIdIdEquals
     * @param addressIdIdNotEquals
     * @param addressIdIdSpecified
     * @param addressIdIdIn
     * @param addressIdIdNotIn
     * @param insuranceIdIdGreaterThan
     * @param insuranceIdIdLessThan
     * @param insuranceIdIdGreaterThanOrEqual
     * @param insuranceIdIdLessThanOrEqual
     * @param insuranceIdIdEquals
     * @param insuranceIdIdNotEquals
     * @param insuranceIdIdSpecified
     * @param insuranceIdIdIn
     * @param insuranceIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns InsurancePolicyHolderDTO OK
     * @throws ApiError
     */
    public static getAllInsurancePolicyHolders(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        firstNameContains?: string,
        firstNameDoesNotContain?: string,
        firstNameEquals?: string,
        firstNameNotEquals?: string,
        firstNameSpecified?: boolean,
        firstNameIn?: Array<string>,
        firstNameNotIn?: Array<string>,
        lastNameContains?: string,
        lastNameDoesNotContain?: string,
        lastNameEquals?: string,
        lastNameNotEquals?: string,
        lastNameSpecified?: boolean,
        lastNameIn?: Array<string>,
        lastNameNotIn?: Array<string>,
        dobGreaterThan?: string,
        dobLessThan?: string,
        dobGreaterThanOrEqual?: string,
        dobLessThanOrEqual?: string,
        dobEquals?: string,
        dobNotEquals?: string,
        dobSpecified?: boolean,
        dobIn?: Array<string>,
        dobNotIn?: Array<string>,
        genderContains?: string,
        genderDoesNotContain?: string,
        genderEquals?: string,
        genderNotEquals?: string,
        genderSpecified?: boolean,
        genderIn?: Array<string>,
        genderNotIn?: Array<string>,
        ssnContains?: string,
        ssnDoesNotContain?: string,
        ssnEquals?: string,
        ssnNotEquals?: string,
        ssnSpecified?: boolean,
        ssnIn?: Array<string>,
        ssnNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        addressIdIdGreaterThan?: number,
        addressIdIdLessThan?: number,
        addressIdIdGreaterThanOrEqual?: number,
        addressIdIdLessThanOrEqual?: number,
        addressIdIdEquals?: number,
        addressIdIdNotEquals?: number,
        addressIdIdSpecified?: boolean,
        addressIdIdIn?: Array<number>,
        addressIdIdNotIn?: Array<number>,
        insuranceIdIdGreaterThan?: number,
        insuranceIdIdLessThan?: number,
        insuranceIdIdGreaterThanOrEqual?: number,
        insuranceIdIdLessThanOrEqual?: number,
        insuranceIdIdEquals?: number,
        insuranceIdIdNotEquals?: number,
        insuranceIdIdSpecified?: boolean,
        insuranceIdIdIn?: Array<number>,
        insuranceIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<InsurancePolicyHolderDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-policy-holders',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'firstName.contains': firstNameContains,
                'firstName.doesNotContain': firstNameDoesNotContain,
                'firstName.equals': firstNameEquals,
                'firstName.notEquals': firstNameNotEquals,
                'firstName.specified': firstNameSpecified,
                'firstName.in': firstNameIn,
                'firstName.notIn': firstNameNotIn,
                'lastName.contains': lastNameContains,
                'lastName.doesNotContain': lastNameDoesNotContain,
                'lastName.equals': lastNameEquals,
                'lastName.notEquals': lastNameNotEquals,
                'lastName.specified': lastNameSpecified,
                'lastName.in': lastNameIn,
                'lastName.notIn': lastNameNotIn,
                'dob.greaterThan': dobGreaterThan,
                'dob.lessThan': dobLessThan,
                'dob.greaterThanOrEqual': dobGreaterThanOrEqual,
                'dob.lessThanOrEqual': dobLessThanOrEqual,
                'dob.equals': dobEquals,
                'dob.notEquals': dobNotEquals,
                'dob.specified': dobSpecified,
                'dob.in': dobIn,
                'dob.notIn': dobNotIn,
                'gender.contains': genderContains,
                'gender.doesNotContain': genderDoesNotContain,
                'gender.equals': genderEquals,
                'gender.notEquals': genderNotEquals,
                'gender.specified': genderSpecified,
                'gender.in': genderIn,
                'gender.notIn': genderNotIn,
                'ssn.contains': ssnContains,
                'ssn.doesNotContain': ssnDoesNotContain,
                'ssn.equals': ssnEquals,
                'ssn.notEquals': ssnNotEquals,
                'ssn.specified': ssnSpecified,
                'ssn.in': ssnIn,
                'ssn.notIn': ssnNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'addressIdId.greaterThan': addressIdIdGreaterThan,
                'addressIdId.lessThan': addressIdIdLessThan,
                'addressIdId.greaterThanOrEqual': addressIdIdGreaterThanOrEqual,
                'addressIdId.lessThanOrEqual': addressIdIdLessThanOrEqual,
                'addressIdId.equals': addressIdIdEquals,
                'addressIdId.notEquals': addressIdIdNotEquals,
                'addressIdId.specified': addressIdIdSpecified,
                'addressIdId.in': addressIdIdIn,
                'addressIdId.notIn': addressIdIdNotIn,
                'insuranceIdId.greaterThan': insuranceIdIdGreaterThan,
                'insuranceIdId.lessThan': insuranceIdIdLessThan,
                'insuranceIdId.greaterThanOrEqual': insuranceIdIdGreaterThanOrEqual,
                'insuranceIdId.lessThanOrEqual': insuranceIdIdLessThanOrEqual,
                'insuranceIdId.equals': insuranceIdIdEquals,
                'insuranceIdId.notEquals': insuranceIdIdNotEquals,
                'insuranceIdId.specified': insuranceIdIdSpecified,
                'insuranceIdId.in': insuranceIdIdIn,
                'insuranceIdId.notIn': insuranceIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns InsurancePolicyHolderDTO OK
     * @throws ApiError
     */
    public static createInsurancePolicyHolder(
        requestBody: InsurancePolicyHolderDTO,
    ): CancelablePromise<InsurancePolicyHolderDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/insurance-policy-holders',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param firstNameContains
     * @param firstNameDoesNotContain
     * @param firstNameEquals
     * @param firstNameNotEquals
     * @param firstNameSpecified
     * @param firstNameIn
     * @param firstNameNotIn
     * @param lastNameContains
     * @param lastNameDoesNotContain
     * @param lastNameEquals
     * @param lastNameNotEquals
     * @param lastNameSpecified
     * @param lastNameIn
     * @param lastNameNotIn
     * @param dobGreaterThan
     * @param dobLessThan
     * @param dobGreaterThanOrEqual
     * @param dobLessThanOrEqual
     * @param dobEquals
     * @param dobNotEquals
     * @param dobSpecified
     * @param dobIn
     * @param dobNotIn
     * @param genderContains
     * @param genderDoesNotContain
     * @param genderEquals
     * @param genderNotEquals
     * @param genderSpecified
     * @param genderIn
     * @param genderNotIn
     * @param ssnContains
     * @param ssnDoesNotContain
     * @param ssnEquals
     * @param ssnNotEquals
     * @param ssnSpecified
     * @param ssnIn
     * @param ssnNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param addressIdIdGreaterThan
     * @param addressIdIdLessThan
     * @param addressIdIdGreaterThanOrEqual
     * @param addressIdIdLessThanOrEqual
     * @param addressIdIdEquals
     * @param addressIdIdNotEquals
     * @param addressIdIdSpecified
     * @param addressIdIdIn
     * @param addressIdIdNotIn
     * @param insuranceIdIdGreaterThan
     * @param insuranceIdIdLessThan
     * @param insuranceIdIdGreaterThanOrEqual
     * @param insuranceIdIdLessThanOrEqual
     * @param insuranceIdIdEquals
     * @param insuranceIdIdNotEquals
     * @param insuranceIdIdSpecified
     * @param insuranceIdIdIn
     * @param insuranceIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countInsurancePolicyHolders(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        firstNameContains?: string,
        firstNameDoesNotContain?: string,
        firstNameEquals?: string,
        firstNameNotEquals?: string,
        firstNameSpecified?: boolean,
        firstNameIn?: Array<string>,
        firstNameNotIn?: Array<string>,
        lastNameContains?: string,
        lastNameDoesNotContain?: string,
        lastNameEquals?: string,
        lastNameNotEquals?: string,
        lastNameSpecified?: boolean,
        lastNameIn?: Array<string>,
        lastNameNotIn?: Array<string>,
        dobGreaterThan?: string,
        dobLessThan?: string,
        dobGreaterThanOrEqual?: string,
        dobLessThanOrEqual?: string,
        dobEquals?: string,
        dobNotEquals?: string,
        dobSpecified?: boolean,
        dobIn?: Array<string>,
        dobNotIn?: Array<string>,
        genderContains?: string,
        genderDoesNotContain?: string,
        genderEquals?: string,
        genderNotEquals?: string,
        genderSpecified?: boolean,
        genderIn?: Array<string>,
        genderNotIn?: Array<string>,
        ssnContains?: string,
        ssnDoesNotContain?: string,
        ssnEquals?: string,
        ssnNotEquals?: string,
        ssnSpecified?: boolean,
        ssnIn?: Array<string>,
        ssnNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        addressIdIdGreaterThan?: number,
        addressIdIdLessThan?: number,
        addressIdIdGreaterThanOrEqual?: number,
        addressIdIdLessThanOrEqual?: number,
        addressIdIdEquals?: number,
        addressIdIdNotEquals?: number,
        addressIdIdSpecified?: boolean,
        addressIdIdIn?: Array<number>,
        addressIdIdNotIn?: Array<number>,
        insuranceIdIdGreaterThan?: number,
        insuranceIdIdLessThan?: number,
        insuranceIdIdGreaterThanOrEqual?: number,
        insuranceIdIdLessThanOrEqual?: number,
        insuranceIdIdEquals?: number,
        insuranceIdIdNotEquals?: number,
        insuranceIdIdSpecified?: boolean,
        insuranceIdIdIn?: Array<number>,
        insuranceIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurance-policy-holders/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'firstName.contains': firstNameContains,
                'firstName.doesNotContain': firstNameDoesNotContain,
                'firstName.equals': firstNameEquals,
                'firstName.notEquals': firstNameNotEquals,
                'firstName.specified': firstNameSpecified,
                'firstName.in': firstNameIn,
                'firstName.notIn': firstNameNotIn,
                'lastName.contains': lastNameContains,
                'lastName.doesNotContain': lastNameDoesNotContain,
                'lastName.equals': lastNameEquals,
                'lastName.notEquals': lastNameNotEquals,
                'lastName.specified': lastNameSpecified,
                'lastName.in': lastNameIn,
                'lastName.notIn': lastNameNotIn,
                'dob.greaterThan': dobGreaterThan,
                'dob.lessThan': dobLessThan,
                'dob.greaterThanOrEqual': dobGreaterThanOrEqual,
                'dob.lessThanOrEqual': dobLessThanOrEqual,
                'dob.equals': dobEquals,
                'dob.notEquals': dobNotEquals,
                'dob.specified': dobSpecified,
                'dob.in': dobIn,
                'dob.notIn': dobNotIn,
                'gender.contains': genderContains,
                'gender.doesNotContain': genderDoesNotContain,
                'gender.equals': genderEquals,
                'gender.notEquals': genderNotEquals,
                'gender.specified': genderSpecified,
                'gender.in': genderIn,
                'gender.notIn': genderNotIn,
                'ssn.contains': ssnContains,
                'ssn.doesNotContain': ssnDoesNotContain,
                'ssn.equals': ssnEquals,
                'ssn.notEquals': ssnNotEquals,
                'ssn.specified': ssnSpecified,
                'ssn.in': ssnIn,
                'ssn.notIn': ssnNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'addressIdId.greaterThan': addressIdIdGreaterThan,
                'addressIdId.lessThan': addressIdIdLessThan,
                'addressIdId.greaterThanOrEqual': addressIdIdGreaterThanOrEqual,
                'addressIdId.lessThanOrEqual': addressIdIdLessThanOrEqual,
                'addressIdId.equals': addressIdIdEquals,
                'addressIdId.notEquals': addressIdIdNotEquals,
                'addressIdId.specified': addressIdIdSpecified,
                'addressIdId.in': addressIdIdIn,
                'addressIdId.notIn': addressIdIdNotIn,
                'insuranceIdId.greaterThan': insuranceIdIdGreaterThan,
                'insuranceIdId.lessThan': insuranceIdIdLessThan,
                'insuranceIdId.greaterThanOrEqual': insuranceIdIdGreaterThanOrEqual,
                'insuranceIdId.lessThanOrEqual': insuranceIdIdLessThanOrEqual,
                'insuranceIdId.equals': insuranceIdIdEquals,
                'insuranceIdId.notEquals': insuranceIdIdNotEquals,
                'insuranceIdId.specified': insuranceIdIdSpecified,
                'insuranceIdId.in': insuranceIdIdIn,
                'insuranceIdId.notIn': insuranceIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
