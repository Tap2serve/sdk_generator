/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ProviderAvailabilityDTO } from '../models/ProviderAvailabilityDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class ProviderAvailabilityResourceService {

    /**
     * @param id
     * @returns ProviderAvailabilityDTO OK
     * @throws ApiError
     */
    public static getProviderAvailability(
        id: number,
    ): CancelablePromise<ProviderAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns ProviderAvailabilityDTO OK
     * @throws ApiError
     */
    public static updateProviderAvailability(
        id: number,
        requestBody: ProviderAvailabilityDTO,
    ): CancelablePromise<ProviderAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/provider-availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteProviderAvailability(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/provider-availabilities/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns ProviderAvailabilityDTO OK
     * @throws ApiError
     */
    public static partialUpdateProviderAvailability(
        id: number,
        requestBody: ProviderAvailabilityDTO,
    ): CancelablePromise<ProviderAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/provider-availabilities/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param weekDayContains
     * @param weekDayDoesNotContain
     * @param weekDayEquals
     * @param weekDayNotEquals
     * @param weekDaySpecified
     * @param weekDayIn
     * @param weekDayNotIn
     * @param openingTimeGreaterThan
     * @param openingTimeLessThan
     * @param openingTimeGreaterThanOrEqual
     * @param openingTimeLessThanOrEqual
     * @param openingTimeEquals
     * @param openingTimeNotEquals
     * @param openingTimeSpecified
     * @param openingTimeIn
     * @param openingTimeNotIn
     * @param closingTimeGreaterThan
     * @param closingTimeLessThan
     * @param closingTimeGreaterThanOrEqual
     * @param closingTimeLessThanOrEqual
     * @param closingTimeEquals
     * @param closingTimeNotEquals
     * @param closingTimeSpecified
     * @param closingTimeIn
     * @param closingTimeNotIn
     * @param availabilityIdIdGreaterThan
     * @param availabilityIdIdLessThan
     * @param availabilityIdIdGreaterThanOrEqual
     * @param availabilityIdIdLessThanOrEqual
     * @param availabilityIdIdEquals
     * @param availabilityIdIdNotEquals
     * @param availabilityIdIdSpecified
     * @param availabilityIdIdIn
     * @param availabilityIdIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns ProviderAvailabilityDTO OK
     * @throws ApiError
     */
    public static getAllProviderAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        weekDayContains?: string,
        weekDayDoesNotContain?: string,
        weekDayEquals?: string,
        weekDayNotEquals?: string,
        weekDaySpecified?: boolean,
        weekDayIn?: Array<string>,
        weekDayNotIn?: Array<string>,
        openingTimeGreaterThan?: string,
        openingTimeLessThan?: string,
        openingTimeGreaterThanOrEqual?: string,
        openingTimeLessThanOrEqual?: string,
        openingTimeEquals?: string,
        openingTimeNotEquals?: string,
        openingTimeSpecified?: boolean,
        openingTimeIn?: Array<string>,
        openingTimeNotIn?: Array<string>,
        closingTimeGreaterThan?: string,
        closingTimeLessThan?: string,
        closingTimeGreaterThanOrEqual?: string,
        closingTimeLessThanOrEqual?: string,
        closingTimeEquals?: string,
        closingTimeNotEquals?: string,
        closingTimeSpecified?: boolean,
        closingTimeIn?: Array<string>,
        closingTimeNotIn?: Array<string>,
        availabilityIdIdGreaterThan?: number,
        availabilityIdIdLessThan?: number,
        availabilityIdIdGreaterThanOrEqual?: number,
        availabilityIdIdLessThanOrEqual?: number,
        availabilityIdIdEquals?: number,
        availabilityIdIdNotEquals?: number,
        availabilityIdIdSpecified?: boolean,
        availabilityIdIdIn?: Array<number>,
        availabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<ProviderAvailabilityDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-availabilities',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'weekDay.contains': weekDayContains,
                'weekDay.doesNotContain': weekDayDoesNotContain,
                'weekDay.equals': weekDayEquals,
                'weekDay.notEquals': weekDayNotEquals,
                'weekDay.specified': weekDaySpecified,
                'weekDay.in': weekDayIn,
                'weekDay.notIn': weekDayNotIn,
                'openingTime.greaterThan': openingTimeGreaterThan,
                'openingTime.lessThan': openingTimeLessThan,
                'openingTime.greaterThanOrEqual': openingTimeGreaterThanOrEqual,
                'openingTime.lessThanOrEqual': openingTimeLessThanOrEqual,
                'openingTime.equals': openingTimeEquals,
                'openingTime.notEquals': openingTimeNotEquals,
                'openingTime.specified': openingTimeSpecified,
                'openingTime.in': openingTimeIn,
                'openingTime.notIn': openingTimeNotIn,
                'closingTime.greaterThan': closingTimeGreaterThan,
                'closingTime.lessThan': closingTimeLessThan,
                'closingTime.greaterThanOrEqual': closingTimeGreaterThanOrEqual,
                'closingTime.lessThanOrEqual': closingTimeLessThanOrEqual,
                'closingTime.equals': closingTimeEquals,
                'closingTime.notEquals': closingTimeNotEquals,
                'closingTime.specified': closingTimeSpecified,
                'closingTime.in': closingTimeIn,
                'closingTime.notIn': closingTimeNotIn,
                'availabilityIdId.greaterThan': availabilityIdIdGreaterThan,
                'availabilityIdId.lessThan': availabilityIdIdLessThan,
                'availabilityIdId.greaterThanOrEqual': availabilityIdIdGreaterThanOrEqual,
                'availabilityIdId.lessThanOrEqual': availabilityIdIdLessThanOrEqual,
                'availabilityIdId.equals': availabilityIdIdEquals,
                'availabilityIdId.notEquals': availabilityIdIdNotEquals,
                'availabilityIdId.specified': availabilityIdIdSpecified,
                'availabilityIdId.in': availabilityIdIdIn,
                'availabilityIdId.notIn': availabilityIdIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns ProviderAvailabilityDTO OK
     * @throws ApiError
     */
    public static createProviderAvailability(
        requestBody: ProviderAvailabilityDTO,
    ): CancelablePromise<ProviderAvailabilityDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/provider-availabilities',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param weekDayContains
     * @param weekDayDoesNotContain
     * @param weekDayEquals
     * @param weekDayNotEquals
     * @param weekDaySpecified
     * @param weekDayIn
     * @param weekDayNotIn
     * @param openingTimeGreaterThan
     * @param openingTimeLessThan
     * @param openingTimeGreaterThanOrEqual
     * @param openingTimeLessThanOrEqual
     * @param openingTimeEquals
     * @param openingTimeNotEquals
     * @param openingTimeSpecified
     * @param openingTimeIn
     * @param openingTimeNotIn
     * @param closingTimeGreaterThan
     * @param closingTimeLessThan
     * @param closingTimeGreaterThanOrEqual
     * @param closingTimeLessThanOrEqual
     * @param closingTimeEquals
     * @param closingTimeNotEquals
     * @param closingTimeSpecified
     * @param closingTimeIn
     * @param closingTimeNotIn
     * @param availabilityIdIdGreaterThan
     * @param availabilityIdIdLessThan
     * @param availabilityIdIdGreaterThanOrEqual
     * @param availabilityIdIdLessThanOrEqual
     * @param availabilityIdIdEquals
     * @param availabilityIdIdNotEquals
     * @param availabilityIdIdSpecified
     * @param availabilityIdIdIn
     * @param availabilityIdIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countProviderAvailabilities(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        weekDayContains?: string,
        weekDayDoesNotContain?: string,
        weekDayEquals?: string,
        weekDayNotEquals?: string,
        weekDaySpecified?: boolean,
        weekDayIn?: Array<string>,
        weekDayNotIn?: Array<string>,
        openingTimeGreaterThan?: string,
        openingTimeLessThan?: string,
        openingTimeGreaterThanOrEqual?: string,
        openingTimeLessThanOrEqual?: string,
        openingTimeEquals?: string,
        openingTimeNotEquals?: string,
        openingTimeSpecified?: boolean,
        openingTimeIn?: Array<string>,
        openingTimeNotIn?: Array<string>,
        closingTimeGreaterThan?: string,
        closingTimeLessThan?: string,
        closingTimeGreaterThanOrEqual?: string,
        closingTimeLessThanOrEqual?: string,
        closingTimeEquals?: string,
        closingTimeNotEquals?: string,
        closingTimeSpecified?: boolean,
        closingTimeIn?: Array<string>,
        closingTimeNotIn?: Array<string>,
        availabilityIdIdGreaterThan?: number,
        availabilityIdIdLessThan?: number,
        availabilityIdIdGreaterThanOrEqual?: number,
        availabilityIdIdLessThanOrEqual?: number,
        availabilityIdIdEquals?: number,
        availabilityIdIdNotEquals?: number,
        availabilityIdIdSpecified?: boolean,
        availabilityIdIdIn?: Array<number>,
        availabilityIdIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/provider-availabilities/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'weekDay.contains': weekDayContains,
                'weekDay.doesNotContain': weekDayDoesNotContain,
                'weekDay.equals': weekDayEquals,
                'weekDay.notEquals': weekDayNotEquals,
                'weekDay.specified': weekDaySpecified,
                'weekDay.in': weekDayIn,
                'weekDay.notIn': weekDayNotIn,
                'openingTime.greaterThan': openingTimeGreaterThan,
                'openingTime.lessThan': openingTimeLessThan,
                'openingTime.greaterThanOrEqual': openingTimeGreaterThanOrEqual,
                'openingTime.lessThanOrEqual': openingTimeLessThanOrEqual,
                'openingTime.equals': openingTimeEquals,
                'openingTime.notEquals': openingTimeNotEquals,
                'openingTime.specified': openingTimeSpecified,
                'openingTime.in': openingTimeIn,
                'openingTime.notIn': openingTimeNotIn,
                'closingTime.greaterThan': closingTimeGreaterThan,
                'closingTime.lessThan': closingTimeLessThan,
                'closingTime.greaterThanOrEqual': closingTimeGreaterThanOrEqual,
                'closingTime.lessThanOrEqual': closingTimeLessThanOrEqual,
                'closingTime.equals': closingTimeEquals,
                'closingTime.notEquals': closingTimeNotEquals,
                'closingTime.specified': closingTimeSpecified,
                'closingTime.in': closingTimeIn,
                'closingTime.notIn': closingTimeNotIn,
                'availabilityIdId.greaterThan': availabilityIdIdGreaterThan,
                'availabilityIdId.lessThan': availabilityIdIdLessThan,
                'availabilityIdId.greaterThanOrEqual': availabilityIdIdGreaterThanOrEqual,
                'availabilityIdId.lessThanOrEqual': availabilityIdIdLessThanOrEqual,
                'availabilityIdId.equals': availabilityIdIdEquals,
                'availabilityIdId.notEquals': availabilityIdIdNotEquals,
                'availabilityIdId.specified': availabilityIdIdSpecified,
                'availabilityIdId.in': availabilityIdIdIn,
                'availabilityIdId.notIn': availabilityIdIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
