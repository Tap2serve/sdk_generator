/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InsuranceDTO } from '../models/InsuranceDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class InsuranceResourceService {

    /**
     * @param id
     * @param requestBody
     * @returns InsuranceDTO OK
     * @throws ApiError
     */
    public static updateInsurance(
        id: number,
        requestBody: InsuranceDTO,
    ): CancelablePromise<InsuranceDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/insurances/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteInsurance(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/insurances/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns InsuranceDTO OK
     * @throws ApiError
     */
    public static partialUpdateInsurance(
        id: number,
        requestBody: InsuranceDTO,
    ): CancelablePromise<InsuranceDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/insurances/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param memberIdContains
     * @param memberIdDoesNotContain
     * @param memberIdEquals
     * @param memberIdNotEquals
     * @param memberIdSpecified
     * @param memberIdIn
     * @param memberIdNotIn
     * @param planIdContains
     * @param planIdDoesNotContain
     * @param planIdEquals
     * @param planIdNotEquals
     * @param planIdSpecified
     * @param planIdIn
     * @param planIdNotIn
     * @param groupIdContains
     * @param groupIdDoesNotContain
     * @param groupIdEquals
     * @param groupIdNotEquals
     * @param groupIdSpecified
     * @param groupIdIn
     * @param groupIdNotIn
     * @param groupNameContains
     * @param groupNameDoesNotContain
     * @param groupNameEquals
     * @param groupNameNotEquals
     * @param groupNameSpecified
     * @param groupNameIn
     * @param groupNameNotIn
     * @param copayGreaterThan
     * @param copayLessThan
     * @param copayGreaterThanOrEqual
     * @param copayLessThanOrEqual
     * @param copayEquals
     * @param copayNotEquals
     * @param copaySpecified
     * @param copayIn
     * @param copayNotIn
     * @param relationshipWithHolderEquals
     * @param relationshipWithHolderNotEquals
     * @param relationshipWithHolderSpecified
     * @param relationshipWithHolderIn
     * @param relationshipWithHolderNotIn
     * @param cardFrontSideContains
     * @param cardFrontSideDoesNotContain
     * @param cardFrontSideEquals
     * @param cardFrontSideNotEquals
     * @param cardFrontSideSpecified
     * @param cardFrontSideIn
     * @param cardFrontSideNotIn
     * @param cardBackSideContains
     * @param cardBackSideDoesNotContain
     * @param cardBackSideEquals
     * @param cardBackSideNotEquals
     * @param cardBackSideSpecified
     * @param cardBackSideIn
     * @param cardBackSideNotIn
     * @param payerPhoneNumberContains
     * @param payerPhoneNumberDoesNotContain
     * @param payerPhoneNumberEquals
     * @param payerPhoneNumberNotEquals
     * @param payerPhoneNumberSpecified
     * @param payerPhoneNumberIn
     * @param payerPhoneNumberNotIn
     * @param payerFaxNumberContains
     * @param payerFaxNumberDoesNotContain
     * @param payerFaxNumberEquals
     * @param payerFaxNumberNotEquals
     * @param payerFaxNumberSpecified
     * @param payerFaxNumberIn
     * @param payerFaxNumberNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param primaryInsuranceAppointmentIdGreaterThan
     * @param primaryInsuranceAppointmentIdLessThan
     * @param primaryInsuranceAppointmentIdGreaterThanOrEqual
     * @param primaryInsuranceAppointmentIdLessThanOrEqual
     * @param primaryInsuranceAppointmentIdEquals
     * @param primaryInsuranceAppointmentIdNotEquals
     * @param primaryInsuranceAppointmentIdSpecified
     * @param primaryInsuranceAppointmentIdIn
     * @param primaryInsuranceAppointmentIdNotIn
     * @param secondaryInsuranceAppointmentIdGreaterThan
     * @param secondaryInsuranceAppointmentIdLessThan
     * @param secondaryInsuranceAppointmentIdGreaterThanOrEqual
     * @param secondaryInsuranceAppointmentIdLessThanOrEqual
     * @param secondaryInsuranceAppointmentIdEquals
     * @param secondaryInsuranceAppointmentIdNotEquals
     * @param secondaryInsuranceAppointmentIdSpecified
     * @param secondaryInsuranceAppointmentIdIn
     * @param secondaryInsuranceAppointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param insurancePolicyHolderIdGreaterThan
     * @param insurancePolicyHolderIdLessThan
     * @param insurancePolicyHolderIdGreaterThanOrEqual
     * @param insurancePolicyHolderIdLessThanOrEqual
     * @param insurancePolicyHolderIdEquals
     * @param insurancePolicyHolderIdNotEquals
     * @param insurancePolicyHolderIdSpecified
     * @param insurancePolicyHolderIdIn
     * @param insurancePolicyHolderIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns InsuranceDTO OK
     * @throws ApiError
     */
    public static getAllInsurances(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeEquals?: 'PRIMARY' | 'SECONDARY' | 'OTHER',
        typeNotEquals?: 'PRIMARY' | 'SECONDARY' | 'OTHER',
        typeSpecified?: boolean,
        typeIn?: Array<'PRIMARY' | 'SECONDARY' | 'OTHER'>,
        typeNotIn?: Array<'PRIMARY' | 'SECONDARY' | 'OTHER'>,
        memberIdContains?: string,
        memberIdDoesNotContain?: string,
        memberIdEquals?: string,
        memberIdNotEquals?: string,
        memberIdSpecified?: boolean,
        memberIdIn?: Array<string>,
        memberIdNotIn?: Array<string>,
        planIdContains?: string,
        planIdDoesNotContain?: string,
        planIdEquals?: string,
        planIdNotEquals?: string,
        planIdSpecified?: boolean,
        planIdIn?: Array<string>,
        planIdNotIn?: Array<string>,
        groupIdContains?: string,
        groupIdDoesNotContain?: string,
        groupIdEquals?: string,
        groupIdNotEquals?: string,
        groupIdSpecified?: boolean,
        groupIdIn?: Array<string>,
        groupIdNotIn?: Array<string>,
        groupNameContains?: string,
        groupNameDoesNotContain?: string,
        groupNameEquals?: string,
        groupNameNotEquals?: string,
        groupNameSpecified?: boolean,
        groupNameIn?: Array<string>,
        groupNameNotIn?: Array<string>,
        copayGreaterThan?: number,
        copayLessThan?: number,
        copayGreaterThanOrEqual?: number,
        copayLessThanOrEqual?: number,
        copayEquals?: number,
        copayNotEquals?: number,
        copaySpecified?: boolean,
        copayIn?: Array<number>,
        copayNotIn?: Array<number>,
        relationshipWithHolderEquals?: 'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE',
        relationshipWithHolderNotEquals?: 'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE',
        relationshipWithHolderSpecified?: boolean,
        relationshipWithHolderIn?: Array<'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE'>,
        relationshipWithHolderNotIn?: Array<'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE'>,
        cardFrontSideContains?: string,
        cardFrontSideDoesNotContain?: string,
        cardFrontSideEquals?: string,
        cardFrontSideNotEquals?: string,
        cardFrontSideSpecified?: boolean,
        cardFrontSideIn?: Array<string>,
        cardFrontSideNotIn?: Array<string>,
        cardBackSideContains?: string,
        cardBackSideDoesNotContain?: string,
        cardBackSideEquals?: string,
        cardBackSideNotEquals?: string,
        cardBackSideSpecified?: boolean,
        cardBackSideIn?: Array<string>,
        cardBackSideNotIn?: Array<string>,
        payerPhoneNumberContains?: string,
        payerPhoneNumberDoesNotContain?: string,
        payerPhoneNumberEquals?: string,
        payerPhoneNumberNotEquals?: string,
        payerPhoneNumberSpecified?: boolean,
        payerPhoneNumberIn?: Array<string>,
        payerPhoneNumberNotIn?: Array<string>,
        payerFaxNumberContains?: string,
        payerFaxNumberDoesNotContain?: string,
        payerFaxNumberEquals?: string,
        payerFaxNumberNotEquals?: string,
        payerFaxNumberSpecified?: boolean,
        payerFaxNumberIn?: Array<string>,
        payerFaxNumberNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        primaryInsuranceAppointmentIdGreaterThan?: number,
        primaryInsuranceAppointmentIdLessThan?: number,
        primaryInsuranceAppointmentIdGreaterThanOrEqual?: number,
        primaryInsuranceAppointmentIdLessThanOrEqual?: number,
        primaryInsuranceAppointmentIdEquals?: number,
        primaryInsuranceAppointmentIdNotEquals?: number,
        primaryInsuranceAppointmentIdSpecified?: boolean,
        primaryInsuranceAppointmentIdIn?: Array<number>,
        primaryInsuranceAppointmentIdNotIn?: Array<number>,
        secondaryInsuranceAppointmentIdGreaterThan?: number,
        secondaryInsuranceAppointmentIdLessThan?: number,
        secondaryInsuranceAppointmentIdGreaterThanOrEqual?: number,
        secondaryInsuranceAppointmentIdLessThanOrEqual?: number,
        secondaryInsuranceAppointmentIdEquals?: number,
        secondaryInsuranceAppointmentIdNotEquals?: number,
        secondaryInsuranceAppointmentIdSpecified?: boolean,
        secondaryInsuranceAppointmentIdIn?: Array<number>,
        secondaryInsuranceAppointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        insurancePolicyHolderIdGreaterThan?: number,
        insurancePolicyHolderIdLessThan?: number,
        insurancePolicyHolderIdGreaterThanOrEqual?: number,
        insurancePolicyHolderIdLessThanOrEqual?: number,
        insurancePolicyHolderIdEquals?: number,
        insurancePolicyHolderIdNotEquals?: number,
        insurancePolicyHolderIdSpecified?: boolean,
        insurancePolicyHolderIdIn?: Array<number>,
        insurancePolicyHolderIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<InsuranceDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurances',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'memberId.contains': memberIdContains,
                'memberId.doesNotContain': memberIdDoesNotContain,
                'memberId.equals': memberIdEquals,
                'memberId.notEquals': memberIdNotEquals,
                'memberId.specified': memberIdSpecified,
                'memberId.in': memberIdIn,
                'memberId.notIn': memberIdNotIn,
                'planId.contains': planIdContains,
                'planId.doesNotContain': planIdDoesNotContain,
                'planId.equals': planIdEquals,
                'planId.notEquals': planIdNotEquals,
                'planId.specified': planIdSpecified,
                'planId.in': planIdIn,
                'planId.notIn': planIdNotIn,
                'groupId.contains': groupIdContains,
                'groupId.doesNotContain': groupIdDoesNotContain,
                'groupId.equals': groupIdEquals,
                'groupId.notEquals': groupIdNotEquals,
                'groupId.specified': groupIdSpecified,
                'groupId.in': groupIdIn,
                'groupId.notIn': groupIdNotIn,
                'groupName.contains': groupNameContains,
                'groupName.doesNotContain': groupNameDoesNotContain,
                'groupName.equals': groupNameEquals,
                'groupName.notEquals': groupNameNotEquals,
                'groupName.specified': groupNameSpecified,
                'groupName.in': groupNameIn,
                'groupName.notIn': groupNameNotIn,
                'copay.greaterThan': copayGreaterThan,
                'copay.lessThan': copayLessThan,
                'copay.greaterThanOrEqual': copayGreaterThanOrEqual,
                'copay.lessThanOrEqual': copayLessThanOrEqual,
                'copay.equals': copayEquals,
                'copay.notEquals': copayNotEquals,
                'copay.specified': copaySpecified,
                'copay.in': copayIn,
                'copay.notIn': copayNotIn,
                'relationshipWithHolder.equals': relationshipWithHolderEquals,
                'relationshipWithHolder.notEquals': relationshipWithHolderNotEquals,
                'relationshipWithHolder.specified': relationshipWithHolderSpecified,
                'relationshipWithHolder.in': relationshipWithHolderIn,
                'relationshipWithHolder.notIn': relationshipWithHolderNotIn,
                'cardFrontSide.contains': cardFrontSideContains,
                'cardFrontSide.doesNotContain': cardFrontSideDoesNotContain,
                'cardFrontSide.equals': cardFrontSideEquals,
                'cardFrontSide.notEquals': cardFrontSideNotEquals,
                'cardFrontSide.specified': cardFrontSideSpecified,
                'cardFrontSide.in': cardFrontSideIn,
                'cardFrontSide.notIn': cardFrontSideNotIn,
                'cardBackSide.contains': cardBackSideContains,
                'cardBackSide.doesNotContain': cardBackSideDoesNotContain,
                'cardBackSide.equals': cardBackSideEquals,
                'cardBackSide.notEquals': cardBackSideNotEquals,
                'cardBackSide.specified': cardBackSideSpecified,
                'cardBackSide.in': cardBackSideIn,
                'cardBackSide.notIn': cardBackSideNotIn,
                'payerPhoneNumber.contains': payerPhoneNumberContains,
                'payerPhoneNumber.doesNotContain': payerPhoneNumberDoesNotContain,
                'payerPhoneNumber.equals': payerPhoneNumberEquals,
                'payerPhoneNumber.notEquals': payerPhoneNumberNotEquals,
                'payerPhoneNumber.specified': payerPhoneNumberSpecified,
                'payerPhoneNumber.in': payerPhoneNumberIn,
                'payerPhoneNumber.notIn': payerPhoneNumberNotIn,
                'payerFaxNumber.contains': payerFaxNumberContains,
                'payerFaxNumber.doesNotContain': payerFaxNumberDoesNotContain,
                'payerFaxNumber.equals': payerFaxNumberEquals,
                'payerFaxNumber.notEquals': payerFaxNumberNotEquals,
                'payerFaxNumber.specified': payerFaxNumberSpecified,
                'payerFaxNumber.in': payerFaxNumberIn,
                'payerFaxNumber.notIn': payerFaxNumberNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'primaryInsuranceAppointmentId.greaterThan': primaryInsuranceAppointmentIdGreaterThan,
                'primaryInsuranceAppointmentId.lessThan': primaryInsuranceAppointmentIdLessThan,
                'primaryInsuranceAppointmentId.greaterThanOrEqual': primaryInsuranceAppointmentIdGreaterThanOrEqual,
                'primaryInsuranceAppointmentId.lessThanOrEqual': primaryInsuranceAppointmentIdLessThanOrEqual,
                'primaryInsuranceAppointmentId.equals': primaryInsuranceAppointmentIdEquals,
                'primaryInsuranceAppointmentId.notEquals': primaryInsuranceAppointmentIdNotEquals,
                'primaryInsuranceAppointmentId.specified': primaryInsuranceAppointmentIdSpecified,
                'primaryInsuranceAppointmentId.in': primaryInsuranceAppointmentIdIn,
                'primaryInsuranceAppointmentId.notIn': primaryInsuranceAppointmentIdNotIn,
                'secondaryInsuranceAppointmentId.greaterThan': secondaryInsuranceAppointmentIdGreaterThan,
                'secondaryInsuranceAppointmentId.lessThan': secondaryInsuranceAppointmentIdLessThan,
                'secondaryInsuranceAppointmentId.greaterThanOrEqual': secondaryInsuranceAppointmentIdGreaterThanOrEqual,
                'secondaryInsuranceAppointmentId.lessThanOrEqual': secondaryInsuranceAppointmentIdLessThanOrEqual,
                'secondaryInsuranceAppointmentId.equals': secondaryInsuranceAppointmentIdEquals,
                'secondaryInsuranceAppointmentId.notEquals': secondaryInsuranceAppointmentIdNotEquals,
                'secondaryInsuranceAppointmentId.specified': secondaryInsuranceAppointmentIdSpecified,
                'secondaryInsuranceAppointmentId.in': secondaryInsuranceAppointmentIdIn,
                'secondaryInsuranceAppointmentId.notIn': secondaryInsuranceAppointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'insurancePolicyHolderId.greaterThan': insurancePolicyHolderIdGreaterThan,
                'insurancePolicyHolderId.lessThan': insurancePolicyHolderIdLessThan,
                'insurancePolicyHolderId.greaterThanOrEqual': insurancePolicyHolderIdGreaterThanOrEqual,
                'insurancePolicyHolderId.lessThanOrEqual': insurancePolicyHolderIdLessThanOrEqual,
                'insurancePolicyHolderId.equals': insurancePolicyHolderIdEquals,
                'insurancePolicyHolderId.notEquals': insurancePolicyHolderIdNotEquals,
                'insurancePolicyHolderId.specified': insurancePolicyHolderIdSpecified,
                'insurancePolicyHolderId.in': insurancePolicyHolderIdIn,
                'insurancePolicyHolderId.notIn': insurancePolicyHolderIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns InsuranceDTO OK
     * @throws ApiError
     */
    public static createInsurance(
        requestBody: InsuranceDTO,
    ): CancelablePromise<InsuranceDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/insurances',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param patientUuid
     * @returns InsuranceDTO OK
     * @throws ApiError
     */
    public static getAllInsurancesByPatient(
        patientUuid: string,
    ): CancelablePromise<Array<InsuranceDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurances/{patientUuid}',
            path: {
                'patientUuid': patientUuid,
            },
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param typeEquals
     * @param typeNotEquals
     * @param typeSpecified
     * @param typeIn
     * @param typeNotIn
     * @param memberIdContains
     * @param memberIdDoesNotContain
     * @param memberIdEquals
     * @param memberIdNotEquals
     * @param memberIdSpecified
     * @param memberIdIn
     * @param memberIdNotIn
     * @param planIdContains
     * @param planIdDoesNotContain
     * @param planIdEquals
     * @param planIdNotEquals
     * @param planIdSpecified
     * @param planIdIn
     * @param planIdNotIn
     * @param groupIdContains
     * @param groupIdDoesNotContain
     * @param groupIdEquals
     * @param groupIdNotEquals
     * @param groupIdSpecified
     * @param groupIdIn
     * @param groupIdNotIn
     * @param groupNameContains
     * @param groupNameDoesNotContain
     * @param groupNameEquals
     * @param groupNameNotEquals
     * @param groupNameSpecified
     * @param groupNameIn
     * @param groupNameNotIn
     * @param copayGreaterThan
     * @param copayLessThan
     * @param copayGreaterThanOrEqual
     * @param copayLessThanOrEqual
     * @param copayEquals
     * @param copayNotEquals
     * @param copaySpecified
     * @param copayIn
     * @param copayNotIn
     * @param relationshipWithHolderEquals
     * @param relationshipWithHolderNotEquals
     * @param relationshipWithHolderSpecified
     * @param relationshipWithHolderIn
     * @param relationshipWithHolderNotIn
     * @param cardFrontSideContains
     * @param cardFrontSideDoesNotContain
     * @param cardFrontSideEquals
     * @param cardFrontSideNotEquals
     * @param cardFrontSideSpecified
     * @param cardFrontSideIn
     * @param cardFrontSideNotIn
     * @param cardBackSideContains
     * @param cardBackSideDoesNotContain
     * @param cardBackSideEquals
     * @param cardBackSideNotEquals
     * @param cardBackSideSpecified
     * @param cardBackSideIn
     * @param cardBackSideNotIn
     * @param payerPhoneNumberContains
     * @param payerPhoneNumberDoesNotContain
     * @param payerPhoneNumberEquals
     * @param payerPhoneNumberNotEquals
     * @param payerPhoneNumberSpecified
     * @param payerPhoneNumberIn
     * @param payerPhoneNumberNotIn
     * @param payerFaxNumberContains
     * @param payerFaxNumberDoesNotContain
     * @param payerFaxNumberEquals
     * @param payerFaxNumberNotEquals
     * @param payerFaxNumberSpecified
     * @param payerFaxNumberIn
     * @param payerFaxNumberNotIn
     * @param isActiveEquals
     * @param isActiveNotEquals
     * @param isActiveSpecified
     * @param isActiveIn
     * @param isActiveNotIn
     * @param isArchiveEquals
     * @param isArchiveNotEquals
     * @param isArchiveSpecified
     * @param isArchiveIn
     * @param isArchiveNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param payerIdIdGreaterThan
     * @param payerIdIdLessThan
     * @param payerIdIdGreaterThanOrEqual
     * @param payerIdIdLessThanOrEqual
     * @param payerIdIdEquals
     * @param payerIdIdNotEquals
     * @param payerIdIdSpecified
     * @param payerIdIdIn
     * @param payerIdIdNotIn
     * @param primaryInsuranceAppointmentIdGreaterThan
     * @param primaryInsuranceAppointmentIdLessThan
     * @param primaryInsuranceAppointmentIdGreaterThanOrEqual
     * @param primaryInsuranceAppointmentIdLessThanOrEqual
     * @param primaryInsuranceAppointmentIdEquals
     * @param primaryInsuranceAppointmentIdNotEquals
     * @param primaryInsuranceAppointmentIdSpecified
     * @param primaryInsuranceAppointmentIdIn
     * @param primaryInsuranceAppointmentIdNotIn
     * @param secondaryInsuranceAppointmentIdGreaterThan
     * @param secondaryInsuranceAppointmentIdLessThan
     * @param secondaryInsuranceAppointmentIdGreaterThanOrEqual
     * @param secondaryInsuranceAppointmentIdLessThanOrEqual
     * @param secondaryInsuranceAppointmentIdEquals
     * @param secondaryInsuranceAppointmentIdNotEquals
     * @param secondaryInsuranceAppointmentIdSpecified
     * @param secondaryInsuranceAppointmentIdIn
     * @param secondaryInsuranceAppointmentIdNotIn
     * @param patientIdGreaterThan
     * @param patientIdLessThan
     * @param patientIdGreaterThanOrEqual
     * @param patientIdLessThanOrEqual
     * @param patientIdEquals
     * @param patientIdNotEquals
     * @param patientIdSpecified
     * @param patientIdIn
     * @param patientIdNotIn
     * @param insurancePolicyHolderIdGreaterThan
     * @param insurancePolicyHolderIdLessThan
     * @param insurancePolicyHolderIdGreaterThanOrEqual
     * @param insurancePolicyHolderIdLessThanOrEqual
     * @param insurancePolicyHolderIdEquals
     * @param insurancePolicyHolderIdNotEquals
     * @param insurancePolicyHolderIdSpecified
     * @param insurancePolicyHolderIdIn
     * @param insurancePolicyHolderIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countInsurances(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        typeEquals?: 'PRIMARY' | 'SECONDARY' | 'OTHER',
        typeNotEquals?: 'PRIMARY' | 'SECONDARY' | 'OTHER',
        typeSpecified?: boolean,
        typeIn?: Array<'PRIMARY' | 'SECONDARY' | 'OTHER'>,
        typeNotIn?: Array<'PRIMARY' | 'SECONDARY' | 'OTHER'>,
        memberIdContains?: string,
        memberIdDoesNotContain?: string,
        memberIdEquals?: string,
        memberIdNotEquals?: string,
        memberIdSpecified?: boolean,
        memberIdIn?: Array<string>,
        memberIdNotIn?: Array<string>,
        planIdContains?: string,
        planIdDoesNotContain?: string,
        planIdEquals?: string,
        planIdNotEquals?: string,
        planIdSpecified?: boolean,
        planIdIn?: Array<string>,
        planIdNotIn?: Array<string>,
        groupIdContains?: string,
        groupIdDoesNotContain?: string,
        groupIdEquals?: string,
        groupIdNotEquals?: string,
        groupIdSpecified?: boolean,
        groupIdIn?: Array<string>,
        groupIdNotIn?: Array<string>,
        groupNameContains?: string,
        groupNameDoesNotContain?: string,
        groupNameEquals?: string,
        groupNameNotEquals?: string,
        groupNameSpecified?: boolean,
        groupNameIn?: Array<string>,
        groupNameNotIn?: Array<string>,
        copayGreaterThan?: number,
        copayLessThan?: number,
        copayGreaterThanOrEqual?: number,
        copayLessThanOrEqual?: number,
        copayEquals?: number,
        copayNotEquals?: number,
        copaySpecified?: boolean,
        copayIn?: Array<number>,
        copayNotIn?: Array<number>,
        relationshipWithHolderEquals?: 'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE',
        relationshipWithHolderNotEquals?: 'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE',
        relationshipWithHolderSpecified?: boolean,
        relationshipWithHolderIn?: Array<'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE'>,
        relationshipWithHolderNotIn?: Array<'SELF' | 'CHILD' | 'GRANDCHILD' | 'SPOUSE'>,
        cardFrontSideContains?: string,
        cardFrontSideDoesNotContain?: string,
        cardFrontSideEquals?: string,
        cardFrontSideNotEquals?: string,
        cardFrontSideSpecified?: boolean,
        cardFrontSideIn?: Array<string>,
        cardFrontSideNotIn?: Array<string>,
        cardBackSideContains?: string,
        cardBackSideDoesNotContain?: string,
        cardBackSideEquals?: string,
        cardBackSideNotEquals?: string,
        cardBackSideSpecified?: boolean,
        cardBackSideIn?: Array<string>,
        cardBackSideNotIn?: Array<string>,
        payerPhoneNumberContains?: string,
        payerPhoneNumberDoesNotContain?: string,
        payerPhoneNumberEquals?: string,
        payerPhoneNumberNotEquals?: string,
        payerPhoneNumberSpecified?: boolean,
        payerPhoneNumberIn?: Array<string>,
        payerPhoneNumberNotIn?: Array<string>,
        payerFaxNumberContains?: string,
        payerFaxNumberDoesNotContain?: string,
        payerFaxNumberEquals?: string,
        payerFaxNumberNotEquals?: string,
        payerFaxNumberSpecified?: boolean,
        payerFaxNumberIn?: Array<string>,
        payerFaxNumberNotIn?: Array<string>,
        isActiveEquals?: boolean,
        isActiveNotEquals?: boolean,
        isActiveSpecified?: boolean,
        isActiveIn?: Array<boolean>,
        isActiveNotIn?: Array<boolean>,
        isArchiveEquals?: boolean,
        isArchiveNotEquals?: boolean,
        isArchiveSpecified?: boolean,
        isArchiveIn?: Array<boolean>,
        isArchiveNotIn?: Array<boolean>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        payerIdIdGreaterThan?: number,
        payerIdIdLessThan?: number,
        payerIdIdGreaterThanOrEqual?: number,
        payerIdIdLessThanOrEqual?: number,
        payerIdIdEquals?: number,
        payerIdIdNotEquals?: number,
        payerIdIdSpecified?: boolean,
        payerIdIdIn?: Array<number>,
        payerIdIdNotIn?: Array<number>,
        primaryInsuranceAppointmentIdGreaterThan?: number,
        primaryInsuranceAppointmentIdLessThan?: number,
        primaryInsuranceAppointmentIdGreaterThanOrEqual?: number,
        primaryInsuranceAppointmentIdLessThanOrEqual?: number,
        primaryInsuranceAppointmentIdEquals?: number,
        primaryInsuranceAppointmentIdNotEquals?: number,
        primaryInsuranceAppointmentIdSpecified?: boolean,
        primaryInsuranceAppointmentIdIn?: Array<number>,
        primaryInsuranceAppointmentIdNotIn?: Array<number>,
        secondaryInsuranceAppointmentIdGreaterThan?: number,
        secondaryInsuranceAppointmentIdLessThan?: number,
        secondaryInsuranceAppointmentIdGreaterThanOrEqual?: number,
        secondaryInsuranceAppointmentIdLessThanOrEqual?: number,
        secondaryInsuranceAppointmentIdEquals?: number,
        secondaryInsuranceAppointmentIdNotEquals?: number,
        secondaryInsuranceAppointmentIdSpecified?: boolean,
        secondaryInsuranceAppointmentIdIn?: Array<number>,
        secondaryInsuranceAppointmentIdNotIn?: Array<number>,
        patientIdGreaterThan?: number,
        patientIdLessThan?: number,
        patientIdGreaterThanOrEqual?: number,
        patientIdLessThanOrEqual?: number,
        patientIdEquals?: number,
        patientIdNotEquals?: number,
        patientIdSpecified?: boolean,
        patientIdIn?: Array<number>,
        patientIdNotIn?: Array<number>,
        insurancePolicyHolderIdGreaterThan?: number,
        insurancePolicyHolderIdLessThan?: number,
        insurancePolicyHolderIdGreaterThanOrEqual?: number,
        insurancePolicyHolderIdLessThanOrEqual?: number,
        insurancePolicyHolderIdEquals?: number,
        insurancePolicyHolderIdNotEquals?: number,
        insurancePolicyHolderIdSpecified?: boolean,
        insurancePolicyHolderIdIn?: Array<number>,
        insurancePolicyHolderIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/insurances/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'type.equals': typeEquals,
                'type.notEquals': typeNotEquals,
                'type.specified': typeSpecified,
                'type.in': typeIn,
                'type.notIn': typeNotIn,
                'memberId.contains': memberIdContains,
                'memberId.doesNotContain': memberIdDoesNotContain,
                'memberId.equals': memberIdEquals,
                'memberId.notEquals': memberIdNotEquals,
                'memberId.specified': memberIdSpecified,
                'memberId.in': memberIdIn,
                'memberId.notIn': memberIdNotIn,
                'planId.contains': planIdContains,
                'planId.doesNotContain': planIdDoesNotContain,
                'planId.equals': planIdEquals,
                'planId.notEquals': planIdNotEquals,
                'planId.specified': planIdSpecified,
                'planId.in': planIdIn,
                'planId.notIn': planIdNotIn,
                'groupId.contains': groupIdContains,
                'groupId.doesNotContain': groupIdDoesNotContain,
                'groupId.equals': groupIdEquals,
                'groupId.notEquals': groupIdNotEquals,
                'groupId.specified': groupIdSpecified,
                'groupId.in': groupIdIn,
                'groupId.notIn': groupIdNotIn,
                'groupName.contains': groupNameContains,
                'groupName.doesNotContain': groupNameDoesNotContain,
                'groupName.equals': groupNameEquals,
                'groupName.notEquals': groupNameNotEquals,
                'groupName.specified': groupNameSpecified,
                'groupName.in': groupNameIn,
                'groupName.notIn': groupNameNotIn,
                'copay.greaterThan': copayGreaterThan,
                'copay.lessThan': copayLessThan,
                'copay.greaterThanOrEqual': copayGreaterThanOrEqual,
                'copay.lessThanOrEqual': copayLessThanOrEqual,
                'copay.equals': copayEquals,
                'copay.notEquals': copayNotEquals,
                'copay.specified': copaySpecified,
                'copay.in': copayIn,
                'copay.notIn': copayNotIn,
                'relationshipWithHolder.equals': relationshipWithHolderEquals,
                'relationshipWithHolder.notEquals': relationshipWithHolderNotEquals,
                'relationshipWithHolder.specified': relationshipWithHolderSpecified,
                'relationshipWithHolder.in': relationshipWithHolderIn,
                'relationshipWithHolder.notIn': relationshipWithHolderNotIn,
                'cardFrontSide.contains': cardFrontSideContains,
                'cardFrontSide.doesNotContain': cardFrontSideDoesNotContain,
                'cardFrontSide.equals': cardFrontSideEquals,
                'cardFrontSide.notEquals': cardFrontSideNotEquals,
                'cardFrontSide.specified': cardFrontSideSpecified,
                'cardFrontSide.in': cardFrontSideIn,
                'cardFrontSide.notIn': cardFrontSideNotIn,
                'cardBackSide.contains': cardBackSideContains,
                'cardBackSide.doesNotContain': cardBackSideDoesNotContain,
                'cardBackSide.equals': cardBackSideEquals,
                'cardBackSide.notEquals': cardBackSideNotEquals,
                'cardBackSide.specified': cardBackSideSpecified,
                'cardBackSide.in': cardBackSideIn,
                'cardBackSide.notIn': cardBackSideNotIn,
                'payerPhoneNumber.contains': payerPhoneNumberContains,
                'payerPhoneNumber.doesNotContain': payerPhoneNumberDoesNotContain,
                'payerPhoneNumber.equals': payerPhoneNumberEquals,
                'payerPhoneNumber.notEquals': payerPhoneNumberNotEquals,
                'payerPhoneNumber.specified': payerPhoneNumberSpecified,
                'payerPhoneNumber.in': payerPhoneNumberIn,
                'payerPhoneNumber.notIn': payerPhoneNumberNotIn,
                'payerFaxNumber.contains': payerFaxNumberContains,
                'payerFaxNumber.doesNotContain': payerFaxNumberDoesNotContain,
                'payerFaxNumber.equals': payerFaxNumberEquals,
                'payerFaxNumber.notEquals': payerFaxNumberNotEquals,
                'payerFaxNumber.specified': payerFaxNumberSpecified,
                'payerFaxNumber.in': payerFaxNumberIn,
                'payerFaxNumber.notIn': payerFaxNumberNotIn,
                'isActive.equals': isActiveEquals,
                'isActive.notEquals': isActiveNotEquals,
                'isActive.specified': isActiveSpecified,
                'isActive.in': isActiveIn,
                'isActive.notIn': isActiveNotIn,
                'isArchive.equals': isArchiveEquals,
                'isArchive.notEquals': isArchiveNotEquals,
                'isArchive.specified': isArchiveSpecified,
                'isArchive.in': isArchiveIn,
                'isArchive.notIn': isArchiveNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'payerIdId.greaterThan': payerIdIdGreaterThan,
                'payerIdId.lessThan': payerIdIdLessThan,
                'payerIdId.greaterThanOrEqual': payerIdIdGreaterThanOrEqual,
                'payerIdId.lessThanOrEqual': payerIdIdLessThanOrEqual,
                'payerIdId.equals': payerIdIdEquals,
                'payerIdId.notEquals': payerIdIdNotEquals,
                'payerIdId.specified': payerIdIdSpecified,
                'payerIdId.in': payerIdIdIn,
                'payerIdId.notIn': payerIdIdNotIn,
                'primaryInsuranceAppointmentId.greaterThan': primaryInsuranceAppointmentIdGreaterThan,
                'primaryInsuranceAppointmentId.lessThan': primaryInsuranceAppointmentIdLessThan,
                'primaryInsuranceAppointmentId.greaterThanOrEqual': primaryInsuranceAppointmentIdGreaterThanOrEqual,
                'primaryInsuranceAppointmentId.lessThanOrEqual': primaryInsuranceAppointmentIdLessThanOrEqual,
                'primaryInsuranceAppointmentId.equals': primaryInsuranceAppointmentIdEquals,
                'primaryInsuranceAppointmentId.notEquals': primaryInsuranceAppointmentIdNotEquals,
                'primaryInsuranceAppointmentId.specified': primaryInsuranceAppointmentIdSpecified,
                'primaryInsuranceAppointmentId.in': primaryInsuranceAppointmentIdIn,
                'primaryInsuranceAppointmentId.notIn': primaryInsuranceAppointmentIdNotIn,
                'secondaryInsuranceAppointmentId.greaterThan': secondaryInsuranceAppointmentIdGreaterThan,
                'secondaryInsuranceAppointmentId.lessThan': secondaryInsuranceAppointmentIdLessThan,
                'secondaryInsuranceAppointmentId.greaterThanOrEqual': secondaryInsuranceAppointmentIdGreaterThanOrEqual,
                'secondaryInsuranceAppointmentId.lessThanOrEqual': secondaryInsuranceAppointmentIdLessThanOrEqual,
                'secondaryInsuranceAppointmentId.equals': secondaryInsuranceAppointmentIdEquals,
                'secondaryInsuranceAppointmentId.notEquals': secondaryInsuranceAppointmentIdNotEquals,
                'secondaryInsuranceAppointmentId.specified': secondaryInsuranceAppointmentIdSpecified,
                'secondaryInsuranceAppointmentId.in': secondaryInsuranceAppointmentIdIn,
                'secondaryInsuranceAppointmentId.notIn': secondaryInsuranceAppointmentIdNotIn,
                'patientId.greaterThan': patientIdGreaterThan,
                'patientId.lessThan': patientIdLessThan,
                'patientId.greaterThanOrEqual': patientIdGreaterThanOrEqual,
                'patientId.lessThanOrEqual': patientIdLessThanOrEqual,
                'patientId.equals': patientIdEquals,
                'patientId.notEquals': patientIdNotEquals,
                'patientId.specified': patientIdSpecified,
                'patientId.in': patientIdIn,
                'patientId.notIn': patientIdNotIn,
                'insurancePolicyHolderId.greaterThan': insurancePolicyHolderIdGreaterThan,
                'insurancePolicyHolderId.lessThan': insurancePolicyHolderIdLessThan,
                'insurancePolicyHolderId.greaterThanOrEqual': insurancePolicyHolderIdGreaterThanOrEqual,
                'insurancePolicyHolderId.lessThanOrEqual': insurancePolicyHolderIdLessThanOrEqual,
                'insurancePolicyHolderId.equals': insurancePolicyHolderIdEquals,
                'insurancePolicyHolderId.notEquals': insurancePolicyHolderIdNotEquals,
                'insurancePolicyHolderId.specified': insurancePolicyHolderIdSpecified,
                'insurancePolicyHolderId.in': insurancePolicyHolderIdIn,
                'insurancePolicyHolderId.notIn': insurancePolicyHolderIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
