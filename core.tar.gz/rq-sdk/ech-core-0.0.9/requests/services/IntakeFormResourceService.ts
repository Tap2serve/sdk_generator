/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IntakeFormDTO } from '../models/IntakeFormDTO';

import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';

export class IntakeFormResourceService {

    /**
     * @param id
     * @returns IntakeFormDTO OK
     * @throws ApiError
     */
    public static getIntakeForm(
        id: number,
    ): CancelablePromise<IntakeFormDTO> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-forms/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeFormDTO OK
     * @throws ApiError
     */
    public static updateIntakeForm(
        id: number,
        requestBody: IntakeFormDTO,
    ): CancelablePromise<IntakeFormDTO> {
        return __request(OpenAPI, {
            method: 'PUT',
            url: '/api/intake-forms/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param id
     * @returns any OK
     * @throws ApiError
     */
    public static deleteIntakeForm(
        id: number,
    ): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'DELETE',
            url: '/api/intake-forms/{id}',
            path: {
                'id': id,
            },
        });
    }

    /**
     * @param id
     * @param requestBody
     * @returns IntakeFormDTO OK
     * @throws ApiError
     */
    public static partialUpdateIntakeForm(
        id: number,
        requestBody: IntakeFormDTO,
    ): CancelablePromise<IntakeFormDTO> {
        return __request(OpenAPI, {
            method: 'PATCH',
            url: '/api/intake-forms/{id}',
            path: {
                'id': id,
            },
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param intakeFormNameContains
     * @param intakeFormNameDoesNotContain
     * @param intakeFormNameEquals
     * @param intakeFormNameNotEquals
     * @param intakeFormNameSpecified
     * @param intakeFormNameIn
     * @param intakeFormNameNotIn
     * @param sendDateGreaterThan
     * @param sendDateLessThan
     * @param sendDateGreaterThanOrEqual
     * @param sendDateLessThanOrEqual
     * @param sendDateEquals
     * @param sendDateNotEquals
     * @param sendDateSpecified
     * @param sendDateIn
     * @param sendDateNotIn
     * @param dueDateGreaterThan
     * @param dueDateLessThan
     * @param dueDateGreaterThanOrEqual
     * @param dueDateLessThanOrEqual
     * @param dueDateEquals
     * @param dueDateNotEquals
     * @param dueDateSpecified
     * @param dueDateIn
     * @param dueDateNotIn
     * @param submittedDateGreaterThan
     * @param submittedDateLessThan
     * @param submittedDateGreaterThanOrEqual
     * @param submittedDateLessThanOrEqual
     * @param submittedDateEquals
     * @param submittedDateNotEquals
     * @param submittedDateSpecified
     * @param submittedDateIn
     * @param submittedDateNotIn
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param filledByEquals
     * @param filledByNotEquals
     * @param filledBySpecified
     * @param filledByIn
     * @param filledByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param appointmentIdIdGreaterThan
     * @param appointmentIdIdLessThan
     * @param appointmentIdIdGreaterThanOrEqual
     * @param appointmentIdIdLessThanOrEqual
     * @param appointmentIdIdEquals
     * @param appointmentIdIdNotEquals
     * @param appointmentIdIdSpecified
     * @param appointmentIdIdIn
     * @param appointmentIdIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param intakePatientFamilyHistoryIdGreaterThan
     * @param intakePatientFamilyHistoryIdLessThan
     * @param intakePatientFamilyHistoryIdGreaterThanOrEqual
     * @param intakePatientFamilyHistoryIdLessThanOrEqual
     * @param intakePatientFamilyHistoryIdEquals
     * @param intakePatientFamilyHistoryIdNotEquals
     * @param intakePatientFamilyHistoryIdSpecified
     * @param intakePatientFamilyHistoryIdIn
     * @param intakePatientFamilyHistoryIdNotIn
     * @param intakeProblemIdGreaterThan
     * @param intakeProblemIdLessThan
     * @param intakeProblemIdGreaterThanOrEqual
     * @param intakeProblemIdLessThanOrEqual
     * @param intakeProblemIdEquals
     * @param intakeProblemIdNotEquals
     * @param intakeProblemIdSpecified
     * @param intakeProblemIdIn
     * @param intakeProblemIdNotIn
     * @param intakeAllergyIdGreaterThan
     * @param intakeAllergyIdLessThan
     * @param intakeAllergyIdGreaterThanOrEqual
     * @param intakeAllergyIdLessThanOrEqual
     * @param intakeAllergyIdEquals
     * @param intakeAllergyIdNotEquals
     * @param intakeAllergyIdSpecified
     * @param intakeAllergyIdIn
     * @param intakeAllergyIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param intakeVaccineIdGreaterThan
     * @param intakeVaccineIdLessThan
     * @param intakeVaccineIdGreaterThanOrEqual
     * @param intakeVaccineIdLessThanOrEqual
     * @param intakeVaccineIdEquals
     * @param intakeVaccineIdNotEquals
     * @param intakeVaccineIdSpecified
     * @param intakeVaccineIdIn
     * @param intakeVaccineIdNotIn
     * @param intakeMedicalHistoryIdGreaterThan
     * @param intakeMedicalHistoryIdLessThan
     * @param intakeMedicalHistoryIdGreaterThanOrEqual
     * @param intakeMedicalHistoryIdLessThanOrEqual
     * @param intakeMedicalHistoryIdEquals
     * @param intakeMedicalHistoryIdNotEquals
     * @param intakeMedicalHistoryIdSpecified
     * @param intakeMedicalHistoryIdIn
     * @param intakeMedicalHistoryIdNotIn
     * @param distinct
     * @param page Zero-based page index (0..N)
     * @param size The size of the page to be returned
     * @param sort Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.
     * @returns IntakeFormDTO OK
     * @throws ApiError
     */
    public static getAllIntakeForms(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        intakeFormNameContains?: string,
        intakeFormNameDoesNotContain?: string,
        intakeFormNameEquals?: string,
        intakeFormNameNotEquals?: string,
        intakeFormNameSpecified?: boolean,
        intakeFormNameIn?: Array<string>,
        intakeFormNameNotIn?: Array<string>,
        sendDateGreaterThan?: string,
        sendDateLessThan?: string,
        sendDateGreaterThanOrEqual?: string,
        sendDateLessThanOrEqual?: string,
        sendDateEquals?: string,
        sendDateNotEquals?: string,
        sendDateSpecified?: boolean,
        sendDateIn?: Array<string>,
        sendDateNotIn?: Array<string>,
        dueDateGreaterThan?: string,
        dueDateLessThan?: string,
        dueDateGreaterThanOrEqual?: string,
        dueDateLessThanOrEqual?: string,
        dueDateEquals?: string,
        dueDateNotEquals?: string,
        dueDateSpecified?: boolean,
        dueDateIn?: Array<string>,
        dueDateNotIn?: Array<string>,
        submittedDateGreaterThan?: string,
        submittedDateLessThan?: string,
        submittedDateGreaterThanOrEqual?: string,
        submittedDateLessThanOrEqual?: string,
        submittedDateEquals?: string,
        submittedDateNotEquals?: string,
        submittedDateSpecified?: boolean,
        submittedDateIn?: Array<string>,
        submittedDateNotIn?: Array<string>,
        statusEquals?: 'SEND' | 'FILLED' | 'COMPLETED',
        statusNotEquals?: 'SEND' | 'FILLED' | 'COMPLETED',
        statusSpecified?: boolean,
        statusIn?: Array<'SEND' | 'FILLED' | 'COMPLETED'>,
        statusNotIn?: Array<'SEND' | 'FILLED' | 'COMPLETED'>,
        filledByEquals?: 'PATIENT' | 'PROVIDER',
        filledByNotEquals?: 'PATIENT' | 'PROVIDER',
        filledBySpecified?: boolean,
        filledByIn?: Array<'PATIENT' | 'PROVIDER'>,
        filledByNotIn?: Array<'PATIENT' | 'PROVIDER'>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        appointmentIdIdGreaterThan?: number,
        appointmentIdIdLessThan?: number,
        appointmentIdIdGreaterThanOrEqual?: number,
        appointmentIdIdLessThanOrEqual?: number,
        appointmentIdIdEquals?: number,
        appointmentIdIdNotEquals?: number,
        appointmentIdIdSpecified?: boolean,
        appointmentIdIdIn?: Array<number>,
        appointmentIdIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        intakePatientFamilyHistoryIdGreaterThan?: number,
        intakePatientFamilyHistoryIdLessThan?: number,
        intakePatientFamilyHistoryIdGreaterThanOrEqual?: number,
        intakePatientFamilyHistoryIdLessThanOrEqual?: number,
        intakePatientFamilyHistoryIdEquals?: number,
        intakePatientFamilyHistoryIdNotEquals?: number,
        intakePatientFamilyHistoryIdSpecified?: boolean,
        intakePatientFamilyHistoryIdIn?: Array<number>,
        intakePatientFamilyHistoryIdNotIn?: Array<number>,
        intakeProblemIdGreaterThan?: number,
        intakeProblemIdLessThan?: number,
        intakeProblemIdGreaterThanOrEqual?: number,
        intakeProblemIdLessThanOrEqual?: number,
        intakeProblemIdEquals?: number,
        intakeProblemIdNotEquals?: number,
        intakeProblemIdSpecified?: boolean,
        intakeProblemIdIn?: Array<number>,
        intakeProblemIdNotIn?: Array<number>,
        intakeAllergyIdGreaterThan?: number,
        intakeAllergyIdLessThan?: number,
        intakeAllergyIdGreaterThanOrEqual?: number,
        intakeAllergyIdLessThanOrEqual?: number,
        intakeAllergyIdEquals?: number,
        intakeAllergyIdNotEquals?: number,
        intakeAllergyIdSpecified?: boolean,
        intakeAllergyIdIn?: Array<number>,
        intakeAllergyIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        intakeVaccineIdGreaterThan?: number,
        intakeVaccineIdLessThan?: number,
        intakeVaccineIdGreaterThanOrEqual?: number,
        intakeVaccineIdLessThanOrEqual?: number,
        intakeVaccineIdEquals?: number,
        intakeVaccineIdNotEquals?: number,
        intakeVaccineIdSpecified?: boolean,
        intakeVaccineIdIn?: Array<number>,
        intakeVaccineIdNotIn?: Array<number>,
        intakeMedicalHistoryIdGreaterThan?: number,
        intakeMedicalHistoryIdLessThan?: number,
        intakeMedicalHistoryIdGreaterThanOrEqual?: number,
        intakeMedicalHistoryIdLessThanOrEqual?: number,
        intakeMedicalHistoryIdEquals?: number,
        intakeMedicalHistoryIdNotEquals?: number,
        intakeMedicalHistoryIdSpecified?: boolean,
        intakeMedicalHistoryIdIn?: Array<number>,
        intakeMedicalHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
        page?: number,
        size: number = 20,
        sort?: Array<string>,
    ): CancelablePromise<Array<IntakeFormDTO>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-forms',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'intakeFormName.contains': intakeFormNameContains,
                'intakeFormName.doesNotContain': intakeFormNameDoesNotContain,
                'intakeFormName.equals': intakeFormNameEquals,
                'intakeFormName.notEquals': intakeFormNameNotEquals,
                'intakeFormName.specified': intakeFormNameSpecified,
                'intakeFormName.in': intakeFormNameIn,
                'intakeFormName.notIn': intakeFormNameNotIn,
                'sendDate.greaterThan': sendDateGreaterThan,
                'sendDate.lessThan': sendDateLessThan,
                'sendDate.greaterThanOrEqual': sendDateGreaterThanOrEqual,
                'sendDate.lessThanOrEqual': sendDateLessThanOrEqual,
                'sendDate.equals': sendDateEquals,
                'sendDate.notEquals': sendDateNotEquals,
                'sendDate.specified': sendDateSpecified,
                'sendDate.in': sendDateIn,
                'sendDate.notIn': sendDateNotIn,
                'dueDate.greaterThan': dueDateGreaterThan,
                'dueDate.lessThan': dueDateLessThan,
                'dueDate.greaterThanOrEqual': dueDateGreaterThanOrEqual,
                'dueDate.lessThanOrEqual': dueDateLessThanOrEqual,
                'dueDate.equals': dueDateEquals,
                'dueDate.notEquals': dueDateNotEquals,
                'dueDate.specified': dueDateSpecified,
                'dueDate.in': dueDateIn,
                'dueDate.notIn': dueDateNotIn,
                'submittedDate.greaterThan': submittedDateGreaterThan,
                'submittedDate.lessThan': submittedDateLessThan,
                'submittedDate.greaterThanOrEqual': submittedDateGreaterThanOrEqual,
                'submittedDate.lessThanOrEqual': submittedDateLessThanOrEqual,
                'submittedDate.equals': submittedDateEquals,
                'submittedDate.notEquals': submittedDateNotEquals,
                'submittedDate.specified': submittedDateSpecified,
                'submittedDate.in': submittedDateIn,
                'submittedDate.notIn': submittedDateNotIn,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'filledBy.equals': filledByEquals,
                'filledBy.notEquals': filledByNotEquals,
                'filledBy.specified': filledBySpecified,
                'filledBy.in': filledByIn,
                'filledBy.notIn': filledByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'appointmentIdId.greaterThan': appointmentIdIdGreaterThan,
                'appointmentIdId.lessThan': appointmentIdIdLessThan,
                'appointmentIdId.greaterThanOrEqual': appointmentIdIdGreaterThanOrEqual,
                'appointmentIdId.lessThanOrEqual': appointmentIdIdLessThanOrEqual,
                'appointmentIdId.equals': appointmentIdIdEquals,
                'appointmentIdId.notEquals': appointmentIdIdNotEquals,
                'appointmentIdId.specified': appointmentIdIdSpecified,
                'appointmentIdId.in': appointmentIdIdIn,
                'appointmentIdId.notIn': appointmentIdIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'intakePatientFamilyHistoryId.greaterThan': intakePatientFamilyHistoryIdGreaterThan,
                'intakePatientFamilyHistoryId.lessThan': intakePatientFamilyHistoryIdLessThan,
                'intakePatientFamilyHistoryId.greaterThanOrEqual': intakePatientFamilyHistoryIdGreaterThanOrEqual,
                'intakePatientFamilyHistoryId.lessThanOrEqual': intakePatientFamilyHistoryIdLessThanOrEqual,
                'intakePatientFamilyHistoryId.equals': intakePatientFamilyHistoryIdEquals,
                'intakePatientFamilyHistoryId.notEquals': intakePatientFamilyHistoryIdNotEquals,
                'intakePatientFamilyHistoryId.specified': intakePatientFamilyHistoryIdSpecified,
                'intakePatientFamilyHistoryId.in': intakePatientFamilyHistoryIdIn,
                'intakePatientFamilyHistoryId.notIn': intakePatientFamilyHistoryIdNotIn,
                'intakeProblemId.greaterThan': intakeProblemIdGreaterThan,
                'intakeProblemId.lessThan': intakeProblemIdLessThan,
                'intakeProblemId.greaterThanOrEqual': intakeProblemIdGreaterThanOrEqual,
                'intakeProblemId.lessThanOrEqual': intakeProblemIdLessThanOrEqual,
                'intakeProblemId.equals': intakeProblemIdEquals,
                'intakeProblemId.notEquals': intakeProblemIdNotEquals,
                'intakeProblemId.specified': intakeProblemIdSpecified,
                'intakeProblemId.in': intakeProblemIdIn,
                'intakeProblemId.notIn': intakeProblemIdNotIn,
                'intakeAllergyId.greaterThan': intakeAllergyIdGreaterThan,
                'intakeAllergyId.lessThan': intakeAllergyIdLessThan,
                'intakeAllergyId.greaterThanOrEqual': intakeAllergyIdGreaterThanOrEqual,
                'intakeAllergyId.lessThanOrEqual': intakeAllergyIdLessThanOrEqual,
                'intakeAllergyId.equals': intakeAllergyIdEquals,
                'intakeAllergyId.notEquals': intakeAllergyIdNotEquals,
                'intakeAllergyId.specified': intakeAllergyIdSpecified,
                'intakeAllergyId.in': intakeAllergyIdIn,
                'intakeAllergyId.notIn': intakeAllergyIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'intakeVaccineId.greaterThan': intakeVaccineIdGreaterThan,
                'intakeVaccineId.lessThan': intakeVaccineIdLessThan,
                'intakeVaccineId.greaterThanOrEqual': intakeVaccineIdGreaterThanOrEqual,
                'intakeVaccineId.lessThanOrEqual': intakeVaccineIdLessThanOrEqual,
                'intakeVaccineId.equals': intakeVaccineIdEquals,
                'intakeVaccineId.notEquals': intakeVaccineIdNotEquals,
                'intakeVaccineId.specified': intakeVaccineIdSpecified,
                'intakeVaccineId.in': intakeVaccineIdIn,
                'intakeVaccineId.notIn': intakeVaccineIdNotIn,
                'intakeMedicalHistoryId.greaterThan': intakeMedicalHistoryIdGreaterThan,
                'intakeMedicalHistoryId.lessThan': intakeMedicalHistoryIdLessThan,
                'intakeMedicalHistoryId.greaterThanOrEqual': intakeMedicalHistoryIdGreaterThanOrEqual,
                'intakeMedicalHistoryId.lessThanOrEqual': intakeMedicalHistoryIdLessThanOrEqual,
                'intakeMedicalHistoryId.equals': intakeMedicalHistoryIdEquals,
                'intakeMedicalHistoryId.notEquals': intakeMedicalHistoryIdNotEquals,
                'intakeMedicalHistoryId.specified': intakeMedicalHistoryIdSpecified,
                'intakeMedicalHistoryId.in': intakeMedicalHistoryIdIn,
                'intakeMedicalHistoryId.notIn': intakeMedicalHistoryIdNotIn,
                'distinct': distinct,
                'page': page,
                'size': size,
                'sort': sort,
            },
        });
    }

    /**
     * @param requestBody
     * @returns IntakeFormDTO OK
     * @throws ApiError
     */
    public static createIntakeForm(
        requestBody: IntakeFormDTO,
    ): CancelablePromise<IntakeFormDTO> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/intake-forms',
            body: requestBody,
            mediaType: 'application/json',
        });
    }

    /**
     * @param idGreaterThan
     * @param idLessThan
     * @param idGreaterThanOrEqual
     * @param idLessThanOrEqual
     * @param idEquals
     * @param idNotEquals
     * @param idSpecified
     * @param idIn
     * @param idNotIn
     * @param uuidEquals
     * @param uuidNotEquals
     * @param uuidSpecified
     * @param uuidIn
     * @param uuidNotIn
     * @param intakeFormNameContains
     * @param intakeFormNameDoesNotContain
     * @param intakeFormNameEquals
     * @param intakeFormNameNotEquals
     * @param intakeFormNameSpecified
     * @param intakeFormNameIn
     * @param intakeFormNameNotIn
     * @param sendDateGreaterThan
     * @param sendDateLessThan
     * @param sendDateGreaterThanOrEqual
     * @param sendDateLessThanOrEqual
     * @param sendDateEquals
     * @param sendDateNotEquals
     * @param sendDateSpecified
     * @param sendDateIn
     * @param sendDateNotIn
     * @param dueDateGreaterThan
     * @param dueDateLessThan
     * @param dueDateGreaterThanOrEqual
     * @param dueDateLessThanOrEqual
     * @param dueDateEquals
     * @param dueDateNotEquals
     * @param dueDateSpecified
     * @param dueDateIn
     * @param dueDateNotIn
     * @param submittedDateGreaterThan
     * @param submittedDateLessThan
     * @param submittedDateGreaterThanOrEqual
     * @param submittedDateLessThanOrEqual
     * @param submittedDateEquals
     * @param submittedDateNotEquals
     * @param submittedDateSpecified
     * @param submittedDateIn
     * @param submittedDateNotIn
     * @param statusEquals
     * @param statusNotEquals
     * @param statusSpecified
     * @param statusIn
     * @param statusNotIn
     * @param filledByEquals
     * @param filledByNotEquals
     * @param filledBySpecified
     * @param filledByIn
     * @param filledByNotIn
     * @param createdAtGreaterThan
     * @param createdAtLessThan
     * @param createdAtGreaterThanOrEqual
     * @param createdAtLessThanOrEqual
     * @param createdAtEquals
     * @param createdAtNotEquals
     * @param createdAtSpecified
     * @param createdAtIn
     * @param createdAtNotIn
     * @param modifiedAtGreaterThan
     * @param modifiedAtLessThan
     * @param modifiedAtGreaterThanOrEqual
     * @param modifiedAtLessThanOrEqual
     * @param modifiedAtEquals
     * @param modifiedAtNotEquals
     * @param modifiedAtSpecified
     * @param modifiedAtIn
     * @param modifiedAtNotIn
     * @param createdByContains
     * @param createdByDoesNotContain
     * @param createdByEquals
     * @param createdByNotEquals
     * @param createdBySpecified
     * @param createdByIn
     * @param createdByNotIn
     * @param modifiedByContains
     * @param modifiedByDoesNotContain
     * @param modifiedByEquals
     * @param modifiedByNotEquals
     * @param modifiedBySpecified
     * @param modifiedByIn
     * @param modifiedByNotIn
     * @param appointmentIdIdGreaterThan
     * @param appointmentIdIdLessThan
     * @param appointmentIdIdGreaterThanOrEqual
     * @param appointmentIdIdLessThanOrEqual
     * @param appointmentIdIdEquals
     * @param appointmentIdIdNotEquals
     * @param appointmentIdIdSpecified
     * @param appointmentIdIdIn
     * @param appointmentIdIdNotIn
     * @param intakeSocialHistoryIdGreaterThan
     * @param intakeSocialHistoryIdLessThan
     * @param intakeSocialHistoryIdGreaterThanOrEqual
     * @param intakeSocialHistoryIdLessThanOrEqual
     * @param intakeSocialHistoryIdEquals
     * @param intakeSocialHistoryIdNotEquals
     * @param intakeSocialHistoryIdSpecified
     * @param intakeSocialHistoryIdIn
     * @param intakeSocialHistoryIdNotIn
     * @param intakePatientFamilyHistoryIdGreaterThan
     * @param intakePatientFamilyHistoryIdLessThan
     * @param intakePatientFamilyHistoryIdGreaterThanOrEqual
     * @param intakePatientFamilyHistoryIdLessThanOrEqual
     * @param intakePatientFamilyHistoryIdEquals
     * @param intakePatientFamilyHistoryIdNotEquals
     * @param intakePatientFamilyHistoryIdSpecified
     * @param intakePatientFamilyHistoryIdIn
     * @param intakePatientFamilyHistoryIdNotIn
     * @param intakeProblemIdGreaterThan
     * @param intakeProblemIdLessThan
     * @param intakeProblemIdGreaterThanOrEqual
     * @param intakeProblemIdLessThanOrEqual
     * @param intakeProblemIdEquals
     * @param intakeProblemIdNotEquals
     * @param intakeProblemIdSpecified
     * @param intakeProblemIdIn
     * @param intakeProblemIdNotIn
     * @param intakeAllergyIdGreaterThan
     * @param intakeAllergyIdLessThan
     * @param intakeAllergyIdGreaterThanOrEqual
     * @param intakeAllergyIdLessThanOrEqual
     * @param intakeAllergyIdEquals
     * @param intakeAllergyIdNotEquals
     * @param intakeAllergyIdSpecified
     * @param intakeAllergyIdIn
     * @param intakeAllergyIdNotIn
     * @param intakeMedicationIdGreaterThan
     * @param intakeMedicationIdLessThan
     * @param intakeMedicationIdGreaterThanOrEqual
     * @param intakeMedicationIdLessThanOrEqual
     * @param intakeMedicationIdEquals
     * @param intakeMedicationIdNotEquals
     * @param intakeMedicationIdSpecified
     * @param intakeMedicationIdIn
     * @param intakeMedicationIdNotIn
     * @param intakeVaccineIdGreaterThan
     * @param intakeVaccineIdLessThan
     * @param intakeVaccineIdGreaterThanOrEqual
     * @param intakeVaccineIdLessThanOrEqual
     * @param intakeVaccineIdEquals
     * @param intakeVaccineIdNotEquals
     * @param intakeVaccineIdSpecified
     * @param intakeVaccineIdIn
     * @param intakeVaccineIdNotIn
     * @param intakeMedicalHistoryIdGreaterThan
     * @param intakeMedicalHistoryIdLessThan
     * @param intakeMedicalHistoryIdGreaterThanOrEqual
     * @param intakeMedicalHistoryIdLessThanOrEqual
     * @param intakeMedicalHistoryIdEquals
     * @param intakeMedicalHistoryIdNotEquals
     * @param intakeMedicalHistoryIdSpecified
     * @param intakeMedicalHistoryIdIn
     * @param intakeMedicalHistoryIdNotIn
     * @param distinct
     * @returns number OK
     * @throws ApiError
     */
    public static countIntakeForms(
        idGreaterThan?: number,
        idLessThan?: number,
        idGreaterThanOrEqual?: number,
        idLessThanOrEqual?: number,
        idEquals?: number,
        idNotEquals?: number,
        idSpecified?: boolean,
        idIn?: Array<number>,
        idNotIn?: Array<number>,
        uuidEquals?: string,
        uuidNotEquals?: string,
        uuidSpecified?: boolean,
        uuidIn?: Array<string>,
        uuidNotIn?: Array<string>,
        intakeFormNameContains?: string,
        intakeFormNameDoesNotContain?: string,
        intakeFormNameEquals?: string,
        intakeFormNameNotEquals?: string,
        intakeFormNameSpecified?: boolean,
        intakeFormNameIn?: Array<string>,
        intakeFormNameNotIn?: Array<string>,
        sendDateGreaterThan?: string,
        sendDateLessThan?: string,
        sendDateGreaterThanOrEqual?: string,
        sendDateLessThanOrEqual?: string,
        sendDateEquals?: string,
        sendDateNotEquals?: string,
        sendDateSpecified?: boolean,
        sendDateIn?: Array<string>,
        sendDateNotIn?: Array<string>,
        dueDateGreaterThan?: string,
        dueDateLessThan?: string,
        dueDateGreaterThanOrEqual?: string,
        dueDateLessThanOrEqual?: string,
        dueDateEquals?: string,
        dueDateNotEquals?: string,
        dueDateSpecified?: boolean,
        dueDateIn?: Array<string>,
        dueDateNotIn?: Array<string>,
        submittedDateGreaterThan?: string,
        submittedDateLessThan?: string,
        submittedDateGreaterThanOrEqual?: string,
        submittedDateLessThanOrEqual?: string,
        submittedDateEquals?: string,
        submittedDateNotEquals?: string,
        submittedDateSpecified?: boolean,
        submittedDateIn?: Array<string>,
        submittedDateNotIn?: Array<string>,
        statusEquals?: 'SEND' | 'FILLED' | 'COMPLETED',
        statusNotEquals?: 'SEND' | 'FILLED' | 'COMPLETED',
        statusSpecified?: boolean,
        statusIn?: Array<'SEND' | 'FILLED' | 'COMPLETED'>,
        statusNotIn?: Array<'SEND' | 'FILLED' | 'COMPLETED'>,
        filledByEquals?: 'PATIENT' | 'PROVIDER',
        filledByNotEquals?: 'PATIENT' | 'PROVIDER',
        filledBySpecified?: boolean,
        filledByIn?: Array<'PATIENT' | 'PROVIDER'>,
        filledByNotIn?: Array<'PATIENT' | 'PROVIDER'>,
        createdAtGreaterThan?: string,
        createdAtLessThan?: string,
        createdAtGreaterThanOrEqual?: string,
        createdAtLessThanOrEqual?: string,
        createdAtEquals?: string,
        createdAtNotEquals?: string,
        createdAtSpecified?: boolean,
        createdAtIn?: Array<string>,
        createdAtNotIn?: Array<string>,
        modifiedAtGreaterThan?: string,
        modifiedAtLessThan?: string,
        modifiedAtGreaterThanOrEqual?: string,
        modifiedAtLessThanOrEqual?: string,
        modifiedAtEquals?: string,
        modifiedAtNotEquals?: string,
        modifiedAtSpecified?: boolean,
        modifiedAtIn?: Array<string>,
        modifiedAtNotIn?: Array<string>,
        createdByContains?: string,
        createdByDoesNotContain?: string,
        createdByEquals?: string,
        createdByNotEquals?: string,
        createdBySpecified?: boolean,
        createdByIn?: Array<string>,
        createdByNotIn?: Array<string>,
        modifiedByContains?: string,
        modifiedByDoesNotContain?: string,
        modifiedByEquals?: string,
        modifiedByNotEquals?: string,
        modifiedBySpecified?: boolean,
        modifiedByIn?: Array<string>,
        modifiedByNotIn?: Array<string>,
        appointmentIdIdGreaterThan?: number,
        appointmentIdIdLessThan?: number,
        appointmentIdIdGreaterThanOrEqual?: number,
        appointmentIdIdLessThanOrEqual?: number,
        appointmentIdIdEquals?: number,
        appointmentIdIdNotEquals?: number,
        appointmentIdIdSpecified?: boolean,
        appointmentIdIdIn?: Array<number>,
        appointmentIdIdNotIn?: Array<number>,
        intakeSocialHistoryIdGreaterThan?: number,
        intakeSocialHistoryIdLessThan?: number,
        intakeSocialHistoryIdGreaterThanOrEqual?: number,
        intakeSocialHistoryIdLessThanOrEqual?: number,
        intakeSocialHistoryIdEquals?: number,
        intakeSocialHistoryIdNotEquals?: number,
        intakeSocialHistoryIdSpecified?: boolean,
        intakeSocialHistoryIdIn?: Array<number>,
        intakeSocialHistoryIdNotIn?: Array<number>,
        intakePatientFamilyHistoryIdGreaterThan?: number,
        intakePatientFamilyHistoryIdLessThan?: number,
        intakePatientFamilyHistoryIdGreaterThanOrEqual?: number,
        intakePatientFamilyHistoryIdLessThanOrEqual?: number,
        intakePatientFamilyHistoryIdEquals?: number,
        intakePatientFamilyHistoryIdNotEquals?: number,
        intakePatientFamilyHistoryIdSpecified?: boolean,
        intakePatientFamilyHistoryIdIn?: Array<number>,
        intakePatientFamilyHistoryIdNotIn?: Array<number>,
        intakeProblemIdGreaterThan?: number,
        intakeProblemIdLessThan?: number,
        intakeProblemIdGreaterThanOrEqual?: number,
        intakeProblemIdLessThanOrEqual?: number,
        intakeProblemIdEquals?: number,
        intakeProblemIdNotEquals?: number,
        intakeProblemIdSpecified?: boolean,
        intakeProblemIdIn?: Array<number>,
        intakeProblemIdNotIn?: Array<number>,
        intakeAllergyIdGreaterThan?: number,
        intakeAllergyIdLessThan?: number,
        intakeAllergyIdGreaterThanOrEqual?: number,
        intakeAllergyIdLessThanOrEqual?: number,
        intakeAllergyIdEquals?: number,
        intakeAllergyIdNotEquals?: number,
        intakeAllergyIdSpecified?: boolean,
        intakeAllergyIdIn?: Array<number>,
        intakeAllergyIdNotIn?: Array<number>,
        intakeMedicationIdGreaterThan?: number,
        intakeMedicationIdLessThan?: number,
        intakeMedicationIdGreaterThanOrEqual?: number,
        intakeMedicationIdLessThanOrEqual?: number,
        intakeMedicationIdEquals?: number,
        intakeMedicationIdNotEquals?: number,
        intakeMedicationIdSpecified?: boolean,
        intakeMedicationIdIn?: Array<number>,
        intakeMedicationIdNotIn?: Array<number>,
        intakeVaccineIdGreaterThan?: number,
        intakeVaccineIdLessThan?: number,
        intakeVaccineIdGreaterThanOrEqual?: number,
        intakeVaccineIdLessThanOrEqual?: number,
        intakeVaccineIdEquals?: number,
        intakeVaccineIdNotEquals?: number,
        intakeVaccineIdSpecified?: boolean,
        intakeVaccineIdIn?: Array<number>,
        intakeVaccineIdNotIn?: Array<number>,
        intakeMedicalHistoryIdGreaterThan?: number,
        intakeMedicalHistoryIdLessThan?: number,
        intakeMedicalHistoryIdGreaterThanOrEqual?: number,
        intakeMedicalHistoryIdLessThanOrEqual?: number,
        intakeMedicalHistoryIdEquals?: number,
        intakeMedicalHistoryIdNotEquals?: number,
        intakeMedicalHistoryIdSpecified?: boolean,
        intakeMedicalHistoryIdIn?: Array<number>,
        intakeMedicalHistoryIdNotIn?: Array<number>,
        distinct?: boolean,
    ): CancelablePromise<number> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/intake-forms/count',
            query: {
                'id.greaterThan': idGreaterThan,
                'id.lessThan': idLessThan,
                'id.greaterThanOrEqual': idGreaterThanOrEqual,
                'id.lessThanOrEqual': idLessThanOrEqual,
                'id.equals': idEquals,
                'id.notEquals': idNotEquals,
                'id.specified': idSpecified,
                'id.in': idIn,
                'id.notIn': idNotIn,
                'uuid.equals': uuidEquals,
                'uuid.notEquals': uuidNotEquals,
                'uuid.specified': uuidSpecified,
                'uuid.in': uuidIn,
                'uuid.notIn': uuidNotIn,
                'intakeFormName.contains': intakeFormNameContains,
                'intakeFormName.doesNotContain': intakeFormNameDoesNotContain,
                'intakeFormName.equals': intakeFormNameEquals,
                'intakeFormName.notEquals': intakeFormNameNotEquals,
                'intakeFormName.specified': intakeFormNameSpecified,
                'intakeFormName.in': intakeFormNameIn,
                'intakeFormName.notIn': intakeFormNameNotIn,
                'sendDate.greaterThan': sendDateGreaterThan,
                'sendDate.lessThan': sendDateLessThan,
                'sendDate.greaterThanOrEqual': sendDateGreaterThanOrEqual,
                'sendDate.lessThanOrEqual': sendDateLessThanOrEqual,
                'sendDate.equals': sendDateEquals,
                'sendDate.notEquals': sendDateNotEquals,
                'sendDate.specified': sendDateSpecified,
                'sendDate.in': sendDateIn,
                'sendDate.notIn': sendDateNotIn,
                'dueDate.greaterThan': dueDateGreaterThan,
                'dueDate.lessThan': dueDateLessThan,
                'dueDate.greaterThanOrEqual': dueDateGreaterThanOrEqual,
                'dueDate.lessThanOrEqual': dueDateLessThanOrEqual,
                'dueDate.equals': dueDateEquals,
                'dueDate.notEquals': dueDateNotEquals,
                'dueDate.specified': dueDateSpecified,
                'dueDate.in': dueDateIn,
                'dueDate.notIn': dueDateNotIn,
                'submittedDate.greaterThan': submittedDateGreaterThan,
                'submittedDate.lessThan': submittedDateLessThan,
                'submittedDate.greaterThanOrEqual': submittedDateGreaterThanOrEqual,
                'submittedDate.lessThanOrEqual': submittedDateLessThanOrEqual,
                'submittedDate.equals': submittedDateEquals,
                'submittedDate.notEquals': submittedDateNotEquals,
                'submittedDate.specified': submittedDateSpecified,
                'submittedDate.in': submittedDateIn,
                'submittedDate.notIn': submittedDateNotIn,
                'status.equals': statusEquals,
                'status.notEquals': statusNotEquals,
                'status.specified': statusSpecified,
                'status.in': statusIn,
                'status.notIn': statusNotIn,
                'filledBy.equals': filledByEquals,
                'filledBy.notEquals': filledByNotEquals,
                'filledBy.specified': filledBySpecified,
                'filledBy.in': filledByIn,
                'filledBy.notIn': filledByNotIn,
                'createdAt.greaterThan': createdAtGreaterThan,
                'createdAt.lessThan': createdAtLessThan,
                'createdAt.greaterThanOrEqual': createdAtGreaterThanOrEqual,
                'createdAt.lessThanOrEqual': createdAtLessThanOrEqual,
                'createdAt.equals': createdAtEquals,
                'createdAt.notEquals': createdAtNotEquals,
                'createdAt.specified': createdAtSpecified,
                'createdAt.in': createdAtIn,
                'createdAt.notIn': createdAtNotIn,
                'modifiedAt.greaterThan': modifiedAtGreaterThan,
                'modifiedAt.lessThan': modifiedAtLessThan,
                'modifiedAt.greaterThanOrEqual': modifiedAtGreaterThanOrEqual,
                'modifiedAt.lessThanOrEqual': modifiedAtLessThanOrEqual,
                'modifiedAt.equals': modifiedAtEquals,
                'modifiedAt.notEquals': modifiedAtNotEquals,
                'modifiedAt.specified': modifiedAtSpecified,
                'modifiedAt.in': modifiedAtIn,
                'modifiedAt.notIn': modifiedAtNotIn,
                'createdBy.contains': createdByContains,
                'createdBy.doesNotContain': createdByDoesNotContain,
                'createdBy.equals': createdByEquals,
                'createdBy.notEquals': createdByNotEquals,
                'createdBy.specified': createdBySpecified,
                'createdBy.in': createdByIn,
                'createdBy.notIn': createdByNotIn,
                'modifiedBy.contains': modifiedByContains,
                'modifiedBy.doesNotContain': modifiedByDoesNotContain,
                'modifiedBy.equals': modifiedByEquals,
                'modifiedBy.notEquals': modifiedByNotEquals,
                'modifiedBy.specified': modifiedBySpecified,
                'modifiedBy.in': modifiedByIn,
                'modifiedBy.notIn': modifiedByNotIn,
                'appointmentIdId.greaterThan': appointmentIdIdGreaterThan,
                'appointmentIdId.lessThan': appointmentIdIdLessThan,
                'appointmentIdId.greaterThanOrEqual': appointmentIdIdGreaterThanOrEqual,
                'appointmentIdId.lessThanOrEqual': appointmentIdIdLessThanOrEqual,
                'appointmentIdId.equals': appointmentIdIdEquals,
                'appointmentIdId.notEquals': appointmentIdIdNotEquals,
                'appointmentIdId.specified': appointmentIdIdSpecified,
                'appointmentIdId.in': appointmentIdIdIn,
                'appointmentIdId.notIn': appointmentIdIdNotIn,
                'intakeSocialHistoryId.greaterThan': intakeSocialHistoryIdGreaterThan,
                'intakeSocialHistoryId.lessThan': intakeSocialHistoryIdLessThan,
                'intakeSocialHistoryId.greaterThanOrEqual': intakeSocialHistoryIdGreaterThanOrEqual,
                'intakeSocialHistoryId.lessThanOrEqual': intakeSocialHistoryIdLessThanOrEqual,
                'intakeSocialHistoryId.equals': intakeSocialHistoryIdEquals,
                'intakeSocialHistoryId.notEquals': intakeSocialHistoryIdNotEquals,
                'intakeSocialHistoryId.specified': intakeSocialHistoryIdSpecified,
                'intakeSocialHistoryId.in': intakeSocialHistoryIdIn,
                'intakeSocialHistoryId.notIn': intakeSocialHistoryIdNotIn,
                'intakePatientFamilyHistoryId.greaterThan': intakePatientFamilyHistoryIdGreaterThan,
                'intakePatientFamilyHistoryId.lessThan': intakePatientFamilyHistoryIdLessThan,
                'intakePatientFamilyHistoryId.greaterThanOrEqual': intakePatientFamilyHistoryIdGreaterThanOrEqual,
                'intakePatientFamilyHistoryId.lessThanOrEqual': intakePatientFamilyHistoryIdLessThanOrEqual,
                'intakePatientFamilyHistoryId.equals': intakePatientFamilyHistoryIdEquals,
                'intakePatientFamilyHistoryId.notEquals': intakePatientFamilyHistoryIdNotEquals,
                'intakePatientFamilyHistoryId.specified': intakePatientFamilyHistoryIdSpecified,
                'intakePatientFamilyHistoryId.in': intakePatientFamilyHistoryIdIn,
                'intakePatientFamilyHistoryId.notIn': intakePatientFamilyHistoryIdNotIn,
                'intakeProblemId.greaterThan': intakeProblemIdGreaterThan,
                'intakeProblemId.lessThan': intakeProblemIdLessThan,
                'intakeProblemId.greaterThanOrEqual': intakeProblemIdGreaterThanOrEqual,
                'intakeProblemId.lessThanOrEqual': intakeProblemIdLessThanOrEqual,
                'intakeProblemId.equals': intakeProblemIdEquals,
                'intakeProblemId.notEquals': intakeProblemIdNotEquals,
                'intakeProblemId.specified': intakeProblemIdSpecified,
                'intakeProblemId.in': intakeProblemIdIn,
                'intakeProblemId.notIn': intakeProblemIdNotIn,
                'intakeAllergyId.greaterThan': intakeAllergyIdGreaterThan,
                'intakeAllergyId.lessThan': intakeAllergyIdLessThan,
                'intakeAllergyId.greaterThanOrEqual': intakeAllergyIdGreaterThanOrEqual,
                'intakeAllergyId.lessThanOrEqual': intakeAllergyIdLessThanOrEqual,
                'intakeAllergyId.equals': intakeAllergyIdEquals,
                'intakeAllergyId.notEquals': intakeAllergyIdNotEquals,
                'intakeAllergyId.specified': intakeAllergyIdSpecified,
                'intakeAllergyId.in': intakeAllergyIdIn,
                'intakeAllergyId.notIn': intakeAllergyIdNotIn,
                'intakeMedicationId.greaterThan': intakeMedicationIdGreaterThan,
                'intakeMedicationId.lessThan': intakeMedicationIdLessThan,
                'intakeMedicationId.greaterThanOrEqual': intakeMedicationIdGreaterThanOrEqual,
                'intakeMedicationId.lessThanOrEqual': intakeMedicationIdLessThanOrEqual,
                'intakeMedicationId.equals': intakeMedicationIdEquals,
                'intakeMedicationId.notEquals': intakeMedicationIdNotEquals,
                'intakeMedicationId.specified': intakeMedicationIdSpecified,
                'intakeMedicationId.in': intakeMedicationIdIn,
                'intakeMedicationId.notIn': intakeMedicationIdNotIn,
                'intakeVaccineId.greaterThan': intakeVaccineIdGreaterThan,
                'intakeVaccineId.lessThan': intakeVaccineIdLessThan,
                'intakeVaccineId.greaterThanOrEqual': intakeVaccineIdGreaterThanOrEqual,
                'intakeVaccineId.lessThanOrEqual': intakeVaccineIdLessThanOrEqual,
                'intakeVaccineId.equals': intakeVaccineIdEquals,
                'intakeVaccineId.notEquals': intakeVaccineIdNotEquals,
                'intakeVaccineId.specified': intakeVaccineIdSpecified,
                'intakeVaccineId.in': intakeVaccineIdIn,
                'intakeVaccineId.notIn': intakeVaccineIdNotIn,
                'intakeMedicalHistoryId.greaterThan': intakeMedicalHistoryIdGreaterThan,
                'intakeMedicalHistoryId.lessThan': intakeMedicalHistoryIdLessThan,
                'intakeMedicalHistoryId.greaterThanOrEqual': intakeMedicalHistoryIdGreaterThanOrEqual,
                'intakeMedicalHistoryId.lessThanOrEqual': intakeMedicalHistoryIdLessThanOrEqual,
                'intakeMedicalHistoryId.equals': intakeMedicalHistoryIdEquals,
                'intakeMedicalHistoryId.notEquals': intakeMedicalHistoryIdNotEquals,
                'intakeMedicalHistoryId.specified': intakeMedicalHistoryIdSpecified,
                'intakeMedicalHistoryId.in': intakeMedicalHistoryIdIn,
                'intakeMedicalHistoryId.notIn': intakeMedicalHistoryIdNotIn,
                'distinct': distinct,
            },
        });
    }

}
